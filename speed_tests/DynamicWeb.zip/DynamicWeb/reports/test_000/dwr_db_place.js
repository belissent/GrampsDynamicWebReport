// This file is generated

// 'P' is sorted by place name
// 'P' gives for each media object:
//   - gid: Gramps ID
//   - name: The place long name
//   - names: list of place names in the form {name, date, date_sdn} (empty for version 4.0 and below)
//   - type: The place type ('' for version 4.0 and below)
//   - locations: The place locations parts for the main and alternate names (empty for version 4.1 and above), in the form:
//         [{
//         type: type as a string ('street', 'locality', 'parish', 'city', 'state', 'county', etc.)
//         name: name as a string
//         }]
//   - enclosed_by: List of places enclosing this place (empty for version 4.0 and below), in the form:
//         {
//         pdx: place index (in table 'P')
//         date, date_sdn
//         }
//   - coords: The coordinates [latitude, longitude]
//   - code: The place code
//   - note: The place notes
//   - media: A list of the place media references, in the form:
//       - m_idx: media index (in table 'M')
//       - thumb: media thumbnail path
//       - rect: [x1, y1, x2, y2] of the media reference
//       - note: notes of the media reference
//       - cita: list of the media reference source citations index (in table 'C')
//   - cita: A list of the place source citations index (in table 'C')
//   - urls: The list of the place URL in the form:
//       [type, url, description]
//   - bki: A list of the person index (in table 'I') for events referencing this place
//     (including the persons directly referencing this place)
//   - bkf: A list of the family index (in table 'F') for events referencing this place
//   - bkp: A list of the places index (in table 'P') for places enclosed by this place (empty for version 4.0 and below)
//   - change_time: last record modification date
P = [
    {
        "bkf": [],
        "bki": [
            4
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:30",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 34
            }
        ],
        "gid": "P1131",
        "locations": [],
        "media": [],
        "name": "Aberdeen, WA, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Aberdeen"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            5
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:30",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 18
            }
        ],
        "gid": "P1398",
        "locations": [],
        "media": [],
        "name": "Albuquerque, NM, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Albuquerque"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            6
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0036",
        "locations": [],
        "media": [],
        "name": "AR, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "AR"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            0
        ],
        "bkp": [],
        "change_time": "2009-02-11 23:17:29",
        "cita": [],
        "code": "",
        "coords": [
            "30.79102040",
            "-89.84868580"
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 35
            }
        ],
        "gid": "P1132",
        "locations": [],
        "media": [],
        "name": "Bogalusa, Washington, LA, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Bogalusa"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            22
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0003",
        "locations": [],
        "media": [],
        "name": "FL, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "FL"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 16
            }
        ],
        "gid": "P1435",
        "locations": [],
        "media": [],
        "name": "Great Falls, MT, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Great Falls"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            24
        ],
        "change_time": "2013-11-09 09:47:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 2
            }
        ],
        "gid": "P0266",
        "locations": [],
        "media": [],
        "name": "Greene, AR, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Greene"
            }
        ],
        "note": "",
        "type": "County",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            30
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0070",
        "locations": [],
        "media": [],
        "name": "ID, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "ID"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            12
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0039",
        "locations": [],
        "media": [],
        "name": "IN, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "IN"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            1
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 19
            }
        ],
        "gid": "P1106",
        "locations": [],
        "media": [],
        "name": "Jamestowna, NY, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Jamestowna"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            4
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:33",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 29
            }
        ],
        "gid": "P1494",
        "locations": [],
        "media": [],
        "name": "Knoxville, TN, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Knoxville"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            35
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0062",
        "locations": [],
        "media": [],
        "name": "LA, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "LA"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            14
        ],
        "change_time": "2013-11-09 09:47:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 8
            }
        ],
        "gid": "P0316",
        "locations": [],
        "media": [],
        "name": "LaPorte, IN, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "LaPorte"
            }
        ],
        "note": "",
        "type": "County",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            1
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:33",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 33
            }
        ],
        "gid": "P1424",
        "locations": [],
        "media": [],
        "name": "Logan, UT-ID, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Logan"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            5
        ],
        "bkp": [],
        "change_time": "2009-02-11 23:16:29",
        "cita": [],
        "code": "",
        "coords": [
            "41.70753940",
            "-86.89502970"
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 12
            }
        ],
        "gid": "P1623",
        "locations": [],
        "media": [],
        "name": "Michigan City, LaPorte, IN, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Michigan City"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            25
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0041",
        "locations": [],
        "media": [],
        "name": "MS, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "MS"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            5
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0066",
        "locations": [],
        "media": [],
        "name": "MT, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "MT"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            36
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0044",
        "locations": [],
        "media": [],
        "name": "NC, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "NC"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            1
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0042",
        "locations": [],
        "media": [],
        "name": "NM, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "NM"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            9
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0057",
        "locations": [],
        "media": [],
        "name": "NY, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "NY"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            26,
            28
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0000",
        "locations": [],
        "media": [],
        "name": "OH, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "OH"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            27
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0023",
        "locations": [],
        "media": [],
        "name": "OK, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "OK"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            23
        ],
        "change_time": "2013-11-09 09:47:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 4
            }
        ],
        "gid": "P0353",
        "locations": [],
        "media": [],
        "name": "Orange, FL, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Orange"
            }
        ],
        "note": "",
        "type": "County",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            6
        ],
        "bkp": [],
        "change_time": "2009-02-11 23:13:44",
        "cita": [],
        "code": "",
        "coords": [
            "28.53833550",
            "-81.37923650"
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 22
            }
        ],
        "gid": "P1129",
        "locations": [],
        "media": [],
        "name": "Orlando, Orange, FL, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Orlando"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [
            2
        ],
        "bki": [],
        "bkp": [],
        "change_time": "2009-02-11 23:08:30",
        "cita": [],
        "code": "",
        "coords": [
            "36.05840210",
            "-90.49732860"
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 6
            }
        ],
        "gid": "P1498",
        "locations": [],
        "media": [],
        "name": "Paragould, Greene, AR, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Paragould"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [
            0
        ],
        "bki": [],
        "bkp": [],
        "change_time": "2009-02-11 18:29:34",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 15
            }
        ],
        "gid": "P1691",
        "locations": [],
        "media": [],
        "name": "Picayune, MS, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Picayune"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            4
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:34",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 20
            }
        ],
        "gid": "P1388",
        "locations": [],
        "media": [],
        "name": "Portsmouth, OH, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Portsmouth"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            2
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:34",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 21
            }
        ],
        "gid": "P1539",
        "locations": [],
        "media": [],
        "name": "Shawnee, OK, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Shawnee"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            2
        ],
        "bkp": [],
        "change_time": "2009-02-11 18:29:34",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 20
            }
        ],
        "gid": "P1350",
        "locations": [],
        "media": [],
        "name": "Steubenville, OH, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Steubenville"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            10
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0029",
        "locations": [],
        "media": [],
        "name": "TN, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "TN"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            31
        ],
        "change_time": "2013-11-09 09:47:32",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 7
            }
        ],
        "gid": "P0409",
        "locations": [],
        "media": [],
        "name": "Twin Falls, ID, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Twin Falls"
            }
        ],
        "note": "",
        "type": "County",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkp": [],
        "change_time": "2012-01-31 17:29:52",
        "cita": [
            37
        ],
        "code": "",
        "coords": [
            "42.56296680",
            "-114.46087110"
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 30
            }
        ],
        "gid": "P1678",
        "locations": [],
        "media": [
            {
                "cita": [
                    38,
                    39
                ],
                "m_idx": 1,
                "note": "<div>\n<p>\n<b>Nickname</b>: Fred\n</p>\n</div>",
                "rect": [
                    0,
                    0,
                    100,
                    100
                ],
                "thumb": "thumb/238CGQ939HG18SS5MG.png"
            }
        ],
        "name": "Twin Falls, Twin Falls, ID, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Twin Falls"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            2,
            4,
            7,
            8,
            11,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            29,
            33,
            34
        ],
        "change_time": "2009-02-11 18:29:34",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [],
        "gid": "P0957",
        "locations": [],
        "media": [],
        "name": "USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "USA"
            }
        ],
        "note": "",
        "type": "Country",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            13
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0163",
        "locations": [],
        "media": [],
        "name": "UT-ID, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "UT-ID"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            0
        ],
        "change_time": "2013-11-09 09:47:31",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 32
            }
        ],
        "gid": "P0022",
        "locations": [],
        "media": [],
        "name": "WA, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "WA"
            }
        ],
        "note": "",
        "type": "State",
        "urls": []
    },
    {
        "bkf": [],
        "bki": [],
        "bkp": [
            3
        ],
        "change_time": "2016-06-18 00:05:03",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 11
            }
        ],
        "gid": "P0433",
        "locations": [],
        "media": [],
        "name": "Washington, LA, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Washington"
            }
        ],
        "note": "",
        "type": "Parish",
        "urls": []
    },
    {
        "bkf": [
            3
        ],
        "bki": [],
        "bkp": [],
        "change_time": "2009-02-11 18:29:35",
        "cita": [],
        "code": "",
        "coords": [
            "",
            ""
        ],
        "enclosed_by": [
            {
                "date": "",
                "date_sdn": 0,
                "pdx": 17
            }
        ],
        "gid": "P1202",
        "locations": [],
        "media": [],
        "name": "Winston-Salem, NC, USA",
        "names": [
            {
                "date": "",
                "date_sdn": 0,
                "name": "Winston-Salem"
            }
        ],
        "note": "",
        "type": "City",
        "urls": []
    }
]