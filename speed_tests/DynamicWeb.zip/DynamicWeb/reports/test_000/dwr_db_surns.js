// This file is generated

// 'SN' is sorted by surname
// 'SN' gives for each surname:
//  - surname: the surname
//  - letter: the surname first letter
//  - persons: the list of persion index (in table 'I') with this surname

SN = [
    {
        "letter": "D",
        "persons": [
            0
        ],
        "surname": "Daniels"
    },
    {
        "letter": "E",
        "persons": [
            1
        ],
        "surname": "Edwards"
    },
    {
        "letter": "G",
        "persons": [
            2,
            3,
            4
        ],
        "surname": "Garner"
    },
    {
        "letter": "Z",
        "persons": [
            5
        ],
        "surname": "Zieli\u0144ski"
    },
    {
        "letter": "\u0428",
        "persons": [
            6
        ],
        "surname": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432"
    }
]