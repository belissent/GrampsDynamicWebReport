// This file is generated

// 'I' is sorted by person name
// 'I' gives for individual:
//   - gid: Gramps ID
//   - name: The complete name
//   - short_name: The short name
//   - names: The names as a list of:
//       [full name, type, title, nick, call, given, suffix, list of surnames, family nickname,
//        notes, list of the name source citations index (in table 'C')]
//   - gender: The gender
//   - birth_year: The birth year in the form '1700', '?' (date unknown)
//   - birth_sdn: The birth serial date number (0 if not known)
//   - birth_place: The birth place
//   - death_year: The death year in the form '1700', '?' (date unknown), '' (not dead)
//   - death_sdn: The death serial date number (0 if not known)
//   - death_place: The death place
//   - death_age: The death age
//   - events: A list of events, with for each event:
//       - gid: The event GID
//       - type: The event name
//       - date: The event date
//       - date_sdn: The event serial date number
//       - place: The event place index (in table 'P'), -1 if none
//       - descr: The event description
//       - text: The event text and notes (including event reference notes)
//       - media: A list of the event media index, in the form:
//           - m_idx: media index (in table 'M')
//           - thumb: media thumbnail path
//           - rect: [x1, y1, x2, y2] of the media reference
//           - note: notes of the media reference
//           - cita: list of the media reference source citations index (in table 'C')
//       - cita: A list of the event source citations index (in table 'C')
//   - addrs: A list of addresses, with for each address:
//       - date: The address date
//       - date_sdn: The address serial date number
//       - location: The address place in the form:
//           [street, locality, parish, city, state, county, zip, country]
//       - note: The address notes
//       - cita: A list of the address source citations index (in table 'C')
//   - note: The person notes
//   - media: A list of the person media references, in the form:
//       - m_idx: media index (in table 'M')
//       - thumb: media thumbnail path
//       - rect: [x1, y1, x2, y2] of the media reference
//       - note: notes of the media reference
//       - cita: list of the media reference source citations index (in table 'C')
//   - note: A list of the person source citations index (in table 'C')
//   - media: The list of the person attributes in the form:
//       [attribute, value, note, list of citations]
//   - urls: The list of the person URL in the form:
//       [type, url, description]
//   - fams: A list of partners families index (in table 'F')
//   - famc: A list of parents families in the form:
//       [index (in table 'F'), relation to father, relation to mother, notes, list of citations]
//   - assoc: A list of associations in the form:
//       [person index (in table 'I'), relationship, notes, list of citations (in table 'C')]
//   - change_time: last record modification date
I = [
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Bogalusa, Washington, LA, USA",
        "birth_sdn": 0,
        "birth_year": "?",
        "change_time": "2007-07-26 10:34:25",
        "cita": [
            8
        ],
        "death_age": "",
        "death_place": "",
        "death_sdn": 0,
        "death_year": "",
        "events": [
            {
                "cita": [],
                "date": "",
                "date_sdn": 0,
                "descr": "Birth of Daniels, Phoebe",
                "gid": "E2682",
                "media": [],
                "part_family": [],
                "part_person": [
                    0
                ],
                "place": 3,
                "text": "",
                "type": "Birth"
            }
        ],
        "famc": [],
        "fams": [
            4
        ],
        "gender": "F",
        "gid": "I0973",
        "media": [],
        "name": "Daniels, Phoebe",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Daniels, Phoebe",
                "given": "Phoebe",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Daniels"
                ],
                "title": "",
                "type": "Birth Name"
            }
        ],
        "note": "",
        "short_name": "Daniels, Phoebe",
        "urls": []
    },
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Jamestowna, NY, USA",
        "birth_sdn": 2378148,
        "birth_year": "1799",
        "change_time": "2007-07-26 10:34:25",
        "cita": [
            2
        ],
        "death_age": "80 years, 2 months, 16 days",
        "death_place": "",
        "death_sdn": 2407442,
        "death_year": "1879",
        "events": [
            {
                "cita": [],
                "date": "1799-01-17",
                "date_sdn": 2378148,
                "descr": "Birth of Edwards, Lucy",
                "gid": "E0090",
                "media": [],
                "part_family": [],
                "part_person": [
                    1
                ],
                "place": 9,
                "text": "",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "1879-04-02",
                "date_sdn": 2407442,
                "descr": "Death of Edwards, Lucy",
                "gid": "E0091",
                "media": [],
                "part_family": [],
                "part_person": [
                    1
                ],
                "place": -1,
                "text": "",
                "type": "Death"
            },
            {
                "cita": [],
                "date": "1879-04-04",
                "date_sdn": 2407444,
                "descr": "Burial of Edwards, Lucy",
                "gid": "E0092",
                "media": [],
                "part_family": [],
                "part_person": [
                    1
                ],
                "place": 13,
                "text": "",
                "type": "Burial"
            }
        ],
        "famc": [],
        "fams": [
            0,
            3
        ],
        "gender": "F",
        "gid": "I0105",
        "media": [],
        "name": "Edwards, Lucy",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Edwards, Lucy",
                "given": "Lucy",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Edwards"
                ],
                "title": "",
                "type": "Birth Name"
            }
        ],
        "note": "",
        "short_name": "Edwards, Lucy",
        "urls": []
    },
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Steubenville, OH, USA",
        "birth_sdn": 2375575,
        "birth_year": "1792",
        "change_time": "2007-07-26 10:34:25",
        "cita": [
            4
        ],
        "death_age": "unknown",
        "death_place": "Shawnee, OK, USA",
        "death_sdn": 0,
        "death_year": "?",
        "events": [
            {
                "cita": [],
                "date": "1792",
                "date_sdn": 2375575,
                "descr": "Birth of Garner, Joseph",
                "gid": "E0076",
                "media": [],
                "part_family": [],
                "part_person": [
                    2
                ],
                "place": 28,
                "text": "",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "",
                "date_sdn": 0,
                "descr": "Death of Garner, Joseph",
                "gid": "E0077",
                "media": [],
                "part_family": [],
                "part_person": [
                    2
                ],
                "place": 27,
                "text": "",
                "type": "Death"
            }
        ],
        "famc": [],
        "fams": [
            0
        ],
        "gender": "M",
        "gid": "I0104",
        "media": [],
        "name": "Garner, Joseph",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Garner, Joseph",
                "given": "Joseph",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Garner"
                ],
                "title": "",
                "type": "Birth Name"
            }
        ],
        "note": "",
        "short_name": "Garner, Joseph",
        "urls": []
    },
    {
        "addrs": [
            {
                "cita": [
                    16
                ],
                "date": "2000-01-02",
                "date_sdn": 2451546,
                "location": [
                    "1600 Pennsylvania Ave.",
                    "",
                    "",
                    "Washington DC",
                    "District of Columbia",
                    "",
                    "",
                    "USA",
                    ""
                ],
                "note": ""
            }
        ],
        "assoc": [],
        "attr": [
            {
                "cita": [],
                "note": "",
                "type": "Nickname",
                "value": "Big Louie"
            },
            {
                "cita": [
                    17
                ],
                "note": "",
                "type": "Social Security Number",
                "value": "123-456-7890"
            },
            {
                "cita": [],
                "note": "",
                "type": "Description",
                "value": "10 fingers, 10 toes."
            }
        ],
        "birth_place": "Great Falls, MT, USA",
        "birth_sdn": 2398756,
        "birth_year": "1855",
        "change_time": "2015-05-09 14:35:04",
        "cita": [
            5,
            6,
            14
        ],
        "death_age": "56 years, 7 days",
        "death_place": "Twin Falls, Twin Falls, ID, USA",
        "death_sdn": 2419216,
        "death_year": "1911",
        "events": [
            {
                "cita": [
                    0,
                    22,
                    31,
                    32
                ],
                "date": "1855-06-21",
                "date_sdn": 2398756,
                "descr": "Birth of Garner, Lewis Anderson",
                "gid": "E1656",
                "media": [
                    {
                        "cita": [
                            33,
                            34
                        ],
                        "m_idx": 0,
                        "note": "<div>\n<p>\n<b>Father's Age</b>: 25\n</p>\n</div>",
                        "rect": [
                            0,
                            0,
                            100,
                            100
                        ],
                        "thumb": "thumb/b39fe1cfc1305ac4a21.png"
                    }
                ],
                "part_family": [],
                "part_person": [
                    3
                ],
                "place": 5,
                "text": "<div>\n<p>\n<b>Time</b>: 10:00 pm\n</p>\n<p>\n<b>Father's Age</b>: 28\n</p>\n</div>",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "1911-06-28",
                "date_sdn": 2419216,
                "descr": "Death of Garner, Lewis Anderson",
                "gid": "E1657",
                "media": [],
                "part_family": [],
                "part_person": [
                    3
                ],
                "place": 31,
                "text": "<div>\n<i class=\"NoteType\">\nEvent Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\n<span style=\"text-decoration:underline;\">How</span> did he die? <span style=\"color:#ff0909;\"></span><span style=\"font-size:14px;\"><span style=\"color:#ff0909;\">We need to find out!</span></span><span style=\"color:#ff0909;\"></span>\n</p>\n<p>\nPerhaps we find info in <strong></strong><span style=\"background-color:#fbd50a;\"><strong>the new york</strong></span><strong></strong> library\n</p>\n</div>\n<p>\n<b>Cause</b>: Laughter\n</p>\n</div>",
                "type": "Death"
            },
            {
                "cita": [],
                "date": "1911-07-01",
                "date_sdn": 2419219,
                "descr": "Burial of Garner, Lewis Anderson",
                "gid": "E1658",
                "media": [],
                "part_family": [],
                "part_person": [
                    3
                ],
                "place": 31,
                "text": "",
                "type": "Burial"
            }
        ],
        "famc": [
            {
                "cita": [],
                "index": 2,
                "note": "",
                "to_father": "Custom relationship to father",
                "to_mother": "Custom relationship to mother"
            }
        ],
        "fams": [
            1
        ],
        "gender": "M",
        "gid": "I0044",
        "media": [
            {
                "cita": [],
                "m_idx": 1,
                "note": "",
                "rect": [
                    51,
                    19,
                    59,
                    33
                ],
                "thumb": "thumb/238CGQ939HG18SS5MG-51,19-59,33.png"
            },
            {
                "cita": [
                    19,
                    20
                ],
                "m_idx": 2,
                "note": "<div>\n<p>\n<b>Age</b>: 50\n</p>\n</div>",
                "rect": [
                    0,
                    0,
                    100,
                    100
                ],
                "thumb": "thumb/B1AUFQV7H8R9NR4SZM.png"
            }
        ],
        "name": "Garner von Zieli\u0144ski, Lewis Anderson Sr",
        "names": [
            {
                "call": "Anderson",
                "cita": [
                    15
                ],
                "date": "1875-04-01",
                "fam_nick": "Beauregard",
                "full": "Garner von Zieli\u0144ski, Lewis Anderson Sr",
                "given": "Lewis Anderson",
                "nick": "Big Louie",
                "note": "",
                "suffix": "Sr",
                "surnames": [
                    "Garner",
                    "Zieli\u0144ski"
                ],
                "title": "Dr.",
                "type": "Birth Name"
            },
            {
                "call": "",
                "cita": [
                    24
                ],
                "date": "",
                "fam_nick": "",
                "full": "Garner, Louis",
                "given": "Louis",
                "nick": "",
                "note": "<div>\n<i class=\"NoteType\">\nName Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nNames can notes, too. This is a note for the alternate name of Louse Garner for <a href=\"person.html?idx=3\">Lewis Anderson Garner</a>.\n</p>\n</div>\n</div>",
                "suffix": "",
                "surnames": [
                    "Garner"
                ],
                "title": "",
                "type": "Also Known As"
            },
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Garner, Louie",
                "given": "Louie",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Garner"
                ],
                "title": "",
                "type": "Other Name"
            }
        ],
        "note": "<div>\n<i class=\"NoteType\">\nPerson Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nWe have committed to synergistically disseminate resource-leveling methods of empowerment to set us apart from the competition. We envision to globally integrate inexpensive paradigms and professionally engineer timely technology while promoting personal employee growth. Our mission is to assertively build world-class methods of empowerment so that we may professionally promote parallel services to set us apart from the competition. It's our responsibility to dramatically maintain value-added services as well as to professionally simplify principle-centered technology for 100% customer satisfaction.\n</p>\n<p>\nThanks to the Mission Statement Generator from http://www.dilbert.com.\n</p>\n</div>\n<i class=\"NoteType\">\nPerson Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nThis is<strong> a note </strong><span style=\"font-size:18px;\"><strong></strong></span><span style=\"font-family:'Bitstream Vera Sans Mono';\"><span style=\"font-size:18px;\"><strong>showing a lot of differen</strong></span></span><span style=\"font-size:18px;\"><strong></strong></span><strong>t markup that mixes with each other making it a good str</strong><span style=\"text-decoration:underline;\"><strong>ess test for </strong></span><span style=\"text-decoration:underline;\">mar</span>kup notes.<br />\nThis is a note showing a lot of different markup that mixes with each other making it a good stress<span style=\"color:#e611bf;\"> test for markup notes.</span>\n</p>\n<p>\n<span style=\"color:#e611bf;\">This is</span><span style=\"background-color:#f29103;\"><span style=\"color:#e611bf;\"> a no</span></span><span style=\"background-color:#f29103;\">te showing</span> a lot of different<em> markup that </em><strong><em>mixes</em></strong><strong> with</strong> each <span style=\"text-decoration:underline;\">other </span>making it a good stress test for markup notes.\n</p>\n</div>\n<i class=\"NoteType\">\nPerson Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nThis is <strong>a </strong><span style=\"font-size:13px;\"><strong>preformatted</strong></span><strong> note showing a lot</strong> of differe<span style=\"font-size:13px;\"></span><span style=\"font-family:'Bitstream Vera Sans Mono';\"><span style=\"font-size:13px;\">nt markup that mixes with e</span></span><span style=\"font-size:13px;\"></span>ach other making it a good stress test for markup notes.<br />\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; This is a note<span style=\"color:#f61a1a;\"> </span><span style=\"background-color:#73980c;\"><span style=\"color:#f61a1a;\">showing a lot o</span></span><span style=\"background-color:#73980c;\">f</span> different markup that mixes with each other making it a good stress test for markup notes.\n</p>\n<p>\nThis is<br />\n&nbsp; &nbsp; &nbsp; &nbsp; a note showing<br />\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;a lot of different markup<br />\n&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; that mixes with each<br />\nother making it a good stress test for markup notes.\n</p>\n<p>\n<span style=\"font-family:'Bitstream Vera Sans Mono';\">&nbsp; &nbsp;test &nbsp;| &nbsp; &nbsp;val1 &nbsp;| &nbsp; &nbsp; val2</span><br />\n<span style=\"font-family:'Bitstream Vera Sans Mono';\">&nbsp; ------------------------------</span><br />\n<span style=\"font-family:'Bitstream Vera Sans Mono';\">&nbsp; &nbsp; me &nbsp; | &nbsp; blue &nbsp; | &nbsp; &nbsp;red</span>\n</p>\n</div>\n<i class=\"NoteType\">\nGeneral\n</i>\n<div class=\"grampsstylednote\">\n<p>\n<span style=\"font-size:12px;\"></span><span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">This source has all possible references pointing to it. The references are as follows:</span></span>\n</p>\n<p>\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">This note appears as a note to the source and also as a note for the person.</span></span>\n</p>\n<p>\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 01 &nbsp;Person</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 02 &nbsp; &nbsp;Name</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 03 &nbsp; &nbsp;Address</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 04 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 05 &nbsp; &nbsp;PersonRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 06 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 07 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 08 &nbsp; &nbsp;LdsOrd</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 09 &nbsp; &nbsp;EventRef:Attribute </span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 10 &nbsp;Family</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 11 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 12 &nbsp; &nbsp;ChildRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 13 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 14 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 15 &nbsp; &nbsp;LdsOrd</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 16 &nbsp; &nbsp;EventRef:Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 17 &nbsp;Event</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 18 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 19 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 20 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 21 &nbsp;MediaObject</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 22 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 23 &nbsp;Place</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 24 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 25 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 26 &nbsp;Repository:Address</span></span><span style=\"font-size:12px;\"></span>\n</p>\n</div>\n</div>",
        "short_name": "Garner von Zieli\u0144ski, Lewis Anderson Sr",
        "urls": [
            {
                "descr": "",
                "type": "Web Home",
                "uri": "http://www.gramps-project.org/"
            }
        ]
    },
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Aberdeen, WA, USA",
        "birth_sdn": 2388483,
        "birth_year": "1827",
        "change_time": "2010-09-09 13:00:51",
        "cita": [
            1
        ],
        "death_age": "88 years, 8 months, 28 days",
        "death_place": "Portsmouth, OH, USA",
        "death_sdn": 2420897,
        "death_year": "1916",
        "events": [
            {
                "cita": [],
                "date": "1826/7-04-24 (Julian)",
                "date_sdn": 2388483,
                "descr": "Birth of Garner, Robert W.",
                "gid": "E0105",
                "media": [],
                "part_family": [],
                "part_person": [
                    4
                ],
                "place": 0,
                "text": "",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "1916-02-03",
                "date_sdn": 2420897,
                "descr": "Death of Garner, Robert W.",
                "gid": "E0106",
                "media": [],
                "part_family": [],
                "part_person": [
                    4
                ],
                "place": 26,
                "text": "",
                "type": "Death"
            },
            {
                "cita": [],
                "date": "1916-02-05 (Mar25)",
                "date_sdn": 2420899,
                "descr": "Burial of Garner, Robert W.",
                "gid": "E0107",
                "media": [],
                "part_family": [],
                "part_person": [
                    4
                ],
                "place": 10,
                "text": "",
                "type": "Burial"
            }
        ],
        "famc": [
            {
                "cita": [],
                "index": 0,
                "note": "",
                "to_father": "Birth",
                "to_mother": "Birth"
            }
        ],
        "fams": [
            2
        ],
        "gender": "M",
        "gid": "I0106",
        "media": [],
        "name": "Garner, Robert W.",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Garner, Robert W.",
                "given": "Robert W.",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Garner"
                ],
                "title": "",
                "type": "Birth Name"
            }
        ],
        "note": "",
        "short_name": "Garner, Robert W.",
        "urls": []
    },
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Bogalusa, Washington, LA, USA",
        "birth_sdn": 2388459,
        "birth_year": "1827",
        "change_time": "2014-08-06 21:19:12",
        "cita": [
            3
        ],
        "death_age": "54 years, 10 months, 25 days",
        "death_place": "Albuquerque, NM, USA",
        "death_sdn": 2408512,
        "death_year": "1882",
        "events": [
            {
                "cita": [],
                "date": "1827-04-12",
                "date_sdn": 2388459,
                "descr": "Birth of Zieli\u0144ski, Phoebe Emily",
                "gid": "E0124",
                "media": [],
                "part_family": [],
                "part_person": [
                    5
                ],
                "place": 3,
                "text": "",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "1882-03-07",
                "date_sdn": 2408512,
                "descr": "Death of Zieli\u0144ski, Phoebe Emily",
                "gid": "E0125",
                "media": [],
                "part_family": [],
                "part_person": [
                    5
                ],
                "place": 1,
                "text": "",
                "type": "Death"
            },
            {
                "cita": [],
                "date": "1882-03-09",
                "date_sdn": 2408514,
                "descr": "Burial of Zieli\u0144ski, Phoebe Emily",
                "gid": "E0126",
                "media": [],
                "part_family": [],
                "part_person": [
                    5
                ],
                "place": 14,
                "text": "",
                "type": "Burial"
            }
        ],
        "famc": [
            {
                "cita": [],
                "index": 4,
                "note": "",
                "to_father": "Birth",
                "to_mother": "Birth"
            }
        ],
        "fams": [
            2
        ],
        "gender": "F",
        "gid": "I0107",
        "media": [],
        "name": "Zieli\u0144ski, Phoebe Emily",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Zieli\u0144ski, Phoebe Emily",
                "given": "Phoebe Emily",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Zieli\u0144ski"
                ],
                "title": "",
                "type": "Birth Name"
            },
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "Garner, Phoebe Emily",
                "given": "Phoebe Emily",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "Garner"
                ],
                "title": "",
                "type": "Married Name"
            }
        ],
        "note": "",
        "short_name": "Zieli\u0144ski, Phoebe Emily",
        "urls": []
    },
    {
        "addrs": [],
        "assoc": [],
        "attr": [],
        "birth_place": "Bogalusa, Washington, LA, USA",
        "birth_sdn": 2372897,
        "birth_year": "1784",
        "change_time": "2007-07-26 10:34:25",
        "cita": [
            7
        ],
        "death_age": "about 79 years, 6 months, 8 days",
        "death_place": "Orlando, Orange, FL, USA",
        "death_sdn": 2401940,
        "death_year": "1864",
        "events": [
            {
                "cita": [],
                "date": "about 1784-09-00",
                "date_sdn": 2372897,
                "descr": "Birth of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
                "gid": "E2679",
                "media": [],
                "part_family": [],
                "part_person": [
                    6
                ],
                "place": 3,
                "text": "",
                "type": "Birth"
            },
            {
                "cita": [],
                "date": "1864-03-09",
                "date_sdn": 2401940,
                "descr": "Death of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
                "gid": "E2680",
                "media": [],
                "part_family": [],
                "part_person": [
                    6
                ],
                "place": 23,
                "text": "",
                "type": "Death"
            },
            {
                "cita": [],
                "date": "1864-03-00",
                "date_sdn": 2401932,
                "descr": "Burial of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
                "gid": "E2681",
                "media": [],
                "part_family": [],
                "part_person": [
                    6
                ],
                "place": 14,
                "text": "",
                "type": "Burial"
            }
        ],
        "famc": [],
        "fams": [
            4
        ],
        "gender": "M",
        "gid": "I0972",
        "media": [],
        "name": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
        "names": [
            {
                "call": "",
                "cita": [],
                "date": "",
                "fam_nick": "",
                "full": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
                "given": "George",
                "nick": "",
                "note": "",
                "suffix": "",
                "surnames": [
                    "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432"
                ],
                "title": "",
                "type": "Birth Name"
            }
        ],
        "note": "",
        "short_name": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
        "urls": []
    }
]