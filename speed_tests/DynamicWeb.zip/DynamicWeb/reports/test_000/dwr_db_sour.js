// This file is generated

// 'S' is sorted by source title
// 'S' gives for each source:
//   - gid: Gramps ID
//   - title: The source title
//   - text: The source text (author, etc.)
//   - author: The source author
//   - abbrev: The source abbreviation
//   - publ: The source publication information
//   - note: The source notes
//   - media: A list of the source media references, in the form:
//       - m_idx: media index (in table 'M')
//       - thumb: media thumbnail path
//       - rect: [x1, y1, x2, y2] of the media reference
//       - note: notes of the media reference
//       - cita: list of the media reference source citations index (in table 'C')
//   - bkc: A list of the citations index (in table 'C') referencing this source
//   - repo: A list of the repositories for this source, in the form:
//       - r_idx: repository index (in table 'R')
//       - media_type: media type
//       - call_number: call number
//       - note: notes of the repository reference
//   - attr: The list of the sources attributes in the form:
//       [attribute, value, note, list of citations]
//   - change_time: last record modification date
S = [
    {
        "abbrev": "",
        "attr": [],
        "author": "",
        "bkc": [
            14,
            15,
            16,
            17,
            18,
            19,
            20,
            21,
            22,
            23,
            25,
            26,
            27,
            28,
            29,
            30,
            31,
            32,
            33,
            34,
            35,
            36,
            37,
            38,
            39,
            40
        ],
        "change_time": "2012-01-31 17:30:35",
        "gid": "S0001",
        "media": [],
        "note": "<div>\n<i class=\"NoteType\">\nGeneral\n</i>\n<div class=\"grampsstylednote\">\n<p>\n<span style=\"font-size:12px;\"></span><span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">This source has all possible references pointing to it. The references are as follows:</span></span>\n</p>\n<p>\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">This note appears as a note to the source and also as a note for the person.</span></span>\n</p>\n<p>\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 01 &nbsp;Person</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 02 &nbsp; &nbsp;Name</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 03 &nbsp; &nbsp;Address</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 04 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 05 &nbsp; &nbsp;PersonRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 06 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 07 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 08 &nbsp; &nbsp;LdsOrd</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 09 &nbsp; &nbsp;EventRef:Attribute </span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 10 &nbsp;Family</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 11 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 12 &nbsp; &nbsp;ChildRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 13 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 14 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 15 &nbsp; &nbsp;LdsOrd</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 16 &nbsp; &nbsp;EventRef:Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 17 &nbsp;Event</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 18 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 19 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 20 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 21 &nbsp;MediaObject</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 22 &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 23 &nbsp;Place</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 24 &nbsp; &nbsp;MediaRef</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 25 &nbsp; &nbsp; &nbsp;Attribute</span></span><br />\n<span style=\"font-family:'Courier';\"><span style=\"font-size:12px;\">page 26 &nbsp;Repository:Address</span></span><span style=\"font-size:12px;\"></span>\n</p>\n</div>\n</div>",
        "publ": "",
        "repo": [],
        "text": "",
        "title": "All possible citations"
    },
    {
        "abbrev": "BR-GFC 1850",
        "attr": [],
        "author": "Priests of Great Falls Church 1850 - 1867",
        "bkc": [
            0,
            6
        ],
        "change_time": "2009-02-11 18:01:30",
        "gid": "S0000",
        "media": [
            {
                "cita": [],
                "m_idx": 0,
                "note": "",
                "rect": [
                    0,
                    0,
                    100,
                    100
                ],
                "thumb": "thumb/b39fe1cfc1305ac4a21.png"
            }
        ],
        "note": "<div>\n<i class=\"NoteType\">\nSource text\n</i>\n<div class=\"grampsstylednote\">\n<p>\n<strong></strong><span style=\"text-decoration:underline;\"><strong>1855-06-25</strong></span><strong></strong>\n</p>\n<p>\n&nbsp; &nbsp; line 1 &nbsp; &nbsp;fac secunda Junij Baptiza-<br />\n&nbsp; &nbsp; line 2 &nbsp; &nbsp;tus est Lewis Anderson<br />\n&nbsp; &nbsp; line 3 &nbsp; &nbsp;filius legitimus Guillielmus<br />\n&nbsp; &nbsp; line 4 &nbsp; &nbsp;Garner et Elisabetha &nbsp;<br />\n&nbsp; &nbsp; line 5 &nbsp; &nbsp;Becks. Susceptores fuerent<br />\n&nbsp; &nbsp; line 6 &nbsp; &nbsp;petrus Arts et Catharina<br />\n&nbsp; &nbsp; line 7 &nbsp; &nbsp;van de Voorde\n</p>\n</div>\n<i class=\"NoteType\">\nTranscript\n</i>\n<div class=\"grampsstylednote\">\n<p>\n1855-06-25:<br />\nI baptized on June the second Lewis Anderson legitimate son of Guillielmus Garner and Elisabetha Becke. Godparents were petrus Arts and Catharina Van de Voorde\n</p>\n</div>\n</div>",
        "publ": "Microfilm Public Library Great Falls",
        "repo": [
            {
                "call_number": "32Z-345",
                "media_type": "Microfilm",
                "note": "",
                "r_idx": 2
            }
        ],
        "text": "<p>\n<b>\nAuthor: \n</b>\nPriests of Great Falls Church 1850 - 1867\n</p><p>\n<b>\nAbbreviation: \n</b>\nBR-GFC 1850\n</p><p>\n<b>\nPublication information: \n</b>\nMicrofilm Public Library Great Falls\n</p>",
        "title": "Baptize registry 1850 - 1867 Great Falls Church"
    },
    {
        "abbrev": "",
        "attr": [
            {
                "cita": [],
                "note": "",
                "type": "Creation date",
                "value": "24 APR 1999"
            },
            {
                "cita": [],
                "note": "",
                "type": "Generated by",
                "value": "ROOTSV 5.01"
            }
        ],
        "author": "",
        "bkc": [
            1,
            2,
            3,
            4,
            5,
            7,
            8,
            9,
            10,
            11,
            12,
            13
        ],
        "change_time": "2012-01-31 17:30:39",
        "gid": "S0003",
        "media": [],
        "note": "<div>\n<i class=\"NoteType\">\nSource Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nThe repository reference from the source is important\n</p>\n</div>\n</div>",
        "publ": "",
        "repo": [
            {
                "call_number": "CA-123-LL-456_Num/ber",
                "media_type": "Film",
                "note": "",
                "r_idx": 1
            }
        ],
        "text": "",
        "title": "Import from test2.ged"
    },
    {
        "abbrev": "WOTW",
        "attr": [
            {
                "cita": [],
                "note": "",
                "type": "Book Cover Type",
                "value": "Paperback"
            }
        ],
        "author": "John Jacob Jinglehiemerschmitt",
        "bkc": [
            24,
            41
        ],
        "change_time": "2007-07-26 10:34:25",
        "gid": "S0002",
        "media": [],
        "note": "<div>\n<i class=\"NoteType\">\nSource Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nHis name is my name, too.\n</p>\n</div>\n</div>",
        "publ": "",
        "repo": [
            {
                "call_number": "nothing-0",
                "media_type": "Manuscript",
                "note": "",
                "r_idx": 0
            },
            {
                "call_number": "what-321-ever",
                "media_type": "Photo",
                "note": "",
                "r_idx": 1
            }
        ],
        "text": "<p>\n<b>\nAuthor: \n</b>\nJohn Jacob Jinglehiemerschmitt\n</p><p>\n<b>\nAbbreviation: \n</b>\nWOTW\n</p>",
        "title": "World of the Wierd"
    }
]