// This file is generated

// 'F' is sorted by family full name
// 'F' gives for each family:
//   - gid: Gramps ID
//   - name: The family full name
//   - type: The family union type
//   - marr_year: The marriage year in the form '1700', '?' (unknown), or '' (not married)
//   - marr_sdn: The marriage serial date number (0 if not known)
//   - marr_place: The marriage place//   - events: A list of events, with for each event:
//       - gid: The event GID
//       - type: The event name
//       - date: The event date
//       - date_sdn: The event serial date number
//       - place: The event place index (in table 'P'), -1 if none
//       - descr: The event description
//       - text: The event text and notes (including event reference notes)
//       - media: A list of the event media index, in the form:
//           - m_idx: media index (in table 'M')
//           - thumb: media thumbnail path
//           - rect: [x1, y1, x2, y2] of the media reference
//           - note: notes of the media reference
//           - cita: list of the media reference source citations index (in table 'C')
//       - cita: A list of the event source citations index (in table 'C')
//   - note: The family notes
//   - media: A list of the family media references, in the form:
//       - m_idx: media index (in table 'M')
//       - thumb: media thumbnail path
//       - rect: [x1, y1, x2, y2] of the media reference
//       - note: notes of the media reference
//       - cita: list of the media reference source citations index (in table 'C')
//   - cita: A list of the family source citations index (in table 'C')
//   - attr: The list of the family attributes in the form:
//       [attribute, value, note, list of citations]
//   - spou: A list of spouses index (in table 'I')
//   - chil: A list of child in the form:
//       [index (in table 'I'), relation to father, relation to mother, notes, list of citations]
//   - change_time: last record modification date
F = [
    {
        "attr": [],
        "change_time": "2007-07-26 10:34:25",
        "chil": [
            {
                "cita": [],
                "index": 4,
                "note": "",
                "to_father": "Birth",
                "to_mother": "Birth"
            }
        ],
        "cita": [
            12
        ],
        "events": [
            {
                "cita": [],
                "date": "1823-01-03",
                "date_sdn": 2386899,
                "descr": "Marriage of Garner, Joseph and Edwards, Lucy",
                "gid": "E2836",
                "media": [],
                "part_family": [],
                "part_person": [],
                "place": 25,
                "text": "",
                "type": "Marriage"
            }
        ],
        "gid": "F0019",
        "marr_place": "Picayune, MS, USA",
        "marr_sdn": 2386899,
        "marr_year": "1823",
        "media": [],
        "name": "Family of Garner, Joseph and Edwards, Lucy",
        "note": "",
        "spou": [
            2,
            1
        ],
        "type": "Married"
    },
    {
        "attr": [
            {
                "cita": [
                    25,
                    41
                ],
                "note": "<div>\n<i class=\"NoteType\">\nAttribute Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nCourtesy of pyschoanalyze-pinhead from Emacs.\n</p>\n<p>\nI am the psychotherapist.  Please, describe your problems.  Each time<br />\nyou are finished talking, type RET twice.\n</p>\n<p>\nSHHHH!!  I hear SIX TATTOOED TRUCK-DRIVERS tossing ENGINE BLOCKS<br />\n into empty OIL DRUMS..\n</p>\n<p>\nWhy do you say that?\n</p>\n<p>\nI have accepted Provolone into my life!\n</p>\n<p>\nWhat makes you believe you have accepted provolone into your life?\n</p>\n<p>\nIt's 74 degrees, 12 minutes NORTH, and 41 degrees, 3 minutes EAST!!<br />\n Soon, it will be TUESDAY!!\n</p>\n<p>\nMaybe your plans have something to do with this.\n</p>\n<p>\nGOOD-NIGHT, everybody..  Now I have to go administer FIRST-AID<br />\n to my pet LEISURE SUIT!!\n</p>\n<p>\nI don't understand.\n</p>\n<p>\nI'm QUIETLY reading the latest issue of ``BOWLING WORLD''<br />\n while my wife and two children stand QUIETLY BY..\n</p>\n<p>\nTell me something about your family.\n</p>\n<p>\nHow do I get HOME?\n</p>\n<p>\nIs it because do you get home that you came to me?\n</p>\n<p>\nKids, the seven basic food groups are GUM, PUFF PASTRY, PIZZA,<br />\n PESTICIDES, ANTIBIOTICS, NUTRA-SWEET and MILK DUDS!!\n</p>\n</div>\n</div>",
                "type": "Number of Children",
                "value": "8"
            }
        ],
        "change_time": "2012-01-31 17:21:23",
        "chil": [],
        "cita": [
            11,
            23
        ],
        "events": [
            {
                "cita": [
                    30
                ],
                "date": "1875-04-01",
                "date_sdn": 2405980,
                "descr": "Marriage of Garner, Lewis Anderson and Martel, Luella Jacques",
                "gid": "E2815",
                "media": [],
                "part_family": [],
                "part_person": [],
                "place": 24,
                "text": "<div>\n<p>\n<b>Age</b>: 23\n</p>\n</div>",
                "type": "Marriage"
            }
        ],
        "gid": "F0017",
        "marr_place": "Paragould, Greene, AR, USA",
        "marr_sdn": 2405980,
        "marr_year": "1875",
        "media": [
            {
                "cita": [
                    27,
                    28
                ],
                "m_idx": 3,
                "note": "<div>\n<p>\n<b>Identification Number</b>: 12345\n</p>\n</div>",
                "rect": [
                    0,
                    0,
                    100,
                    100
                ],
                "thumb": "thumb/F0QIGQFT275JFJ75E8.png"
            }
        ],
        "name": "Family of Garner von Zieli\u0144ski, Lewis Anderson Sr and Martel, Luella Jacques",
        "note": "<div>\n<i class=\"NoteType\">\nFamily Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nGRAMPS aid to look for its tree to him of family.  It allows that you store data of genealogische to draw for above and investigating.  GRAMPS tries to make all the general capacities available of other programs of genealogischer more importantly but, to put an additional capacity of integration at your service not generally for these programs.  This one is the capacity to directly incorporate all the possible pieces of the information in Gramps and the cases of the data cambiar/manipulateany/all in the whole data base (in any order or order) around the user to support, if it makes the investigation, analysis and interrelation with the potential of the distances of the relation that fill.\n</p>\n<p>\nThis is a paragraph from the gramps-project.org page that was translated by Google's Language Tools to German, back to English, then to Spanish, and once again back to English.\n</p>\n</div>\n</div>",
        "spou": [
            3
        ],
        "type": "Married"
    },
    {
        "attr": [],
        "change_time": "2015-05-09 14:35:00",
        "chil": [
            {
                "cita": [],
                "index": 3,
                "note": "",
                "to_father": "Custom relationship to father",
                "to_mother": "Custom relationship to mother"
            }
        ],
        "cita": [
            10
        ],
        "events": [
            {
                "cita": [],
                "date": "1849-10-04",
                "date_sdn": 2396670,
                "descr": "Marriage of Garner, Robert W. and Zieli\u0144ski, Phoebe Emily",
                "gid": "E2825",
                "media": [],
                "part_family": [],
                "part_person": [],
                "place": 24,
                "text": "",
                "type": "Marriage"
            }
        ],
        "gid": "F0018",
        "marr_place": "Paragould, Greene, AR, USA",
        "marr_sdn": 2396670,
        "marr_year": "1849",
        "media": [],
        "name": "Family of Garner, Robert W. and Zieli\u0144ski, Phoebe Emily",
        "note": "",
        "spou": [
            4,
            5
        ],
        "type": "Married"
    },
    {
        "attr": [],
        "change_time": "2007-07-26 10:34:25",
        "chil": [],
        "cita": [
            13
        ],
        "events": [
            {
                "cita": [],
                "date": "1834-06-08",
                "date_sdn": 2391073,
                "descr": "Marriage of Riley, Thomas and Edwards, Lucy",
                "gid": "E3029",
                "media": [],
                "part_family": [],
                "part_person": [],
                "place": 36,
                "text": "",
                "type": "Marriage"
            }
        ],
        "gid": "F0363",
        "marr_place": "Winston-Salem, NC, USA",
        "marr_sdn": 2391073,
        "marr_year": "1834",
        "media": [],
        "name": "Family of Riley, Thomas and Edwards, Lucy",
        "note": "",
        "spou": [
            1
        ],
        "type": "Married"
    },
    {
        "attr": [],
        "change_time": "2007-07-26 10:34:25",
        "chil": [
            {
                "cita": [],
                "index": 5,
                "note": "",
                "to_father": "Birth",
                "to_mother": "Birth"
            }
        ],
        "cita": [
            9
        ],
        "events": [
            {
                "cita": [],
                "date": "",
                "date_sdn": 0,
                "descr": "Marriage of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George and Daniels, Phoebe",
                "gid": "E2966",
                "media": [],
                "part_family": [],
                "part_person": [],
                "place": -1,
                "text": "",
                "type": "Marriage"
            }
        ],
        "gid": "F0306",
        "marr_place": "",
        "marr_sdn": 0,
        "marr_year": "?",
        "media": [],
        "name": "Family of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George and Daniels, Phoebe",
        "note": "",
        "spou": [
            6,
            0
        ],
        "type": "Married"
    }
]