// This file is generated

// 'C' gives for each source citation:
//   - gid: Gramps ID
//   - source: The source index (in table 'S')
//   - text: The citation text (page, etc.)
//   - note: The citation notes
//   - media: A list of the citation media references, in the form:
//       - m_idx: media index (in table 'M')
//       - thumb: media thumbnail path
//       - rect: [x1, y1, x2, y2] of the media reference
//       - note: notes of the media reference
//       - cita: list of the media reference source citations index (in table 'C')
//   - bki: A list of the person index (in table 'I') referencing this citation
//     (including the person events referencing this citation)
//   - bkf: A list of the family index (in table 'F') referencing this citation
//     (including the family events referencing this citation)
//   - bkm: A list of the media index (in table 'M') referencing this citation
//     (including the media references referencing this citation)
//   - bkp: A list of the place index (in table 'P') referencing this citation
//     (including the media references referencing this citation)
//   - bkr: A list of the repository index (in table 'R') referencing this citation
//   - change_time: last record modification date
C = [
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:30",
        "gid": "C0000",
        "media": [],
        "note": "",
        "source": "1",
        "text": "<p>\n<b>\nDate: \n</b>\n1855-06-25\n</p><p>\n<b>\nConfidence: \n</b>\nHigh\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            4
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:38",
        "gid": "C0182",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            1
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:39",
        "gid": "C0241",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            5
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:39",
        "gid": "C0245",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            2
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:44",
        "gid": "C0782",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:30:39",
        "gid": "C0974",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:46",
        "gid": "C0975",
        "media": [],
        "note": "",
        "source": "1",
        "text": "<p>\n<b>\nDate: \n</b>\n1855-06-25\n</p><p>\n<b>\nConfidence: \n</b>\nHigh\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            6
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:47",
        "gid": "C0996",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            0
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:57",
        "gid": "C1867",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [
            4
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:02",
        "gid": "C2218",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [
            2
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:03",
        "gid": "C2300",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:03",
        "gid": "C2325",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [
            0
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:07",
        "gid": "C2773",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [
            3
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:07",
        "gid": "C2775",
        "media": [],
        "note": "",
        "source": "2",
        "text": ""
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:10:46",
        "gid": "C2828",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 01\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:11:07",
        "gid": "C2829",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 02\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:11:32",
        "gid": "C2830",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 03\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:11:56",
        "gid": "C2831",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 04\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:13:08",
        "gid": "C2832",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 05\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            2
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:13:30",
        "gid": "C2833",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 06\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            2
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:13:56",
        "gid": "C2834",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 07\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:14:16",
        "gid": "C2835",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 08\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:15:14",
        "gid": "C2836",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 09\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:17:43",
        "gid": "C2837",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 10\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:05:46",
        "gid": "C0973",
        "media": [],
        "note": "<div>\n<i class=\"NoteType\">\nSource Reference Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nStrange, isn't it.\n</p>\n</div>\n<i class=\"NoteType\">\nSource text\n</i>\n<div class=\"grampsstylednote\">\n<p>\nOn every third blue moon, Lewis Anderson Garner would dress in a purple dress and claim that his name was Louis Garner.\n</p>\n</div>\n</div>",
        "source": "3",
        "text": "<p>\n<b>\nDate: \n</b>\n1990-03-05\n</p><p>\n<b>\nPage: \n</b>\nPage 11 2/3.\n</p><p>\n<b>\nConfidence: \n</b>\nHigh\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:18:00",
        "gid": "C2838",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 11\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:18:19",
        "gid": "C2839",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 12\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            3
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:18:39",
        "gid": "C2840",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 13\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            3
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:19:12",
        "gid": "C2841",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 14\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:19:54",
        "gid": "C2842",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 15\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:20:51",
        "gid": "C2843",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 16\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:21:47",
        "gid": "C2844",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 17\n</p>"
    },
    {
        "bkf": [],
        "bki": [
            3
        ],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:22:20",
        "gid": "C2845",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 18\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            0
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:23:28",
        "gid": "C2846",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 19\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            0
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:24:14",
        "gid": "C2847",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 20\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            2
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:25:00",
        "gid": "C2848",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 21\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            2
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:25:55",
        "gid": "C2849",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 22\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [],
        "bkp": [
            31
        ],
        "bkr": [],
        "change_time": "2012-01-31 17:27:51",
        "gid": "C2850",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 23\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            1
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:28:25",
        "gid": "C2851",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 24\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [
            1
        ],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:29:00",
        "gid": "C2852",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 25\n</p>"
    },
    {
        "bkf": [],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [
            1
        ],
        "change_time": "2012-01-31 17:30:35",
        "gid": "C2853",
        "media": [],
        "note": "",
        "source": "0",
        "text": "<p>\n<b>\nPage: \n</b>\npage 26\n</p>"
    },
    {
        "bkf": [
            1
        ],
        "bki": [],
        "bkm": [],
        "bkp": [],
        "bkr": [],
        "change_time": "2012-01-31 17:06:03",
        "gid": "C2324",
        "media": [],
        "note": "",
        "source": "3",
        "text": "<p>\n<b>\nPage: \n</b>\nPage pi\n</p>"
    }
]