// This file is generated

P_names_0 = [
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Aberdeen"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Aberdeen"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Acadia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ada"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Adams"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Adams"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Adjuntas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Adrian"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Aguadilla"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "AK"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Akron"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "AL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alachua"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alameda"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alamogordo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albany"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albany"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albany"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albany"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albert Lea"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albertville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Albuquerque"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alexandria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alexandria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alexandria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alice"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Allegan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Allen"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Allentown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Alpena"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Altoona"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Altus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Amarillo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Americus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ames"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Amsterdam"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Anchorage"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Anderson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Anderson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Andrews"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Andrews"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Angelina"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Angola"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ann Arbor"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Anniston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "AR-OK"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "AR"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Arcadia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ardmore"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Arkadelphia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Arlington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Asheville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ashland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ashtabula"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Astoria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Atchison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Atchison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Athens"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Athens"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Athens"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Atlanta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Auburn"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Auburn"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Augusta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Austin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "AZ"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bainbridge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Baldwin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Baldwin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Baltimore"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bangor"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bannock"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Baraboo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Barnstable Town"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Barren"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bartholomew"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bartlesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Batavia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Batesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Baton Rouge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Battle Creek"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bay City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bay City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Beaumont"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Beaver Dam"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Beckley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bedford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Beeville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bell"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bellingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bemidji"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ben Hill"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bennettsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bennington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Berkshire"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Berlin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bethesda"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bexar"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bibb"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Big Rapids"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Big Spring"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Billings"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Binghamton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Birmingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bishop"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bismarck"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Blackfoot"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Blacksburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bloomington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bloomsburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bluefield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Blytheville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bogalusa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boise City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bonneville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boulder"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boulder"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bowling Green"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Boyle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bozeman"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brainerd"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Branson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brazos"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bremerton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brenham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brevard"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brevard"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bridgeport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bridgeton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brookhaven"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brookings"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Broome"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Broward"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brownsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brownsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Brownwood"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bucyrus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Buena Vista"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Buffalo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Bulloch"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Burley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Burlington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Burlington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Burlington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Butte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Butte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "CA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cabo Rojo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Caddo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cadillac"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Caguas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Calcasieu"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Calhoun"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cambridge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cambridge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cambridge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Camden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Camden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cameron"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Campbellsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Canon City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Canton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Canton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cape Coral-Fort Myers"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cape Girardeau"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Carbondale"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Carlsbad"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Carson City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Casper"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cassia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cattaraugus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cayuga"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cedar City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cedartown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Celina"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Central City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Centralia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Centralia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chambers"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Champaign"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Champaign"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Charleston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Charleston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Charlotte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Charlotte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chatham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chattanooga"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chattooga"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chemung"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cherokee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cheyenne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chicago"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chico"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Chillicothe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Christian"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cincinnati"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Citrus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "City of The Dalles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clark"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clarke"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clarksburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clarksdale"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clearlake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clearwater"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cleveland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cleveland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cleveland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clinton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clinton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clinton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clinton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Clovis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "CO"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coamo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cochise"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coconino"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coeur d'Alene"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coffee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coffee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coffeyville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coldwater"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "College Station"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Collier"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Colorado Springs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Colquitt"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Columbus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Concord"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Connersville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cook"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cookeville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coos Bay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corbin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cordele"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corinth"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cornelia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corning"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corpus Christi"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corsicana"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cortland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cortland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Corvallis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Coshocton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cowley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Craighead"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crawford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crawfordsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crescent City North"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crisp"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crossville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Crowley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "CT"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cullman"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Cullman"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dallas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dallas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dallas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dalton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Danville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Danville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Danville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Daphne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Davenport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Daviess"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Daviess"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dawson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dayton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "DC"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "De Ridder"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "DE-MD-NJ"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "DE"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Deaf Smith"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Decatur"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Decatur"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Decatur"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Decatur"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Decatur"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Defiance"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Del Rio"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Delaware"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Deltona"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Deming"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Denver-Aurora"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Des Moines"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Des Moines"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "DeSoto"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Detroit"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dickinson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dickinson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "District of Columbia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dixon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dodge City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dothan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dougherty"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Douglas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Douglas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dover"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dublin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dubois"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "DuBois"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dubuque"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dubuque"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Duluth"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dumas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Duncan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dunn"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Durango"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Durant"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Durham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dutchess"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Duval"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Dyersburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Eagle Pass"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Eagle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "East Baton Rouge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "East Liverpool"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "East Stroudsburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Easton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Eau Claire"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Edison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Edwards"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Edwards"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Effingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Effingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "El Campo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "El Centro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "El Paso"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Elizabeth City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Elkhart"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Elkhart"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ellensburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ellis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Elmira"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Elmore"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Emporia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Enid"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Enterprise"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Erath"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Erie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Erie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Escambia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Escanaba"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Etowah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Eugene"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Eureka"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Evanston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Evansville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fairbanks"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fairfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fairmont"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fairmont"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fajardo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fallon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fargo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Faribault-Northfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Farmington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Farmington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fayette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fayette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fayetteville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fergus Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Findlay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Finney"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fitzgerald"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "FL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Flagler"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Flagstaff"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Flint"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Florence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Florence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Floyd"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fond du Lac"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Forest City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Forrest City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Collins"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Dodge"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Lauderdale"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Leonard Wood"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Morgan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Polk South"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Smith"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Valley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Walton Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Wayne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fort Worth"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fostoria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Frankfort"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Frankfort"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Franklin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Franklin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Frederick"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fremont"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fresno"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fresno"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fulton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fulton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Fulton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "GA-AL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "GA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gadsden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gaffney"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gainesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gainesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gainesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gaithersburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gallup"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Garden City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gardnerville Ranchos"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Garland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gary"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Genesee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "George, UT"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Georgetown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gettysburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gila"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gillette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Glasgow"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Glens Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gloversville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Goldsboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Graham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Granbury"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grand Forks"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grand Junction"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grand Rapids"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grant"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grants Pass"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grants"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Graves"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gray"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Great Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greeley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Green Bay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greene"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greeneville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greensboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greensburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenwood"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Greenwood"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gregg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Grenada"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Guayama"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Guaynabo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Gulfport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Guymon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Habersham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hagerstown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hammond"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hampden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hanford-Corcoran"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hannibal"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hanover"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hardee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harriman"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harris"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harrisburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harrison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harrison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Harrisonburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hartford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hartford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hastings"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hattiesburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Havre"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hays"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hayward"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Helena"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hempstead"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Henderson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Henderson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Henry"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hereford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "HI"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hickory-Morganton-Lenoir"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hidalgo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hillsborough"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hilo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hilton Head Island-Beaufort"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hinesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hobbs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hockley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Holland-Grand Haven"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Homosassa Springs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Honolulu"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hood River"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hood"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hope"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hopkins"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hot Springs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Houma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Houston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Houston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Houston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Houston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Howard"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Howard"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hudson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Humboldt"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Huntsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Huntsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Huron"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hutchinson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Hutchinson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "IA-NE-SD"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "IA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "ID"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Idaho Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "IL-MO"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "IL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Imperial"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "IN"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Independence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Indian River"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Indiana"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Indianola"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Inyo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Iowa City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Iron Mountain"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Isabela"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jackson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jackson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jackson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jackson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jackson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jacksonville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jacksonville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jacksonville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jamestown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jamestowna"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Janesville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jasper"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jasper"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson Davis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jefferson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jennings"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jennings"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jesup"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jim Wells"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Johnson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Johnstown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Jonesboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Joplin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Juneau"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kahului"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kalamazoo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kansas City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kapaa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kearney"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Keene"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kendallville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kennett"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kennewick"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kent"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Keokuk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kerr"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kerrville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ketchikan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Key West-Marathon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kill Devil Hills"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Killeen"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kingsport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kingston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kingsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kinston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Klamath Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kleberg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Knoxville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kokomo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kootenai"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Kosciusko"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "KS"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "KY-IL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "KY"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "La Crosse"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "La Follette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "La Grande"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "La Plata"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "La Salle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "LA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laconia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lafayette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lafayette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lafayette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "LaGrange"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake Charles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake County"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake Havasu City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lakeland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lamesa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lancaster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lancaster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lansing"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "LaPorte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laramie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laredo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Larimer"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Las Cruces"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Las Vegas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Las Vegas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Latah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lauderdale"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laurel"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laurel"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laurens"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Laurinburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lawrence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lawrence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lawrenceburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lawton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lebanon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lebanon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Leon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Levelland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lewisburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lewiston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lewiston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lewistown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lexington Park"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lexington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lexington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lexington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Liberal"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Liberty"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lima"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Limestone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lincoln"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lincoln"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lincoln"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Litchfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Little Rock"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Livonia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Llano"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lock Haven"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Logan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Logan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Logan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "London"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Longview-Kelso"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Longview"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Los Angeles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Los Angeles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Louis, St, Louis, MO-IL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Louisville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Loveland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lowndes"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lucie, FL"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lufkin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lumberton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lynchburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Lyon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Macomb"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Macon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Macon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Macon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madera"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madera"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Madison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Magnolia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mahaska"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Malone"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Manchester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Manhattan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Manitowoc"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mankato"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Maricopa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marietta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marinette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marquette"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshall"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshalltown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marshfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Martinsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marys, St, Marys, PA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Marysville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Maryville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mason"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Matagorda"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Maverick"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mayag\u00fcez"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mayfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Maysville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McAlester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McAllen"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McComb"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McCracken"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McDonough"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McLennan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McMinnville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McPherson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "McPherson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MD"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "ME"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Medford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Memphis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mendocino"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Menomonie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Merced"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Merced"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Meridian"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Merrill"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mesa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mexico"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MI"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miami Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miami-Dade"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miami"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miami"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miami"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Michigan City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Middlesborough"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Middlesex"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Midland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Midland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Midland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Milledgeville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Miller"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Milwaukee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Minden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mineral Wells"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Minneapolis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Minot"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mississippi"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Missoula"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mitchell"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MN"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MO"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Moberly"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mobile"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mobile"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Modesto"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mohave"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Monroe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Monroe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Monroe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Monroe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Monterey"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montgomery"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montrose"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Montrose"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Moore"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mooresville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morehead City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morgan City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morgan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morgan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morgantown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Morristown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Moscow"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Moses Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Moultrie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mount Airy"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mount Pleasant"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mount Sterling"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mount Vernon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mount Vernon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mountain Home"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Mountain Home"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MS-LA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MS"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "MT"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muhlenberg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muncie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muscatine"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muscatine"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muskegon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Muskogee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Myrtle Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Napa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Napa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Naples"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Nashville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Natchez"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Natchitoches"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Navarro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NC"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "ND"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NE"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Bern"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Castle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Castle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Castle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Haven"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Haven"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New London"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Orleans"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Philadelphia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "New Ulm"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Newberry"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Newport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Newton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Nez Perce"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NH"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Niles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NJ"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NM"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Noble"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Nogales"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Nolan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Norfolk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "North Platte"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "North Vernon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Norwalk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Norwich"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Nueces"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NV"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "NY"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oakland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ocala"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ocean City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ocean Pines"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ogden"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ogdensburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "OH"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oil City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "OK"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Okaloosa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oklahoma City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Olean"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Olympia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Omaha"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oneonta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Onondaga"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ontario"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "OR-ID"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "OR"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Orange"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Orange"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Orangeburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Orlando"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Orleans"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oshkosh"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oskaloosa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Otsego"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ottawa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ottumwa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ouachita"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ouachita"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Owensboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Owosso"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oxford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Oxnard"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "PA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Paducah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pahrump"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palatka"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palestine"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palm Bay"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palm Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palm Coast"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Palo Pinto"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pampa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Panama City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Paragould"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Paris"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Payson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Peach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pecos"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pendleton-Hermiston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pensacola"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Peoria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Peoria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Peru"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Philadelphia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Philadelphia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Phillips"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Phoenix Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Phoenix"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Picayune"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pierre"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pike"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pima"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pinellas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pittsburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pittsburgh"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pittsfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Plainview"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Plattsburgh"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Plymouth"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pocatello"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Point Pleasant"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Polk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Polk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Polk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ponca City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ponce"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pontiac"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pope"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Poplar Bluff"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Port Angeles"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Port St"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Portales"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Porterville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Portland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Portland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Portsmouth"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Potter"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pottsville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Poughkeepsie"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "PR"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Providence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Provo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pueblo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pueblo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Puerto Rico"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pulaski"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pulaski"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Pullman"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Punta Gorda"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Putnam"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Quincy"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Racine"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Raleigh-Cary"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rapides"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Reading"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Red Bluff"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Red Wing"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Redding"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Redwood City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Reeves"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Reno-Sparks"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Reno"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rexburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "RI"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Richmond"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Richmond"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Richmond"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Riley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rio Grande City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Riverside"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Riverton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Roanoke Rapids"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Roanoke"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rochester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rock Springs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rockford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rockingham County"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rockingham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rockland"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rocky Mount"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rolla"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rome"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Roseburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Roswell"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Rusk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Russellville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ruston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Safford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Saginaw"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Salem"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Salina"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Salinas"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Saline"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Salisbury"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Salt Lake City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Angelo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Antonio"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Diego"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Diego"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Francisco"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Francisco"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Germ\u00e1n"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Joaquin"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Juan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Luis Obispo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Luis Obispo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Mateo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "San Sebasti\u00e1n"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sandusky"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sanford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sangamon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Ana"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Cruz"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Cruz"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Cruz"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Fe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Isabel"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Santa Rosa-Petaluma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sault Ste"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Savannah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "SC"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Scott"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Scott"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Scottsbluff"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Scottsburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Scranton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "SD"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seaford"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Searcy"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seattle"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sebastian"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Selinsgrove"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Selma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seneca Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seneca"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seneca"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sevierville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seward"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Seymour"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shasta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shawnee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shawnee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sheboygan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shelby"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shelbyville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shelton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sheridan"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sherman-Denison"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Shreveport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sidney"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sierra Vista"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sikeston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Silver City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Silverthorne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sioux City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sioux Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Smith"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Solano"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Somerset"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Somerset"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "South Bend"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Southern Pines"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Spartanburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Spearfish"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Spencer"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Spirit Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Spokane"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Springfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Springfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Springfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Springfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St. Clair"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St. Francis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St. Joseph"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St. Lawrence"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "St. Mary"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stanislaus"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Starkville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Starr"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "State College"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Statesboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Staunton-Waynesboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stephens"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stephenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sterling"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sterling"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Steuben"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Steuben"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Steubenville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stevens Point"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stillwater"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Stockton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Storm Lake"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Story"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sturgis"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Suffolk"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sulphur Springs"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Summerville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Summit"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sumter"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sumter"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sunbury"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sussex"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sutter"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sweetwater"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Sylacauga"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Syracuse"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tahlequah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Talladega"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tallahassee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tallulah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tampa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tangipahoa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Taos"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tarrant"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Taylor"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Taylor"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Taylorville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tehama"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Terre Haute"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Terrebonne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Texarkana"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "The Villages"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Thomaston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Thomasville"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tift"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tifton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tippecanoe"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "TN-GA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "TN"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Toccoa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Toledo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tom Green"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Topeka"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Torrington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Traverse City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Troy"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tucson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tulare"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tullahoma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tuolumne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tupelo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tuscaloosa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tuscaloosa"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tuskegee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Twin Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Twin Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "TX"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Tyler"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ukiah"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ulster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Union City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Union"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Upson"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Urbana"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "USA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "UT-ID"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "UT"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Utica-Rome"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Uvalde"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Uvalde"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "VA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Val Verde"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Valdosta"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vallejo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Valley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Van Wert"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vanderburgh"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ventura"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vermilion"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vernal"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vernon"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vero Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vicksburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Victoria"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Vigo"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Virginia Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Visalia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Volusia"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "VT"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wabash"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wabash"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Waco"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wahpeton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Walker"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Walterboro"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wapello"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Ware"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warner Robins"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warren-Farmington Hills-Troy"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warren"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warren"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warren"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warrensburg"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Warsaw"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Washington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Waterloo-Cedar Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Watertown-Fort Drum"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Watertown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wauchula"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wausau"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Waycross"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wayne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wayne"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Webb"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Webster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Webster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Weirton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Weld"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wenatchee"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "West Helena"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "West Palm Beach"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "West Plains"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wharton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wheeling"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "White"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Whiteside"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Whitewater"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Whitley"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WI-MI"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WI"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wichita Falls"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wichita"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wilbarger"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Williamsport"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Willimantic"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Williston"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Willmar"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wilmington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wilmington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wilmington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Winchester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Windham"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Winfield"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Winnebago"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Winona"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Winston-Salem"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wisconsin Rapids"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Woodbury"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Woodward"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Wooster"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Worcester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Worcester"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Worthington"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WV-OH"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WV-VA"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WV"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "WY"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yakima"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yankton"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yauco"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yazoo City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "York"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Youngstown"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yuba City"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yuba"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yuma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "Yuma"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u0386\u03c1\u03b3\u03bf\u03c2"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u0394\u03c1\u03ac\u03bc\u03b1"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u0398\u03b5\u03c3\u03c3\u03b1\u03bb\u03bf\u03bd\u03af\u03ba\u03b7"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u0399\u03c9\u03ac\u03bd\u03bd\u03b9\u03bd\u03b1"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u039c\u03b5\u03c3\u03bf\u03bb\u03cc\u03b3\u03b3\u03b9"
        }
    ],
    [
        {
            "date": "",
            "date_sdn": 0,
            "name": "\u03a3\u03b9\u03ac\u03c4\u03b9\u03c3\u03c4\u03b1"
        }
    ]
]