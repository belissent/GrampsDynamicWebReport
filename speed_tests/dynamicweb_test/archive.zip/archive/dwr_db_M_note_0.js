// This file is generated

M_note_0 = [
    "",
    "",
    "",
    "",
    "",
    "",
    ""
]