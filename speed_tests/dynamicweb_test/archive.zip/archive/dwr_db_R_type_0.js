// This file is generated

R_type_0 = [
    "Collection",
    "Library",
    "Library"
]