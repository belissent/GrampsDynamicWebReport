// This file is generated

M_gramps_path_0 = [
    "scanned_microfilm.png",
    "1897_expeditionsmannschaft_rio_a.jpg",
    "654px-Aksel_Andersson.jpg",
    "Alimehemet.jpg",
    "AntoineClaudet.png",
    "E_W_Dahlgren.jpg",
    "Gunnlaugur_Larusson_-_Yawn.jpg"
]