// This file is generated

S_media_0 = [
    [],
    [],
    [],
    [
        {
            "cita": [],
            "m_idx": 0,
            "note": "",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/b39fe1cfc1305ac4a21.png"
        }
    ]
]