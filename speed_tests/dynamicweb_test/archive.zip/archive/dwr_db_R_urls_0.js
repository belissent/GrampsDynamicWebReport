// This file is generated

R_urls_0 = [
    [
        {
            "descr": "",
            "type": "Web Home",
            "uri": "http://library.gramps-project.org"
        }
    ],
    [],
    [
        {
            "descr": "",
            "type": "Web Home",
            "uri": "http://great-falls.org"
        }
    ]
]