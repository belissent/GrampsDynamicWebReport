// This file is generated

R_gid_0 = [
    "R0003",
    "R0002",
    "R0000"
]