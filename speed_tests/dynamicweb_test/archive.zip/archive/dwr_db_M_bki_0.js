// This file is generated

M_bki_0 = [
    [
        {
            "bk_idx": 671,
            "cita": [
                2845,
                2846,
                2846
            ],
            "note": "<div>\n<p>\n<b>Father's Age</b>: 25\n</p>\n</div>",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/b39fe1cfc1305ac4a21.png"
        }
    ],
    [
        {
            "bk_idx": 671,
            "cita": [],
            "note": "",
            "rect": [
                51,
                19,
                59,
                33
            ],
            "thumb": "thumb/238CGQ939HG18SS5MG-51,19-59,33.png"
        },
        {
            "bk_idx": 693,
            "cita": [],
            "note": "",
            "rect": [
                15,
                27,
                25,
                43
            ],
            "thumb": "thumb/238CGQ939HG18SS5MG-15,27-25,43.png"
        }
    ],
    [
        {
            "bk_idx": 671,
            "cita": [
                2831,
                2832,
                2832
            ],
            "note": "<div>\n<p>\n<b>Age</b>: 50\n</p>\n</div>",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/B1AUFQV7H8R9NR4SZM.png"
        }
    ],
    [],
    [
        {
            "bk_idx": 1112,
            "cita": [],
            "note": "",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/Y3ARGQWE088EQRTTDH.png"
        }
    ],
    [
        {
            "bk_idx": 665,
            "cita": [],
            "note": "",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/F8JYGQFL2PKLSYH79X.png"
        }
    ],
    [
        {
            "bk_idx": 654,
            "cita": [],
            "note": "",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/78V2GQX2FKNSYQ3OHE.png"
        }
    ]
]