// This file is generated

M_bkp_0 = [
    [],
    [
        {
            "bk_idx": 1169,
            "cita": [
                2850,
                2851,
                2851
            ],
            "note": "<div>\n<p>\n<b>Nickname</b>: Fred\n</p>\n</div>",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/238CGQ939HG18SS5MG.png"
        }
    ],
    [],
    [],
    [],
    [],
    []
]