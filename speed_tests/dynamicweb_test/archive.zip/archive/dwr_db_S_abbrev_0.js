// This file is generated

S_abbrev_0 = [
    "",
    "",
    "WOTW",
    "BR-GFC 1850"
]