// This file is generated

S_author_0 = [
    "",
    "",
    "John Jacob Jinglehiemerschmitt",
    "Priests of Great Falls Church 1850 - 1867"
]