// This file is generated

M_date_sdn_0 = [
    0,
    2413926,
    0,
    0,
    0,
    0,
    0
]