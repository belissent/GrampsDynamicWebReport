// This file is generated

M_gid_0 = [
    "O0000",
    "O0010",
    "O0008",
    "O0006",
    "O0011",
    "O0007",
    "O0009"
]