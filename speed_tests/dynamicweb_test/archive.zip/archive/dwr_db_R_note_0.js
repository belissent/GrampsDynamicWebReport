// This file is generated

R_note_0 = [
    "<div>\n<i class=\"NoteType\">\nRepository Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nSome note on the repo\n</p>\n</div>\n</div>",
    "",
    "<div>\n<i class=\"NoteType\">\nRepository Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nAsk librarian for key to the microfilm closet of <a href=\"place.html?pdx=451\">Great Falls</a> church, it is closed normally\n</p>\n</div>\n</div>"
]