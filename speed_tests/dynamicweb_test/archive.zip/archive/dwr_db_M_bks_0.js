// This file is generated

M_bks_0 = [
    [
        {
            "bk_idx": 3,
            "cita": [],
            "note": "",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/b39fe1cfc1305ac4a21.png"
        }
    ],
    [],
    [],
    [],
    [],
    [],
    []
]