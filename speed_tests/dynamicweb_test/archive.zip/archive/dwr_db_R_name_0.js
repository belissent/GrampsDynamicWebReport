// This file is generated

R_name_0 = [
    "Aunt Martha's Attic",
    "New York Public Library",
    "Public Library Great Falls"
]