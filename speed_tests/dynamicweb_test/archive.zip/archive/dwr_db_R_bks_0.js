// This file is generated

R_bks_0 = [
    [
        {
            "call_number": "nothing-0",
            "media_type": "Manuscript",
            "note": "",
            "s_idx": 2
        }
    ],
    [
        {
            "call_number": "CA-123-LL-456_Num/ber",
            "media_type": "Film",
            "note": "",
            "s_idx": 1
        },
        {
            "call_number": "what-321-ever",
            "media_type": "Photo",
            "note": "",
            "s_idx": 2
        }
    ],
    [
        {
            "call_number": "32Z-345",
            "media_type": "Microfilm",
            "note": "",
            "s_idx": 3
        }
    ]
]