// This file is generated

M_attr_0 = [
    [],
    [],
    [
        {
            "cita": [
                2848
            ],
            "note": "",
            "type": "Description",
            "value": "This seems to be a photo of a relative"
        }
    ],
    [],
    [],
    [],
    []
]