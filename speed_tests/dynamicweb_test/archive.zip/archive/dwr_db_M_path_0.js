// This file is generated

M_path_0 = [
    "image/b39fe1cfc1305ac4a21.png",
    "image/238cgq939hg18ss5mg.jpg",
    "image/b1aufqv7h8r9nr4szm.jpg",
    "image/f0qigqft275jfj75e8.jpg",
    "image/y3argqwe088eqrttdh.png",
    "image/f8jygqfl2pklsyh79x.jpg",
    "image/78v2gqx2fknsyq3ohe.jpg"
]