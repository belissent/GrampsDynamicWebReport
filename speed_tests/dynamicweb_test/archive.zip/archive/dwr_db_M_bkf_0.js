// This file is generated

M_bkf_0 = [
    [],
    [],
    [],
    [
        {
            "bk_idx": 253,
            "cita": [
                2839,
                2840,
                2840
            ],
            "note": "<div>\n<p>\n<b>Identification Number</b>: 12345\n</p>\n</div>",
            "rect": [
                0,
                0,
                100,
                100
            ],
            "thumb": "thumb/F0QIGQFT275JFJ75E8.png"
        }
    ],
    [],
    [],
    []
]