// This file is generated

R_type_0 = [
"Collection",
"Biblioth\u00e8que",
"Biblioth\u00e8que"
]
Dwr.ScriptLoaded('dwr_db_R_type_0.js');
