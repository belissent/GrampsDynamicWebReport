// This file is generated

R_addrs_0 = [
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"location": [
"123 Main St",
"",
"",
"Someville",
"ST",
"",
"",
"USA",
""
],
"note": ""
}
],
[
{
"cita": [
2852
],
"date": "",
"date_sdn": 0,
"location": [
"5th Ave at 42 street",
"",
"",
"New York",
"New York",
"",
"11111",
"USA",
""
],
"note": ""
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"location": [
"Bookstore street 5",
"",
"",
"Great Falls",
"MT",
"",
"",
"USA",
""
],
"note": ""
}
]
]
Dwr.ScriptLoaded('dwr_db_R_addrs_0.js');
