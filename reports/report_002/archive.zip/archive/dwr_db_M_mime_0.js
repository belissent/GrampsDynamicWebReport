// This file is generated

M_mime_0 = [
"image/png",
"image/jpeg",
"image/jpeg",
"image/jpeg",
"image/png",
"image/jpeg",
"image/jpeg"
]
Dwr.ScriptLoaded('dwr_db_M_mime_0.js');
