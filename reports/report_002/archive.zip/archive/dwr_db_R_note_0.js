// This file is generated

R_note_0 = [
"<div>\n<i class=\"NoteType\">\nNote sur le d\u00e9p\u00f4t\n</i>\n<div class=\"grampsstylednote\">\n<p>\nSome note on the repo\n</p>\n</div>\n</div>",
"",
"<div>\n<i class=\"NoteType\">\nNote sur le d\u00e9p\u00f4t\n</i>\n<div class=\"grampsstylednote\">\n<p>\nAsk librarian for key to the microfilm closet of <a href=\"place.html?pdx=451\">Great Falls</a> church, it is closed normally\n</p>\n</div>\n</div>"
]
Dwr.ScriptLoaded('dwr_db_R_note_0.js');
