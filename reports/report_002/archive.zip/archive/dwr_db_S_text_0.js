// This file is generated

S_text_0 = [
"",
"",
"<p>\n<b>\nAuteur: \n</b>\nJohn Jacob Jinglehiemerschmitt\n</p><p>\n<b>\nAbr\u00e9viation: \n</b>\nWOTW\n</p>",
"<p>\n<b>\nAuteur: \n</b>\nPriests of Great Falls Church 1850 - 1867\n</p><p>\n<b>\nAbr\u00e9viation: \n</b>\nBR-GFC 1850\n</p><p>\n<b>\nInformations de publication: \n</b>\nMicrofilm Public Library Great Falls\n</p>"
]
Dwr.ScriptLoaded('dwr_db_S_text_0.js');
