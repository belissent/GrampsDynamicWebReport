// This file is generated

R_xgid = {
"R0000": 2,
"R0002": 1,
"R0003": 0
}
Dwr.ScriptLoaded('dwr_db_R_xgid.js');
