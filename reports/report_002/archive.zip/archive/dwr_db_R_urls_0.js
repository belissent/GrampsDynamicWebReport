// This file is generated

R_urls_0 = [
[
{
"descr": "",
"type": "Site internet",
"uri": "http://library.gramps-project.org"
}
],
[],
[
{
"descr": "",
"type": "Site internet",
"uri": "http://great-falls.org"
}
]
]
Dwr.ScriptLoaded('dwr_db_R_urls_0.js');
