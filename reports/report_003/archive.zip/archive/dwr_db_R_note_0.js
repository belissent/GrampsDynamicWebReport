// This file is generated

R_note_0 = [
"<div>\n<div class=\"grampsstylednote\">\n<p>\nSome note on the repo\n</p>\n</div>\n</div>",
"",
"<div>\n<div class=\"grampsstylednote\">\n<p>\nAsk librarian for key to the microfilm closet of <a href=\"place.html?pdx=301\">Great Falls</a> church, it is closed normally\n</p>\n</div>\n</div>"
]
Dwr.ScriptLoaded('dwr_db_R_note_0.js');
