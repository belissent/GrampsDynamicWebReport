// This file is generated

F_events_0 = [
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Adams, William and Aguilar, Eleanor",
"gid": "E2853",
"media": [],
"part_family": [],
"part_person": [],
"place": 464,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1762-06-20",
"date_sdn": 2364788,
"descr": "Marriage of Adkins, John and Adams, Jane",
"gid": "E2782",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Adkins, Robert Sr. and Nielsen, Martha",
"gid": "E2781",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "about 1729",
"date_sdn": 2352565,
"descr": "Marriage of Allen, Benjamin and Griffith, Experience",
"gid": "E3332",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1705",
"date_sdn": 2343799,
"descr": "Marriage of Allen, Gershom and Kennedy, Ann",
"gid": "E3335",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1695",
"date_sdn": 2340147,
"descr": "Marriage of Allen, John and Dennis, Mary (Hannah?)",
"gid": "E3326",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1713",
"date_sdn": 2346721,
"descr": "Marriage of Allen, Joseph and Barker, Mary",
"gid": "E3329",
"media": [],
"part_family": [],
"part_person": [],
"place": 734,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Alvarado, Franklin and Hodges, Comfort",
"gid": "E3160",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Alvarado, John and James, Pamela",
"gid": "E3158",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Alvarado, Marshall and Bouchard, Jane",
"gid": "E3163",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Alvarado, Thomas C. and \u041c\u0435\u0434\u0432\u0435\u0434\u0435\u0432, Mary",
"gid": "E3162",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Alvarado, William and Moody, Martha",
"gid": "E3161",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1848-01-07",
"date_sdn": 2396034,
"descr": "Marriage of Andersen, Samuel and Moreno, Delilah",
"gid": "E3353",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1712-05-17",
"date_sdn": 2346492,
"descr": "Marriage of Anderson, Rev. John and Christiansen, Martha",
"gid": "E2844",
"media": [],
"part_family": [],
"part_person": [],
"place": 648,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1650",
"date_sdn": 2323711,
"descr": "Marriage of Anderson, Thomas and Carpenter, Sarah",
"gid": "E2869",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1630-06-00",
"date_sdn": 2316557,
"descr": "Marriage of Austin, Hans and Burke, Maria",
"gid": "E2949",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1652-07-02",
"date_sdn": 2324624,
"descr": "Marriage of Austin, Johannas and Jenkins, Margaret",
"gid": "E2951",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Baldwin, Peter and \u041d\u0438\u043a\u0438\u0444\u043e\u0440\u043e\u0432",
"gid": "E3070",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1868-01-01",
"date_sdn": 2403333,
"descr": "Marriage of Ball, Jasper and \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E2739",
"media": [],
"part_family": [],
"part_person": [],
"place": 613,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ball, Matthias Sr. and Maxwell, Ann",
"gid": "E2790",
"media": [],
"part_family": [],
"part_person": [],
"place": 293,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1854-07-23",
"date_sdn": 2398423,
"descr": "Marriage of Ball, Matthias, Jr. and Gonzalez, Eliza Jane",
"gid": "E3322",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1843-11-14",
"date_sdn": 2394519,
"descr": "Marriage of Ball, Matthias, Jr. and Moreno, Abigail Chapman",
"gid": "E3370",
"media": [],
"part_family": [],
"part_person": [],
"place": 506,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1836-05-31",
"date_sdn": 2391796,
"descr": "Marriage of Ball, Matthias, Jr. and Snyder, Ann Louisa",
"gid": "E3321",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ball, Thomas and \u0428\u0430\u0434\u0440\u0438\u043d, Mary",
"gid": "E2788",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ball, William M. and Moreno, Phebe J.",
"gid": "E3359",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Adam and Michaud, Anna Eva",
"gid": "E3111",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Franciskus and Barnett, Anna Gertrude",
"gid": "E3105",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Michael and L\u00f3pez, Anna Elisabeth",
"gid": "E3088",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Simon and Holland, Anna Margaretha",
"gid": "E3089",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Simon and \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"gid": "E3117",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Simon and \u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432, Anna Maria",
"gid": "E3087",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Theobald and Sutton, Anna Maria",
"gid": "E3112",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Valentin and Frazier, Maria Margaretha",
"gid": "E3109",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Beaulieu, Johann Valentin and Morgan, Elisabeth Margaretha",
"gid": "E3104",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of B\u00e9dard, Swanson and \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Mary",
"gid": "E3063",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Benson, Hugh and Ouellet, Rebecca",
"gid": "E3192",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Benson, Joseph Louis(Sr.) and Simard, Sarah",
"gid": "E2882",
"media": [],
"part_family": [],
"part_person": [],
"place": 774,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Benson, Samuel Sr. and Wong, Jane",
"gid": "E3193",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Benson, Walter and Ellis, Margaret Steel",
"gid": "E3191",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "about 1640",
"date_sdn": 2320058,
"descr": "Marriage of Bishop, Quirinus and Simmons, Maria",
"gid": "E3065",
"media": [],
"part_family": [],
"part_person": [],
"place": 9,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1831-12-15",
"date_sdn": 2390167,
"descr": "Marriage of Blake, George and Cunningham, Sally Sarah",
"gid": "E2745",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1580-11-03",
"date_sdn": 2298450,
"descr": "Marriage of Blanco, Bendicht and Fisher, Bendichtli",
"gid": "E2948",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Blanco, Gerhard and \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2940",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1603",
"date_sdn": 2306544,
"descr": "Marriage of Blanco, Hans and Buchanan, Elsbeth",
"gid": "E2946",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1676-06-15",
"date_sdn": 2333373,
"descr": "Marriage of Blanco, Heinrich and Schmidt, Barbli",
"gid": "E2945",
"media": [],
"part_family": [],
"part_person": [],
"place": 847,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Blanco, Henry and Fournier, Peggy",
"gid": "E3227",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1771-12-31",
"date_sdn": 2368269,
"descr": "Marriage of Blanco, Peter and Glover, Elizabeth",
"gid": "E2941",
"media": [],
"part_family": [],
"part_person": [],
"place": 386,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Blanco, Peter and Leonard, Catherine",
"gid": "E3228",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1836-01-07",
"date_sdn": 2391651,
"descr": "Marriage of Blanco, Rufus and Rodriquez, Mariam",
"gid": "E2808",
"media": [],
"part_family": [],
"part_person": [],
"place": 36,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Boucher, James and Dub\u00e9, Rose",
"gid": "E2755",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Boucher, Michael and Boucher, Honora",
"gid": "E3046",
"media": [],
"part_family": [],
"part_person": [],
"place": 102,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1873-02-18",
"date_sdn": 2405208,
"descr": "Marriage of Boucher, Patrick and Dennis, Susan",
"gid": "E3246",
"media": [],
"part_family": [],
"part_person": [],
"place": 492,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1924-03-04",
"date_sdn": 2423849,
"descr": "Marriage of Boucher, Stephen Francis and Gardner, Mary Jane",
"gid": "E2922",
"media": [],
"part_family": [],
"part_person": [],
"place": 870,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Boucher, Thomas W. and Szyma\u0144ski, Mary",
"gid": "E2759",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1880-02-10",
"date_sdn": 2407756,
"descr": "Marriage of Boucher, William and Walters, Mary",
"gid": "E2923",
"media": [],
"part_family": [],
"part_person": [],
"place": 304,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1875-04-11",
"date_sdn": 2405990,
"descr": "Marriage of Boucher, William Bernard and Reeves, Maria",
"gid": "E3035",
"media": [],
"part_family": [],
"part_person": [],
"place": 685,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Boyd, Capt. and Alvarado, Eliza",
"gid": "E3159",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Boyd, Charles Newton and Jones, Martha Elizabeth",
"gid": "E3336",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1895-05-01",
"date_sdn": 2413315,
"descr": "Marriage of Boyd, Charles Newton and Lessard, Izora",
"gid": "E3120",
"media": [],
"part_family": [],
"part_person": [],
"place": 456,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1725",
"date_sdn": 2351104,
"descr": "Marriage of Brooks, Major Marquis II and Rubio, Winifred",
"gid": "E2961",
"media": [],
"part_family": [],
"part_person": [],
"place": 430,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Brooks, Marquis I and Guzman, Isabella",
"gid": "E3028",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Brooks, William Waller and \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"gid": "E3027",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Brown, ????? and \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Mary Ellen",
"gid": "E2858",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1876-02-28",
"date_sdn": 2406313,
"descr": "Marriage of Bush, James and Boucher, Catherine",
"gid": "E3247",
"media": [],
"part_family": [],
"part_person": [],
"place": 492,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Butler, George and Farmer, Eva",
"gid": "E3100",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Carroll, Jacob A. and \u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Maria Catharina",
"gid": "E2879",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1765",
"date_sdn": 2365714,
"descr": "Marriage of Carroll, Matthias Sr. and \u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432, Eva",
"gid": "E2817",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Chambers, William and Moreno, Leah",
"gid": "E3364",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1514",
"date_sdn": 2274037,
"descr": "Marriage of Christiansen, Christopher and Gomez, Jane Joane",
"gid": "E3000",
"media": [],
"part_family": [],
"part_person": [],
"place": 307,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Christiansen, Christopher and Jones, Ann",
"gid": "E2987",
"media": [],
"part_family": [],
"part_person": [],
"place": 339,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Christiansen, Edward and Abbott, Frances",
"gid": "E2985",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1637-05-10",
"date_sdn": 2319092,
"descr": "Marriage of Christiansen, Edward and Thomas, Elizabeth",
"gid": "E2768",
"media": [],
"part_family": [],
"part_person": [],
"place": 867,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1681",
"date_sdn": 2335034,
"descr": "Marriage of Christiansen, John and Harmon, Martha",
"gid": "E2872",
"media": [],
"part_family": [],
"part_person": [],
"place": 648,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1687-01-16",
"date_sdn": 2337240,
"descr": "Marriage of Christiansen, Joseph and Allen, Joanna",
"gid": "E2842",
"media": [],
"part_family": [],
"part_person": [],
"place": 648,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1662-03-11",
"date_sdn": 2328163,
"descr": "Marriage of Christiansen, Nathaniel and Grenier, Mary",
"gid": "E2769",
"media": [],
"part_family": [],
"part_person": [],
"place": 882,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1693-06-08",
"date_sdn": 2339575,
"descr": "Marriage of Christiansen, Samuel and Alvarado, Mary",
"gid": "E2770",
"media": [],
"part_family": [],
"part_person": [],
"place": 648,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1798-05-31",
"date_sdn": 2377917,
"descr": "Marriage of Cook, John and Rodriquez, Mary",
"gid": "E3239",
"media": [],
"part_family": [],
"part_person": [],
"place": 220,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Cross, Thomas and Page, Anna",
"gid": "E3141",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1801-08-11",
"date_sdn": 2379084,
"descr": "Marriage of Cunningham, William Philip and Park, Susannah",
"gid": "E2744",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1824-01-23",
"date_sdn": 2387284,
"descr": "Marriage of Curry, Kenner S. and Jim\u00e9nez, Rebecca",
"gid": "E3203",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Curtis, John and Gibbs, Margaret",
"gid": "E3050",
"media": [],
"part_family": [],
"part_person": [],
"place": 206,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Davis, Benjamin and Alexander, Mary",
"gid": "E2850",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Davis, John and Knight, Hannah",
"gid": "E2849",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Davis, Jonathan and Mitchell, Mary",
"gid": "E2777",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Desjardins, J. and Reeves, Catherine",
"gid": "E3312",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Diaz, William and \u041a\u043e\u043c\u0430\u0440\u043e\u0432, Jane",
"gid": "E3071",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Diaz, William (Rev.) and Hoffman, Fay",
"gid": "E3074",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Dixon, Thomas and Warner, Mary",
"gid": "E3315",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1835-05-13",
"date_sdn": 2391412,
"descr": "Marriage of Dom\u00ednguez, George and \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2927",
"media": [],
"part_family": [],
"part_person": [],
"place": 12,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1848-07-30",
"date_sdn": 2396239,
"descr": "Marriage of Douglas, Abraham and Alvarado, Nancy",
"gid": "E2747",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Douglas, Abraham and Greer, Mary Wein",
"gid": "E3157",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1806-07-28",
"date_sdn": 2380896,
"descr": "Marriage of Douglas, John Sr. and Larson, Christena Wiseman",
"gid": "E3171",
"media": [],
"part_family": [],
"part_person": [],
"place": 759,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1760",
"date_sdn": 2363887,
"descr": "Marriage of Douglas, John Sr. and Moran, Ann Delilah &#8220;Tilley&#8221;",
"gid": "E2813",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1807-10-15",
"date_sdn": 2381340,
"descr": "Marriage of Douglas, Joseph and Carroll, Grace",
"gid": "E2818",
"media": [],
"part_family": [],
"part_person": [],
"place": 689,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1796-03-14",
"date_sdn": 2377109,
"descr": "Marriage of Doyle, Robert Gove and Diaz, Mary Polly",
"gid": "E3303",
"media": [],
"part_family": [],
"part_person": [],
"place": 808,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Dub\u00e9, Jacob and Farmer, Anna Marie",
"gid": "E3097",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Erickson, Charles and \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lucy",
"gid": "E3064",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1839-04-11",
"date_sdn": 2392841,
"descr": "Marriage of Farmer, Benjamin H. and Mills, Isabella",
"gid": "E3091",
"media": [],
"part_family": [],
"part_person": [],
"place": 44,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, George William and Bradley, Mary",
"gid": "E3095",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, Jacob and \u041c\u043e\u0440\u043e\u0437\u043e\u0432, Mary Elizabeth",
"gid": "E3086",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, Michael and Dub\u00e9, Elizabeth",
"gid": "E3103",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, Peter Simon and Bowen, Elizabeth",
"gid": "E3098",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, Simon and \u0411\u0430\u0440\u0430\u043d\u043e\u0432, Susan",
"gid": "E3090",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Farmer, Valentine and Miller, Anna Catherine",
"gid": "E3094",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1863-04-27",
"date_sdn": 2401623,
"descr": "Marriage of Fernandez, Thomas and Ortega, Catherine",
"gid": "E3380",
"media": [],
"part_family": [],
"part_person": [],
"place": 833,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Floyd, Henry and Benson, Nancy",
"gid": "E3196",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1875-02-04",
"date_sdn": 2405924,
"descr": "Marriage of Floyd, John Morgan and Carr, Zelpha Josephine",
"gid": "E3032",
"media": [],
"part_family": [],
"part_person": [],
"place": 207,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ford and Moreno, Elizabeth",
"gid": "E3362",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ford, Samuel and Farmer, Catharine",
"gid": "E3101",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1879-09-17",
"date_sdn": 2407610,
"descr": "Marriage of Ford, Stephen Jacob and Garner, Iola Elizabeth Betty",
"gid": "E3033",
"media": [],
"part_family": [],
"part_person": [],
"place": 823,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Ford, William and Payne, Winifred",
"gid": "E3290",
"media": [],
"part_family": [],
"part_person": [],
"place": 194,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1691-05-11",
"date_sdn": 2338816,
"descr": "Marriage of Fortin, Matthias and Baker, Margaret",
"gid": "E2954",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1577-08-28",
"date_sdn": 2297287,
"descr": "Marriage of Foster, John and Ryan, Elizabeth",
"gid": "E3314",
"media": [],
"part_family": [],
"part_person": [],
"place": 869,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Foster, John and Ryan, Elizabeth",
"gid": "E2995",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1551",
"date_sdn": 2287551,
"descr": "Marriage of Foster, Thomas and Koz\u0142owski, Margret",
"gid": "E3001",
"media": [],
"part_family": [],
"part_person": [],
"place": 869,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1615",
"date_sdn": 2310927,
"descr": "Marriage of Foster, Thomas and Spencer, Ann",
"gid": "E2983",
"media": [],
"part_family": [],
"part_person": [],
"place": 19,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Foster, William and Sanders, Mary",
"gid": "E2841",
"media": [],
"part_family": [],
"part_person": [],
"place": 142,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1823-01-09",
"date_sdn": 2386905,
"descr": "Marriage of Fox, David and Green, Frances",
"gid": "E3285",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Fox, Jacob, Sr. and Palmer, Sarah",
"gid": "E2765",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Fox, Samuel and Mason, Susannah",
"gid": "E2846",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Fox, William and Mason, Hannah",
"gid": "E2845",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Frazier, Johann Adam and Hicks, Anna Eva",
"gid": "E3106",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Frazier, Johann Walter and Beaulieu, Anna Margaretha",
"gid": "E3107",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Gagn\u00e9, Thomas and Reeves, Ann",
"gid": "E3311",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1907-06-02",
"date_sdn": 2417729,
"descr": "Marriage of Garner, Daniel Webster and Jackson, Cora Ellen",
"gid": "E3030",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Garner, Jesse V. and Taylor, Viola",
"gid": "E2823",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [
1615
],
"date": "1875-04-01",
"date_sdn": 2405980,
"descr": "Marriage of Garner, Lewis Anderson and Martel, Luella Jacques",
"gid": "E2815",
"media": [],
"part_family": [],
"part_person": [],
"place": 622,
"text": "<div>\n<p>\n<b>Age</b>: 23\n</p>\n</div>",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1880-11-25",
"date_sdn": 2408045,
"descr": "Marriage of Garner, Robert F. and Cannon, Mary Jane",
"gid": "E3034",
"media": [],
"part_family": [],
"part_person": [],
"place": 622,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1849-10-04",
"date_sdn": 2396670,
"descr": "Marriage of Garner, Robert W. and Zieli\u0144ski, Phoebe Emily",
"gid": "E2825",
"media": [],
"part_family": [],
"part_person": [],
"place": 622,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Gibson, Mr. and James, Mary",
"gid": "E3173",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Gilbert, ?? and L\u00e9vesque, Wilma",
"gid": "E3121",
"media": [],
"part_family": [],
"part_person": [],
"place": 675,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Gonz\u00e1lez and Ball, Martha",
"gid": "E3350",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1590-11-01",
"date_sdn": 2302100,
"descr": "Marriage of Goodman, Ralph and Powell, Martha",
"gid": "E3060",
"media": [],
"part_family": [],
"part_person": [],
"place": 524,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1674-01-16",
"date_sdn": 2332492,
"descr": "Marriage of Green, Edward and Lefebvre, Mary",
"gid": "E2773",
"media": [],
"part_family": [],
"part_person": [],
"place": 638,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1701-04-06",
"date_sdn": 2342433,
"descr": "Marriage of Green, Edward and \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Christina",
"gid": "E2776",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1759-01-17",
"date_sdn": 2363538,
"descr": "Marriage of Green, James and Christiansen, Frances",
"gid": "E2778",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1787-02-10",
"date_sdn": 2373789,
"descr": "Marriage of Green, Randolph and Davis, Sabra",
"gid": "E2779",
"media": [],
"part_family": [],
"part_person": [],
"place": 142,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Green, Yelverton and Robertson, Elizabeth",
"gid": "E2909",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1628",
"date_sdn": 2315675,
"descr": "Marriage of Grenier, Joseph and Peters, Rose",
"gid": "E2874",
"media": [],
"part_family": [],
"part_person": [],
"place": 526,
"text": "",
"type": "Marriage"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Gutierrez, Thomas and Boucher, Nora A.",
"gid": "E2758",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Hanson, Robert and Schwartz, Helewisa",
"gid": "E2991",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Hardy, Jakob and Beaulieu, Anna Maria",
"gid": "E3110",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1692-12-28",
"date_sdn": 2339413,
"descr": "Marriage of Harrison, Edward and Allen, Sarah",
"gid": "E3325",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of H\u00e9bert, Mr. and Page, Mary",
"gid": "E3205",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Hernandez, John and Norris, Elizabeth",
"gid": "E3334",
"media": [],
"part_family": [],
"part_person": [],
"place": 287,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Hern\u00e1ndez, Thomas and Douglas, Elizabeth",
"gid": "E3166",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1881-10-04",
"date_sdn": 2408358,
"descr": "Marriage of Hines and Douglas, Eliza Jane",
"gid": "E3156",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Hunt, Isaac and \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Nancy Ann",
"gid": "E3296",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Hugh Jr. and Wi\u015bniewski, D.",
"gid": "E3210",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Isaac and Andersen, Martha",
"gid": "E3212",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Joseph and Floyd, Nancy",
"gid": "E3211",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Robert and Pratt, Sarah",
"gid": "E3052",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Thomas and Marshall, Kate Teel",
"gid": "E3214",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Thomas and Parent, Betsy",
"gid": "E3213",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Walter Crockett and Hern\u00e1ndez, Nancy",
"gid": "E3216",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of James, Walter Crockett and \u0417\u0430\u0445\u0430\u0440\u043e\u0432, Margaret",
"gid": "E3217",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1871-03-22",
"date_sdn": 2404509,
"descr": "Marriage of Jankowski, George and Page, Margaret",
"gid": "E3128",
"media": [],
"part_family": [],
"part_person": [],
"place": 76,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1629-02-20",
"date_sdn": 2316091,
"descr": "Marriage of Jenkins, Peter and Marsh, Margaret",
"gid": "E2950",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1820-04-26",
"date_sdn": 2385917,
"descr": "Marriage of Jim\u00e9nez, Andrew and Palmer, Sarah",
"gid": "E3200",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1828-07-20",
"date_sdn": 2388924,
"descr": "Marriage of Jim\u00e9nez, Cornelius and Blair, Jane",
"gid": "E3204",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1851-06-05",
"date_sdn": 2397279,
"descr": "Marriage of Jim\u00e9nez, George Henry, III and Blake, M. Susannah",
"gid": "E2793",
"media": [],
"part_family": [],
"part_person": [],
"place": 698,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Jim\u00e9nez, George Henry, Jr. and Silva, Mildred",
"gid": "E2746",
"media": [],
"part_family": [],
"part_person": [],
"place": 191,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1787-11-08",
"date_sdn": 2374060,
"descr": "Marriage of Jim\u00e9nez, George, Sr. and Henry, Elizabeth",
"gid": "E2894",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1818-09-09",
"date_sdn": 2385322,
"descr": "Marriage of Jim\u00e9nez, John and Palmer, Mary",
"gid": "E3201",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Johnson, Henry and Sparks, Catherine",
"gid": "E2814",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Jones, Hugh and \u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432, ??",
"gid": "E2986",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Joseph, Alfred and Moreno, Minerva",
"gid": "E3356",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kami\u0144ski and Reed, Jane",
"gid": "E3278",
"media": [],
"part_family": [],
"part_person": [],
"place": 595,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kelley, Thomas and Douglas, Catherine",
"gid": "E3167",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kim, Frank and Kristensen, Catherine Virginia",
"gid": "E2792",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1343-10-00",
"date_sdn": 2211854,
"descr": "Marriage of Knudsen, John and Huff, Isabel",
"gid": "E2998",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Knudsen, Ralph and Huff, Isabel",
"gid": "E2997",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Knudsen, Ralph and Walton, Theophania(Tiffany)",
"gid": "E2996",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Knudsen, Ranulf and Huff, Bertrama",
"gid": "E2994",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Knudsen, Robert and Schwartz, Helewisa",
"gid": "E2993",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kowalski, John and Wells, Alice",
"gid": "E3047",
"media": [],
"part_family": [],
"part_person": [],
"place": 499,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kowalski, Thomas and Santos, Alice",
"gid": "E3048",
"media": [],
"part_family": [],
"part_person": [],
"place": 201,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Kristensen, John Francis&#8220;Chick&#8221; and \u4f0a\u85e4, Mary",
"gid": "E3039",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Landry, Michael Edward and Brady, CatherineJosephine",
"gid": "E3375",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lane, Remo and Barnes, Ernestina",
"gid": "E2891",
"media": [],
"part_family": [],
"part_person": [],
"place": 55,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lapointe, John and Madsen, Catherine",
"gid": "E3067",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1817",
"date_sdn": 2384706,
"descr": "Marriage of Lavoie, Henry and James, Patsy",
"gid": "E3175",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1650-12-11",
"date_sdn": 2324055,
"descr": "Marriage of Lefebvre, Joseph and Gregory, Mary",
"gid": "E2771",
"media": [],
"part_family": [],
"part_person": [],
"place": 638,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lefebvre, Robert and \u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"gid": "E2875",
"media": [],
"part_family": [],
"part_person": [],
"place": 224,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lessard and Castro, ???",
"gid": "E3245",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lessard, ??? and Castro, ???",
"gid": "E2926",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1894-10-17",
"date_sdn": 2413119,
"descr": "Marriage of Lessard, Ira Willis and Jim\u00e9nez, Lucinda Ellen",
"gid": "E2783",
"media": [],
"part_family": [],
"part_person": [],
"place": 768,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1868-03-24",
"date_sdn": 2403416,
"descr": "Marriage of Lessard, Isaac and Dom\u00ednguez, Mary E.",
"gid": "E3393",
"media": [],
"part_family": [],
"part_person": [],
"place": 397,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1921-02-16",
"date_sdn": 2422737,
"descr": "Marriage of Lessard, Ralph Raymond and Davidson, Bernice",
"gid": "E2822",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1888-12-19",
"date_sdn": 2410991,
"descr": "Marriage of L\u00e9vesque, James W. and Lessard, Emma Jane",
"gid": "E3119",
"media": [],
"part_family": [],
"part_person": [],
"place": 768,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Lewandowski, Thomas and Jankowski, Isabella Belle",
"gid": "E3130",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Little, O. D. and Webb, Anna Mabel",
"gid": "E3233",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of L\u00f3pez, Hans Valentin and Beaulieu, Anna Ottilia",
"gid": "E3114",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1860-10-00",
"date_sdn": 2400685,
"descr": "Marriage of Mar\u00edn, Alfred Franklin(Frank) and Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E3025",
"media": [],
"part_family": [],
"part_person": [],
"place": 70,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1885-10-15",
"date_sdn": 2409830,
"descr": "Marriage of Mar\u00edn, Moses Wallace and Landry, Eleanor (Nellie) Therese",
"gid": "E3014",
"media": [],
"part_family": [],
"part_person": [],
"place": 878,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1920-06-23",
"date_sdn": 2422499,
"descr": "Marriage of Mar\u00edn, Walter Matthew and Boucher, Mary Cecilia",
"gid": "E3003",
"media": [],
"part_family": [],
"part_person": [],
"place": 878,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1840-04-04",
"date_sdn": 2393200,
"descr": "Marriage of Martel, Henry and H\u00e9bert, Ruth Ann",
"gid": "E2967",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Massey, John and \u041c\u0430\u043b\u044c\u0446\u0435\u0432, Joan",
"gid": "E2999",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Maxwell, William and Nielsen, Elizabeth",
"gid": "E2787",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Mazur, William and Crawford, Margaret",
"gid": "E3056",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1827-09-13",
"date_sdn": 2388613,
"descr": "Marriage of McCarthy, Valentine Thomas and Jim\u00e9nez, Sarah",
"gid": "E3202",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1939",
"date_sdn": 2429265,
"descr": "Marriage of McCoy, Francis and Reed, Sarah",
"gid": "E3260",
"media": [],
"part_family": [],
"part_person": [],
"place": 454,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1725",
"date_sdn": 2351104,
"descr": "Marriage of Mendoza, James and Allen, Abigail",
"gid": "E3328",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Michaud, Valentin and Beaulieu, Anna Eva",
"gid": "E3115",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Molina, Robert",
"gid": "E3051",
"media": [],
"part_family": [],
"part_person": [],
"place": 499,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1813-09-02",
"date_sdn": 2383489,
"descr": "Marriage of Moreno, Aaron and \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E2789",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Moreno, Christian and Price, Mary",
"gid": "E3361",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Moreno, Christian, I and Mann, Agnes",
"gid": "E2855",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1855-07-12",
"date_sdn": 2398777,
"descr": "Marriage of Moreno, Darius and Craig, Mary J.",
"gid": "E3358",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Moreno, Esau and Caron, Mary E.",
"gid": "E3366",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1749-04-02",
"date_sdn": 2359961,
"descr": "Marriage of Moreno, Johann Christian II and \u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"gid": "E2856",
"media": [],
"part_family": [],
"part_person": [],
"place": 147,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1775-03-21",
"date_sdn": 2369445,
"descr": "Marriage of Moreno, Maj. Christopher and Bass, Mary",
"gid": "E2786",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1858-04-22",
"date_sdn": 2399792,
"descr": "Marriage of Moreno, Solon and Perkins, Lydia",
"gid": "E3357",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1840-11-05",
"date_sdn": 2393415,
"descr": "Marriage of Moreno, Thomas H. and D\u0105browski, Letitia C.",
"gid": "E3351",
"media": [],
"part_family": [],
"part_person": [],
"place": 270,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1818-09-22",
"date_sdn": 2385335,
"descr": "Marriage of Morris, Cyrus and Graves, Martha",
"gid": "E2820",
"media": [],
"part_family": [],
"part_person": [],
"place": 306,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Mullins, Robert? and Houston, Ellender",
"gid": "E3015",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Munoz, Shadrach M. and Mar\u00edn, Nancy H.",
"gid": "E3324",
"media": [],
"part_family": [],
"part_person": [],
"place": 477,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Myers, James and Boucher, Catherine",
"gid": "E2924",
"media": [],
"part_family": [],
"part_person": [],
"place": 739,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Neal, James and Page, Elizabeth",
"gid": "E3125",
"media": [],
"part_family": [],
"part_person": [],
"place": 619,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1904-02-17",
"date_sdn": 2416528,
"descr": "Marriage of Neal, John and Schneider, Belle Irene",
"gid": "E3151",
"media": [],
"part_family": [],
"part_person": [],
"place": 256,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1666-01-12",
"date_sdn": 2329566,
"descr": "Marriage of Norris, John and Howell, Mary (Sarah)",
"gid": "E2873",
"media": [],
"part_family": [],
"part_person": [],
"place": 65,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1689",
"date_sdn": 2337956,
"descr": "Marriage of Norris, John and \u041d\u043e\u0432\u0438\u043a\u043e\u0432, Sarah",
"gid": "E3333",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Olson, ??????? and Mar\u00edn, Alice",
"gid": "E3383",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Owens, Wilford and Jankowski, Matilda",
"gid": "E3131",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1908-09-01",
"date_sdn": 2418186,
"descr": "Marriage of Page, Andrew Vincent and Zimmerman, Edith Irene",
"gid": "E2919",
"media": [],
"part_family": [],
"part_person": [],
"place": 407,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1882-12-26",
"date_sdn": 2408806,
"descr": "Marriage of Page, David and Douglas, Elizabeth",
"gid": "E3122",
"media": [],
"part_family": [],
"part_person": [],
"place": 164,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1908",
"date_sdn": 2417942,
"descr": "Marriage of Page, John James and Adkins, Minnie",
"gid": "E3136",
"media": [],
"part_family": [],
"part_person": [],
"place": 619,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Page, John James and Mcdaniel, Margaret",
"gid": "E3135",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Page, Mr. and James, Martha",
"gid": "E3174",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Page, Richard C. and Rodriguez, Helen M.",
"gid": "E3222",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Page, Robert and Neal, Belle",
"gid": "E3206",
"media": [],
"part_family": [],
"part_person": [],
"place": 605,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Palmer, Robert and \u041f\u043e\u043f\u043e\u0432, ???????",
"gid": "E2766",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Parent, Capt.Jacob C. and James, Jane",
"gid": "E2749",
"media": [],
"part_family": [],
"part_person": [],
"place": 191,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Parent, Montgomery and Alvarado, Patsy",
"gid": "E3180",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1888-08-23",
"date_sdn": 2410873,
"descr": "Marriage of Parker, Frank R. and Garner, Anetta",
"gid": "E3036",
"media": [],
"part_family": [],
"part_person": [],
"place": 128,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Parsons, Henry and Douglas, Ellen",
"gid": "E3168",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Patterson, George and Farmer, Elizabeth",
"gid": "E3099",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Patton, Adolph and Moreno, Lelia L.",
"gid": "E3360",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1840-05-04",
"date_sdn": 2393230,
"descr": "Marriage of Payne, Alexander and Kami\u0144ski, Elizabeth",
"gid": "E3292",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1818-10-20",
"date_sdn": 2385363,
"descr": "Marriage of Payne, Alexander and Salazar, Catherine",
"gid": "E3291",
"media": [],
"part_family": [],
"part_person": [],
"place": 315,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1843-01-27",
"date_sdn": 2394228,
"descr": "Marriage of Payne, Fielding and Lawrence, Dorcas C.",
"gid": "E3289",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1783-12-15",
"date_sdn": 2372636,
"descr": "Marriage of Payne, George and Diaz, Frances",
"gid": "E2965",
"media": [],
"part_family": [],
"part_person": [],
"place": 194,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Payne, Leonard and Hall, Elizabeth",
"gid": "E2962",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Pedersen, William and Benson, Elizabeth",
"gid": "E3195",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Perry, M. and Reeves, Elizabeth",
"gid": "E3309",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1596",
"date_sdn": 2303987,
"descr": "Marriage of Peters, George Sr. and Ramsey, Joan",
"gid": "E2910",
"media": [],
"part_family": [],
"part_person": [],
"place": 340,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1632",
"date_sdn": 2317136,
"descr": "Marriage of Piotrowski, John and Todd, Olive",
"gid": "E2860",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1813-11-07",
"date_sdn": 2383555,
"descr": "Marriage of Poole, Dr. John and James, Jane",
"gid": "E3179",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1911-11-22",
"date_sdn": 2419363,
"descr": "Marriage of Pope, John and Kristensen, Mary Elizabeth",
"gid": "E2791",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1849-11-29",
"date_sdn": 2396726,
"descr": "Marriage of Porter, David and Moreno, Mary H.",
"gid": "E3354",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Quinn, Abraham and Blanco, Malvina",
"gid": "E3225",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1875-10-07",
"date_sdn": 2406169,
"descr": "Marriage of Ram\u00edrez, John B. and Garner, Rebecca Catharine",
"gid": "E3031",
"media": [],
"part_family": [],
"part_person": [],
"place": 622,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1879-07-25",
"date_sdn": 2407556,
"descr": "Marriage of Reed, Edward and Reed, Ellen",
"gid": "E3038",
"media": [],
"part_family": [],
"part_person": [],
"place": 303,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1903",
"date_sdn": 2416116,
"descr": "Marriage of Reed, Francis Vincent and \u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"gid": "E3041",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1883-09-12",
"date_sdn": 2409066,
"descr": "Marriage of Reed, Francis Vincent and \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E3102",
"media": [],
"part_family": [],
"part_person": [],
"place": 608,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1870-05-24",
"date_sdn": 2404207,
"descr": "Marriage of Reed, John and Bernier, Margaret",
"gid": "E3044",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reed, Matthew and Gibbs, Mary",
"gid": "E3261",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reed, Michael and Goodwin, Alice",
"gid": "E3279",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reed, Patrick and Gibbs, Elizabeth",
"gid": "E3276",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reed, Peter and \u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432, Hanora",
"gid": "E3262",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reed, Peter James? and Reed, Catherine",
"gid": "E3277",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1847-08-15",
"date_sdn": 2395889,
"descr": "Marriage of Reeves, James and Meyer, Catherine",
"gid": "E2810",
"media": [],
"part_family": [],
"part_person": [],
"place": 742,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1877-08-01",
"date_sdn": 2406833,
"descr": "Marriage of Reeves, John and Flowers, Mary A.",
"gid": "E3313",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reid, Hans and \u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"gid": "E2952",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Reynolds, John and Newman, Margaret",
"gid": "E3293",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1588-10-29",
"date_sdn": 2301367,
"descr": "Marriage of Reynolds, John and Stevens, Elizabeth",
"gid": "E3061",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1665",
"date_sdn": 2329190,
"descr": "Marriage of Reynolds, Nicholas and Murray, Susannah",
"gid": "E3054",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1849-02-02",
"date_sdn": 2396426,
"descr": "Marriage of Rodriquez, Mordica and \u0412\u043e\u0440\u043e\u043d\u043e\u0432, Katherine",
"gid": "E3242",
"media": [],
"part_family": [],
"part_person": [],
"place": 47,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1793-10-20",
"date_sdn": 2376233,
"descr": "Marriage of Rodriquez, Mordica and \u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"gid": "E3240",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1806-10-17",
"date_sdn": 2380977,
"descr": "Marriage of Rodriquez, Richard and \u0416\u0443\u043a\u043e\u0432, Hannah",
"gid": "E3243",
"media": [],
"part_family": [],
"part_person": [],
"place": 356,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Romero, Ernest and Jankowski, Minnie",
"gid": "E3134",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1833-09-19",
"date_sdn": 2390811,
"descr": "Marriage of Roy, Prince Alfred and Mar\u00edn, Frances Coppage",
"gid": "E3323",
"media": [],
"part_family": [],
"part_person": [],
"place": 194,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Sanchez, John and Curtis, Margaret",
"gid": "E3049",
"media": [],
"part_family": [],
"part_person": [],
"place": 206,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Sanders, Henry and Rose, Ann",
"gid": "E2982",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Santiago, Mathias and James, Molly",
"gid": "E3178",
"media": [],
"part_family": [],
"part_person": [],
"place": 605,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Schneider and Neal, Margaret",
"gid": "E3126",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1811-06-21",
"date_sdn": 2382685,
"descr": "Marriage of Schultz, John and Payne, Jane Coppage",
"gid": "E2960",
"media": [],
"part_family": [],
"part_person": [],
"place": 194,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "5",
"date_sdn": 1722887,
"descr": "Marriage of Schultz, Rev.Isaac and Turner, Mary",
"gid": "E2957",
"media": [],
"part_family": [],
"part_person": [],
"place": 630,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1829-11-19",
"date_sdn": 2389411,
"descr": "Marriage of Serrano, Archibald and Delgado, Catherine",
"gid": "E3224",
"media": [],
"part_family": [],
"part_person": [],
"place": 663,
"text": "",
"type": "Marriage"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Shelton, Peter and Farmer, Caroline",
"gid": "E3092",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Steele, Valentine and Beaulieu, Anna Elisabeth",
"gid": "E3108",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Stephens, Adam and Blanco, Anna Maria",
"gid": "E3229",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Strickland, Col. Robert and James, Patsy",
"gid": "E3215",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Swanson, William and Jensen, Elizabeth",
"gid": "E3072",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Taylor, Jacob and Farmer, Susanna",
"gid": "E3096",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Terry, J. and Reeves, Bridget",
"gid": "E3310",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1605-11-10",
"date_sdn": 2307588,
"descr": "Marriage of Thomas, Elder Thomas and Barrett, Anne",
"gid": "E2767",
"media": [],
"part_family": [],
"part_person": [],
"place": 349,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Thomsen, new and Farmer, Elizabeth",
"gid": "E3093",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Thornton, Arthur Otto and Mar\u00edn, Lilla Estella",
"gid": "E3220",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1759-07-00",
"date_sdn": 2363703,
"descr": "Marriage of Todd, Charles and Cole, Eurydice",
"gid": "E2861",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1843-09-20",
"date_sdn": 2394464,
"descr": "Marriage of Todd, George W. and Morris, Jane",
"gid": "E2797",
"media": [],
"part_family": [],
"part_person": [],
"place": 392,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Todd, Hodges and Piotrowski, Lucy",
"gid": "E2800",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Todd, John and Warner, Elizabeth",
"gid": "E2799",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1871-09-21",
"date_sdn": 2404692,
"descr": "Marriage of Todd, John M. and Farmer, Elizabeth Ellen",
"gid": "E2798",
"media": [],
"part_family": [],
"part_person": [],
"place": 402,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1819",
"date_sdn": 2385436,
"descr": "Marriage of Todd, William and \u6e21\u8fba, Mary (Polly)",
"gid": "E2801",
"media": [],
"part_family": [],
"part_person": [],
"place": 641,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Wallace, Abraham and Greene, Marcy",
"gid": "E2851",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1705-05-22",
"date_sdn": 2343940,
"descr": "Marriage of Warner, Capt. Andrew and Christiansen, Hannah",
"gid": "E2843",
"media": [],
"part_family": [],
"part_person": [],
"place": 422,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Warner, Capt. Francis and Ingram, Mary",
"gid": "E2867",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1677-11-13",
"date_sdn": 2333889,
"descr": "Marriage of Warner, Capt. George and Alvarez, Mary",
"gid": "E2763",
"media": [],
"part_family": [],
"part_person": [],
"place": 458,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Warner, Daniel and Higgins, Charity",
"gid": "E3316",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1736-09-22",
"date_sdn": 2355386,
"descr": "Marriage of Warner, Edward and Anderson, Mary Molly",
"gid": "E2762",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Warner, George and Nichols, Elizabeth",
"gid": "E3318",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1714",
"date_sdn": 2347086,
"descr": "Marriage of Warner, Johnathon and Montgomery, Mary",
"gid": "E3320",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1911-04-25",
"date_sdn": 2419152,
"descr": "Marriage of Warner, Martin Bogarte and Klein, Alma Katherine",
"gid": "E2761",
"media": [],
"part_family": [],
"part_person": [],
"place": 331,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1920-02-22",
"date_sdn": 2422377,
"descr": "Marriage of Warner, Martin Bogarte and Page, Clara Belle",
"gid": "E2750",
"media": [],
"part_family": [],
"part_person": [],
"place": 607,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Warner, Noah and Burns, Margaret",
"gid": "E3176",
"media": [],
"part_family": [],
"part_person": [],
"place": 357,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1845-01-01",
"date_sdn": 2394933,
"descr": "Marriage of Warner, Piatt D. and Fox, Julia Colville",
"gid": "E3392",
"media": [],
"part_family": [],
"part_person": [],
"place": 617,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Warner, Thomas and Black, Jane",
"gid": "E2984",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1888-08-09",
"date_sdn": 2410859,
"descr": "Marriage of Warner, Warren W. and Ball, Abigail",
"gid": "E3068",
"media": [],
"part_family": [],
"part_person": [],
"place": 746,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Waters and Webb, Mary",
"gid": "E3348",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Waters, John and Webb, Mary",
"gid": "E3081",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1901-12-12",
"date_sdn": 2415731,
"descr": "Marriage of Waters, William and Neal, Matilda",
"gid": "E3127",
"media": [],
"part_family": [],
"part_person": [],
"place": 616,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "before 1800",
"date_sdn": 2378497,
"descr": "Marriage of Webb, Alex and \u041c\u0430\u043a\u0430\u0440\u043e\u0432, Nancy",
"gid": "E3079",
"media": [],
"part_family": [],
"part_person": [],
"place": 119,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Webb, Andrew and Webb, Margaret Margarite?",
"gid": "E2977",
"media": [],
"part_family": [],
"part_person": [],
"place": 203,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Webb, Elias and Gibbs, Nancy",
"gid": "E3078",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1896-03-05",
"date_sdn": 2413624,
"descr": "Marriage of Webb, Francis Irvin and Todd, Louella Jane",
"gid": "E3371",
"media": [],
"part_family": [],
"part_person": [],
"place": 478,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1880-12-14",
"date_sdn": 2408064,
"descr": "Marriage of Webb, James Marshall and Ballard, Judith Ellen",
"gid": "E3084",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1867-04-24",
"date_sdn": 2403081,
"descr": "Marriage of Webb, Livingstone Martin and Blanco, Lucinda Catherine",
"gid": "E2807",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Webb, William John and Wagner, Martha Ann",
"gid": "E3083",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Webster, Conrad and Castillo, Margaretha",
"gid": "E3066",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "1815-09-01",
"date_sdn": 2384218,
"descr": "Marriage of Williams, Thomas Jr. and Jim\u00e9nez, Elizabeth",
"gid": "E3199",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1575-09-02",
"date_sdn": 2296561,
"descr": "Marriage of Wise, Thomas and Ramos, Mary",
"gid": "E2876",
"media": [],
"part_family": [],
"part_person": [],
"place": 110,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Wood, Peter and Gibbs, Lucy",
"gid": "E3300",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of Woods, James and \u0417\u044b\u0440\u044f\u043d\u043e\u0432, Mary",
"gid": "E3295",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Johann Adam and Beaulieu, Anna Margaretha",
"gid": "E3116",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432, Jacob and Benson, Mary",
"gid": "E3194",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0410\u043d\u0434\u0440\u0435\u0435\u0432, William and Douglas, Susan",
"gid": "E3170",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1680-01-12",
"date_sdn": 2334679,
"descr": "Marriage of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob and Su\u00e1rez, Marie",
"gid": "E2953",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1715-12-09",
"date_sdn": 2347793,
"descr": "Marriage of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob and Reid, Anna Catherina",
"gid": "E2955",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1877-09-26",
"date_sdn": 2406889,
"descr": "Marriage of \u0412\u043b\u0430\u0441\u043e\u0432, John and Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E3118",
"media": [],
"part_family": [],
"part_person": [],
"place": 183,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0414\u0430\u0432\u044b\u0434\u043e\u0432 and Ball, Jane",
"gid": "E3349",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1803-01-31",
"date_sdn": 2379622,
"descr": "Marriage of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr. and Woods, Mary Polly",
"gid": "E3302",
"media": [],
"part_family": [],
"part_person": [],
"place": 808,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr. and Lapointe, Lucy aka Sarah",
"gid": "E2975",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William and Page, Sarah",
"gid": "E3062",
"media": [],
"part_family": [],
"part_person": [],
"place": 157,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William and Wood, Polly",
"gid": "E3299",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1740",
"date_sdn": 2356582,
"descr": "Marriage of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph and Rice, Virginia Margaret",
"gid": "E2784",
"media": [],
"part_family": [],
"part_person": [],
"place": 885,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1782-06-20",
"date_sdn": 2372093,
"descr": "Marriage of \u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr. and Adkins, Martha",
"gid": "E2785",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1821-12-27",
"date_sdn": 2386527,
"descr": "Marriage of \u0417\u044b\u043a\u043e\u0432, John and Hopkins, Mary Eve",
"gid": "E3381",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041b\u0435\u0431\u0435\u0434\u0435\u0432, Trustum and Warner, Johanna",
"gid": "E3317",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041b\u043e\u0433\u0438\u043d\u043e\u0432, Guy and Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E2794",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041c\u0430\u043a\u0430\u0440\u043e\u0432, Joseph",
"gid": "E3082",
"media": [],
"part_family": [],
"part_person": [],
"place": 119,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432 and Allen, Abigail",
"gid": "E3327",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, George and \u0416\u0443\u043a\u043e\u0432, Annabell Gordon",
"gid": "E2774",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "about 1715",
"date_sdn": 2347451,
"descr": "Marriage of \u041d\u043e\u0432\u0438\u043a\u043e\u0432, Thomas and Allen, Rachel",
"gid": "E3331",
"media": [],
"part_family": [],
"part_person": [],
"place": 793,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041f\u0430\u0432\u043b\u043e\u0432, Reuben and Douglas, Lucinda J.",
"gid": "E3169",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph and Rodr\u00edguez, Agatha",
"gid": "E2990",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0420\u043e\u043c\u0430\u043d\u043e\u0432, John and Moreno, Delilah",
"gid": "E3365",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Eudo and Rios, Agnes",
"gid": "E2988",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald and Gray, Beatrix",
"gid": "E2989",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0422\u0430\u0440\u0430\u0441\u043e\u0432, Simon and Todd, Flora Belle",
"gid": "E3385",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1854-02-04",
"date_sdn": 2398254,
"descr": "Marriage of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses and Holt, Bridget",
"gid": "E2863",
"media": [],
"part_family": [],
"part_person": [],
"place": 608,
"text": "",
"type": "Marriage"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas and Jankowski, Margaret Jane &#8220;Maggie&#8221;",
"gid": "E3132",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George and Daniels, Phoebe",
"gid": "E2966",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1806-05-20",
"date_sdn": 2380827,
"descr": "Marriage of \u4e2d\u6751, Thomas and Jim\u00e9nez, Polly Mary",
"gid": "E3197",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u5c71\u672c, Antoine Desaure Perronett and \u0421\u043e\u043a\u043e\u043b\u043e\u0432, Louise",
"gid": "E3075",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "1701-03-05",
"date_sdn": 2342401,
"descr": "Marriage of \u658e\u85e4, Zariakius Cyriacus and Bishop, Anna Barbara",
"gid": "E2878",
"media": [],
"part_family": [],
"part_person": [],
"place": 350,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u9234\u6728, Allen and Mar\u00edn, Alice",
"gid": "E3382",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Marriage of \u9234\u6728, Robert B. and Blanco, Mary F.",
"gid": "E3235",
"media": [],
"part_family": [],
"part_person": [],
"place": -1,
"text": "",
"type": "Marriage"
}
]
]
Dwr.ScriptLoaded('dwr_db_F_events_0.js');
