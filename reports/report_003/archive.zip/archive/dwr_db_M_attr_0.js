// This file is generated

M_attr_0 = [
[],
[],
[
{
"cita": [
1621
],
"note": "",
"type": "Description",
"value": "This seems to be a photo of a relative"
}
],
[],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_M_attr_0.js');
