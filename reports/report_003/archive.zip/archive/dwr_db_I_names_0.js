// This file is generated

I_names_0 = [
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0623\u062d\u0645\u062f",
"given": "\u0623\u062d\u0645\u062f",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u062e\u062f\u064a\u062c\u0629",
"given": "\u062e\u062f\u064a\u062c\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0631\u064a\u062d\u0627\u0646\u0629",
"given": "\u0631\u064a\u062d\u0627\u0646\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0635\u0627\u0644\u062d",
"given": "\u0635\u0627\u0644\u062d",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0639\u0627\u0626\u0634\u0629",
"given": "\u0639\u0627\u0626\u0634\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0639\u0628\u062f \u0627\u0644\u0644\u0647",
"given": "\u0639\u0628\u062f\u00a0\u0627\u0644\u0644\u0647",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0645\u062d\u0645\u062f",
"given": "\u0645\u062d\u0645\u062f",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Abbott, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Abbott"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adams, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adams, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Minnie",
"given": "Minnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Robert Sr.",
"given": "Robert Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Aguilar, Eleanor",
"given": "Eleanor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Aguilar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Aguilar, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Aguilar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alexander, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alexander"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Abigail",
"given": "Abigail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Enos",
"given": "Enos",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Gershom",
"given": "Gershom",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Joanna",
"given": "Joanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Job",
"given": "Job",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Jonathan",
"given": "Jonathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Lediah",
"given": "Lediah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Lydia",
"given": "Lydia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Rachel",
"given": "Rachel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Col. Charles",
"given": "Col. Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Eliza",
"given": "Eliza",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Franklin",
"given": "Franklin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jeffrey",
"given": "Jeffrey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Marshall",
"given": "Marshall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Thomas C.",
"given": "Thomas C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarez, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Mary Molly",
"given": "Mary Molly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Rev. John",
"given": "Rev. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Austin, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Austin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Austin, Johannas",
"given": "Johannas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Austin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Baker, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Baker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Baldwin, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Baldwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Abigail",
"given": "Abigail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Ida B.",
"given": "Ida B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Jasper",
"given": "Jasper",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Katie E.",
"given": "Katie E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Lucy A.",
"given": "Lucy A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias",
"given": "Matthias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias Sr.",
"given": "Matthias Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias, Jr.",
"given": "Matthias, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Robert Lee",
"given": "Robert Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ballard, Judith Ellen",
"given": "Judith Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ballard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barker, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barnes, Ernestina",
"given": "Ernestina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barnes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barnett, Anna Gertrude",
"given": "Anna Gertrude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barnett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barrett, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bass, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bass"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Catharina",
"given": "Anna Catharina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Elisabeth",
"given": "Anna Elisabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Ottilia",
"given": "Anna Ottilia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Franciskus",
"given": "Johann Franciskus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Michael",
"given": "Johann Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Theobald",
"given": "Johann Theobald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Valentin",
"given": "Johann Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Valentin",
"given": "Johann Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9dard, Swanson",
"given": "Swanson",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9dard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Col. David",
"given": "Col. David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Col. Joseph",
"given": "Col. Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, James Edwin",
"given": "James Edwin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Jason Spotswood",
"given": "Jason Spotswood",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Joseph Louis(Sr.)",
"given": "Joseph Louis(Sr.)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Louise DeSoix",
"given": "Louise DeSoix",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Martha Ellen",
"given": "Martha Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Martha Ellen M.",
"given": "Martha Ellen M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Mary Frances",
"given": "Mary Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Robert Watkins",
"given": "Robert Watkins",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Samuel Sr.",
"given": "Samuel Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Thomas Stewart",
"given": "Thomas Stewart",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bernier, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bernier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Berry, Honorah",
"given": "Honorah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Berry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bishop, Anna Barbara",
"given": "Anna Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bishop"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bishop, Quirinus",
"given": "Quirinus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bishop"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Black, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Black"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blair, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blair"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blake, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blake"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blake, M. Susannah",
"given": "M. Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blake"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Bendicht",
"given": "Bendicht",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Catarina",
"given": "Catarina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Gerhard",
"given": "Gerhard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Heinrich",
"given": "Heinrich",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, John W.",
"given": "John W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, L. J.",
"given": "L. J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Lucinda Catherine",
"given": "Lucinda Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Malvina",
"given": "Malvina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Margareta",
"given": "Margareta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mary F.",
"given": "Mary F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Milton",
"given": "Milton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Paris",
"given": "Paris",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Rufus",
"given": "Rufus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Stephen",
"given": "Stephen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bouchard, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bouchard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Fr. Patrick",
"given": "Fr. Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Fr.Lawrence M.",
"given": "Fr.Lawrence M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Mary Cecilia",
"given": "Mary Cecilia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Nora A.",
"given": "Nora A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Prof. William Joseph",
"given": "Prof. William Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Sharon",
"given": "Sharon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Stephen Francis",
"given": "Stephen Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas W.",
"given": "Thomas W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William Bernard",
"given": "William Bernard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William C.",
"given": "William C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bowen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bowen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Capt.",
"given": "Capt.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Carmen Alberta",
"given": "Carmen Alberta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Charles Newton",
"given": "Charles Newton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bradley, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bradley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, CatherineJosephine",
"given": "CatherineJosephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Briggs, Joyce Inez",
"given": "Joyce Inez",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Briggs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Fielding",
"given": "Fielding",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Guillaume de",
"given": "Guillaume de",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Major Marquis II",
"given": "Major Marquis II",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Marquis I",
"given": "Marquis I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Marquis IV",
"given": "Marquis IV",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Miriam",
"given": "Miriam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Spencer",
"given": "Spencer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, William Waller",
"given": "William Waller",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brown, ?????",
"given": "?????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brown"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Buchanan, Elsbeth",
"given": "Elsbeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Buchanan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burke, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burke"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burns, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burns"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, John Joseph",
"given": "John Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Martin",
"given": "Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Butler, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Butler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cannon, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cannon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caron, Mary E.",
"given": "Mary E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caron"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carpenter, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carpenter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carr, Zelpha Josephine",
"given": "Zelpha Josephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carr"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Grace",
"given": "Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Jacob A.",
"given": "Jacob A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Matthias Sr.",
"given": "Matthias Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Castillo, Margaretha",
"given": "Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Castillo"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Castro, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Castro"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Chambers, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Chambers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Nathaniel",
"given": "Nathaniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Clark, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Clark"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cole, Eurydice",
"given": "Eurydice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cole, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cook, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cook"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Copeland, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Copeland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Craig, Mary J.",
"given": "Mary J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Craig"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Crawford, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Crawford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, Peter Sr.",
"given": "Peter Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, Sally Sarah",
"given": "Sally Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, William Philip",
"given": "William Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curry, Kenner S.",
"given": "Kenner S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curtis, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curtis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curtis, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curtis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "D\u0105browski, Letitia C.",
"given": "Letitia C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"D\u0105browski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Daniels",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Daniels"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Daniels, Phoebe",
"given": "Phoebe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Daniels"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davidson, Bernice",
"given": "Bernice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davidson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Jonathan",
"given": "Jonathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Sabra",
"given": "Sabra",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dean, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dean"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Delgado, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Delgado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dennis, Mary (Hannah?)",
"given": "Mary (Hannah?)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dennis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dennis, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dennis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Desjardins, J.",
"given": "J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Desjardins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Clemence",
"given": "Clemence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Cuthbert",
"given": "Cuthbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Mary Polly",
"given": "Mary Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Urselie",
"given": "Urselie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William (Rev.)",
"given": "William (Rev.)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dixon, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dixon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Mahala",
"given": "Mahala",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Mary E.",
"given": "Mary E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Zorada",
"given": "Zorada",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Alfred",
"given": "Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Eliza Jane",
"given": "Eliza Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frederick",
"given": "Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frederick",
"given": "Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John Sr.",
"given": "John Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Johnathon",
"given": "Johnathon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Lucinda J.",
"given": "Lucinda J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Mary\"Polly\"",
"given": "Mary\"Polly\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Doyle, Robert Gove",
"given": "Robert Gove",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Doyle"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Rose",
"given": "Rose",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Edwards, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Edwards"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Elliott, Lodowick",
"given": "Lodowick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Elliott"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ellis, Margaret Steel",
"given": "Margaret Steel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ellis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Erickson, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Erickson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Estrada, Mary Claire",
"given": "Mary Claire",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Estrada"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Anna Marie",
"given": "Anna Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Benjamin H.",
"given": "Benjamin H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Caroline",
"given": "Caroline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Catharine",
"given": "Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Cyrus Melville",
"given": "Cyrus Melville",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth Ellen",
"given": "Elizabeth Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Eva",
"given": "Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Flora Alice",
"given": "Flora Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, George William",
"given": "George William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Magdalena",
"given": "Magdalena",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Miranda Keziah",
"given": "Miranda Keziah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Peter Simon",
"given": "Peter Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Simon",
"given": "Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Susanna",
"given": "Susanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Susanne Delilah",
"given": "Susanne Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Valentine",
"given": "Valentine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Winfield Scott",
"given": "Winfield Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ferguson, Lord Samuel",
"given": "Lord Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ferguson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fisher, Bendichtli",
"given": "Bendichtli",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fisher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Flowers, Mary A.",
"given": "Mary A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Flowers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Gregory Scott",
"given": "Gregory Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, John Morgan",
"given": "John Morgan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, John S.",
"given": "John S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Martha Frances \"Fannie\"",
"given": "Martha Frances \"Fannie\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Lorinda Catherine",
"given": "Lorinda Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Stephen Jacob",
"given": "Stephen Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fortin, Matthias",
"given": "Matthias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fortin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fournier, Peggy",
"given": "Peggy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fournier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Jacob, Sr.",
"given": "Jacob, Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Julia Colville",
"given": "Julia Colville",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Johann Walter",
"given": "Johann Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Maria Margaretha",
"given": "Maria Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gagn\u00e9, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gagn\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gardner, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gardner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Anderson",
"given": "Anderson",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Anetta",
"given": "Anetta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Antoinette",
"given": "Antoinette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Bertha P.",
"given": "Bertha P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Cecile Elizabeth",
"given": "Cecile Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Daniel Burton",
"given": "Daniel Burton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Daniel Webster",
"given": "Daniel Webster",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Emma A.",
"given": "Emma A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Eugene Stanley",
"given": "Eugene Stanley",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Iola Elizabeth Betty",
"given": "Iola Elizabeth Betty",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jennie S.",
"given": "Jennie S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jesse V.",
"given": "Jesse V.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Lewis",
"given": "Lewis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "Anderson",
"cita": [
1600
],
"date": "1875-04-01",
"fam_nick": "Beauregard",
"full": "Garner von Zieli\u0144ski, Lewis Anderson Sr",
"given": "Lewis Anderson",
"nick": "Big Louie",
"note": "",
"suffix": "Sr",
"surnames": [
"Garner",
"Zieli\u0144ski"
],
"title": "Dr.",
"type": "Birth Name"
},
{
"call": "",
"cita": [
1609
],
"date": "",
"fam_nick": "",
"full": "Garner, Louis",
"given": "Louis",
"nick": "",
"note": "<div>\n<div class=\"grampsstylednote\">\n<p>\nNames can notes, too. This is a note for the alternate name of Louse Garner for <a href=\"person.html?idx=388\">Lewis Anderson Garner</a>.\n</p>\n</div>\n</div>",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Also Known As"
},
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Louie",
"given": "Louie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Other Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Margaret Ann",
"given": "Margaret Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Mary J.",
"given": "Mary J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Mary M.",
"given": "Mary M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Phebe",
"given": "Phebe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Raymond E.",
"given": "Raymond E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Rebecca Catharine",
"given": "Rebecca Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Robert F.",
"given": "Robert F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Robert W.",
"given": "Robert W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Walter E.",
"given": "Walter E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Wayne Allen",
"given": "Wayne Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gauthier, Julius",
"given": "Julius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gauthier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibson, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gilbert, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gilbert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Glover, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Glover"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gomez, Culthbert",
"given": "Culthbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gomez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gomez, Jane Joane",
"given": "Jane Joane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gomez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonz\u00e1lez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonz\u00e1lez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonzalez, Eliza Jane",
"given": "Eliza Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonzalez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonz\u00e1lez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonz\u00e1lez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodman, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodwin, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Graves, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Graves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gray, Beatrix",
"given": "Beatrix",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Randolph",
"given": "Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Yelverton",
"given": "Yelverton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Greene, Marcy",
"given": "Marcy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Greene"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Greer, Mary Wein",
"given": "Mary Wein",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Greer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gregory, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gregory"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grenier, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grenier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grenier, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grenier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Griffith, Experience",
"given": "Experience",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Griffith"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gutierrez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gutierrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guzman, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guzman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hall, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hall"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hanson, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hardy, Jakob",
"given": "Jakob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hardy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harmon, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harmon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harrison, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harvey, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harvey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "H\u00e9bert, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"H\u00e9bert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "H\u00e9bert, Ruth Ann",
"given": "Ruth Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"H\u00e9bert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Henry, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Henry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Henry, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Henry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hernandez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hern\u00e1ndez, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hern\u00e1ndez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hern\u00e1ndez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hern\u00e1ndez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hicks, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hicks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Higgins, Charity",
"given": "Charity",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Higgins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hines",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hines"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hodges, Comfort",
"given": "Comfort",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hodges"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hoffman, Fay",
"given": "Fay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hoffman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holland, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holt, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hopkins, Mary Eve",
"given": "Mary Eve",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hopkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Houston, Ellender",
"given": "Ellender",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Houston"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howard, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, JOHN",
"given": "JOHN",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, Mary (Sarah)",
"given": "Mary (Sarah)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Huff, Bertrama",
"given": "Bertrama",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Huff"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Huff, Isabel",
"given": "Isabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Huff"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hunt, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hunt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ingram, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ingram"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jackson, Cora Ellen",
"given": "Cora Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jackson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh Jr.",
"given": "Hugh Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh Sr.",
"given": "Hugh Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Molly",
"given": "Molly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Pamela",
"given": "Pamela",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Walter Crockett",
"given": "Walter Crockett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, George Jr.",
"given": "George Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Isabella Belle",
"given": "Isabella Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Margaret Jane \"Maggie\"",
"given": "Margaret Jane \"Maggie\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Minnie",
"given": "Minnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jenkins, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jenkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jenkins, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jenkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jensen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Amanda E.",
"given": "Amanda E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Armand E.",
"given": "Armand E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Cornelius",
"given": "Cornelius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George H.",
"given": "George H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George Henry, III",
"given": "George Henry, III",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George Henry, Jr.",
"given": "George Henry, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George, Sr.",
"given": "George, Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, James T.",
"given": "James T.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, John T. L.",
"given": "John T. L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lincoln F.",
"given": "Lincoln F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lucinda",
"given": "Lucinda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lucinda Ellen",
"given": "Lucinda Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Mary C.",
"given": "Mary C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Mary C.",
"given": "Mary C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Nancy E.",
"given": "Nancy E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Nathan M.",
"given": "Nathan M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Philip",
"given": "Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Polly Mary",
"given": "Polly Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Richard? Cornelius",
"given": "Richard? Cornelius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Sarah M.",
"given": "Sarah M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Tolbert A.",
"given": "Tolbert A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnson, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnson, Richard F.",
"given": "Richard F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Martha Elizabeth",
"given": "Martha Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph, Alfred",
"given": "Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kaczmarek, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kaczmarek"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kami\u0144ski",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kami\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kami\u0144ski, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kami\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kelley, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kelley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kennedy, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kennedy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kim, Frank",
"given": "Frank",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kim"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Klein, Alma Katherine",
"given": "Alma Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Klein"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knight, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knight"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ranulf",
"given": "Ranulf",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kowalski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kowalski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kowalski, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kowalski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Koz\u0142owski, Margret",
"given": "Margret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Koz\u0142owski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Catherine Virginia",
"given": "Catherine Virginia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, John Francis\"Chick\"",
"given": "John Francis\"Chick\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Margaret Agnes\"Maudy\"",
"given": "Margaret Agnes\"Maudy\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Miles Joseph\"Dutch\"",
"given": "Miles Joseph\"Dutch\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Sarah \"Sr. Sabina\"",
"given": "Sarah \"Sr. Sabina\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Eleanor (Nellie) Therese",
"given": "Eleanor (Nellie) Therese",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Kitty",
"given": "Kitty",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Mary A.",
"given": "Mary A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Michael Edward",
"given": "Michael Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Mollie",
"given": "Mollie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Remo",
"given": "Remo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, Lucy aka Sarah",
"given": "Lucy aka Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, Sir Thomas",
"given": "Sir Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Larson, Christena Wiseman",
"given": "Christena Wiseman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Larson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lavoie, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lavoie"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawrence, Dorcas C.",
"given": "Dorcas C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawrence"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Rev. John L.",
"given": "Rev. John L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Leonard, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Leonard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Carl Tolbert",
"given": "Carl Tolbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Emma Jane",
"given": "Emma Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Ira Willis",
"given": "Ira Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Izora",
"given": "Izora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Ralph Raymond",
"given": "Ralph Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Susanna Marie",
"given": "Susanna Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Clarence",
"given": "Clarence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, James W.",
"given": "James W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Olive",
"given": "Olive",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Wilma",
"given": "Wilma",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Little, O. D.",
"given": "O. D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Little"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00f3pez, Anna Elisabeth",
"given": "Anna Elisabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00f3pez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00f3pez, Hans Valentin",
"given": "Hans Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00f3pez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mack, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mack"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Madsen, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Madsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maldonado, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maldonado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mann, Agnes",
"given": "Agnes",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mann"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Albert",
"given": "Albert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Alfred Franklin(Frank)",
"given": "Alfred Franklin(Frank)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Elizabeth Therese",
"given": "Elizabeth Therese",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Frances Coppage",
"given": "Frances Coppage",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Frank",
"given": "Frank",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Lilla Estella",
"given": "Lilla Estella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Moses Wallace",
"given": "Moses Wallace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Nancy H.",
"given": "Nancy H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Nellie",
"given": "Nellie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Thomas Willis",
"given": "Thomas Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Walter Matthew",
"given": "Walter Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Wilbur",
"given": "Wilbur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Willis",
"given": "Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Willis H.",
"given": "Willis H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Marsh, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Marsh"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Marshall, Kate Teel",
"given": "Kate Teel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Marshall"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martel, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martel, Luella Jacques",
"given": "Luella Jacques",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mason, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mason"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mason, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mason"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Massey, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Massey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maxwell, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maxwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maxwell, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maxwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mazur, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mazur"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCarthy, Valentine Thomas",
"given": "Valentine Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCarthy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Francis",
"given": "Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Paula",
"given": "Paula",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mcdaniel, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mcdaniel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mendoza, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mendoza"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Meyer, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Meyer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Michaud, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Michaud"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Michaud, Valentin",
"given": "Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Michaud"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Miller, Anna Catherine",
"given": "Anna Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Miller"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mills, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mills"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mitchell, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mitchell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Molina, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Molina"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Montgomery, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Montgomery"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moody, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moody"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moran, Ann Delilah \"Tilley\"",
"given": "Ann Delilah \"Tilley\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moran"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Aaron",
"given": "Aaron",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Abigail Chapman",
"given": "Abigail Chapman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Absalom",
"given": "Absalom",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Christian",
"given": "Christian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Christian, I",
"given": "Christian, I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Cyrus W.",
"given": "Cyrus W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Darius",
"given": "Darius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Delilah",
"given": "Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Delilah",
"given": "Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Enoch",
"given": "Enoch",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Enoch T.",
"given": "Enoch T.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Esau",
"given": "Esau",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Flora E.",
"given": "Flora E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Green P.",
"given": "Green P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Johann Christian II",
"given": "Johann Christian II",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Joseph McDowell",
"given": "Joseph McDowell",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Leah",
"given": "Leah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Lelia L.",
"given": "Lelia L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Lydia M.",
"given": "Lydia M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Maj. Christopher",
"given": "Maj. Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Martha A.",
"given": "Martha A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Mary H.",
"given": "Mary H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Minerva",
"given": "Minerva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Noah",
"given": "Noah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Phebe J.",
"given": "Phebe J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Rosan",
"given": "Rosan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Solon",
"given": "Solon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Thomas H.",
"given": "Thomas H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morgan, Elisabeth Margaretha",
"given": "Elisabeth Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morgan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Adam",
"given": "Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Carlisle",
"given": "Carlisle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Cyrus",
"given": "Cyrus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Cyrus",
"given": "Cyrus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Roland",
"given": "Roland",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mullins, Robert?",
"given": "Robert?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mullins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Shadrach M.",
"given": "Shadrach M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Murray, Nicholas",
"given": "Nicholas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Murray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Murray, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Murray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Myers, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Myers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Myers, James Joseph Jr.",
"given": "James Joseph Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Myers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Belle",
"given": "Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Newman, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Newman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nichols, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nichols"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Oliver, Hans Michael",
"given": "Hans Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Oliver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Olson, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Olson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortega, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortega"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortiz, Raymond",
"given": "Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ouellet, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ouellet"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Owens, Wilford",
"given": "Wilford",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Owens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Andrew Vincent",
"given": "Andrew Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Anna",
"given": "Anna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Clara Belle",
"given": "Clara Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Edith Mae",
"given": "Edith Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, George Kenneth (Red)",
"given": "George Kenneth (Red)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, John James",
"given": "John James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Richard C.",
"given": "Richard C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Betsy",
"given": "Betsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Capt.Jacob C.",
"given": "Capt.Jacob C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Harry",
"given": "Harry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Jacob G.",
"given": "Jacob G.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, John Sr.",
"given": "John Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Montgomery",
"given": "Montgomery",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Park, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Park"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Park, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Park"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parker, Frank R.",
"given": "Frank R.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parsons, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parsons"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patterson, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patterson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patton, Adolph",
"given": "Adolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Alexander",
"given": "Alexander",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Fielding",
"given": "Fielding",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Jane Coppage",
"given": "Jane Coppage",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Leonard",
"given": "Leonard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Leonard?",
"given": "Leonard?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Lucretia",
"given": "Lucretia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Moses",
"given": "Moses",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Willis",
"given": "Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Winifred",
"given": "Winifred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pedersen, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pedersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Perkins, Lydia",
"given": "Lydia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Perkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Perry, M.",
"given": "M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Perry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Frank O.",
"given": "Frank O.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, George Sr.",
"given": "George Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Rose",
"given": "Rose",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, John Jr.",
"given": "John Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poole, Dr. John",
"given": "Dr. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pope, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pope"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Powell, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Powell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pratt, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pratt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Price, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Price"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Quinn, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Quinn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Quinn, Abram",
"given": "Abram",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Quinn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ram\u00edrez, John B.",
"given": "John B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ram\u00edrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramos, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramos, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramsey, Joan",
"given": "Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramsey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Bridgette",
"given": "Bridgette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Francis Vincent",
"given": "Francis Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Matthew",
"given": "Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Owen",
"given": "Owen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter James?",
"given": "Peter James?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reese",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reese"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reid, Anna Catherina",
"given": "Anna Catherina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reid"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reid, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reid"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Col. John",
"given": "Col. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Nicholas",
"given": "Nicholas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rice, Virginia Margaret",
"given": "Virginia Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rice"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Richard, Jeanne",
"given": "Jeanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Richard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rios, Agnes",
"given": "Agnes",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rios"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robertson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robertson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodr\u00edguez, Agatha",
"given": "Agatha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodr\u00edguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriguez, Helen M.",
"given": "Helen M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Alvin",
"given": "Alvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Barbara Ann",
"given": "Barbara Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Elizabeth Jane",
"given": "Elizabeth Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Maria Louisa",
"given": "Maria Louisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mariam",
"given": "Mariam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Michael Mordica",
"given": "Michael Mordica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mordica",
"given": "Mordica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Oma",
"given": "Oma",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Richard",
"given": "Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, William Frederick",
"given": "William Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rogers, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rogers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Romero, Ernest",
"given": "Ernest",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Romero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rose, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rose"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Roy, Prince Alfred",
"given": "Prince Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Roy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rubio, John III",
"given": "John III",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rubio"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rubio, Winifred",
"given": "Winifred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rubio"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ruiz, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ruiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ryan, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ryan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ryan, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ryan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Salazar, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Salazar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanchez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanchez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanders, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanders, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Santiago, Mathias",
"given": "Mathias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Santiago"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Santos, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Santos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Saunders, Ursula",
"given": "Ursula",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Saunders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Savard, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Savard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schmidt, Barbli",
"given": "Barbli",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schmidt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schneider",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schneider"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schneider, Belle Irene",
"given": "Belle Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schneider"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schultz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schultz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schultz, Rev.Isaac",
"given": "Rev.Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schultz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schwartz, Helewisa",
"given": "Helewisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schwartz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Archibald",
"given": "Archibald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sharp, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sharp"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Shelton, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Shelton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Silva, Mildred",
"given": "Mildred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Silva"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simard, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simard, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simmons, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simmons"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Snyder, Ann Louisa",
"given": "Ann Louisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Snyder"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sparks, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sparks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Spencer, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Spencer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Steele, Valentine",
"given": "Valentine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Steele"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stephens, Adam",
"given": "Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stephens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stevens, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stevens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Strickland, Col. Robert",
"given": "Col. Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Strickland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Su\u00e1rez, Marie",
"given": "Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Su\u00e1rez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sullivan, Anna",
"given": "Anna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sullivan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sutton, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sutton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Joane",
"given": "Joane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Szyma\u0144ski, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Szyma\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Taylor, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Taylor"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Taylor, Viola",
"given": "Viola",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Taylor"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Terry, J.",
"given": "J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Terry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomas, Elder Thomas",
"given": "Elder Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomsen, new",
"given": "new",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Arthur Otto",
"given": "Arthur Otto",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, James Arthur",
"given": "James Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Benjamin Harrison",
"given": "Benjamin Harrison",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Flora Belle",
"given": "Flora Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, George W.",
"given": "George W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, George Walter",
"given": "George Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Hardy",
"given": "Hardy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Hodges",
"given": "Hodges",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Jesse Elmer",
"given": "Jesse Elmer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, John M.",
"given": "John M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Louella Jane",
"given": "Louella Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Olive",
"given": "Olive",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Percy Haye",
"given": "Percy Haye",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Robert Arthur",
"given": "Robert Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Turner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Turner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Vargas, Caroline Metzger",
"given": "Caroline Metzger",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Vargas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wagner, Martha Ann",
"given": "Martha Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wagner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walker, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wallace, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wallace"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walters, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walters, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walton, Theophania(Tiffany)",
"given": "Theophania(Tiffany)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Amanda",
"given": "Amanda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. Andrew",
"given": "Capt. Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. Francis",
"given": "Capt. Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. George",
"given": "Capt. George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, David Brant",
"given": "David Brant",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Donald Louis",
"given": "Donald Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Dorcas",
"given": "Dorcas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eden",
"given": "Eden",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward Randolph",
"given": "Edward Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eliza Frances",
"given": "Eliza Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eunice",
"given": "Eunice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Ezra",
"given": "Ezra",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Greenleaf",
"given": "Greenleaf",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Humphrey Martin",
"given": "Humphrey Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johanna",
"given": "Johanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John Quincy Adams",
"given": "John Quincy Adams",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johnathan",
"given": "Johnathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johnathon",
"given": "Johnathon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Julia Angeline",
"given": "Julia Angeline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Lewis",
"given": "Lewis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Martin Bogarte",
"given": "Martin Bogarte",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michael Warren",
"given": "Michael Warren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Nathaniel M.",
"given": "Nathaniel M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Noah",
"given": "Noah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Piatt D.",
"given": "Piatt D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Randolph",
"given": "Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Samuel Harvey",
"given": "Samuel Harvey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sarah Maria",
"given": "Sarah Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sir Francis",
"given": "Sir Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sylvester",
"given": "Sylvester",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Warren W.",
"given": "Warren W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, William Waller",
"given": "William Waller",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Alex",
"given": "Alex",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Alexander",
"given": "Alexander",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Anna Mabel",
"given": "Anna Mabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Charles Leroy Boyd",
"given": "Charles Leroy Boyd",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Clarence",
"given": "Clarence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, David Festus",
"given": "David Festus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Elias",
"given": "Elias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Ernest Arlington",
"given": "Ernest Arlington",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Francis Irvin",
"given": "Francis Irvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Harry Noble",
"given": "Harry Noble",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Homer",
"given": "Homer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James Leslie",
"given": "James Leslie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James Marshall",
"given": "James Marshall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James McPheeters",
"given": "James McPheeters",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, John McCrea",
"given": "John McCrea",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Joseph LeRoy",
"given": "Joseph LeRoy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lawrence",
"given": "Lawrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lewis I.",
"given": "Lewis I.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Livingstone Martin",
"given": "Livingstone Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lucinda E.",
"given": "Lucinda E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lucy Mabel",
"given": "Lucy Mabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Margaret Margarite?",
"given": "Margaret Margarite?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary Ruth",
"given": "Mary Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Michael Christie",
"given": "Michael Christie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Newton Kitridge",
"given": "Newton Kitridge",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, R. Eaken",
"given": "R. Eaken",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Sallie",
"given": "Sallie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Sarah Margarite",
"given": "Sarah Margarite",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, William Herman",
"given": "William Herman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, William John",
"given": "William John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webster, Conrad",
"given": "Conrad",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Irwin Arthur",
"given": "Irwin Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wells, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wells"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "White",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"White"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Williams, Thomas Jr.",
"given": "Thomas Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Williams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wise, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wise"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wi\u015bniewski, D.",
"given": "D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wi\u015bniewski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Arnold",
"given": "Arnold",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wong",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wong, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wood, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wood"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wood, Polly",
"given": "Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wood"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, Mary Polly",
"given": "Mary Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Zieli\u0144ski, Phoebe Emily",
"given": "Phoebe Emily",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Zieli\u0144ski"
],
"title": "",
"type": "Birth Name"
},
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Phoebe Emily",
"given": "Phoebe Emily",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Married Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Zimmerman, Edith Irene",
"given": "Edith Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Zimmerman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043d\u0434\u0440\u0435\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043d\u0434\u0440\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0430\u0440\u0430\u043d\u043e\u0432, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0430\u0440\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"given": "Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"given": "Johannas Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043b\u0430\u0441\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043b\u0430\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432, Eva",
"given": "Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432, Rev. Samuel",
"given": "Rev. Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u043d\u043e\u0432, Katherine",
"given": "Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u0432\u044b\u0434\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u0432\u044b\u0434\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"given": "Alexander Carroll Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"given": "Charles Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"given": "Lazarus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Nancy Ann",
"given": "Nancy Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Annabell Gordon",
"given": "Annabell Gordon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u0430\u0445\u0430\u0440\u043e\u0432, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u0430\u0445\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"given": "Col. Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"given": "Joseph Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u043a\u043e\u0432, Angeline",
"given": "Angeline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u043a\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u0440\u044f\u043d\u043e\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u0440\u044f\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0437\u0430\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"given": "Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u043b\u0435\u0441\u043d\u0438\u043a\u043e\u0432, Conrad",
"given": "Conrad",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u043b\u0435\u0441\u043d\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u043c\u0430\u0440\u043e\u0432, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u043c\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432, Hanora",
"given": "Hanora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u0430\u043b\u0435\u0442\u0438\u043d, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u0430\u043b\u0435\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u0435\u0431\u0435\u0434\u0435\u0432, Trustum",
"given": "Trustum",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u0435\u0431\u0435\u0434\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u043e\u0433\u0438\u043d\u043e\u0432, Guy",
"given": "Guy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u043e\u0433\u0438\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0430\u0440\u043e\u0432, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0430\u0440\u043e\u0432, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Christina",
"given": "Christina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043b\u044c\u0446\u0435\u0432, Joan",
"given": "Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043b\u044c\u0446\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u0442\u0432\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0435\u0434\u0432\u0435\u0434\u0435\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0435\u0434\u0432\u0435\u0434\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u043e\u0440\u043e\u0437\u043e\u0432, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u043e\u0440\u043e\u0437\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u0438\u0444\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u0438\u0444\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Maria Catharina",
"given": "Maria Catharina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Veltin",
"given": "Veltin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u043e\u0432\u0438\u043a\u043e\u0432, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u043e\u0432\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u043e\u0432\u0438\u043a\u043e\u0432, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u043e\u0432\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u0430\u0432\u043b\u043e\u0432, Reuben",
"given": "Reuben",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u0430\u0432\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u043f\u043e\u0432, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0420\u043e\u043c\u0430\u043d\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0420\u043e\u043c\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"given": "Cathern",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u043c\u0435\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043c\u0438\u0440\u043d\u043e\u0432, Eudo",
"given": "Eudo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043c\u0438\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"given": "Ribald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043c\u0438\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043e\u043a\u043e\u043b\u043e\u0432, Louise",
"given": "Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043e\u043a\u043e\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0430\u0440\u0430\u0441\u043e\u0432, Simon",
"given": "Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0430\u0440\u0430\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, John P.",
"given": "John P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"given": "Willoughby M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"given": "Catherine Virginia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Mary Ellen",
"given": "Mary Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"given": "Moses",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Myles",
"given": "Myles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Louis",
"given": "Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Merritt",
"given": "Merritt",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043d\u043e\u0432, Maud",
"given": "Maud",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0428\u0430\u0434\u0440\u0438\u043d, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0428\u0430\u0434\u0440\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0627\u0644\u0641\u0636\u0644, \u0627\u0644\u0639\u0628\u0627\u0633\u0629",
"given": "\u0627\u0644\u0639\u0628\u0627\u0633\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0627\u0644\u0641\u0636\u0644"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0e1a\u0e38\u0e0d, Foon",
"given": "Foon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0e1a\u0e38\u0e0d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u4e2d\u6751, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u4e2d\u6751"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u4f0a\u85e4, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u4f0a\u85e4"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Antoine Desaure Perronett",
"given": "Antoine Desaure Perronett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Gabriel Gustav",
"given": "Gabriel Gustav",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Gabriel Gustave",
"given": "Gabriel Gustave",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u658e\u85e4, Zariakius Cyriacus",
"given": "Zariakius Cyriacus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u658e\u85e4"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u6e21\u8fba, Mary (Polly)",
"given": "Mary (Polly)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u6e21\u8fba"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u9234\u6728, Allen",
"given": "Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u9234\u6728"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u9234\u6728, Robert B.",
"given": "Robert B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u9234\u6728"
],
"title": "",
"type": "Birth Name"
}
]
]
Dwr.ScriptLoaded('dwr_db_I_names_0.js');
