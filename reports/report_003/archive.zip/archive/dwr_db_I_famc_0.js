// This file is generated

I_famc_0 = [
[],
[],
[],
[
{
"cita": [],
"index": 1,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 0,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 4,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 6,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 5,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 7,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 14,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 12,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 149,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 20,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 470,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 22,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 28,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 28,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 28,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 29,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 30,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 26,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 341,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 45,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 50,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 43,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 351,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 51,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 361,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 52,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 379,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 53,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 55,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 366,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 68,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 68,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 69,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 366,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 69,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 69,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 366,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 68,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 68,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 69,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 366,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 73,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 77,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 75,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 76,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 83,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 365,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 82,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 91,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 85,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 86,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 89,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 171,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 92,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 93,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 261,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 88,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 90,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 88,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 93,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 98,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 97,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 100,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 103,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 102,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 104,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 380,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 112,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 112,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 112,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 112,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 135,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 138,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 344,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 149,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 147,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 146,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 145,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 148,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 151,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 187,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 150,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 153,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 121,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [
1611
],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Adopted",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 121,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Custom relationship to father",
"to_mother": "Custom relationship to mother"
}
],
[],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Adopted"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 121,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 163,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 169,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 173,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 177,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 176,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 174,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 175,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 178,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 183,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 179,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 182,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 181,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 463,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 191,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 34,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 196,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 203,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 201,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 47,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 199,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 210,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 213,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 219,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 226,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 228,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 227,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 185,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 231,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 134,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 134,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 233,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 134,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 237,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 235,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 236,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 240,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 239,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 432,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 362,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 246,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 247,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 247,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 243,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 247,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 246,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 246,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 250,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 250,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 250,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 368,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 256,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 258,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 368,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 256,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 368,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 257,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 256,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 368,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 260,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 262,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 180,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 277,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 277,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 277,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 272,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 277,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 271,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 272,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 272,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 274,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 272,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 272,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 278,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 279,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 282,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 283,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 288,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 294,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 294,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 293,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 294,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 296,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 296,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 301,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 303,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 302,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 305,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 315,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 314,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 313,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 320,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 319,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 321,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 328,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 340,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 340,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 342,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 342,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 342,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 144,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 349,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 350,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 345,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 350,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 346,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 133,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 352,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 118,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 360,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 268,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 363,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 369,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 370,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 371,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 375,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 23,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 380,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 380,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 380,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 384,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 386,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 393,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 390,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 391,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 389,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 454,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 396,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 402,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 411,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 399,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 407,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 398,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 398,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 398,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 412,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 412,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 400,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 406,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 397,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 410,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 419,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 425,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 425,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 417,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 427,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 417,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 425,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 421,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 417,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 417,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 421,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 416,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 416,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 416,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 422,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 242,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 435,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 436,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 436,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 442,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 441,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 444,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 445,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 448,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 451,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 452,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 453,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 365,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 457,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 459,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 280,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 476,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 466,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 465,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 472,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 468,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 468,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 468,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 468,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 471,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 471,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 475,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 460,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_I_famc_0.js');
