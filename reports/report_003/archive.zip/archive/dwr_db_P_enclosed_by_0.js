// This file is generated

P_enclosed_by_0 = [
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 364
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 214
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 483
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 669
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 654
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 766
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 542
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 8
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 26
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 761
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 112
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 210
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 145
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 41
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 146
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 332
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 281
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 443
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 508
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 199
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 468
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 495
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 382
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 879
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 64
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 830
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 353
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 95
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 844
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 84
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 767
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 87
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 840
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 579
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 117
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 324
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 245
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 125
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 208
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 830
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 579
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 610
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 282
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 587
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 814
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 644
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 131
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 791
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 880
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 171
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 879
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 423
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 540
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 92
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 235
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 57
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 381
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 577
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 257
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 861
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 181
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 586
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 539
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 187
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 89
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 50
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 713
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 4
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 546
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 829
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 645
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 445
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 438
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 219
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 543
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 414
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 496
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 233
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 857
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 238
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 137
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 467
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 154
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 355
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 880
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 8
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 879
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 587
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 842
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 68
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 436
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 431
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 96
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 719
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 597
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 783
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 279
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 259
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 587
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 424
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 56
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 841
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 345
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 200
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 782
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 468
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 197
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 335
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 453
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 143
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 330
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 289
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 786
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 324
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 163
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 676
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 82
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 385
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 138
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 283
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 380
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 8
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 335
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 577
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 581
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 444
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 8
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 807
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 405
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 352
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 417
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 790
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 111
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 161
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 643
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 193
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 853
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 587
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 216
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 576
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 507
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 725
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 813
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 311
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 431
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 73
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 577
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 679
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 879
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 862
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 231
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 325
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 485
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 886
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 494
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 337
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 409
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 505
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 512
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 517
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 429
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 51
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 620
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 753
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 611
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 752
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 435
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 160
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 784
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 541
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 240
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 204
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 563
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 555
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 195
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 333
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 606
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 378
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 707
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 480
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 579
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 814
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 751
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 604
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 473
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 415
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 837
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 822
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 502
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 665
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 347
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 262
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 61
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 302
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 292
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 674
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 246
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 628
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 518
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 799
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 476
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 351
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 486
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 53
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 879
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 750
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 508
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 225
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 814
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 659
}
],
[],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 132
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 3
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 785
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 726
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 702
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 587
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 471
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 852
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 755
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 880
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 265
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 296
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 538
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 72
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 697
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 700
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 657
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 134
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 566
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 772
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 858
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 30
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 185
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 723
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 408
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 108
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 580
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 873
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 662
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 148
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 212
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 318
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 705
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 291
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 463
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 244
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 460
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 859
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 101
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 468
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 691
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 136
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 196
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 583
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 778
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 599
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 10
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 446
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 472
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 338
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 770
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 810
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 281
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 727
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 457
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 634
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 635
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 469
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 802
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 737
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 510
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 712
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 815
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 465
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 129
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 814
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 367
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 455
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 798
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 261
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 832
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 503
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 515
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 192
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 588
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 322
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 838
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 366
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 361
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 618
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 31
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 365
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 568
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 177
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 360
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 594
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 468
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 876
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 812
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 831
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 716
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 556
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 614
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 773
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 107
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 48
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 887
}
]
]
Dwr.ScriptLoaded('dwr_db_P_enclosed_by_0.js');
