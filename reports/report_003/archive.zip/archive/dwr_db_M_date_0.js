// This file is generated

M_date_0 = [
"",
"1897",
"",
"",
"",
"",
""
]
Dwr.ScriptLoaded('dwr_db_M_date_0.js');
