// This file is generated

R_type_0 = [
"Collection",
"Library",
"Library"
]
Dwr.ScriptLoaded('dwr_db_R_type_0.js');
