// This file is generated

M_xgid = {
"O0000": 0,
"O0006": 3,
"O0007": 5,
"O0008": 2,
"O0009": 6,
"O0010": 1,
"O0011": 4
}
Dwr.ScriptLoaded('dwr_db_M_xgid.js');
