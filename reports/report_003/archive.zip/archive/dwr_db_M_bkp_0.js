// This file is generated

M_bkp_0 = [
[],
[
{
"bk_idx": 803,
"cita": [
1623,
1624,
1624
],
"note": "<div>\n<p>\n<b>Nickname</b>: Fred\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/g/m/238cgq939hg18ss5mg.png"
}
],
[],
[],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_M_bkp_0.js');
