// This file is generated

M_path_0 = [
"image/3/08fdde81/scanned_microfilm.png",
"image/3/08fdde81/1897_expeditionsmannschaft_rio_a.jpg",
"image/3/08fdde81/654px-Aksel_Andersson.jpg",
"image/3/08fdde81/Alimehemet.jpg",
"image/3/08fdde81/AntoineClaudet.png",
"image/3/08fdde81/E_W_Dahlgren.jpg",
"image/3/08fdde81/Gunnlaugur_Larusson_-_Yawn.jpg"
]
Dwr.ScriptLoaded('dwr_db_M_path_0.js');
