// This file is generated

I_events_0 = [
[
{
"cita": [],
"date": "164-03-00 (Islamic)",
"date_sdn": 2006261,
"descr": "",
"gid": "E3406",
"media": [],
"part_family": [],
"part_person": [
0
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "204 (Islamic)",
"date_sdn": 2020376,
"descr": "",
"gid": "E3408",
"media": [],
"part_family": [],
"part_person": [
0,
1122
],
"place": -1,
"text": "",
"type": "Marriage"
},
{
"cita": [],
"date": "241-03-12 (Islamic)",
"date_sdn": 2033558,
"descr": "",
"gid": "E3409",
"media": [],
"part_family": [],
"part_person": [
0
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "203 (Islamic)",
"date_sdn": 2020022,
"descr": "",
"gid": "E3413",
"media": [],
"part_family": [],
"part_person": [
3
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "610",
"date_sdn": 1943858,
"descr": "",
"gid": "E3405",
"media": [],
"part_family": [],
"part_person": [
4,
6
],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "213 (Islamic)",
"date_sdn": 2023566,
"descr": "",
"gid": "E3411",
"media": [],
"part_family": [],
"part_person": [
5
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "290 (Islamic)",
"date_sdn": 2050852,
"descr": "",
"gid": "E3412",
"media": [],
"part_family": [],
"part_person": [
5
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "570-04-19",
"date_sdn": 1929357,
"descr": "",
"gid": "E3403",
"media": [],
"part_family": [],
"part_person": [
6
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "632-06-08",
"date_sdn": 1952052,
"descr": "",
"gid": "E3404",
"media": [],
"part_family": [],
"part_person": [
6
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "610",
"date_sdn": 1943858,
"descr": "",
"gid": "E3405",
"media": [],
"part_family": [],
"part_person": [
4,
6
],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1592",
"date_sdn": 2302526,
"descr": "Birth of Abbott, Frances",
"gid": "E0013",
"media": [],
"part_family": [],
"part_person": [
7
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1642-01-00",
"date_sdn": 2320789,
"descr": "Death of Abbott, Frances",
"gid": "E3415",
"media": [],
"part_family": [],
"part_person": [
7
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "between 1746 and 1755",
"date_sdn": 2358774,
"descr": "Birth of Adams, Jane",
"gid": "E1896",
"media": [],
"part_family": [],
"part_person": [
8
],
"place": 639,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "estimated from 1800 to 1805",
"date_sdn": 2378497,
"descr": "Death of Adams, Jane",
"gid": "E1897",
"media": [],
"part_family": [],
"part_person": [
8
],
"place": 379,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1700-10-26",
"date_sdn": 2342271,
"descr": "Birth of Adams, William",
"gid": "E2158",
"media": [],
"part_family": [],
"part_person": [
9
],
"place": 226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1787-03-10",
"date_sdn": 2373817,
"descr": "Death of Adams, William",
"gid": "E2159",
"media": [],
"part_family": [],
"part_person": [
9
],
"place": 326,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1787",
"date_sdn": 2373749,
"descr": "Burial of Adams, William",
"gid": "E2160",
"media": [],
"part_family": [],
"part_person": [
9
],
"place": 627,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "after 1737-10-01",
"date_sdn": 2355760,
"descr": "Birth of Adkins, John",
"gid": "E1894",
"media": [],
"part_family": [],
"part_person": [
10
],
"place": 493,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1787-05-20",
"date_sdn": 2373888,
"descr": "Death of Adkins, John",
"gid": "E1895",
"media": [],
"part_family": [],
"part_person": [
10
],
"place": 875,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1763-06-20",
"date_sdn": 2365153,
"descr": "Birth of Adkins, Martha",
"gid": "E1906",
"media": [],
"part_family": [],
"part_person": [
11
],
"place": 730,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-09-05",
"date_sdn": 2388971,
"descr": "Death of Adkins, Martha",
"gid": "E1907",
"media": [],
"part_family": [],
"part_person": [
11
],
"place": 379,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Adkins, Martha",
"gid": "E1908",
"media": [],
"part_family": [],
"part_person": [
11
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Adkins, Minnie",
"gid": "E0555",
"media": [],
"part_family": [],
"part_person": [
12
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Adkins, Robert Sr.",
"gid": "E1893",
"media": [],
"part_family": [],
"part_person": [
13
],
"place": 396,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "after 1717",
"date_sdn": 2348182,
"descr": "Birth of Aguilar, Eleanor",
"gid": "E2161",
"media": [],
"part_family": [],
"part_person": [
14
],
"place": 336,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1760-02-00",
"date_sdn": 2363918,
"descr": "Death of Aguilar, Eleanor",
"gid": "E2162",
"media": [],
"part_family": [],
"part_person": [
14
],
"place": 639,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1665",
"date_sdn": 2329190,
"descr": "Birth of Aguilar, John",
"gid": "E2624",
"media": [],
"part_family": [],
"part_person": [
15
],
"place": 396,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1745-02-00",
"date_sdn": 2358440,
"descr": "Death of Aguilar, John",
"gid": "E2625",
"media": [],
"part_family": [],
"part_person": [
15
],
"place": 875,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1690",
"date_sdn": 2338321,
"descr": "Birth of Allen, Abigail",
"gid": "E1134",
"media": [],
"part_family": [],
"part_person": [
17
],
"place": 793,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1700",
"date_sdn": 2341973,
"descr": "Birth of Allen, Benjamin",
"gid": "E1142",
"media": [],
"part_family": [],
"part_person": [
18
],
"place": 793,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762-03-10",
"date_sdn": 2364686,
"descr": "Death of Allen, Benjamin",
"gid": "E1143",
"media": [],
"part_family": [],
"part_person": [
18
],
"place": 182,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1667",
"date_sdn": 2329920,
"descr": "Birth of Allen, Enos",
"gid": "E1119",
"media": [],
"part_family": [],
"part_person": [
19
],
"place": 65,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1689-11-21",
"date_sdn": 2338280,
"descr": "Death of Allen, Enos",
"gid": "E1120",
"media": [],
"part_family": [],
"part_person": [
19
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1685",
"date_sdn": 2336495,
"descr": "Birth of Allen, Gershom",
"gid": "E1151",
"media": [],
"part_family": [],
"part_person": [
20
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1711",
"date_sdn": 2345990,
"descr": "Death of Allen, Gershom",
"gid": "E1152",
"media": [],
"part_family": [],
"part_person": [
20
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1670-08-00",
"date_sdn": 2331228,
"descr": "Birth of Allen, Joanna",
"gid": "E2126",
"media": [],
"part_family": [],
"part_person": [
21
],
"place": 648,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1694-06-09",
"date_sdn": 2339941,
"descr": "Birth of Allen, Job",
"gid": "E1136",
"media": [],
"part_family": [],
"part_person": [
22
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1674-05-24",
"date_sdn": 2332620,
"descr": "Birth of Allen, John",
"gid": "E1123",
"media": [],
"part_family": [],
"part_person": [
23
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Allen, John",
"gid": "E1124",
"media": [],
"part_family": [],
"part_person": [
23
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1683-05-29",
"date_sdn": 2335912,
"descr": "Birth of Allen, Jonathan",
"gid": "E1149",
"media": [],
"part_family": [],
"part_person": [
24
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1733-05-08",
"date_sdn": 2354153,
"descr": "Death of Allen, Jonathan",
"gid": "E1150",
"media": [],
"part_family": [],
"part_person": [
24
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1692-05-17",
"date_sdn": 2339188,
"descr": "Birth of Allen, Joseph",
"gid": "E1135",
"media": [],
"part_family": [],
"part_person": [
25
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1679-01-01",
"date_sdn": 2334303,
"descr": "Birth of Allen, Lediah",
"gid": "E1144",
"media": [],
"part_family": [],
"part_person": [
26
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1680",
"date_sdn": 2334668,
"descr": "Death of Allen, Lediah",
"gid": "E1145",
"media": [],
"part_family": [],
"part_person": [
26
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1698-04-28",
"date_sdn": 2341360,
"descr": "Birth of Allen, Lydia",
"gid": "E1141",
"media": [],
"part_family": [],
"part_person": [
27
],
"place": 793,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1666-12-07",
"date_sdn": 2329895,
"descr": "Birth of Allen, Mary",
"gid": "E1118",
"media": [],
"part_family": [],
"part_person": [
28
],
"place": 65,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1696-05-12",
"date_sdn": 2340644,
"descr": "Birth of Allen, Rachel",
"gid": "E1137",
"media": [],
"part_family": [],
"part_person": [
29
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1747",
"date_sdn": 2359139,
"descr": "Death of Allen, Rachel",
"gid": "E1138",
"media": [],
"part_family": [],
"part_person": [
29
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1668-01-00",
"date_sdn": 2330285,
"descr": "Birth of Allen, Sarah",
"gid": "E1121",
"media": [],
"part_family": [],
"part_person": [
30
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1702",
"date_sdn": 2342703,
"descr": "Death of Allen, Sarah",
"gid": "E1122",
"media": [],
"part_family": [],
"part_person": [
30
],
"place": 793,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Col. Charles",
"gid": "E1737",
"media": [],
"part_family": [],
"part_person": [
31
],
"place": 525,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-02-00",
"date_sdn": 2401903,
"descr": "Death of Alvarado, Col. Charles",
"gid": "E1738",
"media": [],
"part_family": [],
"part_person": [
31
],
"place": 484,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1864-02-00",
"date_sdn": 2401903,
"descr": "Burial of Alvarado, Col. Charles",
"gid": "E1739",
"media": [],
"part_family": [],
"part_person": [
31
],
"place": 484,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Eliza",
"gid": "E0619",
"media": [],
"part_family": [],
"part_person": [
32
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Franklin",
"gid": "E0620",
"media": [],
"part_family": [],
"part_person": [
33
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1825-03-13",
"date_sdn": 2387699,
"descr": "Birth of Alvarado, John",
"gid": "E0618",
"media": [],
"part_family": [],
"part_person": [
35
],
"place": 487,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Marshall",
"gid": "E0625",
"media": [],
"part_family": [],
"part_person": [
36
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Mary",
"gid": "E1858",
"media": [],
"part_family": [],
"part_person": [
37
],
"place": 687,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1760-01-17",
"date_sdn": 2363903,
"descr": "Death of Alvarado, Mary",
"gid": "E1859",
"media": [],
"part_family": [],
"part_person": [
37
],
"place": 648,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Nancy",
"gid": "E1735",
"media": [],
"part_family": [],
"part_person": [
38
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1861-03-12",
"date_sdn": 2400847,
"descr": "Death of Alvarado, Nancy",
"gid": "E1736",
"media": [],
"part_family": [],
"part_person": [
38
],
"place": 149,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Thomas C.",
"gid": "E0622",
"media": [],
"part_family": [],
"part_person": [
40
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, William",
"gid": "E0621",
"media": [],
"part_family": [],
"part_person": [
41
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarez, Mary",
"gid": "E1806",
"media": [],
"part_family": [],
"part_person": [
42
],
"place": 806,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Alvarez, Mary",
"gid": "E1807",
"media": [],
"part_family": [],
"part_person": [
42
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Andersen, Samuel",
"gid": "E1186",
"media": [],
"part_family": [],
"part_person": [
44
],
"place": 479,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1858-02-00",
"date_sdn": 2399712,
"descr": "Death of Andersen, Samuel",
"gid": "E1187",
"media": [],
"part_family": [],
"part_person": [
44
],
"place": 506,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1719",
"date_sdn": 2348912,
"descr": "Birth of Anderson, Mary Molly",
"gid": "E1817",
"media": [],
"part_family": [],
"part_person": [
45
],
"place": 728,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1795-04-20",
"date_sdn": 2376780,
"descr": "Death of Anderson, Mary Molly",
"gid": "E1818",
"media": [],
"part_family": [],
"part_person": [
45
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1685",
"date_sdn": 2336495,
"descr": "Birth of Anderson, Rev. John",
"gid": "E2132",
"media": [],
"part_family": [],
"part_person": [
46
],
"place": 519,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1774-11-27",
"date_sdn": 2369331,
"descr": "Death of Anderson, Rev. John",
"gid": "E2133",
"media": [],
"part_family": [],
"part_person": [
46
],
"place": 636,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1628",
"date_sdn": 2315675,
"descr": "Birth of Anderson, Thomas",
"gid": "E2223",
"media": [],
"part_family": [],
"part_person": [
47
],
"place": 428,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1687",
"date_sdn": 2337225,
"descr": "Death of Anderson, Thomas",
"gid": "E2224",
"media": [],
"part_family": [],
"part_person": [
47
],
"place": 267,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1632-05-15",
"date_sdn": 2317271,
"descr": "Birth of Austin, Johannas",
"gid": "E2589",
"media": [],
"part_family": [],
"part_person": [
49
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1667-05-00",
"date_sdn": 2330040,
"descr": "Birth of Baker, Margaret",
"gid": "E2606",
"media": [],
"part_family": [],
"part_person": [
50
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1741-10-25",
"date_sdn": 2357245,
"descr": "Death of Baker, Margaret",
"gid": "E2607",
"media": [],
"part_family": [],
"part_person": [
50
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1869-07-08",
"date_sdn": 2403887,
"descr": "Birth of Ball, Abigail",
"gid": "E1233",
"media": [],
"part_family": [],
"part_person": [
52
],
"place": 613,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-04-21",
"date_sdn": 2430471,
"descr": "Death of Ball, Abigail",
"gid": "E1234",
"media": [],
"part_family": [],
"part_person": [
52
],
"place": 407,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1942-04-23",
"date_sdn": 2430473,
"descr": "Burial of Ball, Abigail",
"gid": "E1235",
"media": [],
"part_family": [],
"part_person": [
52
],
"place": 331,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1876-03-17",
"date_sdn": 2406331,
"descr": "Birth of Ball, Ida B.",
"gid": "E1088",
"media": [],
"part_family": [],
"part_person": [
53
],
"place": 168,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1848-07-09",
"date_sdn": 2396218,
"descr": "Birth of Ball, Jane",
"gid": "E1090",
"media": [],
"part_family": [],
"part_person": [
54
],
"place": 824,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1846-12-14",
"date_sdn": 2395645,
"descr": "Birth of Ball, Jasper",
"gid": "E1444",
"media": [],
"part_family": [],
"part_person": [
55
],
"place": 850,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1906-08-04",
"date_sdn": 2417427,
"descr": "Death of Ball, Jasper",
"gid": "E1445",
"media": [],
"part_family": [],
"part_person": [
55
],
"place": 613,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1906-08-06",
"date_sdn": 2417429,
"descr": "Burial of Ball, Jasper",
"gid": "E1446",
"media": [],
"part_family": [],
"part_person": [
55
],
"place": 613,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1870-10-09",
"date_sdn": 2404345,
"descr": "Birth of Ball, Katie E.",
"gid": "E1085",
"media": [],
"part_family": [],
"part_person": [
56
],
"place": 168,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1870-11-11",
"date_sdn": 2404378,
"descr": "Death of Ball, Katie E.",
"gid": "E1086",
"media": [],
"part_family": [],
"part_person": [
56
],
"place": 52,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ball, Lucy A.",
"gid": "E1087",
"media": [],
"part_family": [],
"part_person": [
57
],
"place": 168,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1852-03-02",
"date_sdn": 2397550,
"descr": "Birth of Ball, Martha",
"gid": "E1091",
"media": [],
"part_family": [],
"part_person": [
58
],
"place": 824,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1840-01-13",
"date_sdn": 2393118,
"descr": "Birth of Ball, Matthias",
"gid": "E1095",
"media": [],
"part_family": [],
"part_person": [
59
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1767-03-11",
"date_sdn": 2366513,
"descr": "Birth of Ball, Matthias Sr.",
"gid": "E1919",
"media": [],
"part_family": [],
"part_person": [
60
],
"place": 142,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1848-01-22",
"date_sdn": 2396049,
"descr": "Death of Ball, Matthias Sr.",
"gid": "E1920",
"media": [],
"part_family": [],
"part_person": [
60
],
"place": 572,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1810-08-07",
"date_sdn": 2382367,
"descr": "Birth of Ball, Matthias, Jr.",
"gid": "E1322",
"media": [],
"part_family": [],
"part_person": [
61
],
"place": 21,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1887-12-23",
"date_sdn": 2410629,
"descr": "Death of Ball, Matthias, Jr.",
"gid": "E1323",
"media": [],
"part_family": [],
"part_person": [
61
],
"place": 652,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1887-12-24",
"date_sdn": 2410630,
"descr": "Burial of Ball, Matthias, Jr.",
"gid": "E1324",
"media": [],
"part_family": [],
"part_person": [
61
],
"place": 624,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1871-10-14",
"date_sdn": 2404715,
"descr": "Birth of Ball, Robert Lee",
"gid": "E1082",
"media": [],
"part_family": [],
"part_person": [
62
],
"place": 81,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1728-04-18",
"date_sdn": 2352307,
"descr": "Birth of Ball, Thomas",
"gid": "E1915",
"media": [],
"part_family": [],
"part_person": [
63
],
"place": 544,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1861-10-19",
"date_sdn": 2401068,
"descr": "Birth of Ballard, Judith Ellen",
"gid": "E0339",
"media": [],
"part_family": [],
"part_person": [
65
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-05-20",
"date_sdn": 2416255,
"descr": "Death of Ballard, Judith Ellen",
"gid": "E0340",
"media": [],
"part_family": [],
"part_person": [
65
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Barnes, Ernestina",
"gid": "E2306",
"media": [],
"part_family": [],
"part_person": [
67
],
"place": 55,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-04-15",
"date_sdn": 2438866,
"descr": "Death of Barnes, Ernestina",
"gid": "E2307",
"media": [],
"part_family": [],
"part_person": [
67
],
"place": 166,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Barnes, Ernestina",
"gid": "E2308",
"media": [],
"part_family": [],
"part_person": [
67
],
"place": 498,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1752",
"date_sdn": 2360965,
"descr": "Birth of Barnett, Anna Gertrude",
"gid": "E0395",
"media": [],
"part_family": [],
"part_person": [
68
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1600",
"date_sdn": 2305448,
"descr": "Birth of Barrett, Anne",
"gid": "E1839",
"media": [],
"part_family": [],
"part_person": [
69
],
"place": 224,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Bass, Mary",
"gid": "E1912",
"media": [],
"part_family": [],
"part_person": [
70
],
"place": 514,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1823-10-04",
"date_sdn": 2387173,
"descr": "Death of Bass, Mary",
"gid": "E1913",
"media": [],
"part_family": [],
"part_person": [
70
],
"place": 708,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Birth of Beaulieu, Anna Catharina",
"gid": "E0411",
"media": [],
"part_family": [],
"part_person": [
71
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1706",
"date_sdn": 2344164,
"descr": "Birth of Beaulieu, Anna Elisabeth",
"gid": "E0404",
"media": [],
"part_family": [],
"part_person": [
72
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1772",
"date_sdn": 2368270,
"descr": "Death of Beaulieu, Anna Elisabeth",
"gid": "E0405",
"media": [],
"part_family": [],
"part_person": [
72
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1724",
"date_sdn": 2350738,
"descr": "Birth of Beaulieu, Anna Eva",
"gid": "E0423",
"media": [],
"part_family": [],
"part_person": [
73
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1760",
"date_sdn": 2363887,
"descr": "Death of Beaulieu, Anna Eva",
"gid": "E0424",
"media": [],
"part_family": [],
"part_person": [
73
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1726",
"date_sdn": 2351469,
"descr": "Birth of Beaulieu, Anna Margaretha",
"gid": "E0428",
"media": [],
"part_family": [],
"part_person": [
74
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1755",
"date_sdn": 2362061,
"descr": "Birth of Beaulieu, Anna Margaretha",
"gid": "E0401",
"media": [],
"part_family": [],
"part_person": [
75
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1796",
"date_sdn": 2377036,
"descr": "Death of Beaulieu, Anna Margaretha",
"gid": "E0402",
"media": [],
"part_family": [],
"part_person": [
75
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of Beaulieu, Anna Maria",
"gid": "E0412",
"media": [],
"part_family": [],
"part_person": [
76
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762",
"date_sdn": 2364618,
"descr": "Death of Beaulieu, Anna Maria",
"gid": "E0413",
"media": [],
"part_family": [],
"part_person": [
76
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1749",
"date_sdn": 2359870,
"descr": "Birth of Beaulieu, Anna Maria",
"gid": "E0396",
"media": [],
"part_family": [],
"part_person": [
77
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Death of Beaulieu, Anna Maria",
"gid": "E0397",
"media": [],
"part_family": [],
"part_person": [
77
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1722",
"date_sdn": 2350008,
"descr": "Birth of Beaulieu, Anna Ottilia",
"gid": "E0421",
"media": [],
"part_family": [],
"part_person": [
78
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1793",
"date_sdn": 2375941,
"descr": "Death of Beaulieu, Anna Ottilia",
"gid": "E0422",
"media": [],
"part_family": [],
"part_person": [
78
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1717",
"date_sdn": 2348182,
"descr": "Birth of Beaulieu, Johann Adam",
"gid": "E0415",
"media": [],
"part_family": [],
"part_person": [
79
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1803",
"date_sdn": 2379592,
"descr": "Death of Beaulieu, Johann Adam",
"gid": "E0416",
"media": [],
"part_family": [],
"part_person": [
79
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1738",
"date_sdn": 2355852,
"descr": "Birth of Beaulieu, Johann Adam",
"gid": "E0388",
"media": [],
"part_family": [],
"part_person": [
80
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1745",
"date_sdn": 2358409,
"descr": "Birth of Beaulieu, Johann Franciskus",
"gid": "E0391",
"media": [],
"part_family": [],
"part_person": [
81
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1826",
"date_sdn": 2387993,
"descr": "Death of Beaulieu, Johann Franciskus",
"gid": "E0392",
"media": [],
"part_family": [],
"part_person": [
81
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1711",
"date_sdn": 2345990,
"descr": "Birth of Beaulieu, Johann Michael",
"gid": "E0357",
"media": [],
"part_family": [],
"part_person": [
82
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0355",
"media": [],
"part_family": [],
"part_person": [
83
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1682",
"date_sdn": 2335399,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0359",
"media": [],
"part_family": [],
"part_person": [
84
],
"place": 383,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1728",
"date_sdn": 2352199,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0430",
"media": [],
"part_family": [],
"part_person": [
85
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1771",
"date_sdn": 2367905,
"descr": "Death of Beaulieu, Johann Simon",
"gid": "E0431",
"media": [],
"part_family": [],
"part_person": [
85
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1719",
"date_sdn": 2348912,
"descr": "Birth of Beaulieu, Johann Theobald",
"gid": "E0418",
"media": [],
"part_family": [],
"part_person": [
86
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Death of Beaulieu, Johann Theobald",
"gid": "E0419",
"media": [],
"part_family": [],
"part_person": [
86
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1708",
"date_sdn": 2344894,
"descr": "Birth of Beaulieu, Johann Valentin",
"gid": "E0406",
"media": [],
"part_family": [],
"part_person": [
87
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1802",
"date_sdn": 2379227,
"descr": "Death of Beaulieu, Johann Valentin",
"gid": "E0407",
"media": [],
"part_family": [],
"part_person": [
87
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1735",
"date_sdn": 2354756,
"descr": "Birth of Beaulieu, Johann Valentin",
"gid": "E0389",
"media": [],
"part_family": [],
"part_person": [
88
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1916-04-06",
"date_sdn": 2420960,
"descr": "Birth of B\u00e9langer, James",
"gid": "E2084",
"media": [],
"part_family": [],
"part_person": [
90
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1964-07-02",
"date_sdn": 2438579,
"descr": "Death of B\u00e9langer, James",
"gid": "E2085",
"media": [],
"part_family": [],
"part_person": [
90
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of B\u00e9langer, James",
"gid": "E2086",
"media": [],
"part_family": [],
"part_person": [
90
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1786-08-17",
"date_sdn": 2373612,
"descr": "Birth of Benson, Col. David",
"gid": "E2278",
"media": [],
"part_family": [],
"part_person": [
93
],
"place": 819,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1836-03-06",
"date_sdn": 2391710,
"descr": "Death of Benson, Col. David",
"gid": "E2279",
"media": [],
"part_family": [],
"part_person": [
93
],
"place": 342,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1742-05-07",
"date_sdn": 2357439,
"descr": "Birth of Benson, Col. Joseph",
"gid": "E2273",
"media": [],
"part_family": [],
"part_person": [
94
],
"place": 598,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1730",
"date_sdn": 2352930,
"descr": "Birth of Benson, David",
"gid": "E2275",
"media": [],
"part_family": [],
"part_person": [
95
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1777",
"date_sdn": 2370097,
"descr": "Death of Benson, David",
"gid": "E2276",
"media": [],
"part_family": [],
"part_person": [
95
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1715-01-30",
"date_sdn": 2347480,
"descr": "Birth of Benson, Elizabeth",
"gid": "E0704",
"media": [],
"part_family": [],
"part_person": [
96
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1685-04-13",
"date_sdn": 2336597,
"descr": "Birth of Benson, Elizabeth",
"gid": "E0712",
"media": [],
"part_family": [],
"part_person": [
97
],
"place": 629,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1674-11-20",
"date_sdn": 2332800,
"descr": "Birth of Benson, James",
"gid": "E0706",
"media": [],
"part_family": [],
"part_person": [
100
],
"place": 629,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1711-11-00",
"date_sdn": 2346294,
"descr": "Birth of Benson, James Edwin",
"gid": "E0702",
"media": [],
"part_family": [],
"part_person": [
101
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1713-11-00",
"date_sdn": 2347025,
"descr": "Birth of Benson, Jason Spotswood",
"gid": "E0703",
"media": [],
"part_family": [],
"part_person": [
102
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1707-06-10",
"date_sdn": 2344689,
"descr": "Birth of Benson, John",
"gid": "E0701",
"media": [],
"part_family": [],
"part_person": [
103
],
"place": 346,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Birth of Benson, John",
"gid": "E2277",
"media": [],
"part_family": [],
"part_person": [
104
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1676-01-09",
"date_sdn": 2333215,
"descr": "Birth of Benson, Joseph Louis(Sr.)",
"gid": "E2268",
"media": [],
"part_family": [],
"part_person": [
105
],
"place": 369,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1680-03-15",
"date_sdn": 2334742,
"descr": "Birth of Benson, Louise DeSoix",
"gid": "E0710",
"media": [],
"part_family": [],
"part_person": [
106
],
"place": 629,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1719-09-10",
"date_sdn": 2349164,
"descr": "Birth of Benson, Martha Ellen",
"gid": "E0705",
"media": [],
"part_family": [],
"part_person": [
107
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1747",
"date_sdn": 2359139,
"descr": "Birth of Benson, Martha Ellen M.",
"gid": "E1750",
"media": [],
"part_family": [],
"part_person": [
108
],
"place": 430,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1806",
"date_sdn": 2380688,
"descr": "Death of Benson, Martha Ellen M.",
"gid": "E1751",
"media": [],
"part_family": [],
"part_person": [
108
],
"place": 191,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1682-02-20",
"date_sdn": 2335449,
"descr": "Birth of Benson, Mary Frances",
"gid": "E0711",
"media": [],
"part_family": [],
"part_person": [
110
],
"place": 629,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1678-07-18",
"date_sdn": 2334136,
"descr": "Birth of Benson, Robert Watkins",
"gid": "E0707",
"media": [],
"part_family": [],
"part_person": [
112
],
"place": 629,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1740-03-00",
"date_sdn": 2356642,
"descr": "Birth of Benson, Samuel Sr.",
"gid": "E0715",
"media": [],
"part_family": [],
"part_person": [
113
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1704-03-09",
"date_sdn": 2343501,
"descr": "Birth of Benson, Thomas Stewart",
"gid": "E0700",
"media": [],
"part_family": [],
"part_person": [
114
],
"place": 174,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1709-08-10",
"date_sdn": 2345481,
"descr": "Birth of Benson, William",
"gid": "E2274",
"media": [],
"part_family": [],
"part_person": [
116
],
"place": 835,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1922-12-30",
"date_sdn": 2423419,
"descr": "Death of Bernier, Margaret",
"gid": "E0239",
"media": [],
"part_family": [],
"part_person": [
117
],
"place": 805,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1847-10-07",
"date_sdn": 2395942,
"descr": "Birth of Berry, Honorah",
"gid": "E1563",
"media": [],
"part_family": [],
"part_person": [
118
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1897-10-07",
"date_sdn": 2414205,
"descr": "Death of Berry, Honorah",
"gid": "E1564",
"media": [],
"part_family": [],
"part_person": [
118
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1664-09-29",
"date_sdn": 2329096,
"descr": "Birth of Bishop, Anna Barbara",
"gid": "E2262",
"media": [],
"part_family": [],
"part_person": [
119
],
"place": 350,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1717",
"date_sdn": 2348182,
"descr": "Death of Bishop, Anna Barbara",
"gid": "E2263",
"media": [],
"part_family": [],
"part_person": [
119
],
"place": 846,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "after 1626",
"date_sdn": 2314945,
"descr": "Birth of Bishop, Quirinus",
"gid": "E0295",
"media": [],
"part_family": [],
"part_person": [
120
],
"place": 9,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1683-05-17",
"date_sdn": 2335900,
"descr": "Death of Bishop, Quirinus",
"gid": "E0296",
"media": [],
"part_family": [],
"part_person": [
120
],
"place": 9,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1584",
"date_sdn": 2299604,
"descr": "Birth of Black, Jane",
"gid": "E0012",
"media": [],
"part_family": [],
"part_person": [
121
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1803-05-23",
"date_sdn": 2379734,
"descr": "Birth of Blair, Jane",
"gid": "E0734",
"media": [],
"part_family": [],
"part_person": [
122
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-03-10",
"date_sdn": 2402671,
"descr": "Death of Blair, Jane",
"gid": "E0735",
"media": [],
"part_family": [],
"part_person": [
122
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1806-07-11",
"date_sdn": 2380879,
"descr": "Birth of Blake, George",
"gid": "E1711",
"media": [],
"part_family": [],
"part_person": [
123
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1885-06-27",
"date_sdn": 2409720,
"descr": "Death of Blake, George",
"gid": "E1712",
"media": [],
"part_family": [],
"part_person": [
123
],
"place": 698,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Blake, George",
"gid": "E1713",
"media": [],
"part_family": [],
"part_person": [
123
],
"place": 313,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1832-09-05",
"date_sdn": 2390432,
"descr": "Birth of Blake, M. Susannah",
"gid": "E2113",
"media": [],
"part_family": [],
"part_person": [
124
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-05-25",
"date_sdn": 2422835,
"descr": "Death of Blake, M. Susannah",
"gid": "E2114",
"media": [],
"part_family": [],
"part_person": [
124
],
"place": 313,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-05-27",
"date_sdn": 2422837,
"descr": "Burial of Blake, M. Susannah",
"gid": "E2115",
"media": [],
"part_family": [],
"part_person": [
124
],
"place": 313,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1555",
"date_sdn": 2289012,
"descr": "Birth of Blanco, Bendicht",
"gid": "E2574",
"media": [],
"part_family": [],
"part_person": [
127
],
"place": 521,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1752",
"date_sdn": 2360965,
"descr": "Birth of Blanco, Daniel",
"gid": "E0795",
"media": [],
"part_family": [],
"part_person": [
129
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805",
"date_sdn": 2380323,
"descr": "Death of Blanco, Daniel",
"gid": "E0796",
"media": [],
"part_family": [],
"part_person": [
129
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1718-01-27",
"date_sdn": 2348573,
"descr": "Birth of Blanco, Gerhard",
"gid": "E2553",
"media": [],
"part_family": [],
"part_person": [
131
],
"place": 585,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1783-04-26",
"date_sdn": 2372403,
"descr": "Death of Blanco, Gerhard",
"gid": "E2554",
"media": [],
"part_family": [],
"part_person": [
131
],
"place": 537,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1528",
"date_sdn": 2279150,
"descr": "Birth of Blanco, Hans",
"gid": "E2572",
"media": [],
"part_family": [],
"part_person": [
132
],
"place": 795,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1582-01-07",
"date_sdn": 2298880,
"descr": "Birth of Blanco, Hans",
"gid": "E2575",
"media": [],
"part_family": [],
"part_person": [
133
],
"place": 521,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1494",
"date_sdn": 2266733,
"descr": "Birth of Blanco, Hans",
"gid": "E2571",
"media": [],
"part_family": [],
"part_person": [
134
],
"place": 14,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1639-11-10",
"date_sdn": 2320006,
"descr": "Birth of Blanco, Heinrich",
"gid": "E2577",
"media": [],
"part_family": [],
"part_person": [
135
],
"place": 521,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1847",
"date_sdn": 2395663,
"descr": "Death of Blanco, Henry",
"gid": "E0788",
"media": [],
"part_family": [],
"part_person": [
136
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1838",
"date_sdn": 2392376,
"descr": "Birth of Blanco, John W.",
"gid": "E2479",
"media": [],
"part_family": [],
"part_person": [
137
],
"place": 714,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1856",
"date_sdn": 2398950,
"descr": "Birth of Blanco, L. J.",
"gid": "E2492",
"media": [],
"part_family": [],
"part_person": [
138
],
"place": 114,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1849-01-25",
"date_sdn": 2396418,
"descr": "Birth of Blanco, Lucinda Catherine",
"gid": "E2145",
"media": [],
"part_family": [],
"part_person": [
139
],
"place": 466,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1932-10-21",
"date_sdn": 2427002,
"descr": "Death of Blanco, Lucinda Catherine",
"gid": "E2146",
"media": [],
"part_family": [],
"part_person": [
139
],
"place": 612,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1932-10-23",
"date_sdn": 2427004,
"descr": "Burial of Blanco, Lucinda Catherine",
"gid": "E2147",
"media": [],
"part_family": [],
"part_person": [
139
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1836-11-15",
"date_sdn": 2391964,
"descr": "Birth of Blanco, Malvina",
"gid": "E2476",
"media": [],
"part_family": [],
"part_person": [
140
],
"place": 714,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-03-07",
"date_sdn": 2421660,
"descr": "Death of Blanco, Malvina",
"gid": "E2477",
"media": [],
"part_family": [],
"part_person": [
140
],
"place": 559,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1918-03-09",
"date_sdn": 2421662,
"descr": "Burial of Blanco, Malvina",
"gid": "E2478",
"media": [],
"part_family": [],
"part_person": [
140
],
"place": 116,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Blanco, Mary F.",
"gid": "E2480",
"media": [],
"part_family": [],
"part_person": [
143
],
"place": 714,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1854",
"date_sdn": 2398220,
"descr": "Birth of Blanco, Milton",
"gid": "E2488",
"media": [],
"part_family": [],
"part_person": [
144
],
"place": 758,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1462",
"date_sdn": 2255045,
"descr": "Birth of Blanco, Mr.",
"gid": "E2570",
"media": [],
"part_family": [],
"part_person": [
145
],
"place": 14,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Blanco, Paris",
"gid": "E2481",
"media": [],
"part_family": [],
"part_person": [
146
],
"place": 714,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "20",
"date_sdn": 1728365,
"descr": "Birth of Blanco, Rufus",
"gid": "E1978",
"media": [],
"part_family": [],
"part_person": [
149
],
"place": 113,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-11-04",
"date_sdn": 2402910,
"descr": "Death of Blanco, Rufus",
"gid": "E1979",
"media": [],
"part_family": [],
"part_person": [
149
],
"place": 75,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1866-11-06",
"date_sdn": 2402912,
"descr": "Burial of Blanco, Rufus",
"gid": "E1980",
"media": [],
"part_family": [],
"part_person": [
149
],
"place": 699,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1759-01-02",
"date_sdn": 2363523,
"descr": "Birth of Blanco, Samuel",
"gid": "E0793",
"media": [],
"part_family": [],
"part_person": [
150
],
"place": 537,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1840-01-14",
"date_sdn": 2393119,
"descr": "Death of Blanco, Samuel",
"gid": "E0794",
"media": [],
"part_family": [],
"part_person": [
150
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1851-04-14",
"date_sdn": 2397227,
"descr": "Birth of Blanco, Stephen",
"gid": "E2485",
"media": [],
"part_family": [],
"part_person": [
151
],
"place": 105,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-04-08",
"date_sdn": 2416213,
"descr": "Death of Blanco, Stephen",
"gid": "E2486",
"media": [],
"part_family": [],
"part_person": [
151
],
"place": 173,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1903-04-10",
"date_sdn": 2416215,
"descr": "Burial of Blanco, Stephen",
"gid": "E2487",
"media": [],
"part_family": [],
"part_person": [
151
],
"place": 97,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1850-05-14",
"date_sdn": 2396892,
"descr": "Birth of Boucher, Bridget",
"gid": "E1569",
"media": [],
"part_family": [],
"part_person": [
153
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1922-05-11",
"date_sdn": 2423186,
"descr": "Death of Boucher, Bridget",
"gid": "E1570",
"media": [],
"part_family": [],
"part_person": [
153
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Bridget",
"gid": "E2333",
"media": [],
"part_family": [],
"part_person": [
154
],
"place": 25,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1816",
"date_sdn": 2384340,
"descr": "Birth of Boucher, Catherine",
"gid": "E2327",
"media": [],
"part_family": [],
"part_person": [
155
],
"place": 25,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1857",
"date_sdn": 2399316,
"descr": "Death of Boucher, Catherine",
"gid": "E2328",
"media": [],
"part_family": [],
"part_person": [
155
],
"place": 341,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1857",
"date_sdn": 2399316,
"descr": "Burial of Boucher, Catherine",
"gid": "E2329",
"media": [],
"part_family": [],
"part_person": [
155
],
"place": 811,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1869-07-05",
"date_sdn": 2403884,
"descr": "Birth of Boucher, Catherine",
"gid": "E1565",
"media": [],
"part_family": [],
"part_person": [
156
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1890-01-19",
"date_sdn": 2411387,
"descr": "Death of Boucher, Catherine",
"gid": "E1566",
"media": [],
"part_family": [],
"part_person": [
156
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Fr. Patrick",
"gid": "E2410",
"media": [],
"part_family": [],
"part_person": [
161
],
"place": 769,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1896-07-24",
"date_sdn": 2413765,
"descr": "Birth of Boucher, Fr.Lawrence M.",
"gid": "E1800",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1972-05-03",
"date_sdn": 2441441,
"descr": "Death of Boucher, Fr.Lawrence M.",
"gid": "E1801",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Fr.Lawrence M.",
"gid": "E1802",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": 721,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Birth of Boucher, Honora",
"gid": "E2641",
"media": [],
"part_family": [],
"part_person": [
163
],
"place": 464,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-09",
"date_sdn": 2413234,
"descr": "Death of Boucher, Honora",
"gid": "E2642",
"media": [],
"part_family": [],
"part_person": [
163
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1895-02-00",
"date_sdn": 2413226,
"descr": "Burial of Boucher, Honora",
"gid": "E2643",
"media": [],
"part_family": [],
"part_person": [
163
],
"place": 451,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, James",
"gid": "E1550",
"media": [],
"part_family": [],
"part_person": [
164
],
"place": 608,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1890-02-17",
"date_sdn": 2411416,
"descr": "Birth of Boucher, Mary Cecilia",
"gid": "E1889",
"media": [],
"part_family": [],
"part_person": [
166
],
"place": 878,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1945-06-03",
"date_sdn": 2431610,
"descr": "Death of Boucher, Mary Cecilia",
"gid": "E1890",
"media": [],
"part_family": [],
"part_person": [
166
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1945-06-05",
"date_sdn": 2431612,
"descr": "Burial of Boucher, Mary Cecilia",
"gid": "E1891",
"media": [],
"part_family": [],
"part_person": [
166
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1920-02-18",
"date_sdn": 2422373,
"descr": "Death of Boucher, Michael",
"gid": "E1562",
"media": [],
"part_family": [],
"part_person": [
167
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1820",
"date_sdn": 2385801,
"descr": "Birth of Boucher, Michael",
"gid": "E2619",
"media": [],
"part_family": [],
"part_person": [
168
],
"place": 25,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1859-01-09",
"date_sdn": 2400054,
"descr": "Death of Boucher, Michael",
"gid": "E2620",
"media": [],
"part_family": [],
"part_person": [
168
],
"place": 62,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1859",
"date_sdn": 2400046,
"descr": "Burial of Boucher, Michael",
"gid": "E2621",
"media": [],
"part_family": [],
"part_person": [
168
],
"place": 451,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1879-07-18",
"date_sdn": 2407549,
"descr": "Birth of Boucher, Nora A.",
"gid": "E1545",
"media": [],
"part_family": [],
"part_person": [
169
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1939-08-15",
"date_sdn": 2429491,
"descr": "Death of Boucher, Nora A.",
"gid": "E1546",
"media": [],
"part_family": [],
"part_person": [
169
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Patrick",
"gid": "E0862",
"media": [],
"part_family": [],
"part_person": [
170
],
"place": 769,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1886",
"date_sdn": 2409908,
"descr": "Birth of Boucher, Prof. William Joseph",
"gid": "E2413",
"media": [],
"part_family": [],
"part_person": [
171
],
"place": 769,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1977-01-26",
"date_sdn": 2443170,
"descr": "Death of Boucher, Prof. William Joseph",
"gid": "E2414",
"media": [],
"part_family": [],
"part_person": [
171
],
"place": 241,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1943-11-26",
"date_sdn": 2431055,
"descr": "Birth of Boucher, Sharon",
"gid": "E1793",
"media": [],
"part_family": [],
"part_person": [
172
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1973-06-11",
"date_sdn": 2441845,
"descr": "Death of Boucher, Sharon",
"gid": "E1794",
"media": [],
"part_family": [],
"part_person": [
172
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Stephen Francis",
"gid": "E2353",
"media": [],
"part_family": [],
"part_person": [
173
],
"place": 769,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1975-08-24",
"date_sdn": 2442649,
"descr": "Death of Boucher, Stephen Francis",
"gid": "E2354",
"media": [],
"part_family": [],
"part_person": [
173
],
"place": 769,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1975-08-00",
"date_sdn": 2442626,
"descr": "Burial of Boucher, Stephen Francis",
"gid": "E2355",
"media": [],
"part_family": [],
"part_person": [
173
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1840-12-24",
"date_sdn": 2393464,
"descr": "Birth of Boucher, Thomas",
"gid": "E1556",
"media": [],
"part_family": [],
"part_person": [
174
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1885-07-29",
"date_sdn": 2409752,
"descr": "Death of Boucher, Thomas",
"gid": "E1557",
"media": [],
"part_family": [],
"part_person": [
174
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1888-12-06",
"date_sdn": 2410978,
"descr": "Birth of Boucher, Thomas W.",
"gid": "E1548",
"media": [],
"part_family": [],
"part_person": [
175
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-04-02",
"date_sdn": 2430452,
"descr": "Death of Boucher, Thomas W.",
"gid": "E1549",
"media": [],
"part_family": [],
"part_person": [
175
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1870-09-10",
"date_sdn": 2404316,
"descr": "Birth of Boucher, William",
"gid": "E1567",
"media": [],
"part_family": [],
"part_person": [
176
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-06-26",
"date_sdn": 2430902,
"descr": "Death of Boucher, William",
"gid": "E1568",
"media": [],
"part_family": [],
"part_person": [
176
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1851-02-07",
"date_sdn": 2397161,
"descr": "Birth of Boucher, William",
"gid": "E2350",
"media": [],
"part_family": [],
"part_person": [
177
],
"place": 769,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-08-02",
"date_sdn": 2434227,
"descr": "Death of Boucher, William",
"gid": "E2351",
"media": [],
"part_family": [],
"part_person": [
177
],
"place": 769,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1952-08-03",
"date_sdn": 2434228,
"descr": "Burial of Boucher, William",
"gid": "E2352",
"media": [],
"part_family": [],
"part_person": [
177
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1854-01-25",
"date_sdn": 2398244,
"descr": "Birth of Boucher, William Bernard",
"gid": "E1811",
"media": [],
"part_family": [],
"part_person": [
178
],
"place": 809,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-27",
"date_sdn": 2425608,
"descr": "Death of Boucher, William Bernard",
"gid": "E1812",
"media": [],
"part_family": [],
"part_person": [
178
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1928-12-29",
"date_sdn": 2425610,
"descr": "Burial of Boucher, William Bernard",
"gid": "E1813",
"media": [],
"part_family": [],
"part_person": [
178
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1944-01-13",
"date_sdn": 2431103,
"descr": "Death of Boucher, William C.",
"gid": "E1558",
"media": [],
"part_family": [],
"part_person": [
179
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1897-08-14",
"date_sdn": 2414151,
"descr": "Birth of Boyd, Carmen Alberta",
"gid": "E1155",
"media": [],
"part_family": [],
"part_person": [
182
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1949-06-17",
"date_sdn": 2433085,
"descr": "Death of Boyd, Carmen Alberta",
"gid": "E1156",
"media": [],
"part_family": [],
"part_person": [
182
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1868-03-27",
"date_sdn": 2403419,
"descr": "Birth of Boyd, Charles Newton",
"gid": "E0466",
"media": [],
"part_family": [],
"part_person": [
183
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1920-03-21",
"date_sdn": 2422405,
"descr": "Death of Boyd, Charles Newton",
"gid": "E0467",
"media": [],
"part_family": [],
"part_person": [
183
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1789",
"date_sdn": 2374480,
"descr": "Birth of Bradley, Mary",
"gid": "E0372",
"media": [],
"part_family": [],
"part_person": [
184
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1939-08-05",
"date_sdn": 2429481,
"descr": "Birth of Briggs, Joyce Inez",
"gid": "E1638",
"media": [],
"part_family": [],
"part_person": [
186
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1985",
"date_sdn": 2446067,
"descr": "Death of Briggs, Joyce Inez",
"gid": "E1639",
"media": [],
"part_family": [],
"part_person": [
186
],
"place": 370,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1642",
"date_sdn": 2320789,
"descr": "Birth of Brooks, Guillaume de",
"gid": "E0174",
"media": [],
"part_family": [],
"part_person": [
189
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Brooks, Major Marquis II",
"gid": "E2633",
"media": [],
"part_family": [],
"part_person": [
192
],
"place": 69,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1755-05-10",
"date_sdn": 2362190,
"descr": "Death of Brooks, Major Marquis II",
"gid": "E2634",
"media": [],
"part_family": [],
"part_person": [
192
],
"place": 220,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1675",
"date_sdn": 2332842,
"descr": "Birth of Brooks, Marquis I",
"gid": "E2631",
"media": [],
"part_family": [],
"part_person": [
193
],
"place": 781,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1741",
"date_sdn": 2356948,
"descr": "Death of Brooks, Marquis I",
"gid": "E2632",
"media": [],
"part_family": [],
"part_person": [
193
],
"place": 491,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1755-02-26",
"date_sdn": 2362117,
"descr": "Birth of Brooks, Marquis IV",
"gid": "E0166",
"media": [],
"part_family": [],
"part_person": [
194
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1839-02-09",
"date_sdn": 2392780,
"descr": "Death of Brooks, Marquis IV",
"gid": "E0167",
"media": [],
"part_family": [],
"part_person": [
194
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1727-01-18",
"date_sdn": 2351851,
"descr": "Birth of Brooks, William Waller",
"gid": "E0162",
"media": [],
"part_family": [],
"part_person": [
198
],
"place": 491,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1773-09-19",
"date_sdn": 2368897,
"descr": "Death of Brooks, William Waller",
"gid": "E0163",
"media": [],
"part_family": [],
"part_person": [
198
],
"place": 220,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1584-09-27",
"date_sdn": 2299874,
"descr": "Birth of Buchanan, Elsbeth",
"gid": "E2576",
"media": [],
"part_family": [],
"part_person": [
200
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1781-07-22",
"date_sdn": 2371760,
"descr": "Birth of Burns, Margaret",
"gid": "E1278",
"media": [],
"part_family": [],
"part_person": [
202
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-01-17",
"date_sdn": 2396410,
"descr": "Death of Burns, Margaret",
"gid": "E1279",
"media": [],
"part_family": [],
"part_person": [
202
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Bush, James",
"gid": "E0864",
"media": [],
"part_family": [],
"part_person": [
206
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "about 1633",
"date_sdn": 2317502,
"descr": "Birth of Carpenter, Sarah",
"gid": "E2225",
"media": [],
"part_family": [],
"part_person": [
213
],
"place": 93,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1858-12-31",
"date_sdn": 2400045,
"descr": "Birth of Carr, Zelpha Josephine",
"gid": "E0203",
"media": [],
"part_family": [],
"part_person": [
214
],
"place": 99,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-08",
"date_sdn": 2413233,
"descr": "Death of Carr, Zelpha Josephine",
"gid": "E0204",
"media": [],
"part_family": [],
"part_person": [
214
],
"place": 63,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1895-02-10",
"date_sdn": 2413235,
"descr": "Burial of Carr, Zelpha Josephine",
"gid": "E0205",
"media": [],
"part_family": [],
"part_person": [
214
],
"place": 765,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1791-12-20",
"date_sdn": 2375563,
"descr": "Birth of Carroll, Grace",
"gid": "E2000",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 144,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1863-02-01",
"date_sdn": 2401538,
"descr": "Death of Carroll, Grace",
"gid": "E2001",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 487,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1863-02-03",
"date_sdn": 2401540,
"descr": "Burial of Carroll, Grace",
"gid": "E2002",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 484,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Carroll, Jacob A.",
"gid": "E2264",
"media": [],
"part_family": [],
"part_person": [
216
],
"place": 13,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1763",
"date_sdn": 2364983,
"descr": "Death of Carroll, Jacob A.",
"gid": "E2265",
"media": [],
"part_family": [],
"part_person": [
216
],
"place": 711,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Carroll, Matthias Sr.",
"gid": "E1998",
"media": [],
"part_family": [],
"part_person": [
217
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of Carroll, Matthias Sr.",
"gid": "E1999",
"media": [],
"part_family": [],
"part_person": [
217
],
"place": 513,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Castro, ???",
"gid": "E2508",
"media": [],
"part_family": [],
"part_person": [
219
],
"place": 191,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1495",
"date_sdn": 2267098,
"descr": "Birth of Christiansen, Christopher",
"gid": "E0062",
"media": [],
"part_family": [],
"part_person": [
221
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1570",
"date_sdn": 2294491,
"descr": "Death of Christiansen, Christopher",
"gid": "E0063",
"media": [],
"part_family": [],
"part_person": [
221
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1530",
"date_sdn": 2279881,
"descr": "Birth of Christiansen, Christopher",
"gid": "E1836",
"media": [],
"part_family": [],
"part_person": [
222
],
"place": 339,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1588",
"date_sdn": 2301065,
"descr": "Death of Christiansen, Christopher",
"gid": "E1837",
"media": [],
"part_family": [],
"part_person": [
222
],
"place": 236,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Christiansen, Christopher",
"gid": "E1838",
"media": [],
"part_family": [],
"part_person": [
222
],
"place": 339,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1583",
"date_sdn": 2299239,
"descr": "Birth of Christiansen, Edward",
"gid": "E1842",
"media": [],
"part_family": [],
"part_person": [
223
],
"place": 176,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1614",
"date_sdn": 2310562,
"descr": "Death of Christiansen, Edward",
"gid": "E1843",
"media": [],
"part_family": [],
"part_person": [
223
],
"place": 692,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Christiansen, Edward",
"gid": "E1844",
"media": [],
"part_family": [],
"part_person": [
223
],
"place": 339,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Christiansen, Edward",
"gid": "E1845",
"media": [],
"part_family": [],
"part_person": [
224
],
"place": 23,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1684",
"date_sdn": 2336129,
"descr": "Death of Christiansen, Edward",
"gid": "E1846",
"media": [],
"part_family": [],
"part_person": [
224
],
"place": 422,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1796-07-06",
"date_sdn": 2377223,
"descr": "Death of Christiansen, Frances",
"gid": "E1879",
"media": [],
"part_family": [],
"part_person": [
225
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1688-02-04",
"date_sdn": 2337624,
"descr": "Birth of Christiansen, Hannah",
"gid": "E2127",
"media": [],
"part_family": [],
"part_person": [
226
],
"place": 422,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1742-06-26",
"date_sdn": 2357489,
"descr": "Death of Christiansen, Hannah",
"gid": "E2128",
"media": [],
"part_family": [],
"part_person": [
226
],
"place": 671,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1662-02-01",
"date_sdn": 2328125,
"descr": "Birth of Christiansen, John",
"gid": "E2230",
"media": [],
"part_family": [],
"part_person": [
227
],
"place": 638,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Christiansen, John",
"gid": "E2231",
"media": [],
"part_family": [],
"part_person": [
227
],
"place": 648,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1455",
"date_sdn": 2252488,
"descr": "Birth of Christiansen, John",
"gid": "E0056",
"media": [],
"part_family": [],
"part_person": [
228
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1514",
"date_sdn": 2274037,
"descr": "Death of Christiansen, John",
"gid": "E0057",
"media": [],
"part_family": [],
"part_person": [
228
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1655-03-01",
"date_sdn": 2325596,
"descr": "Birth of Christiansen, Joseph",
"gid": "E2124",
"media": [],
"part_family": [],
"part_person": [
229
],
"place": 638,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1726-01-00",
"date_sdn": 2351469,
"descr": "Death of Christiansen, Joseph",
"gid": "E2125",
"media": [],
"part_family": [],
"part_person": [
229
],
"place": 422,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1693-04-25",
"date_sdn": 2339531,
"descr": "Birth of Christiansen, Martha",
"gid": "E2134",
"media": [],
"part_family": [],
"part_person": [
230
],
"place": 648,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1766-04-18",
"date_sdn": 2366186,
"descr": "Death of Christiansen, Martha",
"gid": "E2135",
"media": [],
"part_family": [],
"part_person": [
230
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1642-05-15",
"date_sdn": 2320923,
"descr": "Birth of Christiansen, Nathaniel",
"gid": "E1851",
"media": [],
"part_family": [],
"part_person": [
231
],
"place": 638,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1713-11-21",
"date_sdn": 2347045,
"descr": "Death of Christiansen, Nathaniel",
"gid": "E1852",
"media": [],
"part_family": [],
"part_person": [
231
],
"place": 648,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1668",
"date_sdn": 2330285,
"descr": "Birth of Christiansen, Samuel",
"gid": "E1856",
"media": [],
"part_family": [],
"part_person": [
232
],
"place": 638,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-06-25",
"date_sdn": 2361871,
"descr": "Death of Christiansen, Samuel",
"gid": "E1857",
"media": [],
"part_family": [],
"part_person": [
232
],
"place": 648,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1785-03-31",
"date_sdn": 2373108,
"descr": "Birth of Clark, Sarah",
"gid": "E1925",
"media": [],
"part_family": [],
"part_person": [
233
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1727-08-15",
"date_sdn": 2352060,
"descr": "Birth of Cole, Eurydice",
"gid": "E2282",
"media": [],
"part_family": [],
"part_person": [
234
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1757",
"date_sdn": 2362792,
"descr": "Death of Cole, Susannah",
"gid": "E2257",
"media": [],
"part_family": [],
"part_person": [
235
],
"place": 38,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "about 1196",
"date_sdn": 2157890,
"descr": "Birth of Copeland, Mary",
"gid": "E0036",
"media": [],
"part_family": [],
"part_person": [
237
],
"place": 317,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1610",
"date_sdn": 2309101,
"descr": "Birth of Crawford, Margaret",
"gid": "E0266",
"media": [],
"part_family": [],
"part_person": [
239
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1669",
"date_sdn": 2330651,
"descr": "Death of Crawford, Margaret",
"gid": "E0267",
"media": [],
"part_family": [],
"part_person": [
239
],
"place": 308,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Thomas",
"gid": "E0571",
"media": [],
"part_family": [],
"part_person": [
240
],
"place": 211,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cunningham, Peter Sr.",
"gid": "E1726",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 591,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1832-05-00",
"date_sdn": 2390305,
"descr": "Death of Cunningham, Peter Sr.",
"gid": "E1727",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 482,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1832-05-00",
"date_sdn": 2390305,
"descr": "Burial of Cunningham, Peter Sr.",
"gid": "E1728",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 738,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1805-09-25",
"date_sdn": 2380590,
"descr": "Birth of Cunningham, Sally Sarah",
"gid": "E1714",
"media": [],
"part_family": [],
"part_person": [
242
],
"place": 118,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1867-02-19",
"date_sdn": 2403017,
"descr": "Death of Cunningham, Sally Sarah",
"gid": "E1715",
"media": [],
"part_family": [],
"part_person": [
242
],
"place": 698,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Cunningham, Sally Sarah",
"gid": "E1716",
"media": [],
"part_family": [],
"part_person": [
242
],
"place": 313,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1765-04-05",
"date_sdn": 2365808,
"descr": "Birth of Cunningham, William Philip",
"gid": "E1722",
"media": [],
"part_family": [],
"part_person": [
243
],
"place": 874,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1871-04-28",
"date_sdn": 2404546,
"descr": "Death of Cunningham, William Philip",
"gid": "E1723",
"media": [],
"part_family": [],
"part_person": [
243
],
"place": 547,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1871-04-29",
"date_sdn": 2404547,
"descr": "Burial of Cunningham, William Philip",
"gid": "E1724",
"media": [],
"part_family": [],
"part_person": [
243
],
"place": 90,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1478",
"date_sdn": 2260889,
"descr": "Birth of Curtis, Margaret",
"gid": "E0251",
"media": [],
"part_family": [],
"part_person": [
246
],
"place": 632,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Daniels, Phoebe",
"gid": "E2682",
"media": [],
"part_family": [],
"part_person": [
249
],
"place": 80,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1894-09-27",
"date_sdn": 2413099,
"descr": "Birth of Davidson, Bernice",
"gid": "E2035",
"media": [],
"part_family": [],
"part_person": [
250
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1980-05-24",
"date_sdn": 2444384,
"descr": "Death of Davidson, Bernice",
"gid": "E2036",
"media": [],
"part_family": [],
"part_person": [
250
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1743-08-09",
"date_sdn": 2357898,
"descr": "Birth of Davis, Jonathan",
"gid": "E1877",
"media": [],
"part_family": [],
"part_person": [
253
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-12-28",
"date_sdn": 2387624,
"descr": "Death of Davis, Jonathan",
"gid": "E1878",
"media": [],
"part_family": [],
"part_person": [
253
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1762-09-06",
"date_sdn": 2364866,
"descr": "Birth of Davis, Sabra",
"gid": "E1885",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1845-11-01",
"date_sdn": 2395237,
"descr": "Death of Davis, Sabra",
"gid": "E1886",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": 391,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Davis, Sabra",
"gid": "E1887",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": 391,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Delgado, Catherine",
"gid": "E0773",
"media": [],
"part_family": [],
"part_person": [
256
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1932-12-03",
"date_sdn": 2427045,
"descr": "Death of Dennis, Susan",
"gid": "E0863",
"media": [],
"part_family": [],
"part_person": [
258
],
"place": 769,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1761-08-07",
"date_sdn": 2364471,
"descr": "Birth of Diaz, Frances",
"gid": "E2674",
"media": [],
"part_family": [],
"part_person": [
263
],
"place": 162,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1851-10-06",
"date_sdn": 2397402,
"descr": "Death of Diaz, Frances",
"gid": "E2675",
"media": [],
"part_family": [],
"part_person": [
263
],
"place": 371,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1851-10-08",
"date_sdn": 2397404,
"descr": "Burial of Diaz, Frances",
"gid": "E2676",
"media": [],
"part_family": [],
"part_person": [
263
],
"place": 371,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1631-02-01",
"date_sdn": 2316802,
"descr": "Death of Diaz, John",
"gid": "E0310",
"media": [],
"part_family": [],
"part_person": [
265
],
"place": 672,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Diaz, Mary Polly",
"gid": "E1040",
"media": [],
"part_family": [],
"part_person": [
267
],
"place": 884,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1822",
"date_sdn": 2386532,
"descr": "Death of Diaz, Mary Polly",
"gid": "E1041",
"media": [],
"part_family": [],
"part_person": [
267
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1648",
"date_sdn": 2322980,
"descr": "Birth of Diaz, William",
"gid": "E2701",
"media": [],
"part_family": [],
"part_person": [
270
],
"place": 285,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1700-09-16",
"date_sdn": 2342231,
"descr": "Death of Diaz, William",
"gid": "E2702",
"media": [],
"part_family": [],
"part_person": [
270
],
"place": 157,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1530",
"date_sdn": 2279881,
"descr": "Birth of Diaz, William (Rev.)",
"gid": "E0308",
"media": [],
"part_family": [],
"part_person": [
271
],
"place": 394,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1587-10-12",
"date_sdn": 2300984,
"descr": "Death of Diaz, William (Rev.)",
"gid": "E0309",
"media": [],
"part_family": [],
"part_person": [
271
],
"place": 499,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1671",
"date_sdn": 2331381,
"descr": "Birth of Dixon, Thomas",
"gid": "E1064",
"media": [],
"part_family": [],
"part_person": [
272
],
"place": 321,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1811",
"date_sdn": 2382514,
"descr": "Birth of Dom\u00ednguez, George",
"gid": "E2509",
"media": [],
"part_family": [],
"part_person": [
274
],
"place": 459,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Dom\u00ednguez, Mahala",
"gid": "E0488",
"media": [],
"part_family": [],
"part_person": [
275
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1839-03-15",
"date_sdn": 2392814,
"descr": "Birth of Dom\u00ednguez, Mary E.",
"gid": "E1614",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1893-09-30",
"date_sdn": 2412737,
"descr": "Death of Dom\u00ednguez, Mary E.",
"gid": "E1615",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 237,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1893-10-01",
"date_sdn": 2412738,
"descr": "Burial of Dom\u00ednguez, Mary E.",
"gid": "E1616",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 626,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Dom\u00ednguez, Zorada",
"gid": "E0461",
"media": [],
"part_family": [],
"part_person": [
277
],
"place": 573,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1821-02-17",
"date_sdn": 2386214,
"descr": "Birth of Douglas, Abraham",
"gid": "E1732",
"media": [],
"part_family": [],
"part_person": [
280
],
"place": 254,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1901-01-12",
"date_sdn": 2415397,
"descr": "Death of Douglas, Abraham",
"gid": "E1733",
"media": [],
"part_family": [],
"part_person": [
280
],
"place": 213,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1901-01-14",
"date_sdn": 2415399,
"descr": "Burial of Douglas, Abraham",
"gid": "E1734",
"media": [],
"part_family": [],
"part_person": [
280
],
"place": 213,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1827-05-01",
"date_sdn": 2388478,
"descr": "Birth of Douglas, Alfred",
"gid": "E0650",
"media": [],
"part_family": [],
"part_person": [
281
],
"place": 487,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-06-26",
"date_sdn": 2419945,
"descr": "Death of Douglas, Alfred",
"gid": "E0651",
"media": [],
"part_family": [],
"part_person": [
281
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1818-04-09",
"date_sdn": 2385169,
"descr": "Birth of Douglas, Catherine",
"gid": "E0649",
"media": [],
"part_family": [],
"part_person": [
285
],
"place": 649,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Charles",
"gid": "E0632",
"media": [],
"part_family": [],
"part_person": [
286
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1850-08-07",
"date_sdn": 2396977,
"descr": "Birth of Douglas, Eliza Jane",
"gid": "E0630",
"media": [],
"part_family": [],
"part_person": [
287
],
"place": 172,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1915",
"date_sdn": 2420499,
"descr": "Death of Douglas, Eliza Jane",
"gid": "E0631",
"media": [],
"part_family": [],
"part_person": [
287
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1853-02-26",
"date_sdn": 2397911,
"descr": "Birth of Douglas, Elizabeth",
"gid": "E1559",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 213,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1890-02-14",
"date_sdn": 2411413,
"descr": "Death of Douglas, Elizabeth",
"gid": "E1560",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 642,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1890-02-16",
"date_sdn": 2411415,
"descr": "Burial of Douglas, Elizabeth",
"gid": "E1561",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1808-09-20",
"date_sdn": 2381681,
"descr": "Birth of Douglas, Elizabeth",
"gid": "E0643",
"media": [],
"part_family": [],
"part_person": [
290
],
"place": 649,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1830-05-24",
"date_sdn": 2389597,
"descr": "Birth of Douglas, Ellen",
"gid": "E0652",
"media": [],
"part_family": [],
"part_person": [
291
],
"place": 487,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Jacob",
"gid": "E0633",
"media": [],
"part_family": [],
"part_person": [
295
],
"place": 172,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1739-11-25",
"date_sdn": 2356545,
"descr": "Birth of Douglas, John Sr.",
"gid": "E1929",
"media": [],
"part_family": [],
"part_person": [
298
],
"place": 159,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-10-00",
"date_sdn": 2386440,
"descr": "Death of Douglas, John Sr.",
"gid": "E1930",
"media": [],
"part_family": [],
"part_person": [
298
],
"place": 720,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Douglas, John Sr.",
"gid": "E1931",
"media": [],
"part_family": [],
"part_person": [
298
],
"place": 881,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1787-09-07",
"date_sdn": 2373998,
"descr": "Birth of Douglas, Joseph",
"gid": "E1995",
"media": [],
"part_family": [],
"part_person": [
300
],
"place": 759,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1857-03-09",
"date_sdn": 2399383,
"descr": "Death of Douglas, Joseph",
"gid": "E1996",
"media": [],
"part_family": [],
"part_person": [
300
],
"place": 487,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1857-03-11",
"date_sdn": 2399385,
"descr": "Burial of Douglas, Joseph",
"gid": "E1997",
"media": [],
"part_family": [],
"part_person": [
300
],
"place": 484,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1833-05-06",
"date_sdn": 2390675,
"descr": "Birth of Douglas, Lucinda J.",
"gid": "E0653",
"media": [],
"part_family": [],
"part_person": [
301
],
"place": 487,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1785-04-27",
"date_sdn": 2373135,
"descr": "Birth of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2567",
"media": [],
"part_family": [],
"part_person": [
302
],
"place": 448,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-08-30",
"date_sdn": 2394078,
"descr": "Death of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2568",
"media": [],
"part_family": [],
"part_person": [
302
],
"place": 801,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1842-09-01",
"date_sdn": 2394080,
"descr": "Burial of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2569",
"media": [],
"part_family": [],
"part_person": [
302
],
"place": 363,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1815-06-19",
"date_sdn": 2384144,
"descr": "Birth of Douglas, Samuel",
"gid": "E0654",
"media": [],
"part_family": [],
"part_person": [
304
],
"place": 649,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1836-12-01",
"date_sdn": 2391980,
"descr": "Birth of Douglas, Susan",
"gid": "E0655",
"media": [],
"part_family": [],
"part_person": [
306
],
"place": 487,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1773-09-21",
"date_sdn": 2368899,
"descr": "Birth of Doyle, Robert Gove",
"gid": "E1042",
"media": [],
"part_family": [],
"part_person": [
307
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1786",
"date_sdn": 2373384,
"descr": "Birth of Dub\u00e9, Elizabeth",
"gid": "E0387",
"media": [],
"part_family": [],
"part_person": [
308
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1799-01-17",
"date_sdn": 2378148,
"descr": "Birth of Edwards, Lucy",
"gid": "E0090",
"media": [],
"part_family": [],
"part_person": [
311
],
"place": 376,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1879-04-02",
"date_sdn": 2407442,
"descr": "Death of Edwards, Lucy",
"gid": "E0091",
"media": [],
"part_family": [],
"part_person": [
311
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1879-04-04",
"date_sdn": 2407444,
"descr": "Burial of Edwards, Lucy",
"gid": "E0092",
"media": [],
"part_family": [],
"part_person": [
311
],
"place": 461,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1786",
"date_sdn": 2373384,
"descr": "Birth of Farmer, Anna Marie",
"gid": "E0375",
"media": [],
"part_family": [],
"part_person": [
316
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1812-01-03",
"date_sdn": 2382881,
"descr": "Birth of Farmer, Benjamin H.",
"gid": "E2444",
"media": [],
"part_family": [],
"part_person": [
317
],
"place": 639,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1873-08-13",
"date_sdn": 2405384,
"descr": "Death of Farmer, Benjamin H.",
"gid": "E2445",
"media": [],
"part_family": [],
"part_person": [
317
],
"place": 278,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1873-08-14",
"date_sdn": 2405385,
"descr": "Burial of Farmer, Benjamin H.",
"gid": "E2446",
"media": [],
"part_family": [],
"part_person": [
317
],
"place": 133,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1818",
"date_sdn": 2385071,
"descr": "Birth of Farmer, Caroline",
"gid": "E0366",
"media": [],
"part_family": [],
"part_person": [
318
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1798",
"date_sdn": 2377767,
"descr": "Birth of Farmer, Catharine",
"gid": "E0385",
"media": [],
"part_family": [],
"part_person": [
319
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Farmer, Cyrus Melville",
"gid": "E1525",
"media": [],
"part_family": [],
"part_person": [
320
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1792",
"date_sdn": 2375575,
"descr": "Birth of Farmer, Elizabeth",
"gid": "E0378",
"media": [],
"part_family": [],
"part_person": [
322
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1850-06-09",
"date_sdn": 2396918,
"descr": "Birth of Farmer, Elizabeth Ellen",
"gid": "E2489",
"media": [],
"part_family": [],
"part_person": [
323
],
"place": 694,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1931-08-03",
"date_sdn": 2426557,
"descr": "Death of Farmer, Elizabeth Ellen",
"gid": "E2490",
"media": [],
"part_family": [],
"part_person": [
323
],
"place": 523,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1931-08-00",
"date_sdn": 2426555,
"descr": "Burial of Farmer, Elizabeth Ellen",
"gid": "E2491",
"media": [],
"part_family": [],
"part_person": [
323
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1796",
"date_sdn": 2377036,
"descr": "Birth of Farmer, Eva",
"gid": "E0383",
"media": [],
"part_family": [],
"part_person": [
324
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1883",
"date_sdn": 2408812,
"descr": "Death of Farmer, Eva",
"gid": "E0384",
"media": [],
"part_family": [],
"part_person": [
324
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858-02-19",
"date_sdn": 2399730,
"descr": "Birth of Farmer, Flora Alice",
"gid": "E1526",
"media": [],
"part_family": [],
"part_person": [
325
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1777",
"date_sdn": 2370097,
"descr": "Birth of Farmer, Jacob",
"gid": "E0353",
"media": [],
"part_family": [],
"part_person": [
327
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1860-03-17",
"date_sdn": 2400487,
"descr": "Birth of Farmer, John",
"gid": "E1527",
"media": [],
"part_family": [],
"part_person": [
328
],
"place": 796,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Farmer, Magdalena",
"gid": "E0367",
"media": [],
"part_family": [],
"part_person": [
329
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1842-08-09",
"date_sdn": 2394057,
"descr": "Birth of Farmer, Mary Ann",
"gid": "E1521",
"media": [],
"part_family": [],
"part_person": [
330
],
"place": 788,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1775",
"date_sdn": 2369366,
"descr": "Birth of Farmer, Michael",
"gid": "E0386",
"media": [],
"part_family": [],
"part_person": [
331
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1852-09-27",
"date_sdn": 2397759,
"descr": "Birth of Farmer, Miranda Keziah",
"gid": "E1524",
"media": [],
"part_family": [],
"part_person": [
332
],
"place": 788,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1790",
"date_sdn": 2374845,
"descr": "Birth of Farmer, Peter Simon",
"gid": "E0376",
"media": [],
"part_family": [],
"part_person": [
333
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1845",
"date_sdn": 2394933,
"descr": "Death of Farmer, Peter Simon",
"gid": "E0377",
"media": [],
"part_family": [],
"part_person": [
333
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1840-05-07",
"date_sdn": 2393233,
"descr": "Birth of Farmer, Sarah Jane",
"gid": "E1517",
"media": [],
"part_family": [],
"part_person": [
334
],
"place": 788,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1815",
"date_sdn": 2383975,
"descr": "Birth of Farmer, Simon",
"gid": "E0363",
"media": [],
"part_family": [],
"part_person": [
335
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875",
"date_sdn": 2405890,
"descr": "Death of Farmer, Simon",
"gid": "E0364",
"media": [],
"part_family": [],
"part_person": [
335
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1784",
"date_sdn": 2372653,
"descr": "Birth of Farmer, Susanna",
"gid": "E0373",
"media": [],
"part_family": [],
"part_person": [
336
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-12-02",
"date_sdn": 2394903,
"descr": "Birth of Farmer, Susanne Delilah",
"gid": "E1522",
"media": [],
"part_family": [],
"part_person": [
337
],
"place": 788,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1779",
"date_sdn": 2370827,
"descr": "Birth of Farmer, Valentine",
"gid": "E0368",
"media": [],
"part_family": [],
"part_person": [
338
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1833",
"date_sdn": 2390550,
"descr": "Death of Farmer, Valentine",
"gid": "E0369",
"media": [],
"part_family": [],
"part_person": [
338
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1847-07-29",
"date_sdn": 2395872,
"descr": "Birth of Farmer, Winfield Scott",
"gid": "E1523",
"media": [],
"part_family": [],
"part_person": [
339
],
"place": 788,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ferguson, Lord Samuel",
"gid": "E2254",
"media": [],
"part_family": [],
"part_person": [
340
],
"place": 706,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Fernandez, Michael",
"gid": "E0908",
"media": [],
"part_family": [],
"part_person": [
341
],
"place": 878,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1825-11-27",
"date_sdn": 2387958,
"descr": "Birth of Fernandez, Thomas",
"gid": "E2671",
"media": [],
"part_family": [],
"part_person": [
342
],
"place": 247,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-11-26",
"date_sdn": 2416080,
"descr": "Death of Fernandez, Thomas",
"gid": "E2672",
"media": [],
"part_family": [],
"part_person": [
342
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902",
"date_sdn": 2415751,
"descr": "Burial of Fernandez, Thomas",
"gid": "E2673",
"media": [],
"part_family": [],
"part_person": [
342
],
"place": 787,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1559",
"date_sdn": 2290473,
"descr": "Birth of Fisher, Bendichtli",
"gid": "E2573",
"media": [],
"part_family": [],
"part_person": [
343
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1983-04-18",
"date_sdn": 2445443,
"descr": "Birth of Floyd, Gregory Scott",
"gid": "E1472",
"media": [],
"part_family": [],
"part_person": [
345
],
"place": 348,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-06-15",
"date_sdn": 2445501,
"descr": "Death of Floyd, Gregory Scott",
"gid": "E1473",
"media": [],
"part_family": [],
"part_person": [
345
],
"place": 348,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1802",
"date_sdn": 2379227,
"descr": "Birth of Floyd, John S.",
"gid": "E1291",
"media": [],
"part_family": [],
"part_person": [
348
],
"place": 425,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1893",
"date_sdn": 2412465,
"descr": "Death of Floyd, John S.",
"gid": "E1292",
"media": [],
"part_family": [],
"part_person": [
348
],
"place": 584,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Floyd, John S.",
"gid": "E1293",
"media": [],
"part_family": [],
"part_person": [
348
],
"place": 218,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1843-05-13",
"date_sdn": 2394334,
"descr": "Birth of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2592",
"media": [],
"part_family": [],
"part_person": [
349
],
"place": 658,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-04-17",
"date_sdn": 2419875,
"descr": "Death of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2593",
"media": [],
"part_family": [],
"part_person": [
349
],
"place": 776,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1913-04-19",
"date_sdn": 2419877,
"descr": "Burial of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2594",
"media": [],
"part_family": [],
"part_person": [
349
],
"place": 175,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1774-01-01",
"date_sdn": 2369001,
"descr": "Birth of Floyd, Nancy",
"gid": "E0756",
"media": [],
"part_family": [],
"part_person": [
350
],
"place": 762,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-11-26",
"date_sdn": 2396723,
"descr": "Death of Floyd, Nancy",
"gid": "E0757",
"media": [],
"part_family": [],
"part_person": [
350
],
"place": 605,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1916-10-31",
"date_sdn": 2421168,
"descr": "Birth of Ford, Lorinda Catherine",
"gid": "E1584",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 392,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-11-27",
"date_sdn": 2445666,
"descr": "Death of Ford, Lorinda Catherine",
"gid": "E1585",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ford, Lorinda Catherine",
"gid": "E1586",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 274,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1664",
"date_sdn": 2328824,
"descr": "Birth of Fortin, Matthias",
"gid": "E2604",
"media": [],
"part_family": [],
"part_person": [
356
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1744-06-23",
"date_sdn": 2358217,
"descr": "Death of Fortin, Matthias",
"gid": "E2605",
"media": [],
"part_family": [],
"part_person": [
356
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1653",
"date_sdn": 2324807,
"descr": "Birth of Foster, David",
"gid": "E1060",
"media": [],
"part_family": [],
"part_person": [
357
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1555",
"date_sdn": 2289012,
"descr": "Birth of Foster, John",
"gid": "E0072",
"media": [],
"part_family": [],
"part_person": [
358
],
"place": 869,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1598-01-31",
"date_sdn": 2304748,
"descr": "Death of Foster, John",
"gid": "E0073",
"media": [],
"part_family": [],
"part_person": [
358
],
"place": 869,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1504",
"date_sdn": 2270384,
"descr": "Birth of Foster, John",
"gid": "E0066",
"media": [],
"part_family": [],
"part_person": [
359
],
"place": 339,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Foster, Thomas",
"gid": "E0068",
"media": [],
"part_family": [],
"part_person": [
360
],
"place": 49,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1557-06-23",
"date_sdn": 2289916,
"descr": "Death of Foster, Thomas",
"gid": "E0069",
"media": [],
"part_family": [],
"part_person": [
360
],
"place": 339,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1582-04-14",
"date_sdn": 2298977,
"descr": "Birth of Foster, Thomas",
"gid": "E0010",
"media": [],
"part_family": [],
"part_person": [
361
],
"place": 869,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1658-06-01",
"date_sdn": 2326784,
"descr": "Death of Foster, Thomas",
"gid": "E0011",
"media": [],
"part_family": [],
"part_person": [
361
],
"place": 650,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1625",
"date_sdn": 2314580,
"descr": "Birth of Foster, William",
"gid": "E2120",
"media": [],
"part_family": [],
"part_person": [
362
],
"place": 806,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1798-07-22",
"date_sdn": 2377969,
"descr": "Birth of Fox, David",
"gid": "E1288",
"media": [],
"part_family": [],
"part_person": [
364
],
"place": 839,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1868-07-31",
"date_sdn": 2403545,
"descr": "Death of Fox, David",
"gid": "E1289",
"media": [],
"part_family": [],
"part_person": [
364
],
"place": 35,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1868-08-02",
"date_sdn": 2403547,
"descr": "Burial of Fox, David",
"gid": "E1290",
"media": [],
"part_family": [],
"part_person": [
364
],
"place": 269,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1769-02-00",
"date_sdn": 2367206,
"descr": "Birth of Fox, Jacob, Sr.",
"gid": "E1830",
"media": [],
"part_family": [],
"part_person": [
365
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-09-03",
"date_sdn": 2387508,
"descr": "Death of Fox, Jacob, Sr.",
"gid": "E1831",
"media": [],
"part_family": [],
"part_person": [
365
],
"place": 745,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1823-12-25",
"date_sdn": 2387255,
"descr": "Birth of Fox, Julia Colville",
"gid": "E1423",
"media": [],
"part_family": [],
"part_person": [
366
],
"place": 440,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-02-12",
"date_sdn": 2416523,
"descr": "Death of Fox, Julia Colville",
"gid": "E1424",
"media": [],
"part_family": [],
"part_person": [
366
],
"place": 94,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1904",
"date_sdn": 2416481,
"descr": "Burial of Fox, Julia Colville",
"gid": "E1425",
"media": [],
"part_family": [],
"part_person": [
366
],
"place": 269,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1700",
"date_sdn": 2341973,
"descr": "Birth of Fox, Samuel",
"gid": "E1824",
"media": [],
"part_family": [],
"part_person": [
367
],
"place": 883,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1744",
"date_sdn": 2358043,
"descr": "Death of Fox, Samuel",
"gid": "E1825",
"media": [],
"part_family": [],
"part_person": [
367
],
"place": 625,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fox, Samuel",
"gid": "E1826",
"media": [],
"part_family": [],
"part_person": [
367
],
"place": 789,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Fox, William",
"gid": "E2136",
"media": [],
"part_family": [],
"part_person": [
368
],
"place": 731,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Death of Fox, William",
"gid": "E2137",
"media": [],
"part_family": [],
"part_person": [
368
],
"place": 668,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fox, William",
"gid": "E2138",
"media": [],
"part_family": [],
"part_person": [
368
],
"place": 32,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1746",
"date_sdn": 2358774,
"descr": "Birth of Frazier, Johann Adam",
"gid": "E0400",
"media": [],
"part_family": [],
"part_person": [
369
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1748",
"date_sdn": 2359504,
"descr": "Birth of Frazier, Johann Walter",
"gid": "E0403",
"media": [],
"part_family": [],
"part_person": [
370
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1712",
"date_sdn": 2346355,
"descr": "Birth of Frazier, Maria Margaretha",
"gid": "E0408",
"media": [],
"part_family": [],
"part_person": [
371
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "before 1901",
"date_sdn": 2415386,
"descr": "Death of Gagn\u00e9, Thomas",
"gid": "E1053",
"media": [],
"part_family": [],
"part_person": [
372
],
"place": 553,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1963-01-10",
"date_sdn": 2438040,
"descr": "Death of Gardner, Mary Jane",
"gid": "E2471",
"media": [],
"part_family": [],
"part_person": [
373
],
"place": 860,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1963-01-12",
"date_sdn": 2438042,
"descr": "Burial of Gardner, Mary Jane",
"gid": "E2472",
"media": [],
"part_family": [],
"part_person": [
373
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1825-01-28",
"date_sdn": 2387655,
"descr": "Birth of Garner, Anderson",
"gid": "E0178",
"media": [],
"part_family": [],
"part_person": [
375
],
"place": 762,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1887-04-07",
"date_sdn": 2410369,
"descr": "Death of Garner, Anderson",
"gid": "E0179",
"media": [],
"part_family": [],
"part_person": [
375
],
"place": 589,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1887-04-08",
"date_sdn": 2410370,
"descr": "Burial of Garner, Anderson",
"gid": "E0180",
"media": [],
"part_family": [],
"part_person": [
375
],
"place": 589,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1870-06-13",
"date_sdn": 2404227,
"descr": "Birth of Garner, Anetta",
"gid": "E0217",
"media": [],
"part_family": [],
"part_person": [
376
],
"place": 128,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1900-10-04",
"date_sdn": 2415297,
"descr": "Death of Garner, Anetta",
"gid": "E0218",
"media": [],
"part_family": [],
"part_person": [
376
],
"place": 165,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1900-10-00",
"date_sdn": 2415294,
"descr": "Burial of Garner, Anetta",
"gid": "E0219",
"media": [],
"part_family": [],
"part_person": [
376
],
"place": 765,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1870-06-13",
"date_sdn": 2404227,
"descr": "Birth of Garner, Antoinette",
"gid": "E0220",
"media": [],
"part_family": [],
"part_person": [
377
],
"place": 754,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1880",
"date_sdn": 2407716,
"descr": "Death of Garner, Antoinette",
"gid": "E0221",
"media": [],
"part_family": [],
"part_person": [
377
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1888-03-13",
"date_sdn": 2410710,
"descr": "Birth of Garner, Bertha P.",
"gid": "E2051",
"media": [],
"part_family": [],
"part_person": [
378
],
"place": 316,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-04-05",
"date_sdn": 2421689,
"descr": "Death of Garner, Bertha P.",
"gid": "E2052",
"media": [],
"part_family": [],
"part_person": [
378
],
"place": 165,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1918-04-00",
"date_sdn": 2421685,
"descr": "Burial of Garner, Bertha P.",
"gid": "E2053",
"media": [],
"part_family": [],
"part_person": [
378
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1908-03-13",
"date_sdn": 2418014,
"descr": "Birth of Garner, Cecile Elizabeth",
"gid": "E2061",
"media": [],
"part_family": [],
"part_person": [
379
],
"place": 504,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1975-03-22",
"date_sdn": 2442494,
"descr": "Death of Garner, Cecile Elizabeth",
"gid": "E2062",
"media": [],
"part_family": [],
"part_person": [
379
],
"place": 54,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garner, Cecile Elizabeth",
"gid": "E2063",
"media": [],
"part_family": [],
"part_person": [
379
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1914-09-07",
"date_sdn": 2420383,
"descr": "Birth of Garner, Daniel Burton",
"gid": "E2068",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 78,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-10-02",
"date_sdn": 2421139,
"descr": "Death of Garner, Daniel Burton",
"gid": "E2069",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 622,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garner, Daniel Burton",
"gid": "E2070",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-09-30",
"date_sdn": 2409084,
"descr": "Birth of Garner, Daniel Webster",
"gid": "E2048",
"media": [],
"part_family": [],
"part_person": [
381
],
"place": 344,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1936-03-02",
"date_sdn": 2428230,
"descr": "Death of Garner, Daniel Webster",
"gid": "E2049",
"media": [],
"part_family": [],
"part_person": [
381
],
"place": 290,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1936-03-04",
"date_sdn": 2428232,
"descr": "Burial of Garner, Daniel Webster",
"gid": "E2050",
"media": [],
"part_family": [],
"part_person": [
381
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1868-08-18",
"date_sdn": 2403563,
"descr": "Birth of Garner, Emma A.",
"gid": "E0214",
"media": [],
"part_family": [],
"part_person": [
382
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-02-23",
"date_sdn": 2403752,
"descr": "Death of Garner, Emma A.",
"gid": "E0215",
"media": [],
"part_family": [],
"part_person": [
382
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-02-00",
"date_sdn": 2403730,
"descr": "Burial of Garner, Emma A.",
"gid": "E0216",
"media": [],
"part_family": [],
"part_person": [
382
],
"place": 765,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1895-12-01",
"date_sdn": 2413529,
"descr": "Birth of Garner, Eugene Stanley",
"gid": "E1702",
"media": [],
"part_family": [],
"part_person": [
383
],
"place": 653,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-03-01",
"date_sdn": 2445761,
"descr": "Death of Garner, Eugene Stanley",
"gid": "E1703",
"media": [],
"part_family": [],
"part_person": [
383
],
"place": 803,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1984-03-03",
"date_sdn": 2445763,
"descr": "Burial of Garner, Eugene Stanley",
"gid": "E1704",
"media": [],
"part_family": [],
"part_person": [
383
],
"place": 803,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1860-11-01",
"date_sdn": 2400716,
"descr": "Birth of Garner, Iola Elizabeth Betty",
"gid": "E0208",
"media": [],
"part_family": [],
"part_person": [
384
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1941-04-17",
"date_sdn": 2430102,
"descr": "Death of Garner, Iola Elizabeth Betty",
"gid": "E0209",
"media": [],
"part_family": [],
"part_person": [
384
],
"place": 399,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1941-04-19",
"date_sdn": 2430104,
"descr": "Burial of Garner, Iola Elizabeth Betty",
"gid": "E0210",
"media": [],
"part_family": [],
"part_person": [
384
],
"place": 158,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1880-09-11",
"date_sdn": 2407970,
"descr": "Birth of Garner, Jennie S.",
"gid": "E2042",
"media": [],
"part_family": [],
"part_person": [
385
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1964-06-20",
"date_sdn": 2438567,
"descr": "Death of Garner, Jennie S.",
"gid": "E2043",
"media": [],
"part_family": [],
"part_person": [
385
],
"place": 165,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1964-06-00",
"date_sdn": 2438548,
"descr": "Burial of Garner, Jennie S.",
"gid": "E2044",
"media": [],
"part_family": [],
"part_person": [
385
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1876-06-18",
"date_sdn": 2406424,
"descr": "Birth of Garner, Jesse V.",
"gid": "E2037",
"media": [],
"part_family": [],
"part_person": [
386
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1929-01-21",
"date_sdn": 2425633,
"descr": "Death of Garner, Jesse V.",
"gid": "E2038",
"media": [],
"part_family": [],
"part_person": [
386
],
"place": 126,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1929",
"date_sdn": 2425613,
"descr": "Burial of Garner, Jesse V.",
"gid": "E2039",
"media": [],
"part_family": [],
"part_person": [
386
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1823-11-18",
"date_sdn": 2387218,
"descr": "Birth of Garner, Lewis",
"gid": "E0175",
"media": [],
"part_family": [],
"part_person": [
387
],
"place": 548,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1911-01-21",
"date_sdn": 2419058,
"descr": "Death of Garner, Lewis",
"gid": "E0176",
"media": [],
"part_family": [],
"part_person": [
387
],
"place": 803,
"text": "<div>\n<p>\n<b>Age</b>: 88 years\n</p>\n</div>",
"type": "Death"
},
{
"cita": [],
"date": "1911-01-23",
"date_sdn": 2419060,
"descr": "Burial of Garner, Lewis",
"gid": "E0177",
"media": [],
"part_family": [],
"part_person": [
387
],
"place": 406,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [
0,
1607,
1616,
1617
],
"date": "1855-06-21",
"date_sdn": 2398756,
"descr": "Birth of Garner, Lewis Anderson",
"gid": "E1656",
"media": [
{
"cita": [
1618,
1619
],
"m_idx": 0,
"note": "<div>\n<p>\n<b>Father's Age</b>: 25\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/1/2/b39fe1cfc1305ac4a21.png"
}
],
"part_family": [],
"part_person": [
388
],
"place": 301,
"text": "<div>\n<p>\n<b>Time</b>: 10:00 pm\n</p>\n<p>\n<b>Father's Age</b>: 28\n</p>\n</div>",
"type": "Birth"
},
{
"cita": [],
"date": "1911-06-28",
"date_sdn": 2419216,
"descr": "Death of Garner, Lewis Anderson",
"gid": "E1657",
"media": [],
"part_family": [],
"part_person": [
388
],
"place": 803,
"text": "<div>\n<div class=\"grampsstylednote\">\n<p>\n<span style=\"text-decoration:underline;\">How</span> did he die? <span style=\"color:#ff0909;\"></span><span style=\"font-size:14px;\"><span style=\"color:#ff0909;\">We need to find out!</span></span><span style=\"color:#ff0909;\"></span>\n</p>\n<p>\nPerhaps we find info in <strong></strong><span style=\"background-color:#fbd50a;\"><strong>the new york</strong></span><strong></strong> library\n</p>\n</div>\n<p>\n<b>Cause</b>: Laughter\n</p>\n</div>",
"type": "Death"
},
{
"cita": [],
"date": "1911-07-01",
"date_sdn": 2419219,
"descr": "Burial of Garner, Lewis Anderson",
"gid": "E1658",
"media": [],
"part_family": [],
"part_person": [
388
],
"place": 803,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1951-07-18",
"date_sdn": 2433846,
"descr": "Birth of Garner, Margaret Ann",
"gid": "E0074",
"media": [],
"part_family": [],
"part_person": [
389
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-02-10",
"date_sdn": 2434053,
"descr": "Death of Garner, Margaret Ann",
"gid": "E0075",
"media": [],
"part_family": [],
"part_person": [
389
],
"place": 608,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1851-10-12",
"date_sdn": 2397408,
"descr": "Birth of Garner, Mary J.",
"gid": "E0194",
"media": [],
"part_family": [],
"part_person": [
390
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1852-04-01",
"date_sdn": 2397580,
"descr": "Death of Garner, Mary J.",
"gid": "E0195",
"media": [],
"part_family": [],
"part_person": [
390
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1858-04-00",
"date_sdn": 2399771,
"descr": "Burial of Garner, Mary J.",
"gid": "E0196",
"media": [],
"part_family": [],
"part_person": [
390
],
"place": 765,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1851-10-12",
"date_sdn": 2397408,
"descr": "Birth of Garner, Mary M.",
"gid": "E0197",
"media": [],
"part_family": [],
"part_person": [
391
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1858-05-24",
"date_sdn": 2399824,
"descr": "Death of Garner, Mary M.",
"gid": "E0198",
"media": [],
"part_family": [],
"part_person": [
391
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1858-05-00",
"date_sdn": 2399801,
"descr": "Burial of Garner, Mary M.",
"gid": "E0199",
"media": [],
"part_family": [],
"part_person": [
391
],
"place": 765,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1850",
"date_sdn": 2396759,
"descr": "Birth of Garner, Phebe",
"gid": "E0192",
"media": [],
"part_family": [],
"part_person": [
392
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1860",
"date_sdn": 2400411,
"descr": "Death of Garner, Phebe",
"gid": "E0193",
"media": [],
"part_family": [],
"part_person": [
392
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1878-09-16",
"date_sdn": 2407244,
"descr": "Birth of Garner, Raymond E.",
"gid": "E2040",
"media": [],
"part_family": [],
"part_person": [
393
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-05-02",
"date_sdn": 2422812,
"descr": "Death of Garner, Raymond E.",
"gid": "E2041",
"media": [],
"part_family": [],
"part_person": [
393
],
"place": 39,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1857-05-30",
"date_sdn": 2399465,
"descr": "Birth of Garner, Rebecca Catharine",
"gid": "E0200",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 207,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1937-04-09",
"date_sdn": 2428633,
"descr": "Death of Garner, Rebecca Catharine",
"gid": "E0201",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 18,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1937-04-11",
"date_sdn": 2428635,
"descr": "Burial of Garner, Rebecca Catharine",
"gid": "E0202",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 481,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1863-04-04",
"date_sdn": 2401600,
"descr": "Birth of Garner, Robert F.",
"gid": "E0211",
"media": [],
"part_family": [],
"part_person": [
395
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-12-25",
"date_sdn": 2425240,
"descr": "Marriage of W\u00f3jcik, Arnold and Garner, Helen Bernice",
"gid": "E2829",
"media": [],
"part_family": [],
"part_person": [
395
],
"place": -1,
"text": "",
"type": "Marriage (Witness)"
},
{
"cita": [],
"date": "1940-02-17",
"date_sdn": 2429677,
"descr": "Death of Garner, Robert F.",
"gid": "E0212",
"media": [],
"part_family": [],
"part_person": [
395
],
"place": 489,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1940-02-19",
"date_sdn": 2429679,
"descr": "Burial of Garner, Robert F.",
"gid": "E0213",
"media": [],
"part_family": [],
"part_person": [
395
],
"place": 207,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1826/7-04-24 (Julian)",
"date_sdn": 2388483,
"descr": "Birth of Garner, Robert W.",
"gid": "E0105",
"media": [],
"part_family": [],
"part_person": [
396
],
"place": 0,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-03",
"date_sdn": 2420897,
"descr": "Death of Garner, Robert W.",
"gid": "E0106",
"media": [],
"part_family": [],
"part_person": [
396
],
"place": 653,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1916-02-05 (Mar25)",
"date_sdn": 2420899,
"descr": "Burial of Garner, Robert W.",
"gid": "E0107",
"media": [],
"part_family": [],
"part_person": [
396
],
"place": 406,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1882-02-17",
"date_sdn": 2408494,
"descr": "Birth of Garner, Walter E.",
"gid": "E2045",
"media": [],
"part_family": [],
"part_person": [
397
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1946-10-23",
"date_sdn": 2432117,
"descr": "Death of Garner, Walter E.",
"gid": "E2046",
"media": [],
"part_family": [],
"part_person": [
397
],
"place": 59,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1946-10-00",
"date_sdn": 2432095,
"descr": "Burial of Garner, Walter E.",
"gid": "E2047",
"media": [],
"part_family": [],
"part_person": [
397
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1961-11-21",
"date_sdn": 2437625,
"descr": "Birth of Garrett, Wayne Allen",
"gid": "E2293",
"media": [],
"part_family": [],
"part_person": [
398
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1967-01-00",
"date_sdn": 2439492,
"descr": "Death of Garrett, Wayne Allen",
"gid": "E2294",
"media": [],
"part_family": [],
"part_person": [
398
],
"place": 608,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1810-12-20",
"date_sdn": 2382502,
"descr": "Birth of Gauthier, Julius",
"gid": "E0646",
"media": [],
"part_family": [],
"part_person": [
399
],
"place": 649,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1979-10-01",
"date_sdn": 2444148,
"descr": "Death of Gibbs, Elizabeth",
"gid": "E0978",
"media": [],
"part_family": [],
"part_person": [
400
],
"place": 400,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "about 1460",
"date_sdn": 2254314,
"descr": "Birth of Gibbs, Margaret",
"gid": "E0252",
"media": [],
"part_family": [],
"part_person": [
402
],
"place": 206,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1936-01-29",
"date_sdn": 2428197,
"descr": "Death of Gibbs, Mary",
"gid": "E0937",
"media": [],
"part_family": [],
"part_person": [
403
],
"place": 877,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1473",
"date_sdn": 2259063,
"descr": "Birth of Gomez, Culthbert",
"gid": "E0061",
"media": [],
"part_family": [],
"part_person": [
408
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1499",
"date_sdn": 2268559,
"descr": "Birth of Gomez, Jane Joane",
"gid": "E0064",
"media": [],
"part_family": [],
"part_person": [
409
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1573",
"date_sdn": 2295587,
"descr": "Death of Gomez, Jane Joane",
"gid": "E0065",
"media": [],
"part_family": [],
"part_person": [
409
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1708-06-01",
"date_sdn": 2345046,
"descr": "Birth of Gonz\u00e1lez, Elizabeth",
"gid": "E1866",
"media": [],
"part_family": [],
"part_person": [
412
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Goodman, Ralph",
"gid": "E0272",
"media": [],
"part_family": [],
"part_person": [
413
],
"place": 312,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1626-06-25",
"date_sdn": 2315120,
"descr": "Burial of Goodman, Ralph",
"gid": "E0273",
"media": [],
"part_family": [],
"part_person": [
413
],
"place": 524,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1798-08-16",
"date_sdn": 2377994,
"descr": "Birth of Graves, Martha",
"gid": "E2021",
"media": [],
"part_family": [],
"part_person": [
415
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1862-12-12",
"date_sdn": 2401487,
"descr": "Death of Graves, Martha",
"gid": "E2022",
"media": [],
"part_family": [],
"part_person": [
415
],
"place": 272,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Graves, Martha",
"gid": "E2023",
"media": [],
"part_family": [],
"part_person": [
415
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1050",
"date_sdn": 2104565,
"descr": "Birth of Gray, Beatrix",
"gid": "E0024",
"media": [],
"part_family": [],
"part_person": [
416
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1112",
"date_sdn": 2127209,
"descr": "Death of Gray, Beatrix",
"gid": "E0025",
"media": [],
"part_family": [],
"part_person": [
416
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1685-06-06",
"date_sdn": 2336651,
"descr": "Birth of Green, Edward",
"gid": "E1873",
"media": [],
"part_family": [],
"part_person": [
417
],
"place": 67,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1756-10-20",
"date_sdn": 2362719,
"descr": "Death of Green, Edward",
"gid": "E1874",
"media": [],
"part_family": [],
"part_person": [
417
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Green, Edward",
"gid": "E1863",
"media": [],
"part_family": [],
"part_person": [
418
],
"place": 396,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1688-07-31",
"date_sdn": 2337802,
"descr": "Death of Green, Edward",
"gid": "E1864",
"media": [],
"part_family": [],
"part_person": [
418
],
"place": 527,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1804-07-22",
"date_sdn": 2380160,
"descr": "Birth of Green, Frances",
"gid": "E1309",
"media": [],
"part_family": [],
"part_person": [
419
],
"place": 648,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1886-07-31",
"date_sdn": 2410119,
"descr": "Death of Green, Frances",
"gid": "E1310",
"media": [],
"part_family": [],
"part_person": [
419
],
"place": 35,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1886-08-02",
"date_sdn": 2410121,
"descr": "Burial of Green, Frances",
"gid": "E1311",
"media": [],
"part_family": [],
"part_person": [
419
],
"place": 269,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1739-04-07",
"date_sdn": 2356313,
"descr": "Birth of Green, James",
"gid": "E1880",
"media": [],
"part_family": [],
"part_person": [
420
],
"place": 527,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805-11-28",
"date_sdn": 2380654,
"descr": "Death of Green, James",
"gid": "E1881",
"media": [],
"part_family": [],
"part_person": [
420
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1768-03-17",
"date_sdn": 2366885,
"descr": "Birth of Green, Randolph",
"gid": "E1882",
"media": [],
"part_family": [],
"part_person": [
421
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-03-17",
"date_sdn": 2392451,
"descr": "Death of Green, Randolph",
"gid": "E1883",
"media": [],
"part_family": [],
"part_person": [
421
],
"place": 391,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Green, Randolph",
"gid": "E1884",
"media": [],
"part_family": [],
"part_person": [
421
],
"place": 391,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1683-10-24",
"date_sdn": 2336060,
"descr": "Death of Green, Yelverton",
"gid": "E2423",
"media": [],
"part_family": [],
"part_person": [
422
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1605",
"date_sdn": 2307275,
"descr": "Birth of Grenier, Joseph",
"gid": "E2241",
"media": [],
"part_family": [],
"part_person": [
426
],
"place": 339,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1647-12-04",
"date_sdn": 2322952,
"descr": "Death of Grenier, Joseph",
"gid": "E2242",
"media": [],
"part_family": [],
"part_person": [
426
],
"place": 690,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Grenier, Joseph",
"gid": "E2243",
"media": [],
"part_family": [],
"part_person": [
426
],
"place": 222,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1638",
"date_sdn": 2319328,
"descr": "Birth of Grenier, Mary",
"gid": "E1849",
"media": [],
"part_family": [],
"part_person": [
427
],
"place": 426,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1703-07-12",
"date_sdn": 2343260,
"descr": "Death of Grenier, Mary",
"gid": "E1850",
"media": [],
"part_family": [],
"part_person": [
427
],
"place": 648,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "about 1405",
"date_sdn": 2234226,
"descr": "Birth of Guerrero, Robert",
"gid": "E0255",
"media": [],
"part_family": [],
"part_person": [
429
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1430",
"date_sdn": 2243357,
"descr": "Birth of Guerrero, Robert",
"gid": "E0254",
"media": [],
"part_family": [],
"part_person": [
430
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1380",
"date_sdn": 2225095,
"descr": "Birth of Guerrero, Walter",
"gid": "E0256",
"media": [],
"part_family": [],
"part_person": [
432
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1350",
"date_sdn": 2214138,
"descr": "Birth of Guerrero, Walter",
"gid": "E0257",
"media": [],
"part_family": [],
"part_person": [
433
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1695",
"date_sdn": 2340147,
"descr": "Birth of Guzman, Isabella",
"gid": "E0172",
"media": [],
"part_family": [],
"part_person": [
435
],
"place": 499,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1700",
"date_sdn": 2341973,
"descr": "Death of Guzman, Isabella",
"gid": "E0173",
"media": [],
"part_family": [],
"part_person": [
435
],
"place": 499,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1745",
"date_sdn": 2358409,
"descr": "Death of Hall, Elizabeth",
"gid": "E2647",
"media": [],
"part_family": [],
"part_person": [
436
],
"place": 220,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Hall, Elizabeth",
"gid": "E2648",
"media": [],
"part_family": [],
"part_person": [
436
],
"place": 220,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1110",
"date_sdn": 2126479,
"descr": "Birth of Hanson, Robert",
"gid": "E0030",
"media": [],
"part_family": [],
"part_person": [
437
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1185",
"date_sdn": 2153873,
"descr": "Death of Hanson, Robert",
"gid": "E0031",
"media": [],
"part_family": [],
"part_person": [
437
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Hardy, Jakob",
"gid": "E0414",
"media": [],
"part_family": [],
"part_person": [
438
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1671",
"date_sdn": 2331381,
"descr": "Birth of Harmon, Martha",
"gid": "E2232",
"media": [],
"part_family": [],
"part_person": [
439
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of H\u00e9bert, Mr.",
"gid": "E0736",
"media": [],
"part_family": [],
"part_person": [
443
],
"place": 119,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of H\u00e9bert, Ruth Ann",
"gid": "E2688",
"media": [],
"part_family": [],
"part_person": [
444
],
"place": 33,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1843",
"date_sdn": 2394202,
"descr": "Death of H\u00e9bert, Ruth Ann",
"gid": "E2689",
"media": [],
"part_family": [],
"part_person": [
444
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1770-04-00",
"date_sdn": 2367630,
"descr": "Birth of Henry, Elizabeth",
"gid": "E2318",
"media": [],
"part_family": [],
"part_person": [
445
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1836-05-14",
"date_sdn": 2391779,
"descr": "Death of Henry, Elizabeth",
"gid": "E2319",
"media": [],
"part_family": [],
"part_person": [
445
],
"place": 744,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1836-05-15",
"date_sdn": 2391780,
"descr": "Burial of Henry, Elizabeth",
"gid": "E2320",
"media": [],
"part_family": [],
"part_person": [
445
],
"place": 260,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1751",
"date_sdn": 2360600,
"descr": "Birth of Hicks, Anna Eva",
"gid": "E0398",
"media": [],
"part_family": [],
"part_person": [
450
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of Hicks, Anna Eva",
"gid": "E0399",
"media": [],
"part_family": [],
"part_person": [
450
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1682",
"date_sdn": 2335399,
"descr": "Birth of Higgins, Charity",
"gid": "E1067",
"media": [],
"part_family": [],
"part_person": [
451
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1685",
"date_sdn": 2336495,
"descr": "Birth of Holland, Anna Margaretha",
"gid": "E0362",
"media": [],
"part_family": [],
"part_person": [
455
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1829-12-00",
"date_sdn": 2389423,
"descr": "Birth of Holt, Bridget",
"gid": "E2561",
"media": [],
"part_family": [],
"part_person": [
456
],
"place": 474,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-02-14",
"date_sdn": 2416525,
"descr": "Death of Holt, Bridget",
"gid": "E2562",
"media": [],
"part_family": [],
"part_person": [
456
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Holt, Bridget",
"gid": "E2563",
"media": [],
"part_family": [],
"part_person": [
456
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1805-10-18",
"date_sdn": 2380613,
"descr": "Birth of Hopkins, Mary Eve",
"gid": "E1380",
"media": [],
"part_family": [],
"part_person": [
457
],
"place": 33,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1865-05-11",
"date_sdn": 2402368,
"descr": "Death of Hopkins, Mary Eve",
"gid": "E1381",
"media": [],
"part_family": [],
"part_person": [
457
],
"place": 828,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1865-05-13",
"date_sdn": 2402370,
"descr": "Burial of Hopkins, Mary Eve",
"gid": "E1382",
"media": [],
"part_family": [],
"part_person": [
457
],
"place": 88,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1790-06-21",
"date_sdn": 2375016,
"descr": "Birth of Houston, Ellender",
"gid": "E0130",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1855-07-30",
"date_sdn": 2398795,
"descr": "Death of Houston, Ellender",
"gid": "E0131",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": 763,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Houston, Ellender",
"gid": "E0132",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": 533,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1615",
"date_sdn": 2310927,
"descr": "Birth of Howell, JOHN",
"gid": "E2626",
"media": [],
"part_family": [],
"part_person": [
460
],
"place": 253,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1644-12-28",
"date_sdn": 2321881,
"descr": "Death of Howell, JOHN",
"gid": "E2627",
"media": [],
"part_family": [],
"part_person": [
460
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1641-02-12",
"date_sdn": 2320466,
"descr": "Birth of Howell, Mary (Sarah)",
"gid": "E2238",
"media": [],
"part_family": [],
"part_person": [
461
],
"place": 593,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1686",
"date_sdn": 2336860,
"descr": "Death of Howell, Mary (Sarah)",
"gid": "E2239",
"media": [],
"part_family": [],
"part_person": [
461
],
"place": 24,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Howell, Mary (Sarah)",
"gid": "E2240",
"media": [],
"part_family": [],
"part_person": [
461
],
"place": 24,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1220",
"date_sdn": 2166656,
"descr": "Birth of Huff, Bertrama",
"gid": "E0039",
"media": [],
"part_family": [],
"part_person": [
462
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1300",
"date_sdn": 2195876,
"descr": "Birth of Huff, Isabel",
"gid": "E0048",
"media": [],
"part_family": [],
"part_person": [
463
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1625",
"date_sdn": 2314580,
"descr": "Birth of Ingram, Mary",
"gid": "E2213",
"media": [],
"part_family": [],
"part_person": [
465
],
"place": 280,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1688-07-29",
"date_sdn": 2337800,
"descr": "Death of Ingram, Mary",
"gid": "E2214",
"media": [],
"part_family": [],
"part_person": [
465
],
"place": 775,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of James",
"gid": "E0683",
"media": [],
"part_family": [],
"part_person": [
467
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1768",
"date_sdn": 2366809,
"descr": "Birth of James, Hugh Jr.",
"gid": "E0684",
"media": [],
"part_family": [],
"part_person": [
469
],
"place": 412,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1768",
"date_sdn": 2366809,
"descr": "Death of James, Hugh Jr.",
"gid": "E0685",
"media": [],
"part_family": [],
"part_person": [
469
],
"place": 846,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of James, Hugh Sr.",
"gid": "E1752",
"media": [],
"part_family": [],
"part_person": [
470
],
"place": 151,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1785",
"date_sdn": 2373019,
"descr": "Death of James, Hugh Sr.",
"gid": "E1753",
"media": [],
"part_family": [],
"part_person": [
470
],
"place": 156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Isaac",
"gid": "E0690",
"media": [],
"part_family": [],
"part_person": [
471
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Jane",
"gid": "E1746",
"media": [],
"part_family": [],
"part_person": [
473
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-09-03",
"date_sdn": 2395543,
"descr": "Death of James, Jane",
"gid": "E1747",
"media": [],
"part_family": [],
"part_person": [
473
],
"place": 487,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1739",
"date_sdn": 2356217,
"descr": "Birth of James, Jane",
"gid": "E0679",
"media": [],
"part_family": [],
"part_person": [
474
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1741",
"date_sdn": 2356948,
"descr": "Birth of James, John",
"gid": "E0680",
"media": [],
"part_family": [],
"part_person": [
475
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1773-03-03",
"date_sdn": 2368697,
"descr": "Birth of James, Joseph",
"gid": "E0687",
"media": [],
"part_family": [],
"part_person": [
476
],
"place": 846,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Death of James, Joseph",
"gid": "E0688",
"media": [],
"part_family": [],
"part_person": [
476
],
"place": 605,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1737",
"date_sdn": 2355487,
"descr": "Birth of James, Martha",
"gid": "E0678",
"media": [],
"part_family": [],
"part_person": [
478
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1735",
"date_sdn": 2354756,
"descr": "Birth of James, Mary",
"gid": "E0677",
"media": [],
"part_family": [],
"part_person": [
479
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1770",
"date_sdn": 2367540,
"descr": "Birth of James, Molly",
"gid": "E0686",
"media": [],
"part_family": [],
"part_person": [
480
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1729",
"date_sdn": 2352565,
"descr": "Birth of James, Robert",
"gid": "E0675",
"media": [],
"part_family": [],
"part_person": [
483
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Thomas",
"gid": "E0689",
"media": [],
"part_family": [],
"part_person": [
485
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Walter Crockett",
"gid": "E0691",
"media": [],
"part_family": [],
"part_person": [
486
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1733",
"date_sdn": 2354026,
"descr": "Birth of James, William",
"gid": "E0676",
"media": [],
"part_family": [],
"part_person": [
487
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1886-08-10",
"date_sdn": 2410129,
"descr": "Birth of Jankowski, David",
"gid": "E0542",
"media": [],
"part_family": [],
"part_person": [
488
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1951-04-10",
"date_sdn": 2433747,
"descr": "Death of Jankowski, David",
"gid": "E0543",
"media": [],
"part_family": [],
"part_person": [
488
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1957-04-12",
"date_sdn": 2435941,
"descr": "Burial of Jankowski, David",
"gid": "E0544",
"media": [],
"part_family": [],
"part_person": [
488
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1847-01-01",
"date_sdn": 2395663,
"descr": "Birth of Jankowski, George",
"gid": "E0516",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1930-02-01",
"date_sdn": 2426009,
"descr": "Death of Jankowski, George",
"gid": "E0517",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1930-02-03",
"date_sdn": 2426011,
"descr": "Burial of Jankowski, George",
"gid": "E0518",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1882-03-28",
"date_sdn": 2408533,
"descr": "Birth of Jankowski, George Jr.",
"gid": "E0533",
"media": [],
"part_family": [],
"part_person": [
490
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-11-17",
"date_sdn": 2430681,
"descr": "Death of Jankowski, George Jr.",
"gid": "E0534",
"media": [],
"part_family": [],
"part_person": [
490
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1942-11-19",
"date_sdn": 2430683,
"descr": "Burial of Jankowski, George Jr.",
"gid": "E0535",
"media": [],
"part_family": [],
"part_person": [
490
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1878-03-20",
"date_sdn": 2407064,
"descr": "Birth of Jankowski, Isabella Belle",
"gid": "E0531",
"media": [],
"part_family": [],
"part_person": [
491
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-03-31",
"date_sdn": 2424241,
"descr": "Death of Jankowski, Isabella Belle",
"gid": "E0532",
"media": [],
"part_family": [],
"part_person": [
491
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1876-04-01",
"date_sdn": 2406346,
"descr": "Birth of Jankowski, John",
"gid": "E0528",
"media": [],
"part_family": [],
"part_person": [
492
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1939-10-15",
"date_sdn": 2429552,
"descr": "Death of Jankowski, John",
"gid": "E0529",
"media": [],
"part_family": [],
"part_person": [
492
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1939-10-15",
"date_sdn": 2429552,
"descr": "Burial of Jankowski, John",
"gid": "E0530",
"media": [],
"part_family": [],
"part_person": [
492
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1889-05-28",
"date_sdn": 2411151,
"descr": "Birth of Jankowski, Margaret Jane &#8220;Maggie&#8221;",
"gid": "E0545",
"media": [],
"part_family": [],
"part_person": [
493
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1960-01-05",
"date_sdn": 2436939,
"descr": "Death of Jankowski, Margaret Jane &#8220;Maggie&#8221;",
"gid": "E0546",
"media": [],
"part_family": [],
"part_person": [
493
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1885-06-07",
"date_sdn": 2409700,
"descr": "Birth of Jankowski, Matilda",
"gid": "E0536",
"media": [],
"part_family": [],
"part_person": [
494
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-01-22",
"date_sdn": 2424173,
"descr": "Death of Jankowski, Matilda",
"gid": "E0537",
"media": [],
"part_family": [],
"part_person": [
494
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1892-05-24",
"date_sdn": 2412243,
"descr": "Birth of Jankowski, Minnie",
"gid": "E0549",
"media": [],
"part_family": [],
"part_person": [
495
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-01-08",
"date_sdn": 2445708,
"descr": "Death of Jankowski, Minnie",
"gid": "E0550",
"media": [],
"part_family": [],
"part_person": [
495
],
"place": 619,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1872-08-27",
"date_sdn": 2405033,
"descr": "Birth of Jankowski, Robert",
"gid": "E0519",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-01-02",
"date_sdn": 2430727,
"descr": "Death of Jankowski, Robert",
"gid": "E0520",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1943-01-04",
"date_sdn": 2430729,
"descr": "Burial of Jankowski, Robert",
"gid": "E0521",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 843,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1874-12-08",
"date_sdn": 2405866,
"descr": "Birth of Jankowski, Sarah",
"gid": "E0522",
"media": [],
"part_family": [],
"part_person": [
497
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1948-02-17",
"date_sdn": 2432599,
"descr": "Death of Jankowski, Sarah",
"gid": "E0523",
"media": [],
"part_family": [],
"part_person": [
497
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1630-02-00",
"date_sdn": 2316437,
"descr": "Birth of Jenkins, Margaret",
"gid": "E2590",
"media": [],
"part_family": [],
"part_person": [
498
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1708-07-25",
"date_sdn": 2345100,
"descr": "Death of Jenkins, Margaret",
"gid": "E2591",
"media": [],
"part_family": [],
"part_person": [
498
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Jenkins, Peter",
"gid": "E2585",
"media": [],
"part_family": [],
"part_person": [
499
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1680-10-14",
"date_sdn": 2334955,
"descr": "Death of Jenkins, Peter",
"gid": "E2586",
"media": [],
"part_family": [],
"part_person": [
499
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1835-07-13",
"date_sdn": 2391473,
"descr": "Birth of Jim\u00e9nez, Amanda E.",
"gid": "E0441",
"media": [],
"part_family": [],
"part_person": [
501
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1883-04-25",
"date_sdn": 2408926,
"descr": "Death of Jim\u00e9nez, Amanda E.",
"gid": "E0442",
"media": [],
"part_family": [],
"part_person": [
501
],
"place": 482,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1835-07-15",
"date_sdn": 2391475,
"descr": "Burial of Jim\u00e9nez, Amanda E.",
"gid": "E0443",
"media": [],
"part_family": [],
"part_person": [
501
],
"place": 764,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1792-01-21",
"date_sdn": 2375595,
"descr": "Birth of Jim\u00e9nez, Andrew",
"gid": "E0725",
"media": [],
"part_family": [],
"part_person": [
502
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Armand E.",
"gid": "E0483",
"media": [],
"part_family": [],
"part_person": [
503
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1805-07-27",
"date_sdn": 2380530,
"descr": "Birth of Jim\u00e9nez, Cornelius",
"gid": "E0732",
"media": [],
"part_family": [],
"part_person": [
504
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-03-05",
"date_sdn": 2402666,
"descr": "Death of Jim\u00e9nez, Cornelius",
"gid": "E0733",
"media": [],
"part_family": [],
"part_person": [
504
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1790-11-28",
"date_sdn": 2375176,
"descr": "Birth of Jim\u00e9nez, Elizabeth",
"gid": "E0721",
"media": [],
"part_family": [],
"part_person": [
505
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-04-00",
"date_sdn": 2388814,
"descr": "Death of Jim\u00e9nez, Elizabeth",
"gid": "E0722",
"media": [],
"part_family": [],
"part_person": [
505
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, George H.",
"gid": "E0487",
"media": [],
"part_family": [],
"part_person": [
506
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1826-08-15",
"date_sdn": 2388219,
"descr": "Birth of Jim\u00e9nez, George Henry, III",
"gid": "E2095",
"media": [],
"part_family": [],
"part_person": [
507
],
"place": 6,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1907-10-25",
"date_sdn": 2417874,
"descr": "Death of Jim\u00e9nez, George Henry, III",
"gid": "E2096",
"media": [],
"part_family": [],
"part_person": [
507
],
"place": 704,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1802-09-29",
"date_sdn": 2379498,
"descr": "Birth of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2081",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 744,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-02-19",
"date_sdn": 2403748,
"descr": "Death of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2082",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 313,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-02-21",
"date_sdn": 2403750,
"descr": "Burial of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2083",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 189,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1760-02-10",
"date_sdn": 2363927,
"descr": "Birth of Jim\u00e9nez, George, Sr.",
"gid": "E1708",
"media": [],
"part_family": [],
"part_person": [
509
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1827-07-28",
"date_sdn": 2388566,
"descr": "Death of Jim\u00e9nez, George, Sr.",
"gid": "E1709",
"media": [],
"part_family": [],
"part_person": [
509
],
"place": 232,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1827-07-29",
"date_sdn": 2388567,
"descr": "Burial of Jim\u00e9nez, George, Sr.",
"gid": "E1710",
"media": [],
"part_family": [],
"part_person": [
509
],
"place": 260,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1839-08-06",
"date_sdn": 2392958,
"descr": "Birth of Jim\u00e9nez, James T.",
"gid": "E0447",
"media": [],
"part_family": [],
"part_person": [
510
],
"place": 573,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1839-08-06",
"date_sdn": 2392958,
"descr": "Death of Jim\u00e9nez, James T.",
"gid": "E0448",
"media": [],
"part_family": [],
"part_person": [
510
],
"place": 482,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1839-08-07",
"date_sdn": 2392959,
"descr": "Burial of Jim\u00e9nez, James T.",
"gid": "E0449",
"media": [],
"part_family": [],
"part_person": [
510
],
"place": 271,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1794-11-05",
"date_sdn": 2376614,
"descr": "Birth of Jim\u00e9nez, John",
"gid": "E0726",
"media": [],
"part_family": [],
"part_person": [
511
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-01-28",
"date_sdn": 2386194,
"descr": "Death of Jim\u00e9nez, John",
"gid": "E0727",
"media": [],
"part_family": [],
"part_person": [
511
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1829-08-30",
"date_sdn": 2389330,
"descr": "Birth of Jim\u00e9nez, John T. L.",
"gid": "E0450",
"media": [],
"part_family": [],
"part_person": [
512
],
"place": 482,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1851-06-20",
"date_sdn": 2397294,
"descr": "Death of Jim\u00e9nez, John T. L.",
"gid": "E0451",
"media": [],
"part_family": [],
"part_person": [
512
],
"place": 573,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1851-06-21",
"date_sdn": 2397295,
"descr": "Burial of Jim\u00e9nez, John T. L.",
"gid": "E0452",
"media": [],
"part_family": [],
"part_person": [
512
],
"place": 393,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Lincoln F.",
"gid": "E0485",
"media": [],
"part_family": [],
"part_person": [
513
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Lucinda",
"gid": "E0460",
"media": [],
"part_family": [],
"part_person": [
514
],
"place": 482,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1870-02-05",
"date_sdn": 2404099,
"descr": "Birth of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1591",
"media": [],
"part_family": [],
"part_person": [
515
],
"place": 313,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1949-02-21",
"date_sdn": 2432969,
"descr": "Death of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1592",
"media": [],
"part_family": [],
"part_person": [
515
],
"place": 392,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1949-02-00",
"date_sdn": 2432949,
"descr": "Burial of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1593",
"media": [],
"part_family": [],
"part_person": [
515
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1849-12-08",
"date_sdn": 2396735,
"descr": "Birth of Jim\u00e9nez, Mary C.",
"gid": "E0453",
"media": [],
"part_family": [],
"part_person": [
516
],
"place": 482,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-10-10",
"date_sdn": 2403981,
"descr": "Death of Jim\u00e9nez, Mary C.",
"gid": "E0454",
"media": [],
"part_family": [],
"part_person": [
516
],
"place": 482,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-10-11",
"date_sdn": 2403982,
"descr": "Burial of Jim\u00e9nez, Mary C.",
"gid": "E0455",
"media": [],
"part_family": [],
"part_person": [
516
],
"place": 271,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Mary C.",
"gid": "E0479",
"media": [],
"part_family": [],
"part_person": [
517
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Nancy E.",
"gid": "E0456",
"media": [],
"part_family": [],
"part_person": [
518
],
"place": 482,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-10-10",
"date_sdn": 2394850,
"descr": "Birth of Jim\u00e9nez, Nathan M.",
"gid": "E0444",
"media": [],
"part_family": [],
"part_person": [
519
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1848-07-01",
"date_sdn": 2396210,
"descr": "Death of Jim\u00e9nez, Nathan M.",
"gid": "E0445",
"media": [],
"part_family": [],
"part_person": [
519
],
"place": 573,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1848-07-03",
"date_sdn": 2396212,
"descr": "Burial of Jim\u00e9nez, Nathan M.",
"gid": "E0446",
"media": [],
"part_family": [],
"part_person": [
519
],
"place": 189,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Philip",
"gid": "E0486",
"media": [],
"part_family": [],
"part_person": [
520
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1788-09-24",
"date_sdn": 2374381,
"descr": "Birth of Jim\u00e9nez, Polly Mary",
"gid": "E0720",
"media": [],
"part_family": [],
"part_person": [
521
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1799-09-12",
"date_sdn": 2378386,
"descr": "Birth of Jim\u00e9nez, Rebecca",
"gid": "E0729",
"media": [],
"part_family": [],
"part_person": [
522
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Richard? Cornelius",
"gid": "E0459",
"media": [],
"part_family": [],
"part_person": [
523
],
"place": 482,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1797-04-20",
"date_sdn": 2377511,
"descr": "Birth of Jim\u00e9nez, Sarah",
"gid": "E0728",
"media": [],
"part_family": [],
"part_person": [
524
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Sarah M.",
"gid": "E0478",
"media": [],
"part_family": [],
"part_person": [
525
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Tolbert A.",
"gid": "E0484",
"media": [],
"part_family": [],
"part_person": [
526
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1750-05-04",
"date_sdn": 2360358,
"descr": "Birth of Johansen, John",
"gid": "E0791",
"media": [],
"part_family": [],
"part_person": [
527
],
"place": 29,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1835",
"date_sdn": 2391280,
"descr": "Death of Johansen, John",
"gid": "E0792",
"media": [],
"part_family": [],
"part_person": [
527
],
"place": 574,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1917-01-13",
"date_sdn": 2421242,
"descr": "Birth of Johnson, Richard F.",
"gid": "E2075",
"media": [],
"part_family": [],
"part_person": [
529
],
"place": 800,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1982-09-22",
"date_sdn": 2445235,
"descr": "Death of Johnson, Richard F.",
"gid": "E2076",
"media": [],
"part_family": [],
"part_person": [
529
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Johnson, Richard F.",
"gid": "E2077",
"media": [],
"part_family": [],
"part_person": [
529
],
"place": 760,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1550",
"date_sdn": 2287186,
"descr": "Birth of Jones, Ann",
"gid": "E0016",
"media": [],
"part_family": [],
"part_person": [
530
],
"place": 692,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1518",
"date_sdn": 2275498,
"descr": "Birth of Jones, Hugh",
"gid": "E0015",
"media": [],
"part_family": [],
"part_person": [
531
],
"place": 692,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1876-08-24",
"date_sdn": 2406491,
"descr": "Birth of Jones, Martha Elizabeth",
"gid": "E1158",
"media": [],
"part_family": [],
"part_person": [
532
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Kaczmarek, Isabella",
"gid": "E2056",
"media": [],
"part_family": [],
"part_person": [
534
],
"place": 85,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-04-21",
"date_sdn": 2416592,
"descr": "Death of Kaczmarek, Isabella",
"gid": "E2057",
"media": [],
"part_family": [],
"part_person": [
534
],
"place": 642,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1904-04-23",
"date_sdn": 2416594,
"descr": "Burial of Kaczmarek, Isabella",
"gid": "E2058",
"media": [],
"part_family": [],
"part_person": [
534
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1885-12-25",
"date_sdn": 2409901,
"descr": "Birth of Klein, Alma Katherine",
"gid": "E0058",
"media": [],
"part_family": [],
"part_person": [
540
],
"place": 664,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-11-22",
"date_sdn": 2420094,
"descr": "Death of Klein, Alma Katherine",
"gid": "E0059",
"media": [],
"part_family": [],
"part_person": [
540
],
"place": 616,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1913-11-24",
"date_sdn": 2420096,
"descr": "Burial of Klein, Alma Katherine",
"gid": "E0060",
"media": [],
"part_family": [],
"part_person": [
540
],
"place": 590,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1325",
"date_sdn": 2205007,
"descr": "Birth of Knudsen, John",
"gid": "E0049",
"media": [],
"part_family": [],
"part_person": [
542
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1368",
"date_sdn": 2220712,
"descr": "Death of Knudsen, John",
"gid": "E0050",
"media": [],
"part_family": [],
"part_person": [
542
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1345",
"date_sdn": 2212312,
"descr": "Birth of Knudsen, John",
"gid": "E0052",
"media": [],
"part_family": [],
"part_person": [
543
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1388",
"date_sdn": 2228017,
"descr": "Death of Knudsen, John",
"gid": "E0053",
"media": [],
"part_family": [],
"part_person": [
543
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1250",
"date_sdn": 2177614,
"descr": "Birth of Knudsen, Ralph",
"gid": "E0043",
"media": [],
"part_family": [],
"part_person": [
544
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1316",
"date_sdn": 2201719,
"descr": "Death of Knudsen, Ralph",
"gid": "E0044",
"media": [],
"part_family": [],
"part_person": [
544
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1300",
"date_sdn": 2195876,
"descr": "Birth of Knudsen, Ralph",
"gid": "E0046",
"media": [],
"part_family": [],
"part_person": [
545
],
"place": 71,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1343",
"date_sdn": 2211581,
"descr": "Death of Knudsen, Ralph",
"gid": "E0047",
"media": [],
"part_family": [],
"part_person": [
545
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1220",
"date_sdn": 2166656,
"descr": "Birth of Knudsen, Ranulf",
"gid": "E0037",
"media": [],
"part_family": [],
"part_person": [
546
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1294",
"date_sdn": 2193685,
"descr": "Death of Knudsen, Ranulf",
"gid": "E0038",
"media": [],
"part_family": [],
"part_person": [
546
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1192",
"date_sdn": 2156429,
"descr": "Birth of Knudsen, Robert",
"gid": "E0034",
"media": [],
"part_family": [],
"part_person": [
547
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1252-12-07",
"date_sdn": 2178685,
"descr": "Death of Knudsen, Robert",
"gid": "E0035",
"media": [],
"part_family": [],
"part_person": [
547
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1560",
"date_sdn": 2290838,
"descr": "Birth of Kowalski, John",
"gid": "E0242",
"media": [],
"part_family": [],
"part_person": [
548
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1630-08-30",
"date_sdn": 2316647,
"descr": "Death of Kowalski, John",
"gid": "E0243",
"media": [],
"part_family": [],
"part_person": [
548
],
"place": 104,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Kowalski, Thomas",
"gid": "E0246",
"media": [],
"part_family": [],
"part_person": [
549
],
"place": 201,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1535",
"date_sdn": 2281707,
"descr": "Birth of Koz\u0142owski, Margret",
"gid": "E0070",
"media": [],
"part_family": [],
"part_person": [
550
],
"place": 869,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1598",
"date_sdn": 2304718,
"descr": "Death of Koz\u0142owski, Margret",
"gid": "E0071",
"media": [],
"part_family": [],
"part_person": [
550
],
"place": 869,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1892-02-22",
"date_sdn": 2412151,
"descr": "Birth of Kristensen, Catherine Virginia",
"gid": "E1948",
"media": [],
"part_family": [],
"part_person": [
551
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-03-01",
"date_sdn": 2424576,
"descr": "Death of Kristensen, Catherine Virginia",
"gid": "E1949",
"media": [],
"part_family": [],
"part_person": [
551
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1889-10-10",
"date_sdn": 2411286,
"descr": "Birth of Kristensen, John Francis&#8220;Chick&#8221;",
"gid": "E1950",
"media": [],
"part_family": [],
"part_person": [
552
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-10-23",
"date_sdn": 2429195,
"descr": "Death of Kristensen, John Francis&#8220;Chick&#8221;",
"gid": "E1951",
"media": [],
"part_family": [],
"part_person": [
552
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1894-12-02",
"date_sdn": 2413165,
"descr": "Birth of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1955",
"media": [],
"part_family": [],
"part_person": [
553
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1974-07-21",
"date_sdn": 2442250,
"descr": "Death of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1956",
"media": [],
"part_family": [],
"part_person": [
553
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1974-07-23",
"date_sdn": 2442252,
"descr": "Burial of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1957",
"media": [],
"part_family": [],
"part_person": [
553
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1887-06-14",
"date_sdn": 2410437,
"descr": "Birth of Kristensen, Mary Elizabeth",
"gid": "E1942",
"media": [],
"part_family": [],
"part_person": [
554
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-10-22",
"date_sdn": 2421889,
"descr": "Death of Kristensen, Mary Elizabeth",
"gid": "E1943",
"media": [],
"part_family": [],
"part_person": [
554
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1897-01-01",
"date_sdn": 2413926,
"descr": "Birth of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1952",
"media": [],
"part_family": [],
"part_person": [
555
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1971-10-19",
"date_sdn": 2441244,
"descr": "Death of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1953",
"media": [],
"part_family": [],
"part_person": [
555
],
"place": 42,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1971-10-21",
"date_sdn": 2441246,
"descr": "Burial of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1954",
"media": [],
"part_family": [],
"part_person": [
555
],
"place": 121,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1885-06-25",
"date_sdn": 2409718,
"descr": "Birth of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1945",
"media": [],
"part_family": [],
"part_person": [
556
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-01-04",
"date_sdn": 2424520,
"descr": "Death of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1946",
"media": [],
"part_family": [],
"part_person": [
556
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1926-01-05",
"date_sdn": 2424521,
"descr": "Burial of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1947",
"media": [],
"part_family": [],
"part_person": [
556
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1864-12-00",
"date_sdn": 2402207,
"descr": "Birth of Landry, Eleanor (Nellie) Therese",
"gid": "E1797",
"media": [],
"part_family": [],
"part_person": [
557
],
"place": 878,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1935-12-12",
"date_sdn": 2428149,
"descr": "Death of Landry, Eleanor (Nellie) Therese",
"gid": "E1798",
"media": [],
"part_family": [],
"part_person": [
557
],
"place": 5,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1935-12-14",
"date_sdn": 2428151,
"descr": "Burial of Landry, Eleanor (Nellie) Therese",
"gid": "E1799",
"media": [],
"part_family": [],
"part_person": [
557
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1889-05-28",
"date_sdn": 2411151,
"descr": "Birth of Landry, Mary A.",
"gid": "E1301",
"media": [],
"part_family": [],
"part_person": [
559
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1955-11-18",
"date_sdn": 2435430,
"descr": "Death of Landry, Mary A.",
"gid": "E1302",
"media": [],
"part_family": [],
"part_person": [
559
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Landry, Michael Edward",
"gid": "E1297",
"media": [],
"part_family": [],
"part_person": [
560
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-08-23",
"date_sdn": 2425116,
"descr": "Death of Landry, Michael Edward",
"gid": "E1298",
"media": [],
"part_family": [],
"part_person": [
560
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Landry, Michael Edward",
"gid": "E1299",
"media": [],
"part_family": [],
"part_person": [
560
],
"place": 608,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lane, Remo",
"gid": "E2303",
"media": [],
"part_family": [],
"part_person": [
562
],
"place": 55,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-01-19",
"date_sdn": 2421978,
"descr": "Death of Lane, Remo",
"gid": "E2304",
"media": [],
"part_family": [],
"part_person": [
562
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Lane, Remo",
"gid": "E2305",
"media": [],
"part_family": [],
"part_person": [
562
],
"place": 498,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1718",
"date_sdn": 2348547,
"descr": "Birth of Lapointe, Lucy aka Sarah",
"gid": "E2708",
"media": [],
"part_family": [],
"part_person": [
564
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1741",
"date_sdn": 2356948,
"descr": "Death of Lapointe, Lucy aka Sarah",
"gid": "E2709",
"media": [],
"part_family": [],
"part_person": [
564
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1834-11-18",
"date_sdn": 2391236,
"descr": "Death of Larson, Christena Wiseman",
"gid": "E0669",
"media": [],
"part_family": [],
"part_person": [
567
],
"place": 681,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1834-11-20",
"date_sdn": 2391238,
"descr": "Burial of Larson, Christena Wiseman",
"gid": "E0670",
"media": [],
"part_family": [],
"part_person": [
567
],
"place": 27,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lefebvre, Joseph",
"gid": "E1862",
"media": [],
"part_family": [],
"part_person": [
570
],
"place": 871,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1654-03-22",
"date_sdn": 2325252,
"descr": "Birth of Lefebvre, Mary",
"gid": "E1865",
"media": [],
"part_family": [],
"part_person": [
571
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1584-12-20",
"date_sdn": 2299958,
"descr": "Birth of Lefebvre, Rev. John L.",
"gid": "E1860",
"media": [],
"part_family": [],
"part_person": [
572
],
"place": 110,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1653-11-03",
"date_sdn": 2325113,
"descr": "Death of Lefebvre, Rev. John L.",
"gid": "E1861",
"media": [],
"part_family": [],
"part_person": [
572
],
"place": 638,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1511",
"date_sdn": 2272941,
"descr": "Birth of Lefebvre, Robert",
"gid": "E2141",
"media": [],
"part_family": [],
"part_person": [
573
],
"place": 632,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1558-10-20",
"date_sdn": 2290400,
"descr": "Death of Lefebvre, Robert",
"gid": "E2142",
"media": [],
"part_family": [],
"part_person": [
573
],
"place": 110,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard",
"gid": "E0858",
"media": [],
"part_family": [],
"part_person": [
575
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard, ???",
"gid": "E2507",
"media": [],
"part_family": [],
"part_person": [
576
],
"place": 554,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1904-07-30",
"date_sdn": 2416692,
"descr": "Birth of Lessard, Carl Tolbert",
"gid": "E1490",
"media": [],
"part_family": [],
"part_person": [
577
],
"place": 704,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1985-07-04",
"date_sdn": 2446251,
"descr": "Death of Lessard, Carl Tolbert",
"gid": "E1491",
"media": [],
"part_family": [],
"part_person": [
577
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1985-07-08",
"date_sdn": 2446255,
"descr": "Burial of Lessard, Carl Tolbert",
"gid": "E1492",
"media": [],
"part_family": [],
"part_person": [
577
],
"place": 83,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1868-08-00",
"date_sdn": 2403546,
"descr": "Birth of Lessard, Emma Jane",
"gid": "E0436",
"media": [],
"part_family": [],
"part_person": [
578
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1933-08-00",
"date_sdn": 2427286,
"descr": "Death of Lessard, Emma Jane",
"gid": "E0437",
"media": [],
"part_family": [],
"part_person": [
578
],
"place": 217,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1871-06-15",
"date_sdn": 2404594,
"descr": "Birth of Lessard, Ira Willis",
"gid": "E1575",
"media": [],
"part_family": [],
"part_person": [
579
],
"place": 470,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1924-12-15",
"date_sdn": 2424135,
"descr": "Death of Lessard, Ira Willis",
"gid": "E1576",
"media": [],
"part_family": [],
"part_person": [
579
],
"place": 592,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1924-12-18",
"date_sdn": 2424138,
"descr": "Burial of Lessard, Ira Willis",
"gid": "E1577",
"media": [],
"part_family": [],
"part_person": [
579
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1828-10-00",
"date_sdn": 2388997,
"descr": "Birth of Lessard, Isaac",
"gid": "E1613",
"media": [],
"part_family": [],
"part_person": [
580
],
"place": 554,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard, Izora",
"gid": "E0464",
"media": [],
"part_family": [],
"part_person": [
581
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-05-06",
"date_sdn": 2415876,
"descr": "Death of Lessard, Izora",
"gid": "E0465",
"media": [],
"part_family": [],
"part_person": [
581
],
"place": 420,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1895-07-20",
"date_sdn": 2413395,
"descr": "Birth of Lessard, Ralph Raymond",
"gid": "E1001",
"media": [],
"part_family": [],
"part_person": [
582
],
"place": 704,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-07-08",
"date_sdn": 2440411,
"descr": "Death of Lessard, Ralph Raymond",
"gid": "E1002",
"media": [],
"part_family": [],
"part_person": [
582
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1896-09-20",
"date_sdn": 2413823,
"descr": "Birth of Lessard, Susanna Marie",
"gid": "E1007",
"media": [],
"part_family": [],
"part_person": [
583
],
"place": 704,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1981-10-16",
"date_sdn": 2444894,
"descr": "Death of Lessard, Susanna Marie",
"gid": "E1008",
"media": [],
"part_family": [],
"part_person": [
583
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Clarence",
"gid": "E0476",
"media": [],
"part_family": [],
"part_person": [
584
],
"place": 675,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1866-03-00",
"date_sdn": 2402662,
"descr": "Birth of L\u00e9vesque, James W.",
"gid": "E0462",
"media": [],
"part_family": [],
"part_person": [
585
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918",
"date_sdn": 2421595,
"descr": "Death of L\u00e9vesque, James W.",
"gid": "E0463",
"media": [],
"part_family": [],
"part_person": [
585
],
"place": 821,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Olive",
"gid": "E0468",
"media": [],
"part_family": [],
"part_person": [
586
],
"place": 675,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Wilma",
"gid": "E0470",
"media": [],
"part_family": [],
"part_person": [
587
],
"place": 675,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of L\u00f3pez, Anna Elisabeth",
"gid": "E0358",
"media": [],
"part_family": [],
"part_person": [
590
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mann, Agnes",
"gid": "E2163",
"media": [],
"part_family": [],
"part_person": [
595
],
"place": 501,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1895-08-27",
"date_sdn": 2413433,
"descr": "Birth of Mar\u00edn, Albert",
"gid": "E1111",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-06-14",
"date_sdn": 2438926,
"descr": "Death of Mar\u00edn, Albert",
"gid": "E1112",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Albert",
"gid": "E1113",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": 528,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2578",
"media": [],
"part_family": [],
"part_person": [
597
],
"place": 615,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-12-25",
"date_sdn": 2402231,
"descr": "Death of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2579",
"media": [],
"part_family": [],
"part_person": [
597
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1860-12-27",
"date_sdn": 2400772,
"descr": "Burial of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2580",
"media": [],
"part_family": [],
"part_person": [
597
],
"place": 215,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1928-10-11",
"date_sdn": 2425531,
"descr": "Birth of Mar\u00edn, Elizabeth Therese",
"gid": "E0438",
"media": [],
"part_family": [],
"part_person": [
599
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-29",
"date_sdn": 2425610,
"descr": "Death of Mar\u00edn, Elizabeth Therese",
"gid": "E0439",
"media": [],
"part_family": [],
"part_person": [
599
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Elizabeth Therese",
"gid": "E0440",
"media": [],
"part_family": [],
"part_person": [
599
],
"place": 608,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1813-03-25",
"date_sdn": 2383328,
"descr": "Birth of Mar\u00edn, Frances Coppage",
"gid": "E1107",
"media": [],
"part_family": [],
"part_person": [
600
],
"place": 609,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1891-10-01",
"date_sdn": 2412007,
"descr": "Death of Mar\u00edn, Frances Coppage",
"gid": "E1108",
"media": [],
"part_family": [],
"part_person": [
600
],
"place": 740,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1891-10-03",
"date_sdn": 2412009,
"descr": "Burial of Mar\u00edn, Frances Coppage",
"gid": "E1109",
"media": [],
"part_family": [],
"part_person": [
600
],
"place": 740,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1956-10-00",
"date_sdn": 2435748,
"descr": "Death of Mar\u00edn, Frank",
"gid": "E1100",
"media": [],
"part_family": [],
"part_person": [
601
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Frank",
"gid": "E1101",
"media": [],
"part_family": [],
"part_person": [
601
],
"place": 22,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-02-26",
"date_sdn": 2408868,
"descr": "Birth of Mar\u00edn, Lilla Estella",
"gid": "E1153",
"media": [],
"part_family": [],
"part_person": [
602
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1961-02-25",
"date_sdn": 2437356,
"descr": "Death of Mar\u00edn, Lilla Estella",
"gid": "E1154",
"media": [],
"part_family": [],
"part_person": [
602
],
"place": 522,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1862-04-08",
"date_sdn": 2401239,
"descr": "Birth of Mar\u00edn, Moses Wallace",
"gid": "E1780",
"media": [],
"part_family": [],
"part_person": [
603
],
"place": 682,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1909-08-08",
"date_sdn": 2418527,
"descr": "Death of Mar\u00edn, Moses Wallace",
"gid": "E1781",
"media": [],
"part_family": [],
"part_person": [
603
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1909-08-10",
"date_sdn": 2418529,
"descr": "Burial of Mar\u00edn, Moses Wallace",
"gid": "E1782",
"media": [],
"part_family": [],
"part_person": [
603
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mar\u00edn, Nancy H.",
"gid": "E1287",
"media": [],
"part_family": [],
"part_person": [
604
],
"place": 623,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1897-06-21",
"date_sdn": 2414097,
"descr": "Birth of Mar\u00edn, Thomas Willis",
"gid": "E1130",
"media": [],
"part_family": [],
"part_person": [
606
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-06-28",
"date_sdn": 2437844,
"descr": "Death of Mar\u00edn, Thomas Willis",
"gid": "E1131",
"media": [],
"part_family": [],
"part_person": [
606
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Thomas Willis",
"gid": "E1132",
"media": [],
"part_family": [],
"part_person": [
606
],
"place": 748,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1893-12-29",
"date_sdn": 2412827,
"descr": "Birth of Mar\u00edn, Walter Matthew",
"gid": "E1867",
"media": [],
"part_family": [],
"part_person": [
607
],
"place": 878,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-01-16",
"date_sdn": 2440238,
"descr": "Death of Mar\u00edn, Walter Matthew",
"gid": "E1868",
"media": [],
"part_family": [],
"part_person": [
607
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1969-01-18",
"date_sdn": 2440240,
"descr": "Burial of Mar\u00edn, Walter Matthew",
"gid": "E1869",
"media": [],
"part_family": [],
"part_person": [
607
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1906-10-00",
"date_sdn": 2417485,
"descr": "Death of Mar\u00edn, Wilbur",
"gid": "E1139",
"media": [],
"part_family": [],
"part_person": [
608
],
"place": 359,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1906-10-22",
"date_sdn": 2417506,
"descr": "Burial of Mar\u00edn, Wilbur",
"gid": "E1140",
"media": [],
"part_family": [],
"part_person": [
608
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1822-11-11",
"date_sdn": 2386846,
"descr": "Birth of Mar\u00edn, Willis H.",
"gid": "E1284",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 570,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1894-01-02",
"date_sdn": 2412831,
"descr": "Death of Mar\u00edn, Willis H.",
"gid": "E1285",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1894-01-03",
"date_sdn": 2412832,
"descr": "Burial of Mar\u00edn, Willis H.",
"gid": "E1286",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 608,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1612",
"date_sdn": 2309831,
"descr": "Birth of Marsh, Margaret",
"gid": "E2587",
"media": [],
"part_family": [],
"part_person": [
611
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1680-05-20",
"date_sdn": 2334808,
"descr": "Death of Marsh, Margaret",
"gid": "E2588",
"media": [],
"part_family": [],
"part_person": [
611
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1805-10-27",
"date_sdn": 2380622,
"descr": "Birth of Martel, Henry",
"gid": "E2685",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 849,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-01-18",
"date_sdn": 2415768,
"descr": "Death of Martel, Henry",
"gid": "E2686",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 329,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902",
"date_sdn": 2415751,
"descr": "Burial of Martel, Henry",
"gid": "E2687",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 329,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1852-01-23",
"date_sdn": 2397511,
"descr": "Birth of Martel, Luella Jacques",
"gid": "E1679",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 249,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-04-28",
"date_sdn": 2422808,
"descr": "Death of Martel, Luella Jacques",
"gid": "E1680",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 560,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-04-30",
"date_sdn": 2422810,
"descr": "Burial of Martel, Luella Jacques",
"gid": "E1681",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 560,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1420",
"date_sdn": 2239704,
"descr": "Birth of Massey, John",
"gid": "E0054",
"media": [],
"part_family": [],
"part_person": [
617
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1606",
"date_sdn": 2307640,
"descr": "Birth of Mazur, William",
"gid": "E0265",
"media": [],
"part_family": [],
"part_person": [
620
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1890-05-23",
"date_sdn": 2411511,
"descr": "Birth of McCoy, Francis",
"gid": "E0931",
"media": [],
"part_family": [],
"part_person": [
622
],
"place": 670,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-05-19",
"date_sdn": 2437804,
"descr": "Death of McCoy, Francis",
"gid": "E0932",
"media": [],
"part_family": [],
"part_person": [
622
],
"place": 250,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1979-02-07",
"date_sdn": 2443912,
"descr": "Birth of McCoy, Paula",
"gid": "E0921",
"media": [],
"part_family": [],
"part_person": [
623
],
"place": 780,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-07-03",
"date_sdn": 2445519,
"descr": "Death of McCoy, Paula",
"gid": "E0922",
"media": [],
"part_family": [],
"part_person": [
623
],
"place": 327,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mcdaniel, Margaret",
"gid": "E0554",
"media": [],
"part_family": [],
"part_person": [
624
],
"place": 677,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1825-06-19",
"date_sdn": 2387797,
"descr": "Birth of Meyer, Catherine",
"gid": "E0040",
"media": [],
"part_family": [],
"part_person": [
626
],
"place": 434,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1911-01-30",
"date_sdn": 2419067,
"descr": "Death of Meyer, Catherine",
"gid": "E0041",
"media": [],
"part_family": [],
"part_person": [
626
],
"place": 109,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1911-02-01",
"date_sdn": 2419069,
"descr": "Burial of Meyer, Catherine",
"gid": "E0042",
"media": [],
"part_family": [],
"part_person": [
626
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1716",
"date_sdn": 2347816,
"descr": "Birth of Michaud, Anna Eva",
"gid": "E0417",
"media": [],
"part_family": [],
"part_person": [
627
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of Michaud, Valentin",
"gid": "E0427",
"media": [],
"part_family": [],
"part_person": [
628
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1818-01-05",
"date_sdn": 2385075,
"descr": "Birth of Mills, Isabella",
"gid": "E2466",
"media": [],
"part_family": [],
"part_person": [
630
],
"place": 639,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1874-08-20",
"date_sdn": 2405756,
"descr": "Death of Mills, Isabella",
"gid": "E2467",
"media": [],
"part_family": [],
"part_person": [
630
],
"place": 536,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1874-08-21",
"date_sdn": 2405757,
"descr": "Burial of Mills, Isabella",
"gid": "E2468",
"media": [],
"part_family": [],
"part_person": [
630
],
"place": 133,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1740-02-23",
"date_sdn": 2356635,
"descr": "Birth of Mitchell, Mary",
"gid": "E1875",
"media": [],
"part_family": [],
"part_person": [
631
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-12-28",
"date_sdn": 2387624,
"descr": "Death of Mitchell, Mary",
"gid": "E1876",
"media": [],
"part_family": [],
"part_person": [
631
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1450",
"date_sdn": 2250662,
"descr": "Birth of Molina, Robert",
"gid": "E0253",
"media": [],
"part_family": [],
"part_person": [
632
],
"place": 632,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1686",
"date_sdn": 2336860,
"descr": "Birth of Montgomery, Mary",
"gid": "E1078",
"media": [],
"part_family": [],
"part_person": [
633
],
"place": 793,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moran, Ann Delilah &#8220;Tilley&#8221;",
"gid": "E1935",
"media": [],
"part_family": [],
"part_person": [
635
],
"place": 343,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1801",
"date_sdn": 2378862,
"descr": "Death of Moran, Ann Delilah &#8220;Tilley&#8221;",
"gid": "E1936",
"media": [],
"part_family": [],
"part_person": [
635
],
"place": 432,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1784-02-05",
"date_sdn": 2372688,
"descr": "Birth of Moreno, Aaron",
"gid": "E2008",
"media": [],
"part_family": [],
"part_person": [
639
],
"place": 323,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-02-18",
"date_sdn": 2395346,
"descr": "Death of Moreno, Aaron",
"gid": "E2009",
"media": [],
"part_family": [],
"part_person": [
639
],
"place": 149,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1846-02-20",
"date_sdn": 2395348,
"descr": "Burial of Moreno, Aaron",
"gid": "E2010",
"media": [],
"part_family": [],
"part_person": [
639
],
"place": 251,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1823-03-13",
"date_sdn": 2386968,
"descr": "Birth of Moreno, Abigail Chapman",
"gid": "E1335",
"media": [],
"part_family": [],
"part_person": [
640
],
"place": 77,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853-06-02",
"date_sdn": 2398007,
"descr": "Death of Moreno, Abigail Chapman",
"gid": "E1336",
"media": [],
"part_family": [],
"part_person": [
640
],
"place": 358,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1853-06-04",
"date_sdn": 2398009,
"descr": "Burial of Moreno, Abigail Chapman",
"gid": "E1337",
"media": [],
"part_family": [],
"part_person": [
640
],
"place": 624,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1786-01-13",
"date_sdn": 2373396,
"descr": "Birth of Moreno, Absalom",
"gid": "E1205",
"media": [],
"part_family": [],
"part_person": [
641
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-04-15",
"date_sdn": 2392480,
"descr": "Death of Moreno, Absalom",
"gid": "E1206",
"media": [],
"part_family": [],
"part_person": [
641
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1838-04-17",
"date_sdn": 2392482,
"descr": "Burial of Moreno, Absalom",
"gid": "E1207",
"media": [],
"part_family": [],
"part_person": [
641
],
"place": 613,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1693",
"date_sdn": 2339417,
"descr": "Birth of Moreno, Christian, I",
"gid": "E1939",
"media": [],
"part_family": [],
"part_person": [
643
],
"place": 403,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1772-04-16",
"date_sdn": 2368376,
"descr": "Death of Moreno, Christian, I",
"gid": "E1940",
"media": [],
"part_family": [],
"part_person": [
643
],
"place": 741,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Moreno, Christian, I",
"gid": "E1941",
"media": [],
"part_family": [],
"part_person": [
643
],
"place": 413,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1825-08-18",
"date_sdn": 2387857,
"descr": "Birth of Moreno, Cyrus W.",
"gid": "E1189",
"media": [],
"part_family": [],
"part_person": [
644
],
"place": 623,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1828-03-21",
"date_sdn": 2388803,
"descr": "Birth of Moreno, Darius",
"gid": "E1182",
"media": [],
"part_family": [],
"part_person": [
645
],
"place": 827,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1818-01-05",
"date_sdn": 2385075,
"descr": "Birth of Moreno, Delilah",
"gid": "E1184",
"media": [],
"part_family": [],
"part_person": [
647
],
"place": 623,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1871-01-08",
"date_sdn": 2404436,
"descr": "Death of Moreno, Delilah",
"gid": "E1185",
"media": [],
"part_family": [],
"part_person": [
647
],
"place": 407,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1799-11-29",
"date_sdn": 2378464,
"descr": "Birth of Moreno, Enoch T.",
"gid": "E1214",
"media": [],
"part_family": [],
"part_person": [
650
],
"place": 79,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1790-01-17",
"date_sdn": 2374861,
"descr": "Birth of Moreno, Esau",
"gid": "E1213",
"media": [],
"part_family": [],
"part_person": [
651
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1860-06-26",
"date_sdn": 2400588,
"descr": "Birth of Moreno, Flora E.",
"gid": "E1199",
"media": [],
"part_family": [],
"part_person": [
652
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-11-24",
"date_sdn": 2394895,
"descr": "Birth of Moreno, Green P.",
"gid": "E1183",
"media": [],
"part_family": [],
"part_person": [
653
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1726-11-15",
"date_sdn": 2351787,
"descr": "Birth of Moreno, Johann Christian II",
"gid": "E1961",
"media": [],
"part_family": [],
"part_person": [
654
],
"place": 13,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1797-12-10",
"date_sdn": 2377745,
"descr": "Death of Moreno, Johann Christian II",
"gid": "E1962",
"media": [],
"part_family": [],
"part_person": [
654
],
"place": 323,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1782-01-07",
"date_sdn": 2371929,
"descr": "Birth of Moreno, John",
"gid": "E1204",
"media": [],
"part_family": [],
"part_person": [
655
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1816-01-26",
"date_sdn": 2384365,
"descr": "Birth of Moreno, Joseph McDowell",
"gid": "E1177",
"media": [],
"part_family": [],
"part_person": [
656
],
"place": 623,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-06-28",
"date_sdn": 2394015,
"descr": "Death of Moreno, Joseph McDowell",
"gid": "E1178",
"media": [],
"part_family": [],
"part_person": [
656
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1794-09-10",
"date_sdn": 2376558,
"descr": "Birth of Moreno, Leah",
"gid": "E1208",
"media": [],
"part_family": [],
"part_person": [
657
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875-11-05",
"date_sdn": 2406198,
"descr": "Death of Moreno, Leah",
"gid": "E1209",
"media": [],
"part_family": [],
"part_person": [
657
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858-12-12",
"date_sdn": 2400026,
"descr": "Birth of Moreno, Lelia L.",
"gid": "E1198",
"media": [],
"part_family": [],
"part_person": [
658
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1864-04-15",
"date_sdn": 2401977,
"descr": "Birth of Moreno, Lydia M.",
"gid": "E1201",
"media": [],
"part_family": [],
"part_person": [
659
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1752-11-23",
"date_sdn": 2361292,
"descr": "Birth of Moreno, Maj. Christopher",
"gid": "E1983",
"media": [],
"part_family": [],
"part_person": [
660
],
"place": 683,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1823-09-14",
"date_sdn": 2387153,
"descr": "Death of Moreno, Maj. Christopher",
"gid": "E1984",
"media": [],
"part_family": [],
"part_person": [
660
],
"place": 708,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1862-11-11",
"date_sdn": 2401456,
"descr": "Birth of Moreno, Martha A.",
"gid": "E1200",
"media": [],
"part_family": [],
"part_person": [
661
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1820-08-20",
"date_sdn": 2386033,
"descr": "Birth of Moreno, Mary H.",
"gid": "E1188",
"media": [],
"part_family": [],
"part_person": [
662
],
"place": 623,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1830-03-17",
"date_sdn": 2389529,
"descr": "Birth of Moreno, Minerva",
"gid": "E1192",
"media": [],
"part_family": [],
"part_person": [
663
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1856-08-07",
"date_sdn": 2399169,
"descr": "Birth of Moreno, Phebe J.",
"gid": "E1197",
"media": [],
"part_family": [],
"part_person": [
665
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1832-12-26",
"date_sdn": 2390544,
"descr": "Birth of Moreno, Solon",
"gid": "E1193",
"media": [],
"part_family": [],
"part_person": [
667
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1814-08-22",
"date_sdn": 2383843,
"descr": "Birth of Moreno, Thomas H.",
"gid": "E1176",
"media": [],
"part_family": [],
"part_person": [
668
],
"place": 623,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Morgan, Elisabeth Margaretha",
"gid": "E0390",
"media": [],
"part_family": [],
"part_person": [
669
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1795",
"date_sdn": 2376671,
"descr": "Death of Morris, Adam",
"gid": "E2017",
"media": [],
"part_family": [],
"part_person": [
670
],
"place": 655,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1830",
"date_sdn": 2389454,
"descr": "Birth of Morris, Carlisle",
"gid": "E1099",
"media": [],
"part_family": [],
"part_person": [
671
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Morris, Cyrus",
"gid": "E1102",
"media": [],
"part_family": [],
"part_person": [
672
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "20",
"date_sdn": 1728365,
"descr": "Birth of Morris, Cyrus",
"gid": "E2018",
"media": [],
"part_family": [],
"part_person": [
673
],
"place": 684,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1852-08-10",
"date_sdn": 2397711,
"descr": "Death of Morris, Cyrus",
"gid": "E2019",
"media": [],
"part_family": [],
"part_person": [
673
],
"place": 735,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Morris, Cyrus",
"gid": "E2020",
"media": [],
"part_family": [],
"part_person": [
673
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1822-11-20",
"date_sdn": 2386855,
"descr": "Birth of Morris, Jane",
"gid": "E2407",
"media": [],
"part_family": [],
"part_person": [
674
],
"place": 130,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-04-23",
"date_sdn": 2406733,
"descr": "Death of Morris, Jane",
"gid": "E2408",
"media": [],
"part_family": [],
"part_person": [
674
],
"place": 258,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Morris, Jane",
"gid": "E2409",
"media": [],
"part_family": [],
"part_person": [
674
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1841",
"date_sdn": 2393472,
"descr": "Birth of Morris, John",
"gid": "E1106",
"media": [],
"part_family": [],
"part_person": [
675
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1837",
"date_sdn": 2392011,
"descr": "Birth of Morris, Martha",
"gid": "E1104",
"media": [],
"part_family": [],
"part_person": [
676
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1839",
"date_sdn": 2392741,
"descr": "Birth of Morris, Mary",
"gid": "E1105",
"media": [],
"part_family": [],
"part_person": [
677
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1835",
"date_sdn": 2391280,
"descr": "Birth of Morris, Robert",
"gid": "E1103",
"media": [],
"part_family": [],
"part_person": [
678
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Birth of Morris, Roland",
"gid": "E1098",
"media": [],
"part_family": [],
"part_person": [
679
],
"place": 616,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1789",
"date_sdn": 2374480,
"descr": "Birth of Mullins, Robert?",
"gid": "E0127",
"media": [],
"part_family": [],
"part_person": [
680
],
"place": 430,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-08-13",
"date_sdn": 2388948,
"descr": "Death of Mullins, Robert?",
"gid": "E0128",
"media": [],
"part_family": [],
"part_person": [
680
],
"place": 221,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mullins, Robert?",
"gid": "E0129",
"media": [],
"part_family": [],
"part_person": [
680
],
"place": 533,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1617",
"date_sdn": 2311658,
"descr": "Birth of Murray, Nicholas",
"gid": "E0280",
"media": [],
"part_family": [],
"part_person": [
682
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1647",
"date_sdn": 2322615,
"descr": "Birth of Murray, Susannah",
"gid": "E0262",
"media": [],
"part_family": [],
"part_person": [
683
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1813",
"date_sdn": 2383245,
"descr": "Birth of Myers, James",
"gid": "E2493",
"media": [],
"part_family": [],
"part_person": [
684
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1896-06-04",
"date_sdn": 2413715,
"descr": "Death of Myers, James",
"gid": "E2494",
"media": [],
"part_family": [],
"part_person": [
684
],
"place": 757,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1896",
"date_sdn": 2413560,
"descr": "Burial of Myers, James",
"gid": "E2495",
"media": [],
"part_family": [],
"part_person": [
684
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1857-12-22",
"date_sdn": 2399671,
"descr": "Birth of Myers, James Joseph Jr.",
"gid": "E2496",
"media": [],
"part_family": [],
"part_person": [
685
],
"place": 757,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1934-04-05",
"date_sdn": 2427533,
"descr": "Death of Myers, James Joseph Jr.",
"gid": "E2497",
"media": [],
"part_family": [],
"part_person": [
685
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1934",
"date_sdn": 2427439,
"descr": "Burial of Myers, James Joseph Jr.",
"gid": "E2498",
"media": [],
"part_family": [],
"part_person": [
685
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Andrew",
"gid": "E0492",
"media": [],
"part_family": [],
"part_person": [
686
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Belle",
"gid": "E0493",
"media": [],
"part_family": [],
"part_person": [
687
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903",
"date_sdn": 2416116,
"descr": "Death of Neal, Belle",
"gid": "E0494",
"media": [],
"part_family": [],
"part_person": [
687
],
"place": 575,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, David",
"gid": "E0507",
"media": [],
"part_family": [],
"part_person": [
688
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, James",
"gid": "E0498",
"media": [],
"part_family": [],
"part_person": [
689
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, James",
"gid": "E0491",
"media": [],
"part_family": [],
"part_person": [
690
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1872-09-11",
"date_sdn": 2405048,
"descr": "Birth of Neal, John",
"gid": "E0499",
"media": [],
"part_family": [],
"part_person": [
691
],
"place": 180,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-26",
"date_sdn": 2425607,
"descr": "Death of Neal, John",
"gid": "E0500",
"media": [],
"part_family": [],
"part_person": [
691
],
"place": 575,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Margaret",
"gid": "E0501",
"media": [],
"part_family": [],
"part_person": [
692
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1877-02-09",
"date_sdn": 2406660,
"descr": "Birth of Neal, Matilda",
"gid": "E0502",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": 500,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1946",
"date_sdn": 2431822,
"descr": "Death of Neal, Matilda",
"gid": "E0503",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1711-01-03",
"date_sdn": 2345992,
"descr": "Birth of Nichols, Elizabeth",
"gid": "E1074",
"media": [],
"part_family": [],
"part_person": [
695
],
"place": 866,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1768-04-15",
"date_sdn": 2366914,
"descr": "Death of Nichols, Elizabeth",
"gid": "E1075",
"media": [],
"part_family": [],
"part_person": [
695
],
"place": 866,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1679",
"date_sdn": 2334303,
"descr": "Birth of Norris, Elizabeth",
"gid": "E1146",
"media": [],
"part_family": [],
"part_person": [
698
],
"place": 734,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1731-05-10",
"date_sdn": 2353424,
"descr": "Death of Norris, Elizabeth",
"gid": "E1147",
"media": [],
"part_family": [],
"part_person": [
698
],
"place": 287,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1731-05-12",
"date_sdn": 2353426,
"descr": "Burial of Norris, Elizabeth",
"gid": "E1148",
"media": [],
"part_family": [],
"part_person": [
698
],
"place": 736,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1633-09-08",
"date_sdn": 2317752,
"descr": "Birth of Norris, John",
"gid": "E2235",
"media": [],
"part_family": [],
"part_person": [
699
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1712-08-27",
"date_sdn": 2346594,
"descr": "Death of Norris, John",
"gid": "E2236",
"media": [],
"part_family": [],
"part_person": [
699
],
"place": 24,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1712",
"date_sdn": 2346355,
"descr": "Burial of Norris, John",
"gid": "E2237",
"media": [],
"part_family": [],
"part_person": [
699
],
"place": 391,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1600",
"date_sdn": 2305448,
"descr": "Birth of Norris, William",
"gid": "E1117",
"media": [],
"part_family": [],
"part_person": [
700
],
"place": 631,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1843",
"date_sdn": 2394202,
"descr": "Birth of Ortega, Catherine",
"gid": "E2693",
"media": [],
"part_family": [],
"part_person": [
703
],
"place": 464,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1876",
"date_sdn": 2406255,
"descr": "Death of Ortega, Catherine",
"gid": "E2694",
"media": [],
"part_family": [],
"part_person": [
703
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1887-02-05",
"date_sdn": 2410308,
"descr": "Birth of Page, Andrew Vincent",
"gid": "E1055",
"media": [],
"part_family": [],
"part_person": [
707
],
"place": 607,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-09-27",
"date_sdn": 2444144,
"descr": "Death of Page, Andrew Vincent",
"gid": "E1056",
"media": [],
"part_family": [],
"part_person": [
707
],
"place": 239,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1979-09-29",
"date_sdn": 2444146,
"descr": "Burial of Page, Andrew Vincent",
"gid": "E1057",
"media": [],
"part_family": [],
"part_person": [
707
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1867",
"date_sdn": 2402968,
"descr": "Birth of Page, Anna",
"gid": "E0570",
"media": [],
"part_family": [],
"part_person": [
708
],
"place": 619,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1889-10-14",
"date_sdn": 2411290,
"descr": "Birth of Page, Clara Belle",
"gid": "E1534",
"media": [],
"part_family": [],
"part_person": [
709
],
"place": 607,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-12-20",
"date_sdn": 2440576,
"descr": "Death of Page, Clara Belle",
"gid": "E1535",
"media": [],
"part_family": [],
"part_person": [
709
],
"place": 715,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1969-12-23",
"date_sdn": 2440579,
"descr": "Burial of Page, Clara Belle",
"gid": "E1536",
"media": [],
"part_family": [],
"part_person": [
709
],
"place": 331,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1850-01-01",
"date_sdn": 2396759,
"descr": "Birth of Page, David",
"gid": "E1553",
"media": [],
"part_family": [],
"part_person": [
710
],
"place": 848,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1922-10-13",
"date_sdn": 2423341,
"descr": "Death of Page, David",
"gid": "E1554",
"media": [],
"part_family": [],
"part_person": [
710
],
"place": 642,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1922-10-15",
"date_sdn": 2423343,
"descr": "Burial of Page, David",
"gid": "E1555",
"media": [],
"part_family": [],
"part_person": [
710
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, David",
"gid": "E0750",
"media": [],
"part_family": [],
"part_person": [
711
],
"place": 796,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1909",
"date_sdn": 2418308,
"descr": "Death of Page, David",
"gid": "E0751",
"media": [],
"part_family": [],
"part_person": [
711
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1885-05-27",
"date_sdn": 2409689,
"descr": "Birth of Page, Edith Mae",
"gid": "E1079",
"media": [],
"part_family": [],
"part_person": [
712
],
"place": 607,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-05-00",
"date_sdn": 2438882,
"descr": "Death of Page, Edith Mae",
"gid": "E1080",
"media": [],
"part_family": [],
"part_person": [
712
],
"place": 149,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1965-05-00",
"date_sdn": 2438882,
"descr": "Burial of Page, Edith Mae",
"gid": "E1081",
"media": [],
"part_family": [],
"part_person": [
712
],
"place": 60,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1841",
"date_sdn": 2393472,
"descr": "Birth of Page, Elizabeth",
"gid": "E0489",
"media": [],
"part_family": [],
"part_person": [
713
],
"place": 848,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1915",
"date_sdn": 2420499,
"descr": "Death of Page, Elizabeth",
"gid": "E0490",
"media": [],
"part_family": [],
"part_person": [
713
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1914-09-28",
"date_sdn": 2420404,
"descr": "Birth of Page, George Kenneth (Red)",
"gid": "E0560",
"media": [],
"part_family": [],
"part_person": [
714
],
"place": 667,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1936-03-18",
"date_sdn": 2428246,
"descr": "Death of Page, George Kenneth (Red)",
"gid": "E0561",
"media": [],
"part_family": [],
"part_person": [
714
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1936-03-20",
"date_sdn": 2428248,
"descr": "Burial of Page, George Kenneth (Red)",
"gid": "E0562",
"media": [],
"part_family": [],
"part_person": [
714
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, John James",
"gid": "E0551",
"media": [],
"part_family": [],
"part_person": [
715
],
"place": 180,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-11-18",
"date_sdn": 2431047,
"descr": "Death of Page, John James",
"gid": "E0552",
"media": [],
"part_family": [],
"part_person": [
715
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1943-11-20",
"date_sdn": 2431049,
"descr": "Burial of Page, John James",
"gid": "E0553",
"media": [],
"part_family": [],
"part_person": [
715
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1851-02-10",
"date_sdn": 2397164,
"descr": "Birth of Page, Margaret",
"gid": "E0510",
"media": [],
"part_family": [],
"part_person": [
716
],
"place": 558,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-11-22",
"date_sdn": 2424477,
"descr": "Death of Page, Margaret",
"gid": "E0511",
"media": [],
"part_family": [],
"part_person": [
716
],
"place": 575,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1925-11-24",
"date_sdn": 2424479,
"descr": "Burial of Page, Margaret",
"gid": "E0512",
"media": [],
"part_family": [],
"part_person": [
716
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Birth of Page, Mary",
"gid": "E0588",
"media": [],
"part_family": [],
"part_person": [
717
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Death of Page, Mary",
"gid": "E0589",
"media": [],
"part_family": [],
"part_person": [
717
],
"place": 619,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Birth of Page, Rebecca",
"gid": "E0590",
"media": [],
"part_family": [],
"part_person": [
719
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Death of Page, Rebecca",
"gid": "E0591",
"media": [],
"part_family": [],
"part_person": [
719
],
"place": 619,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1974-11-00",
"date_sdn": 2442353,
"descr": "Death of Page, Richard C.",
"gid": "E0755",
"media": [],
"part_family": [],
"part_person": [
720
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1847-06-11",
"date_sdn": 2395824,
"descr": "Birth of Page, Robert",
"gid": "E0508",
"media": [],
"part_family": [],
"part_person": [
721
],
"place": 619,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-03-22",
"date_sdn": 2425328,
"descr": "Death of Page, Robert",
"gid": "E0509",
"media": [],
"part_family": [],
"part_person": [
721
],
"place": 575,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1819-10-09",
"date_sdn": 2385717,
"descr": "Death of Palmer, Sarah",
"gid": "E1835",
"media": [],
"part_family": [],
"part_person": [
726
],
"place": 745,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Parent, Capt.Jacob C.",
"gid": "E1743",
"media": [],
"part_family": [],
"part_person": [
728
],
"place": 488,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1811-11-09",
"date_sdn": 2382826,
"descr": "Death of Parent, Capt.Jacob C.",
"gid": "E1744",
"media": [],
"part_family": [],
"part_person": [
728
],
"place": 150,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1811-11-11",
"date_sdn": 2382828,
"descr": "Burial of Parent, Capt.Jacob C.",
"gid": "E1745",
"media": [],
"part_family": [],
"part_person": [
728
],
"place": 209,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1797",
"date_sdn": 2377402,
"descr": "Birth of Parent, Montgomery",
"gid": "E0658",
"media": [],
"part_family": [],
"part_person": [
733
],
"place": 703,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1871-04-28",
"date_sdn": 2404546,
"descr": "Death of Park, Susannah",
"gid": "E1725",
"media": [],
"part_family": [],
"part_person": [
737
],
"place": 554,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1788-01-03",
"date_sdn": 2374116,
"descr": "Birth of Payne, Fielding",
"gid": "E1009",
"media": [],
"part_family": [],
"part_person": [
743
],
"place": 194,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1747-08-22",
"date_sdn": 2359372,
"descr": "Birth of Payne, George",
"gid": "E2628",
"media": [],
"part_family": [],
"part_person": [
745
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-07-09",
"date_sdn": 2386356,
"descr": "Death of Payne, George",
"gid": "E2629",
"media": [],
"part_family": [],
"part_person": [
745
],
"place": 371,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1821-07-11",
"date_sdn": 2386358,
"descr": "Burial of Payne, George",
"gid": "E2630",
"media": [],
"part_family": [],
"part_person": [
745
],
"place": 371,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, James",
"gid": "E1013",
"media": [],
"part_family": [],
"part_person": [
746
],
"place": 762,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, Jane Coppage",
"gid": "E2196",
"media": [],
"part_family": [],
"part_person": [
747
],
"place": 430,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1873-06-07",
"date_sdn": 2405317,
"descr": "Death of Payne, Jane Coppage",
"gid": "E2197",
"media": [],
"part_family": [],
"part_person": [
747
],
"place": 584,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1873-06-07",
"date_sdn": 2405317,
"descr": "Burial of Payne, Jane Coppage",
"gid": "E2198",
"media": [],
"part_family": [],
"part_person": [
747
],
"place": 608,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1655",
"date_sdn": 2325537,
"descr": "Birth of Payne, Leonard",
"gid": "E2644",
"media": [],
"part_family": [],
"part_person": [
748
],
"place": 268,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1745-10-00",
"date_sdn": 2358682,
"descr": "Death of Payne, Leonard",
"gid": "E2645",
"media": [],
"part_family": [],
"part_person": [
748
],
"place": 220,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1745",
"date_sdn": 2358409,
"descr": "Burial of Payne, Leonard",
"gid": "E2646",
"media": [],
"part_family": [],
"part_person": [
748
],
"place": 220,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "before 1720",
"date_sdn": 2349277,
"descr": "Birth of Payne, Leonard?",
"gid": "E2649",
"media": [],
"part_family": [],
"part_person": [
749
],
"place": 220,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1757",
"date_sdn": 2362792,
"descr": "Death of Payne, Leonard?",
"gid": "E2650",
"media": [],
"part_family": [],
"part_person": [
749
],
"place": 220,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Payne, Leonard?",
"gid": "E2651",
"media": [],
"part_family": [],
"part_person": [
749
],
"place": 220,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, Winifred",
"gid": "E1010",
"media": [],
"part_family": [],
"part_person": [
754
],
"place": 194,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1981-06-02",
"date_sdn": 2444758,
"descr": "Death of Peters, Frank O.",
"gid": "E0575",
"media": [],
"part_family": [],
"part_person": [
758
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1583",
"date_sdn": 2299239,
"descr": "Birth of Peters, George Sr.",
"gid": "E2428",
"media": [],
"part_family": [],
"part_person": [
759
],
"place": 695,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1648",
"date_sdn": 2322980,
"descr": "Death of Peters, George Sr.",
"gid": "E2429",
"media": [],
"part_family": [],
"part_person": [
759
],
"place": 426,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Peters, George Sr.",
"gid": "E2430",
"media": [],
"part_family": [],
"part_person": [
759
],
"place": 462,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1608",
"date_sdn": 2308370,
"descr": "Birth of Peters, Rose",
"gid": "E2244",
"media": [],
"part_family": [],
"part_person": [
761
],
"place": 339,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1695",
"date_sdn": 2340147,
"descr": "Death of Peters, Rose",
"gid": "E2245",
"media": [],
"part_family": [],
"part_person": [
761
],
"place": 264,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Peters, Rose",
"gid": "E2246",
"media": [],
"part_family": [],
"part_person": [
761
],
"place": 222,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1613",
"date_sdn": 2310197,
"descr": "Birth of Piotrowski, John",
"gid": "E2190",
"media": [],
"part_family": [],
"part_person": [
762
],
"place": 190,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1670",
"date_sdn": 2331016,
"descr": "Death of Piotrowski, John",
"gid": "E2191",
"media": [],
"part_family": [],
"part_person": [
762
],
"place": 38,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1677",
"date_sdn": 2333573,
"descr": "Death of Piotrowski, John Jr.",
"gid": "E2222",
"media": [],
"part_family": [],
"part_person": [
763
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1957-04-24",
"date_sdn": 2435953,
"descr": "Death of Pope, John",
"gid": "E1944",
"media": [],
"part_family": [],
"part_person": [
766
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Powell, Martha",
"gid": "E0276",
"media": [],
"part_family": [],
"part_person": [
769
],
"place": 170,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1611-01-11",
"date_sdn": 2309476,
"descr": "Burial of Powell, Martha",
"gid": "E0277",
"media": [],
"part_family": [],
"part_person": [
769
],
"place": 524,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1838-04-25",
"date_sdn": 2392490,
"descr": "Birth of Quinn, Abraham",
"gid": "E0783",
"media": [],
"part_family": [],
"part_person": [
772
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-18",
"date_sdn": 2420912,
"descr": "Death of Quinn, Abraham",
"gid": "E0784",
"media": [],
"part_family": [],
"part_person": [
772
],
"place": 675,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1838-04-25",
"date_sdn": 2392490,
"descr": "Birth of Quinn, Abram",
"gid": "E2482",
"media": [],
"part_family": [],
"part_person": [
773
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-18",
"date_sdn": 2420912,
"descr": "Death of Quinn, Abram",
"gid": "E2483",
"media": [],
"part_family": [],
"part_person": [
773
],
"place": 205,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1916-02-00",
"date_sdn": 2420895,
"descr": "Burial of Quinn, Abram",
"gid": "E2484",
"media": [],
"part_family": [],
"part_person": [
773
],
"place": 43,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1526",
"date_sdn": 2278420,
"descr": "Birth of Ramos, John",
"gid": "E0248",
"media": [],
"part_family": [],
"part_person": [
775
],
"place": 499,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1556",
"date_sdn": 2289377,
"descr": "Birth of Ramos, Mary",
"gid": "E2249",
"media": [],
"part_family": [],
"part_person": [
776
],
"place": 442,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1588-01-07",
"date_sdn": 2301071,
"descr": "Death of Ramos, Mary",
"gid": "E2250",
"media": [],
"part_family": [],
"part_person": [
776
],
"place": 110,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ramos, Mary",
"gid": "E2251",
"media": [],
"part_family": [],
"part_person": [
776
],
"place": 845,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1850-01-19",
"date_sdn": 2396777,
"descr": "Birth of Reed, Bridgette",
"gid": "E2170",
"media": [],
"part_family": [],
"part_person": [
778
],
"place": 314,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1901-08-13",
"date_sdn": 2415610,
"descr": "Death of Reed, Bridgette",
"gid": "E2171",
"media": [],
"part_family": [],
"part_person": [
778
],
"place": 17,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1847-06-28",
"date_sdn": 2395841,
"descr": "Birth of Reed, Edward",
"gid": "E0226",
"media": [],
"part_family": [],
"part_person": [
780
],
"place": 234,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1892-03-05",
"date_sdn": 2412163,
"descr": "Death of Reed, Edward",
"gid": "E0227",
"media": [],
"part_family": [],
"part_person": [
780
],
"place": 640,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Ellen",
"gid": "E0228",
"media": [],
"part_family": [],
"part_person": [
781
],
"place": 374,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1857-05-02",
"date_sdn": 2399437,
"descr": "Birth of Reed, Francis Vincent",
"gid": "E1729",
"media": [],
"part_family": [],
"part_person": [
782
],
"place": 552,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1945-03-02",
"date_sdn": 2431517,
"descr": "Death of Reed, Francis Vincent",
"gid": "E1730",
"media": [],
"part_family": [],
"part_person": [
782
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1945-03-04",
"date_sdn": 2431519,
"descr": "Burial of Reed, Francis Vincent",
"gid": "E1731",
"media": [],
"part_family": [],
"part_person": [
782
],
"place": 608,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1853-06-13",
"date_sdn": 2398018,
"descr": "Birth of Reed, Hugh",
"gid": "E2166",
"media": [],
"part_family": [],
"part_person": [
783
],
"place": 552,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1917-04-24",
"date_sdn": 2421343,
"descr": "Death of Reed, Hugh",
"gid": "E2167",
"media": [],
"part_family": [],
"part_person": [
783
],
"place": 608,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "about 1898",
"date_sdn": 2414291,
"descr": "Birth of Reed, Jane",
"gid": "E0970",
"media": [],
"part_family": [],
"part_person": [
785
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1976-02-25",
"date_sdn": 2442834,
"descr": "Death of Reed, Jane",
"gid": "E0971",
"media": [],
"part_family": [],
"part_person": [
785
],
"place": 656,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, John",
"gid": "E2510",
"media": [],
"part_family": [],
"part_person": [
786
],
"place": 729,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1886-08-11",
"date_sdn": 2410130,
"descr": "Death of Reed, John",
"gid": "E2511",
"media": [],
"part_family": [],
"part_person": [
786
],
"place": 729,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1886-08-00",
"date_sdn": 2410120,
"descr": "Burial of Reed, John",
"gid": "E2512",
"media": [],
"part_family": [],
"part_person": [
786
],
"place": 729,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1844-05-19",
"date_sdn": 2394706,
"descr": "Birth of Reed, John",
"gid": "E2168",
"media": [],
"part_family": [],
"part_person": [
787
],
"place": 202,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-03-28",
"date_sdn": 2424603,
"descr": "Death of Reed, John",
"gid": "E2169",
"media": [],
"part_family": [],
"part_person": [
787
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1847",
"date_sdn": 2395663,
"descr": "Birth of Reed, Matthew",
"gid": "E0935",
"media": [],
"part_family": [],
"part_person": [
788
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-10-21",
"date_sdn": 2425175,
"descr": "Death of Reed, Matthew",
"gid": "E0936",
"media": [],
"part_family": [],
"part_person": [
788
],
"place": 877,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1925-03-19",
"date_sdn": 2424229,
"descr": "Death of Reed, Michael",
"gid": "E0938",
"media": [],
"part_family": [],
"part_person": [
789
],
"place": 877,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Michael",
"gid": "E0993",
"media": [],
"part_family": [],
"part_person": [
790
],
"place": 441,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Owen",
"gid": "E0980",
"media": [],
"part_family": [],
"part_person": [
791
],
"place": 390,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1967-07-07",
"date_sdn": 2439679,
"descr": "Death of Reed, Patrick",
"gid": "E0963",
"media": [],
"part_family": [],
"part_person": [
792
],
"place": 749,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1967-07-09",
"date_sdn": 2439681,
"descr": "Burial of Reed, Patrick",
"gid": "E0964",
"media": [],
"part_family": [],
"part_person": [
792
],
"place": 454,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Peter",
"gid": "E0988",
"media": [],
"part_family": [],
"part_person": [
793
],
"place": 167,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1904",
"date_sdn": 2416481,
"descr": "Birth of Reed, Peter",
"gid": "E0939",
"media": [],
"part_family": [],
"part_person": [
794
],
"place": 877,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1981-04-12",
"date_sdn": 2444707,
"descr": "Death of Reed, Peter",
"gid": "E0940",
"media": [],
"part_family": [],
"part_person": [
794
],
"place": 255,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Peter James?",
"gid": "E0979",
"media": [],
"part_family": [],
"part_person": [
795
],
"place": 328,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1906-04-00",
"date_sdn": 2417302,
"descr": "Birth of Reed, Sarah",
"gid": "E0933",
"media": [],
"part_family": [],
"part_person": [
796
],
"place": 877,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-05-12",
"date_sdn": 2445833,
"descr": "Death of Reed, Sarah",
"gid": "E0934",
"media": [],
"part_family": [],
"part_person": [
796
],
"place": 877,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1750",
"date_sdn": 2360235,
"descr": "Death of Reese",
"gid": "E1698",
"media": [],
"part_family": [],
"part_person": [
797
],
"place": 544,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reese",
"gid": "E1699",
"media": [],
"part_family": [],
"part_person": [
797
],
"place": 544,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "after 1901",
"date_sdn": 2415386,
"descr": "Death of Reeves, Ann",
"gid": "E1052",
"media": [],
"part_family": [],
"part_person": [
798
],
"place": 553,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "before 1901",
"date_sdn": 2415386,
"descr": "Death of Reeves, Catherine",
"gid": "E1054",
"media": [],
"part_family": [],
"part_person": [
800
],
"place": 553,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1883-03-21",
"date_sdn": 2408891,
"descr": "Birth of Reeves, Honora",
"gid": "E1580",
"media": [],
"part_family": [],
"part_person": [
802
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1908-11-08",
"date_sdn": 2418254,
"descr": "Death of Reeves, Honora",
"gid": "E1581",
"media": [],
"part_family": [],
"part_person": [
802
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1819-03-24",
"date_sdn": 2385518,
"descr": "Birth of Reeves, James",
"gid": "E0019",
"media": [],
"part_family": [],
"part_person": [
803
],
"place": 334,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1897-07-11",
"date_sdn": 2414117,
"descr": "Death of Reeves, James",
"gid": "E0020",
"media": [],
"part_family": [],
"part_person": [
803
],
"place": 109,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1897-07-13",
"date_sdn": 2414119,
"descr": "Burial of Reeves, James",
"gid": "E0021",
"media": [],
"part_family": [],
"part_person": [
803
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1892-05-25",
"date_sdn": 2412244,
"descr": "Birth of Reeves, Margaret",
"gid": "E1578",
"media": [],
"part_family": [],
"part_person": [
806
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-03-30",
"date_sdn": 2428988,
"descr": "Death of Reeves, Margaret",
"gid": "E1579",
"media": [],
"part_family": [],
"part_person": [
806
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1856-11-26",
"date_sdn": 2399280,
"descr": "Birth of Reeves, Maria",
"gid": "E1832",
"media": [],
"part_family": [],
"part_person": [
807
],
"place": 74,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1929-01-29",
"date_sdn": 2425641,
"descr": "Death of Reeves, Maria",
"gid": "E1833",
"media": [],
"part_family": [],
"part_person": [
807
],
"place": 878,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1929-01-31",
"date_sdn": 2425643,
"descr": "Burial of Reeves, Maria",
"gid": "E1834",
"media": [],
"part_family": [],
"part_person": [
807
],
"place": 878,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1880-11-28",
"date_sdn": 2408048,
"descr": "Birth of Reeves, Mary",
"gid": "E1571",
"media": [],
"part_family": [],
"part_person": [
808
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-03-12",
"date_sdn": 2433353,
"descr": "Death of Reeves, Mary",
"gid": "E1572",
"media": [],
"part_family": [],
"part_person": [
808
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1051",
"media": [],
"part_family": [],
"part_person": [
811
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1694-02-04",
"date_sdn": 2339816,
"descr": "Birth of Reid, Anna Catherina",
"gid": "E2611",
"media": [],
"part_family": [],
"part_person": [
812
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1740-11-20",
"date_sdn": 2356906,
"descr": "Death of Reid, Anna Catherina",
"gid": "E2612",
"media": [],
"part_family": [],
"part_person": [
812
],
"place": 389,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reid, Anna Catherina",
"gid": "E2613",
"media": [],
"part_family": [],
"part_person": [
812
],
"place": 452,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1644",
"date_sdn": 2321519,
"descr": "Birth of Reid, Hans",
"gid": "E2595",
"media": [],
"part_family": [],
"part_person": [
813
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1707-12-06",
"date_sdn": 2344868,
"descr": "Death of Reid, Hans",
"gid": "E2596",
"media": [],
"part_family": [],
"part_person": [
813
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1622",
"date_sdn": 2313484,
"descr": "Birth of Reynolds, Col. John",
"gid": "E2655",
"media": [],
"part_family": [],
"part_person": [
814
],
"place": 433,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1670",
"date_sdn": 2331016,
"descr": "Death of Reynolds, Col. John",
"gid": "E2656",
"media": [],
"part_family": [],
"part_person": [
814
],
"place": 430,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, Col. John",
"gid": "E2657",
"media": [],
"part_family": [],
"part_person": [
814
],
"place": 430,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1669",
"date_sdn": 2330651,
"descr": "Birth of Reynolds, David",
"gid": "E2652",
"media": [],
"part_family": [],
"part_person": [
815
],
"place": 743,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1695",
"date_sdn": 2340147,
"descr": "Death of Reynolds, David",
"gid": "E2653",
"media": [],
"part_family": [],
"part_person": [
815
],
"place": 733,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, David",
"gid": "E2654",
"media": [],
"part_family": [],
"part_person": [
815
],
"place": 633,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Death of Reynolds, John",
"gid": "E2664",
"media": [],
"part_family": [],
"part_person": [
816
],
"place": 229,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, John",
"gid": "E2665",
"media": [],
"part_family": [],
"part_person": [
816
],
"place": 430,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1566",
"date_sdn": 2293030,
"descr": "Birth of Reynolds, John",
"gid": "E0278",
"media": [],
"part_family": [],
"part_person": [
817
],
"place": 433,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1643",
"date_sdn": 2321154,
"descr": "Birth of Reynolds, Nicholas",
"gid": "E2658",
"media": [],
"part_family": [],
"part_person": [
818
],
"place": 139,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1695",
"date_sdn": 2340147,
"descr": "Death of Reynolds, Nicholas",
"gid": "E2659",
"media": [],
"part_family": [],
"part_person": [
818
],
"place": 733,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, Nicholas",
"gid": "E2660",
"media": [],
"part_family": [],
"part_person": [
818
],
"place": 771,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1695",
"date_sdn": 2340147,
"descr": "Birth of Reynolds, William",
"gid": "E2661",
"media": [],
"part_family": [],
"part_person": [
820
],
"place": 549,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1788",
"date_sdn": 2374114,
"descr": "Death of Reynolds, William",
"gid": "E2662",
"media": [],
"part_family": [],
"part_person": [
820
],
"place": 475,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, William",
"gid": "E2663",
"media": [],
"part_family": [],
"part_person": [
820
],
"place": 475,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1723",
"date_sdn": 2350373,
"descr": "Birth of Rice, Virginia Margaret",
"gid": "E1901",
"media": [],
"part_family": [],
"part_person": [
821
],
"place": 34,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Death of Rice, Virginia Margaret",
"gid": "E1902",
"media": [],
"part_family": [],
"part_person": [
821
],
"place": 418,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Rice, Virginia Margaret",
"gid": "E1903",
"media": [],
"part_family": [],
"part_person": [
821
],
"place": 418,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1703",
"date_sdn": 2343068,
"descr": "Birth of Richard, Jeanne",
"gid": "E2207",
"media": [],
"part_family": [],
"part_person": [
822
],
"place": 58,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1792",
"date_sdn": 2375575,
"descr": "Death of Richard, Jeanne",
"gid": "E2208",
"media": [],
"part_family": [],
"part_person": [
822
],
"place": 439,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Richard, Jeanne",
"gid": "E2209",
"media": [],
"part_family": [],
"part_person": [
822
],
"place": 15,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1018",
"date_sdn": 2092877,
"descr": "Birth of Rios, Agnes",
"gid": "E0018",
"media": [],
"part_family": [],
"part_person": [
823
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1703-10-24",
"date_sdn": 2343364,
"descr": "Death of Robertson, Elizabeth",
"gid": "E2424",
"media": [],
"part_family": [],
"part_person": [
824
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1080",
"date_sdn": 2115522,
"descr": "Birth of Rodr\u00edguez, Agatha",
"gid": "E0026",
"media": [],
"part_family": [],
"part_person": [
825
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1142",
"date_sdn": 2138167,
"descr": "Death of Rodr\u00edguez, Agatha",
"gid": "E0027",
"media": [],
"part_family": [],
"part_person": [
825
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Alvin",
"gid": "E0831",
"media": [],
"part_family": [],
"part_person": [
828
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1820-02-28",
"date_sdn": 2385859,
"descr": "Birth of Rodriquez, Barbara Ann",
"gid": "E0834",
"media": [],
"part_family": [],
"part_person": [
829
],
"place": 497,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-07-20",
"date_sdn": 2415951,
"descr": "Death of Rodriquez, Barbara Ann",
"gid": "E0835",
"media": [],
"part_family": [],
"part_person": [
829
],
"place": 387,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Charles",
"gid": "E0849",
"media": [],
"part_family": [],
"part_person": [
830
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Elizabeth",
"gid": "E0856",
"media": [],
"part_family": [],
"part_person": [
831
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1816-04-01",
"date_sdn": 2384431,
"descr": "Birth of Rodriquez, Elizabeth Jane",
"gid": "E0832",
"media": [],
"part_family": [],
"part_person": [
832
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1776-07-22",
"date_sdn": 2369934,
"descr": "Birth of Rodriquez, James",
"gid": "E0850",
"media": [],
"part_family": [],
"part_person": [
833
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1807-01-22",
"date_sdn": 2381074,
"descr": "Birth of Rodriquez, John",
"gid": "E0830",
"media": [],
"part_family": [],
"part_person": [
834
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1849-12-25",
"date_sdn": 2396752,
"descr": "Death of Rodriquez, John",
"gid": "E0826",
"media": [],
"part_family": [],
"part_person": [
835
],
"place": 356,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1781-03-05",
"date_sdn": 2371621,
"descr": "Birth of Rodriquez, Margaret",
"gid": "E0854",
"media": [],
"part_family": [],
"part_person": [
836
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1825-09-24",
"date_sdn": 2387894,
"descr": "Birth of Rodriquez, Maria Louisa",
"gid": "E0840",
"media": [],
"part_family": [],
"part_person": [
837
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1814-05-14",
"date_sdn": 2383743,
"descr": "Birth of Rodriquez, Mariam",
"gid": "E1975",
"media": [],
"part_family": [],
"part_person": [
838
],
"place": 709,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1900-08-31",
"date_sdn": 2415263,
"descr": "Death of Rodriquez, Mariam",
"gid": "E1976",
"media": [],
"part_family": [],
"part_person": [
838
],
"place": 75,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1900-09-02",
"date_sdn": 2415265,
"descr": "Burial of Rodriquez, Mariam",
"gid": "E1977",
"media": [],
"part_family": [],
"part_person": [
838
],
"place": 299,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1770-03-03",
"date_sdn": 2367601,
"descr": "Birth of Rodriquez, Mary",
"gid": "E0843",
"media": [],
"part_family": [],
"part_person": [
839
],
"place": 447,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1823-06-17",
"date_sdn": 2387064,
"descr": "Birth of Rodriquez, Mary Ann",
"gid": "E0837",
"media": [],
"part_family": [],
"part_person": [
840
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1828-08-27",
"date_sdn": 2388962,
"descr": "Birth of Rodriquez, Michael Mordica",
"gid": "E0841",
"media": [],
"part_family": [],
"part_person": [
841
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1772-01-06",
"date_sdn": 2368275,
"descr": "Birth of Rodriquez, Mordica",
"gid": "E0844",
"media": [],
"part_family": [],
"part_person": [
842
],
"place": 412,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853-07-00",
"date_sdn": 2398036,
"descr": "Death of Rodriquez, Mordica",
"gid": "E0845",
"media": [],
"part_family": [],
"part_person": [
842
],
"place": 47,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1821-11-28",
"date_sdn": 2386498,
"descr": "Birth of Rodriquez, Oma",
"gid": "E0836",
"media": [],
"part_family": [],
"part_person": [
843
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Peter",
"gid": "E0842",
"media": [],
"part_family": [],
"part_person": [
844
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1778-07-31",
"date_sdn": 2370673,
"descr": "Birth of Rodriquez, Richard",
"gid": "E0853",
"media": [],
"part_family": [],
"part_person": [
845
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Thomas",
"gid": "E0855",
"media": [],
"part_family": [],
"part_person": [
846
],
"place": 412,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1806-12-17",
"date_sdn": 2381038,
"descr": "Birth of Rodriquez, William Frederick",
"gid": "E0829",
"media": [],
"part_family": [],
"part_person": [
847
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1818-05-07",
"date_sdn": 2385197,
"descr": "Birth of Rodriquez, William M.",
"gid": "E0833",
"media": [],
"part_family": [],
"part_person": [
848
],
"place": 497,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1759-02-17",
"date_sdn": 2363569,
"descr": "Birth of Rogers, Barbara",
"gid": "E0665",
"media": [],
"part_family": [],
"part_person": [
849
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1785",
"date_sdn": 2373019,
"descr": "Death of Rogers, Barbara",
"gid": "E0666",
"media": [],
"part_family": [],
"part_person": [
849
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Rose, Ann",
"gid": "E2737",
"media": [],
"part_family": [],
"part_person": [
851
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Birth of Rubio, Winifred",
"gid": "E2635",
"media": [],
"part_family": [],
"part_person": [
854
],
"place": 637,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1751-10-06",
"date_sdn": 2360878,
"descr": "Death of Rubio, Winifred",
"gid": "E2636",
"media": [],
"part_family": [],
"part_person": [
854
],
"place": 430,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1751",
"date_sdn": 2360600,
"descr": "Burial of Rubio, Winifred",
"gid": "E2637",
"media": [],
"part_family": [],
"part_person": [
854
],
"place": 490,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1786-04-20",
"date_sdn": 2373493,
"descr": "Birth of Ruiz, Catherine",
"gid": "E1719",
"media": [],
"part_family": [],
"part_person": [
855
],
"place": 430,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-09-25",
"date_sdn": 2406888,
"descr": "Death of Ruiz, Catherine",
"gid": "E1720",
"media": [],
"part_family": [],
"part_person": [
855
],
"place": 186,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ruiz, Catherine",
"gid": "E1721",
"media": [],
"part_family": [],
"part_person": [
855
],
"place": 437,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1556",
"date_sdn": 2289377,
"descr": "Birth of Ryan, Elizabeth",
"gid": "E1058",
"media": [],
"part_family": [],
"part_person": [
856
],
"place": 869,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1628",
"date_sdn": 2315675,
"descr": "Death of Ryan, Elizabeth",
"gid": "E1059",
"media": [],
"part_family": [],
"part_person": [
856
],
"place": 869,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1508",
"date_sdn": 2271845,
"descr": "Birth of Ryan, Elizabeth",
"gid": "E0067",
"media": [],
"part_family": [],
"part_person": [
857
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1480",
"date_sdn": 2261619,
"descr": "Birth of Sanchez, John",
"gid": "E2139",
"media": [],
"part_family": [],
"part_person": [
859
],
"place": 632,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1545",
"date_sdn": 2285360,
"descr": "Death of Sanchez, John",
"gid": "E2140",
"media": [],
"part_family": [],
"part_person": [
859
],
"place": 632,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Sanders, Henry",
"gid": "E0006",
"media": [],
"part_family": [],
"part_person": [
860
],
"place": 673,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1658-06-17",
"date_sdn": 2326800,
"descr": "Death of Sanders, Henry",
"gid": "E0007",
"media": [],
"part_family": [],
"part_person": [
860
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1629",
"date_sdn": 2316041,
"descr": "Birth of Sanders, Mary",
"gid": "E2121",
"media": [],
"part_family": [],
"part_person": [
861
],
"place": 115,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Santos, Alice",
"gid": "E0247",
"media": [],
"part_family": [],
"part_person": [
863
],
"place": 201,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1680",
"date_sdn": 2334668,
"descr": "Birth of Saunders, Ursula",
"gid": "E2258",
"media": [],
"part_family": [],
"part_person": [
864
],
"place": 305,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1740",
"date_sdn": 2356582,
"descr": "Death of Saunders, Ursula",
"gid": "E2259",
"media": [],
"part_family": [],
"part_person": [
864
],
"place": 100,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Birth of Savard, Honora",
"gid": "E2404",
"media": [],
"part_family": [],
"part_person": [
865
],
"place": 203,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-04-01",
"date_sdn": 2415841,
"descr": "Death of Savard, Honora",
"gid": "E2405",
"media": [],
"part_family": [],
"part_person": [
865
],
"place": 769,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Savard, Honora",
"gid": "E2406",
"media": [],
"part_family": [],
"part_person": [
865
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1655",
"date_sdn": 2325537,
"descr": "Birth of Schmidt, Barbli",
"gid": "E2581",
"media": [],
"part_family": [],
"part_person": [
866
],
"place": 140,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1885-02-14",
"date_sdn": 2409587,
"descr": "Birth of Schneider, Belle Irene",
"gid": "E0609",
"media": [],
"part_family": [],
"part_person": [
868
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1960-10-11",
"date_sdn": 2437219,
"descr": "Death of Schneider, Belle Irene",
"gid": "E0610",
"media": [],
"part_family": [],
"part_person": [
868
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Schultz, John",
"gid": "E0003",
"media": [],
"part_family": [],
"part_person": [
869
],
"place": 459,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1860",
"date_sdn": 2400411,
"descr": "Death of Schultz, John",
"gid": "E0004",
"media": [],
"part_family": [],
"part_person": [
869
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Schultz, John",
"gid": "E0005",
"media": [],
"part_family": [],
"part_person": [
869
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Schultz, Rev.Isaac",
"gid": "E2616",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 630,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Death of Schultz, Rev.Isaac",
"gid": "E2617",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 722,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Burial of Schultz, Rev.Isaac",
"gid": "E2618",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 661,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1110",
"date_sdn": 2126479,
"descr": "Birth of Schwartz, Helewisa",
"gid": "E0032",
"media": [],
"part_family": [],
"part_person": [
871
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1195",
"date_sdn": 2157525,
"descr": "Death of Schwartz, Helewisa",
"gid": "E0033",
"media": [],
"part_family": [],
"part_person": [
871
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1804-12-15",
"date_sdn": 2380306,
"descr": "Birth of Serrano, Archibald",
"gid": "E0774",
"media": [],
"part_family": [],
"part_person": [
872
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-11-17",
"date_sdn": 2394157,
"descr": "Death of Serrano, Archibald",
"gid": "E0775",
"media": [],
"part_family": [],
"part_person": [
872
],
"place": 675,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1842-11-19",
"date_sdn": 2394159,
"descr": "Burial of Serrano, Archibald",
"gid": "E0776",
"media": [],
"part_family": [],
"part_person": [
872
],
"place": 295,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1834-04-03",
"date_sdn": 2391007,
"descr": "Birth of Serrano, Joseph",
"gid": "E0777",
"media": [],
"part_family": [],
"part_person": [
873
],
"place": 86,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1899-11-02",
"date_sdn": 2414961,
"descr": "Death of Serrano, Joseph",
"gid": "E0778",
"media": [],
"part_family": [],
"part_person": [
873
],
"place": 675,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1899-11-04",
"date_sdn": 2414963,
"descr": "Burial of Serrano, Joseph",
"gid": "E0779",
"media": [],
"part_family": [],
"part_person": [
873
],
"place": 567,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Serrano, Joseph",
"gid": "E0780",
"media": [],
"part_family": [],
"part_person": [
874
],
"place": 675,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Sharp, ???",
"gid": "E2219",
"media": [],
"part_family": [],
"part_person": [
875
],
"place": 847,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "9",
"date_sdn": 1724348,
"descr": "Death of Sharp, ???",
"gid": "E2220",
"media": [],
"part_family": [],
"part_person": [
875
],
"place": 388,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Sharp, ???",
"gid": "E2221",
"media": [],
"part_family": [],
"part_person": [
875
],
"place": 864,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1805-10-06",
"date_sdn": 2380601,
"descr": "Birth of Silva, Mildred",
"gid": "E2088",
"media": [],
"part_family": [],
"part_person": [
877
],
"place": 191,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-05-10",
"date_sdn": 2403828,
"descr": "Death of Silva, Mildred",
"gid": "E2089",
"media": [],
"part_family": [],
"part_person": [
877
],
"place": 313,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-05-12",
"date_sdn": 2403830,
"descr": "Burial of Silva, Mildred",
"gid": "E2090",
"media": [],
"part_family": [],
"part_person": [
877
],
"place": 313,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Simard, Sarah",
"gid": "E2269",
"media": [],
"part_family": [],
"part_person": [
878
],
"place": 369,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Simard, Thomas",
"gid": "E2270",
"media": [],
"part_family": [],
"part_person": [
879
],
"place": 774,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1626",
"date_sdn": 2314945,
"descr": "Birth of Simmons, Maria",
"gid": "E0297",
"media": [],
"part_family": [],
"part_person": [
880
],
"place": 9,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1840-02-20",
"date_sdn": 2393156,
"descr": "Death of Snyder, Ann Louisa",
"gid": "E1092",
"media": [],
"part_family": [],
"part_person": [
881
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "about 1585",
"date_sdn": 2299970,
"descr": "Birth of Spencer, Ann",
"gid": "E0008",
"media": [],
"part_family": [],
"part_person": [
883
],
"place": 820,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1662-12-20",
"date_sdn": 2328447,
"descr": "Death of Spencer, Ann",
"gid": "E0009",
"media": [],
"part_family": [],
"part_person": [
883
],
"place": 650,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Stevens, Elizabeth",
"gid": "E0279",
"media": [],
"part_family": [],
"part_person": [
886
],
"place": 872,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1656-05-21",
"date_sdn": 2326043,
"descr": "Birth of Su\u00e1rez, Marie",
"gid": "E2602",
"media": [],
"part_family": [],
"part_person": [
888
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1731-01-05",
"date_sdn": 2353299,
"descr": "Death of Su\u00e1rez, Marie",
"gid": "E2603",
"media": [],
"part_family": [],
"part_person": [
888
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1691",
"date_sdn": 2338686,
"descr": "Birth of Sullivan, Anna",
"gid": "E2584",
"media": [],
"part_family": [],
"part_person": [
889
],
"place": 666,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1718",
"date_sdn": 2348547,
"descr": "Birth of Sutton, Anna Maria",
"gid": "E0420",
"media": [],
"part_family": [],
"part_person": [
890
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1620",
"date_sdn": 2312753,
"descr": "Birth of Swanson, William",
"gid": "E0300",
"media": [],
"part_family": [],
"part_person": [
896
],
"place": 320,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1684-10-15",
"date_sdn": 2336417,
"descr": "Death of Swanson, William",
"gid": "E0301",
"media": [],
"part_family": [],
"part_person": [
896
],
"place": 532,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Birth of Taylor, Jacob",
"gid": "E0374",
"media": [],
"part_family": [],
"part_person": [
898
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1580",
"date_sdn": 2298143,
"descr": "Birth of Thomas, Elder Thomas",
"gid": "E1840",
"media": [],
"part_family": [],
"part_person": [
901
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1632",
"date_sdn": 2317136,
"descr": "Death of Thomas, Elder Thomas",
"gid": "E1841",
"media": [],
"part_family": [],
"part_person": [
901
],
"place": 354,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1620",
"date_sdn": 2312753,
"descr": "Birth of Thomas, Elizabeth",
"gid": "E1847",
"media": [],
"part_family": [],
"part_person": [
902
],
"place": 37,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1713",
"date_sdn": 2346721,
"descr": "Death of Thomas, Elizabeth",
"gid": "E1848",
"media": [],
"part_family": [],
"part_person": [
902
],
"place": 868,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Thornton, Arthur Otto",
"gid": "E1170",
"media": [],
"part_family": [],
"part_person": [
904
],
"place": 263,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1911-07-12",
"date_sdn": 2419230,
"descr": "Birth of Thornton, James Arthur",
"gid": "E1179",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-12-02",
"date_sdn": 2445671,
"descr": "Death of Thornton, James Arthur",
"gid": "E1180",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Thornton, James Arthur",
"gid": "E1181",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": 748,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1891-09-22",
"date_sdn": 2411998,
"descr": "Birth of Todd, Benjamin Harrison",
"gid": "E1511",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1968-02-13",
"date_sdn": 2439900,
"descr": "Death of Todd, Benjamin Harrison",
"gid": "E1512",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": 561,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Benjamin Harrison",
"gid": "E1513",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": 732,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1727-08-15",
"date_sdn": 2352060,
"descr": "Birth of Todd, Charles",
"gid": "E2271",
"media": [],
"part_family": [],
"part_person": [
907
],
"place": 562,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805-07-06",
"date_sdn": 2380509,
"descr": "Death of Todd, Charles",
"gid": "E2272",
"media": [],
"part_family": [],
"part_person": [
907
],
"place": 855,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1873-07-13",
"date_sdn": 2405353,
"descr": "Birth of Todd, Flora Belle",
"gid": "E1493",
"media": [],
"part_family": [],
"part_person": [
908
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-02-18",
"date_sdn": 2433331,
"descr": "Death of Todd, Flora Belle",
"gid": "E1494",
"media": [],
"part_family": [],
"part_person": [
908
],
"place": 277,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Flora Belle",
"gid": "E1495",
"media": [],
"part_family": [],
"part_person": [
908
],
"place": 135,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1820-01-02",
"date_sdn": 2385802,
"descr": "Birth of Todd, George W.",
"gid": "E2381",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 834,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-16",
"date_sdn": 2413241,
"descr": "Death of Todd, George W.",
"gid": "E2382",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 258,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, George W.",
"gid": "E2383",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1879-03-03",
"date_sdn": 2407412,
"descr": "Birth of Todd, George Walter",
"gid": "E1498",
"media": [],
"part_family": [],
"part_person": [
910
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-06-28",
"date_sdn": 2422138,
"descr": "Death of Todd, George Walter",
"gid": "E1499",
"media": [],
"part_family": [],
"part_person": [
910
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1678",
"date_sdn": 2333938,
"descr": "Birth of Todd, Hardy",
"gid": "E2233",
"media": [],
"part_family": [],
"part_person": [
911
],
"place": 38,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Death of Todd, Hardy",
"gid": "E2234",
"media": [],
"part_family": [],
"part_person": [
911
],
"place": 38,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1699",
"date_sdn": 2341608,
"descr": "Death of Todd, Hodges",
"gid": "E2203",
"media": [],
"part_family": [],
"part_person": [
912
],
"place": 38,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1881-09-10",
"date_sdn": 2408334,
"descr": "Birth of Todd, Jesse Elmer",
"gid": "E1500",
"media": [],
"part_family": [],
"part_person": [
913
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-12-12",
"date_sdn": 2436185,
"descr": "Death of Todd, Jesse Elmer",
"gid": "E1501",
"media": [],
"part_family": [],
"part_person": [
913
],
"place": 732,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1851-06-07",
"date_sdn": 2397281,
"descr": "Birth of Todd, John M.",
"gid": "E2425",
"media": [],
"part_family": [],
"part_person": [
915
],
"place": 258,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-02-23",
"date_sdn": 2422744,
"descr": "Death of Todd, John M.",
"gid": "E2426",
"media": [],
"part_family": [],
"part_person": [
915
],
"place": 523,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-02-25",
"date_sdn": 2422746,
"descr": "Burial of Todd, John M.",
"gid": "E2427",
"media": [],
"part_family": [],
"part_person": [
915
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1877-03-26",
"date_sdn": 2406705,
"descr": "Birth of Todd, Louella Jane",
"gid": "E1633",
"media": [],
"part_family": [],
"part_person": [
916
],
"place": 288,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-01-26",
"date_sdn": 2438787,
"descr": "Death of Todd, Louella Jane",
"gid": "E1634",
"media": [],
"part_family": [],
"part_person": [
916
],
"place": 693,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1965-01-00",
"date_sdn": 2438762,
"descr": "Burial of Todd, Louella Jane",
"gid": "E1635",
"media": [],
"part_family": [],
"part_person": [
916
],
"place": 83,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1894-09-09",
"date_sdn": 2413081,
"descr": "Birth of Todd, Percy Haye",
"gid": "E1514",
"media": [],
"part_family": [],
"part_person": [
918
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-05-29",
"date_sdn": 2433431,
"descr": "Death of Todd, Percy Haye",
"gid": "E1515",
"media": [],
"part_family": [],
"part_person": [
918
],
"place": 732,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Percy Haye",
"gid": "E1516",
"media": [],
"part_family": [],
"part_person": [
918
],
"place": 732,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1874-11-19",
"date_sdn": 2405847,
"descr": "Birth of Todd, Robert Arthur",
"gid": "E1496",
"media": [],
"part_family": [],
"part_person": [
919
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1940-12-20",
"date_sdn": 2429984,
"descr": "Death of Todd, Robert Arthur",
"gid": "E1497",
"media": [],
"part_family": [],
"part_person": [
919
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1790-10-01",
"date_sdn": 2375118,
"descr": "Birth of Todd, William",
"gid": "E2343",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": 373,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-07-08",
"date_sdn": 2395486,
"descr": "Death of Todd, William",
"gid": "E2344",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": 91,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, William",
"gid": "E2345",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Wallace, Abraham",
"gid": "E2149",
"media": [],
"part_family": [],
"part_person": [
925
],
"place": 142,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1864",
"date_sdn": 2401872,
"descr": "Birth of Walters, Mary",
"gid": "E2473",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 203,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1937-04-06",
"date_sdn": 2428630,
"descr": "Death of Walters, Mary",
"gid": "E2474",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 28,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1937-04-08",
"date_sdn": 2428632,
"descr": "Burial of Walters, Mary",
"gid": "E2475",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1250",
"date_sdn": 2177614,
"descr": "Birth of Walton, Theophania(Tiffany)",
"gid": "E0045",
"media": [],
"part_family": [],
"part_person": [
928
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1740-08-15",
"date_sdn": 2356809,
"descr": "Birth of Warner, Andrew",
"gid": "E1819",
"media": [],
"part_family": [],
"part_person": [
931
],
"place": 545,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1827-10-14",
"date_sdn": 2388644,
"descr": "Death of Warner, Andrew",
"gid": "E1820",
"media": [],
"part_family": [],
"part_person": [
931
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1684-01-20",
"date_sdn": 2336148,
"descr": "Birth of Warner, Capt. Andrew",
"gid": "E1808",
"media": [],
"part_family": [],
"part_person": [
932
],
"place": 275,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-01-11",
"date_sdn": 2361706,
"descr": "Death of Warner, Capt. Andrew",
"gid": "E1809",
"media": [],
"part_family": [],
"part_person": [
932
],
"place": 422,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Capt. Andrew",
"gid": "E1810",
"media": [],
"part_family": [],
"part_person": [
932
],
"place": 851,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1618",
"date_sdn": 2312023,
"descr": "Birth of Warner, Capt. Francis",
"gid": "E2211",
"media": [],
"part_family": [],
"part_person": [
933
],
"place": 777,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1687-09-24",
"date_sdn": 2337491,
"descr": "Death of Warner, Capt. Francis",
"gid": "E2212",
"media": [],
"part_family": [],
"part_person": [
933
],
"place": 826,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1650",
"date_sdn": 2323711,
"descr": "Birth of Warner, Capt. George",
"gid": "E1803",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 141,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1710-11-08",
"date_sdn": 2345936,
"descr": "Death of Warner, Capt. George",
"gid": "E1804",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 756,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Capt. George",
"gid": "E1805",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 122,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1682-12-05",
"date_sdn": 2335737,
"descr": "Birth of Warner, Daniel",
"gid": "E1066",
"media": [],
"part_family": [],
"part_person": [
936
],
"place": 866,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1922-08-22",
"date_sdn": 2423289,
"descr": "Birth of Warner, Donald Louis",
"gid": "E0360",
"media": [],
"part_family": [],
"part_person": [
938
],
"place": 651,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-08-09",
"date_sdn": 2444095,
"descr": "Death of Warner, Donald Louis",
"gid": "E0361",
"media": [],
"part_family": [],
"part_person": [
938
],
"place": 616,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1713-01-06",
"date_sdn": 2346726,
"descr": "Birth of Warner, Edward",
"gid": "E1814",
"media": [],
"part_family": [],
"part_person": [
941
],
"place": 24,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1776-09-27",
"date_sdn": 2370001,
"descr": "Death of Warner, Edward",
"gid": "E1815",
"media": [],
"part_family": [],
"part_person": [
941
],
"place": 825,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Edward",
"gid": "E1816",
"media": [],
"part_family": [],
"part_person": [
941
],
"place": 298,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Warner, Elizabeth",
"gid": "E2175",
"media": [],
"part_family": [],
"part_person": [
945
],
"place": 398,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1683-03-28",
"date_sdn": 2335850,
"descr": "Birth of Warner, Elizabeth",
"gid": "E1071",
"media": [],
"part_family": [],
"part_person": [
946
],
"place": 287,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1678-08-04",
"date_sdn": 2334153,
"descr": "Birth of Warner, George",
"gid": "E1061",
"media": [],
"part_family": [],
"part_person": [
949
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1679",
"date_sdn": 2334303,
"descr": "Death of Warner, George",
"gid": "E1062",
"media": [],
"part_family": [],
"part_person": [
949
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1709-07-21",
"date_sdn": 2345461,
"descr": "Birth of Warner, George",
"gid": "E1073",
"media": [],
"part_family": [],
"part_person": [
950
],
"place": 287,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1681-09-03",
"date_sdn": 2335279,
"descr": "Birth of Warner, Hannah",
"gid": "E1065",
"media": [],
"part_family": [],
"part_person": [
953
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "about 1689",
"date_sdn": 2337956,
"descr": "Birth of Warner, Johnathon",
"gid": "E1076",
"media": [],
"part_family": [],
"part_person": [
960
],
"place": 287,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-07-00",
"date_sdn": 2361877,
"descr": "Death of Warner, Johnathon",
"gid": "E1077",
"media": [],
"part_family": [],
"part_person": [
960
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1892-09-25",
"date_sdn": 2412367,
"descr": "Birth of Warner, Julia Angeline",
"gid": "E0480",
"media": [],
"part_family": [],
"part_person": [
961
],
"place": 569,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1970-12-17",
"date_sdn": 2440938,
"descr": "Death of Warner, Julia Angeline",
"gid": "E0481",
"media": [],
"part_family": [],
"part_person": [
961
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Julia Angeline",
"gid": "E0482",
"media": [],
"part_family": [],
"part_person": [
961
],
"place": 535,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1889-08-11",
"date_sdn": 2411226,
"descr": "Birth of Warner, Martin Bogarte",
"gid": "E1127",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 621,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1961-08-12",
"date_sdn": 2437524,
"descr": "Death of Warner, Martin Bogarte",
"gid": "E1128",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 106,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1961-08-14",
"date_sdn": 2437526,
"descr": "Burial of Warner, Martin Bogarte",
"gid": "E1129",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 331,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1679-01-02",
"date_sdn": 2334304,
"descr": "Birth of Warner, Mary",
"gid": "E1063",
"media": [],
"part_family": [],
"part_person": [
965
],
"place": 98,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1913-10-29",
"date_sdn": 2420070,
"descr": "Birth of Warner, Michael Warren",
"gid": "E0349",
"media": [],
"part_family": [],
"part_person": [
967
],
"place": 427,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-01-18",
"date_sdn": 2445353,
"descr": "Death of Warner, Michael Warren",
"gid": "E0350",
"media": [],
"part_family": [],
"part_person": [
967
],
"place": 608,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1779-09-24",
"date_sdn": 2371093,
"descr": "Birth of Warner, Noah",
"gid": "E1255",
"media": [],
"part_family": [],
"part_person": [
969
],
"place": 545,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1844-06-14",
"date_sdn": 2394732,
"descr": "Death of Warner, Noah",
"gid": "E1256",
"media": [],
"part_family": [],
"part_person": [
969
],
"place": 421,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1844",
"date_sdn": 2394567,
"descr": "Burial of Warner, Noah",
"gid": "E1257",
"media": [],
"part_family": [],
"part_person": [
969
],
"place": 401,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1821-04-09",
"date_sdn": 2386265,
"descr": "Birth of Warner, Piatt D.",
"gid": "E1403",
"media": [],
"part_family": [],
"part_person": [
970
],
"place": 551,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1889-10-11",
"date_sdn": 2411287,
"descr": "Death of Warner, Piatt D.",
"gid": "E1404",
"media": [],
"part_family": [],
"part_person": [
970
],
"place": 35,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1889",
"date_sdn": 2411004,
"descr": "Burial of Warner, Piatt D.",
"gid": "E1405",
"media": [],
"part_family": [],
"part_person": [
970
],
"place": 269,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1543",
"date_sdn": 2284629,
"descr": "Birth of Warner, Sir Francis",
"gid": "E2420",
"media": [],
"part_family": [],
"part_person": [
974
],
"place": 797,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1596-01-28",
"date_sdn": 2304014,
"descr": "Death of Warner, Sir Francis",
"gid": "E2421",
"media": [],
"part_family": [],
"part_person": [
974
],
"place": 449,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1596-01-28",
"date_sdn": 2304014,
"descr": "Burial of Warner, Sir Francis",
"gid": "E2422",
"media": [],
"part_family": [],
"part_person": [
974
],
"place": 449,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1556",
"date_sdn": 2289377,
"descr": "Birth of Warner, Thomas",
"gid": "E2417",
"media": [],
"part_family": [],
"part_person": [
976
],
"place": 582,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1867-01-23",
"date_sdn": 2402990,
"descr": "Birth of Warner, Warren W.",
"gid": "E1210",
"media": [],
"part_family": [],
"part_person": [
977
],
"place": 223,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-03-10",
"date_sdn": 2422028,
"descr": "Death of Warner, Warren W.",
"gid": "E1211",
"media": [],
"part_family": [],
"part_person": [
977
],
"place": 407,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Warren W.",
"gid": "E1212",
"media": [],
"part_family": [],
"part_person": [
977
],
"place": 331,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1871-08-24",
"date_sdn": 2404664,
"descr": "Birth of Waters, William",
"gid": "E0504",
"media": [],
"part_family": [],
"part_person": [
981
],
"place": 848,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-07-12",
"date_sdn": 2429092,
"descr": "Death of Waters, William",
"gid": "E0505",
"media": [],
"part_family": [],
"part_person": [
981
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1938-07-14",
"date_sdn": 2429094,
"descr": "Burial of Waters, William",
"gid": "E0506",
"media": [],
"part_family": [],
"part_person": [
981
],
"place": 642,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1821",
"date_sdn": 2386167,
"descr": "Birth of Webb, Alexander",
"gid": "E2729",
"media": [],
"part_family": [],
"part_person": [
983
],
"place": 600,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1854-02-02",
"date_sdn": 2398252,
"descr": "Death of Webb, Alexander",
"gid": "E2730",
"media": [],
"part_family": [],
"part_person": [
983
],
"place": 377,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1854-02-00",
"date_sdn": 2398251,
"descr": "Burial of Webb, Alexander",
"gid": "E2731",
"media": [],
"part_family": [],
"part_person": [
983
],
"place": 273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Birth of Webb, Andrew",
"gid": "E2718",
"media": [],
"part_family": [],
"part_person": [
984
],
"place": 464,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1850",
"date_sdn": 2396759,
"descr": "Death of Webb, Andrew",
"gid": "E2719",
"media": [],
"part_family": [],
"part_person": [
984
],
"place": 688,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Webb, Andrew",
"gid": "E2720",
"media": [],
"part_family": [],
"part_person": [
984
],
"place": 242,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1890-10-02",
"date_sdn": 2411643,
"descr": "Birth of Webb, Anna Mabel",
"gid": "E0814",
"media": [],
"part_family": [],
"part_person": [
985
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1967-07-12",
"date_sdn": 2439684,
"descr": "Death of Webb, Anna Mabel",
"gid": "E0815",
"media": [],
"part_family": [],
"part_person": [
985
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1834",
"date_sdn": 2390915,
"descr": "Birth of Webb, Charles Leroy Boyd",
"gid": "E0326",
"media": [],
"part_family": [],
"part_person": [
986
],
"place": 686,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1878-04-15",
"date_sdn": 2407090,
"descr": "Birth of Webb, Clarence",
"gid": "E2309",
"media": [],
"part_family": [],
"part_person": [
987
],
"place": 105,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1953-12-24",
"date_sdn": 2434736,
"descr": "Death of Webb, Clarence",
"gid": "E2310",
"media": [],
"part_family": [],
"part_person": [
987
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1953-12-26",
"date_sdn": 2434738,
"descr": "Burial of Webb, Clarence",
"gid": "E2311",
"media": [],
"part_family": [],
"part_person": [
987
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-02-22",
"date_sdn": 2408864,
"descr": "Birth of Webb, David Festus",
"gid": "E0804",
"media": [],
"part_family": [],
"part_person": [
988
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-08-23",
"date_sdn": 2433517,
"descr": "Death of Webb, David Festus",
"gid": "E0805",
"media": [],
"part_family": [],
"part_person": [
988
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1884-11-17",
"date_sdn": 2409498,
"descr": "Birth of Webb, Ernest Arlington",
"gid": "E0801",
"media": [],
"part_family": [],
"part_person": [
990
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-10-07",
"date_sdn": 2436119,
"descr": "Death of Webb, Ernest Arlington",
"gid": "E0802",
"media": [],
"part_family": [],
"part_person": [
990
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1869-04-28",
"date_sdn": 2403816,
"descr": "Birth of Webb, Francis Irvin",
"gid": "E1610",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 678,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-02-07",
"date_sdn": 2435877,
"descr": "Death of Webb, Francis Irvin",
"gid": "E1611",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 297,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1957-02-00",
"date_sdn": 2435871,
"descr": "Burial of Webb, Francis Irvin",
"gid": "E1612",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 83,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1895-11-10",
"date_sdn": 2413508,
"descr": "Birth of Webb, Harry Noble",
"gid": "E0818",
"media": [],
"part_family": [],
"part_person": [
992
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-12-07",
"date_sdn": 2424492,
"descr": "Death of Webb, Harry Noble",
"gid": "E0819",
"media": [],
"part_family": [],
"part_person": [
992
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1886-11-09",
"date_sdn": 2410220,
"descr": "Birth of Webb, James Leslie",
"gid": "E0806",
"media": [],
"part_family": [],
"part_person": [
994
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1963-01-25",
"date_sdn": 2438055,
"descr": "Death of Webb, James Leslie",
"gid": "E0807",
"media": [],
"part_family": [],
"part_person": [
994
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1856-12-04",
"date_sdn": 2399288,
"descr": "Birth of Webb, James Marshall",
"gid": "E0333",
"media": [],
"part_family": [],
"part_person": [
995
],
"place": 230,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-08-04",
"date_sdn": 2429115,
"descr": "Death of Webb, James Marshall",
"gid": "E0334",
"media": [],
"part_family": [],
"part_person": [
995
],
"place": 663,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1938-08-06",
"date_sdn": 2429117,
"descr": "Burial of Webb, James Marshall",
"gid": "E0335",
"media": [],
"part_family": [],
"part_person": [
995
],
"place": 717,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, James McPheeters",
"gid": "E0328",
"media": [],
"part_family": [],
"part_person": [
996
],
"place": 710,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1837",
"date_sdn": 2392011,
"descr": "Birth of Webb, John McCrea",
"gid": "E0327",
"media": [],
"part_family": [],
"part_person": [
997
],
"place": 198,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1847-10-00",
"date_sdn": 2395936,
"descr": "Birth of Webb, Joseph LeRoy",
"gid": "E0771",
"media": [],
"part_family": [],
"part_person": [
998
],
"place": 169,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1878-04-15",
"date_sdn": 2407090,
"descr": "Birth of Webb, Lawrence",
"gid": "E2312",
"media": [],
"part_family": [],
"part_person": [
999
],
"place": 105,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1948-08-29",
"date_sdn": 2432793,
"descr": "Death of Webb, Lawrence",
"gid": "E2313",
"media": [],
"part_family": [],
"part_person": [
999
],
"place": 796,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1948-08-31",
"date_sdn": 2432795,
"descr": "Burial of Webb, Lawrence",
"gid": "E2314",
"media": [],
"part_family": [],
"part_person": [
999
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1903-03-31",
"date_sdn": 2416205,
"descr": "Birth of Webb, Lewis I.",
"gid": "E1048",
"media": [],
"part_family": [],
"part_person": [
1000
],
"place": 75,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-12-25",
"date_sdn": 2430719,
"descr": "Death of Webb, Lewis I.",
"gid": "E1049",
"media": [],
"part_family": [],
"part_person": [
1000
],
"place": 392,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Webb, Lewis I.",
"gid": "E1050",
"media": [],
"part_family": [],
"part_person": [
1000
],
"place": 696,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1846-02-11",
"date_sdn": 2395339,
"descr": "Birth of Webb, Livingstone Martin",
"gid": "E2129",
"media": [],
"part_family": [],
"part_person": [
1001
],
"place": 169,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-04-10",
"date_sdn": 2415850,
"descr": "Death of Webb, Livingstone Martin",
"gid": "E2130",
"media": [],
"part_family": [],
"part_person": [
1001
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902-04-13",
"date_sdn": 2415853,
"descr": "Burial of Webb, Livingstone Martin",
"gid": "E2131",
"media": [],
"part_family": [],
"part_person": [
1001
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, Lucinda E.",
"gid": "E0772",
"media": [],
"part_family": [],
"part_person": [
1002
],
"place": 123,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1899-01-20",
"date_sdn": 2414675,
"descr": "Birth of Webb, Lucy Mabel",
"gid": "E1031",
"media": [],
"part_family": [],
"part_person": [
1003
],
"place": 411,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1971-05-10",
"date_sdn": 2441082,
"descr": "Death of Webb, Lucy Mabel",
"gid": "E1032",
"media": [],
"part_family": [],
"part_person": [
1003
],
"place": 2,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1971-05-13",
"date_sdn": 2441085,
"descr": "Burial of Webb, Lucy Mabel",
"gid": "E1033",
"media": [],
"part_family": [],
"part_person": [
1003
],
"place": 179,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1800",
"date_sdn": 2378497,
"descr": "Birth of Webb, Margaret Margarite?",
"gid": "E2721",
"media": [],
"part_family": [],
"part_person": [
1004
],
"place": 464,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1860",
"date_sdn": 2400411,
"descr": "Death of Webb, Margaret Margarite?",
"gid": "E2722",
"media": [],
"part_family": [],
"part_person": [
1004
],
"place": 688,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "after 1860",
"date_sdn": 2400411,
"descr": "Burial of Webb, Margaret Margarite?",
"gid": "E2723",
"media": [],
"part_family": [],
"part_person": [
1004
],
"place": 242,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1803",
"date_sdn": 2379592,
"descr": "Birth of Webb, Mary",
"gid": "E0319",
"media": [],
"part_family": [],
"part_person": [
1005
],
"place": 578,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1827-01-31",
"date_sdn": 2388388,
"descr": "Birth of Webb, Mary",
"gid": "E0320",
"media": [],
"part_family": [],
"part_person": [
1006
],
"place": 310,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1892-12-15",
"date_sdn": 2412448,
"descr": "Birth of Webb, Mary Ruth",
"gid": "E0816",
"media": [],
"part_family": [],
"part_person": [
1007
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1956-11-29",
"date_sdn": 2435807,
"descr": "Death of Webb, Mary Ruth",
"gid": "E0817",
"media": [],
"part_family": [],
"part_person": [
1007
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1888-11-19",
"date_sdn": 2410961,
"descr": "Birth of Webb, Michael Christie",
"gid": "E0812",
"media": [],
"part_family": [],
"part_person": [
1008
],
"place": 675,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1970-07-23",
"date_sdn": 2440791,
"descr": "Death of Webb, Michael Christie",
"gid": "E0813",
"media": [],
"part_family": [],
"part_person": [
1008
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1842-10-13",
"date_sdn": 2394122,
"descr": "Birth of Webb, Newton Kitridge",
"gid": "E0329",
"media": [],
"part_family": [],
"part_person": [
1010
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1912-07-28",
"date_sdn": 2419612,
"descr": "Death of Webb, Newton Kitridge",
"gid": "E0330",
"media": [],
"part_family": [],
"part_person": [
1010
],
"place": 419,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1912-07-30",
"date_sdn": 2419614,
"descr": "Burial of Webb, Newton Kitridge",
"gid": "E0331",
"media": [],
"part_family": [],
"part_person": [
1010
],
"place": 717,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, Sallie",
"gid": "E0318",
"media": [],
"part_family": [],
"part_person": [
1013
],
"place": 578,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Webb, Sarah Margarite",
"gid": "E0325",
"media": [],
"part_family": [],
"part_person": [
1014
],
"place": 686,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1881-10-27",
"date_sdn": 2408381,
"descr": "Birth of Webb, William Herman",
"gid": "E0341",
"media": [],
"part_family": [],
"part_person": [
1015
],
"place": 663,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-08-23",
"date_sdn": 2434248,
"descr": "Death of Webb, William Herman",
"gid": "E0342",
"media": [],
"part_family": [],
"part_person": [
1015
],
"place": 675,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1829-07-14",
"date_sdn": 2389283,
"descr": "Birth of Webb, William John",
"gid": "E0321",
"media": [],
"part_family": [],
"part_person": [
1016
],
"place": 686,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1888-04-17",
"date_sdn": 2410745,
"descr": "Death of Webb, William John",
"gid": "E0322",
"media": [],
"part_family": [],
"part_person": [
1016
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1920-10-28",
"date_sdn": 2422626,
"descr": "Birth of Welch, Irwin Arthur",
"gid": "E2431",
"media": [],
"part_family": [],
"part_person": [
1018
],
"place": 794,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-06-25",
"date_sdn": 2444050,
"descr": "Death of Welch, Irwin Arthur",
"gid": "E2432",
"media": [],
"part_family": [],
"part_person": [
1018
],
"place": 509,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1979-06-27",
"date_sdn": 2444052,
"descr": "Burial of Welch, Irwin Arthur",
"gid": "E2433",
"media": [],
"part_family": [],
"part_person": [
1018
],
"place": 856,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Wells, Alice",
"gid": "E0244",
"media": [],
"part_family": [],
"part_person": [
1019
],
"place": 104,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1653-11-08",
"date_sdn": 2325118,
"descr": "Death of Wells, Alice",
"gid": "E0245",
"media": [],
"part_family": [],
"part_person": [
1019
],
"place": 499,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1536-06-19",
"date_sdn": 2282242,
"descr": "Birth of Wise, Thomas",
"gid": "E2143",
"media": [],
"part_family": [],
"part_person": [
1022
],
"place": 319,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1606-10-09",
"date_sdn": 2307921,
"descr": "Death of Wise, Thomas",
"gid": "E2144",
"media": [],
"part_family": [],
"part_person": [
1022
],
"place": 228,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1967-06-25",
"date_sdn": 2439667,
"descr": "Death of W\u00f3jcik, Arnold",
"gid": "E2079",
"media": [],
"part_family": [],
"part_person": [
1024
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of W\u00f3jcik, Arnold",
"gid": "E2080",
"media": [],
"part_family": [],
"part_person": [
1024
],
"place": 816,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1771-01-29",
"date_sdn": 2367933,
"descr": "Birth of Wood, Polly",
"gid": "E1029",
"media": [],
"part_family": [],
"part_person": [
1028
],
"place": 127,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1850",
"date_sdn": 2396759,
"descr": "Death of Wood, Polly",
"gid": "E1030",
"media": [],
"part_family": [],
"part_person": [
1028
],
"place": 103,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1777-11-29",
"date_sdn": 2370429,
"descr": "Birth of Woods, Mary Polly",
"gid": "E1038",
"media": [],
"part_family": [],
"part_person": [
1030
],
"place": 846,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1854-11-15",
"date_sdn": 2398538,
"descr": "Death of Woods, Mary Polly",
"gid": "E1039",
"media": [],
"part_family": [],
"part_person": [
1030
],
"place": 368,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1827-04-12",
"date_sdn": 2388459,
"descr": "Birth of Zieli\u0144ski, Phoebe Emily",
"gid": "E0124",
"media": [],
"part_family": [],
"part_person": [
1032
],
"place": 80,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1882-03-07",
"date_sdn": 2408512,
"descr": "Death of Zieli\u0144ski, Phoebe Emily",
"gid": "E0125",
"media": [],
"part_family": [],
"part_person": [
1032
],
"place": 16,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1882-03-09",
"date_sdn": 2408514,
"descr": "Burial of Zieli\u0144ski, Phoebe Emily",
"gid": "E0126",
"media": [],
"part_family": [],
"part_person": [
1032
],
"place": 520,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1890-05-20",
"date_sdn": 2411508,
"descr": "Birth of Zimmerman, Edith Irene",
"gid": "E2461",
"media": [],
"part_family": [],
"part_person": [
1033
],
"place": 45,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-12-21",
"date_sdn": 2438020,
"descr": "Death of Zimmerman, Edith Irene",
"gid": "E2462",
"media": [],
"part_family": [],
"part_person": [
1033
],
"place": 407,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1962-12-23",
"date_sdn": 2438022,
"descr": "Burial of Zimmerman, Edith Irene",
"gid": "E2463",
"media": [],
"part_family": [],
"part_person": [
1033
],
"place": 607,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1730",
"date_sdn": 2352930,
"descr": "Birth of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"gid": "E0432",
"media": [],
"part_family": [],
"part_person": [
1034
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"gid": "E0433",
"media": [],
"part_family": [],
"part_person": [
1034
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1721",
"date_sdn": 2349643,
"descr": "Birth of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Johann Adam",
"gid": "E0429",
"media": [],
"part_family": [],
"part_person": [
1035
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1815",
"date_sdn": 2383975,
"descr": "Birth of \u0411\u0430\u0440\u0430\u043d\u043e\u0432, Susan",
"gid": "E0365",
"media": [],
"part_family": [],
"part_person": [
1038
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1717-01-26",
"date_sdn": 2348207,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2555",
"media": [],
"part_family": [],
"part_person": [
1039
],
"place": 243,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1788-04-20",
"date_sdn": 2374224,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2556",
"media": [],
"part_family": [],
"part_person": [
1039
],
"place": 300,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1788-04-22",
"date_sdn": 2374226,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2557",
"media": [],
"part_family": [],
"part_person": [
1039
],
"place": 372,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1658",
"date_sdn": 2326633,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2599",
"media": [],
"part_family": [],
"part_person": [
1040
],
"place": 389,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1718-08-16",
"date_sdn": 2348774,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2600",
"media": [],
"part_family": [],
"part_person": [
1040
],
"place": 389,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2601",
"media": [],
"part_family": [],
"part_person": [
1040
],
"place": 452,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1690-02-23",
"date_sdn": 2338374,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2608",
"media": [],
"part_family": [],
"part_person": [
1041
],
"place": 389,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750-12-25",
"date_sdn": 2360593,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2609",
"media": [],
"part_family": [],
"part_person": [
1041
],
"place": 389,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2610",
"media": [],
"part_family": [],
"part_person": [
1041
],
"place": 452,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1732-01-17",
"date_sdn": 2353676,
"descr": "Birth of \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"gid": "E0164",
"media": [],
"part_family": [],
"part_person": [
1042
],
"place": 124,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1789-05-29",
"date_sdn": 2374628,
"descr": "Death of \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"gid": "E0165",
"media": [],
"part_family": [],
"part_person": [
1042
],
"place": 220,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1818",
"date_sdn": 2385071,
"descr": "Birth of \u0412\u043e\u0440\u043e\u043d\u043e\u0432, Katherine",
"gid": "E0848",
"media": [],
"part_family": [],
"part_person": [
1046
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1515",
"date_sdn": 2274402,
"descr": "Birth of \u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"gid": "E2247",
"media": [],
"part_family": [],
"part_person": [
1047
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1572",
"date_sdn": 2295221,
"descr": "Death of \u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"gid": "E2248",
"media": [],
"part_family": [],
"part_person": [
1047
],
"place": 632,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1754",
"date_sdn": 2361696,
"descr": "Birth of \u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432, Anna Maria",
"gid": "E0356",
"media": [],
"part_family": [],
"part_person": [
1049
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1771-04-20",
"date_sdn": 2368014,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"gid": "E1036",
"media": [],
"part_family": [],
"part_person": [
1051
],
"place": 309,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-01-18",
"date_sdn": 2392393,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"gid": "E1037",
"media": [],
"part_family": [],
"part_person": [
1051
],
"place": 368,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1729",
"date_sdn": 2352565,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"gid": "E0283",
"media": [],
"part_family": [],
"part_person": [
1052
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1786",
"date_sdn": 2373384,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"gid": "E0284",
"media": [],
"part_family": [],
"part_person": [
1052
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1687",
"date_sdn": 2337225,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"gid": "E2706",
"media": [],
"part_family": [],
"part_person": [
1053
],
"place": 395,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750-05-13",
"date_sdn": 2360367,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"gid": "E2707",
"media": [],
"part_family": [],
"part_person": [
1053
],
"place": 724,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1737",
"date_sdn": 2355487,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"gid": "E0289",
"media": [],
"part_family": [],
"part_person": [
1054
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1807",
"date_sdn": 2381053,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"gid": "E0290",
"media": [],
"part_family": [],
"part_person": [
1054
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1741",
"date_sdn": 2356948,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"gid": "E0293",
"media": [],
"part_family": [],
"part_person": [
1055
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1778",
"date_sdn": 2370462,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"gid": "E0294",
"media": [],
"part_family": [],
"part_person": [
1055
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1739",
"date_sdn": 2356217,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"gid": "E0291",
"media": [],
"part_family": [],
"part_person": [
1056
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762",
"date_sdn": 2364618,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"gid": "E0292",
"media": [],
"part_family": [],
"part_person": [
1056
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1733",
"date_sdn": 2354026,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lucy",
"gid": "E0288",
"media": [],
"part_family": [],
"part_person": [
1057
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1731",
"date_sdn": 2353295,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Mary",
"gid": "E0285",
"media": [],
"part_family": [],
"part_person": [
1058
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1768-04-01",
"date_sdn": 2366900,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E1027",
"media": [],
"part_family": [],
"part_person": [
1060
],
"place": 884,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853",
"date_sdn": 2397855,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E1028",
"media": [],
"part_family": [],
"part_person": [
1060
],
"place": 571,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E0281",
"media": [],
"part_family": [],
"part_person": [
1061
],
"place": 660,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1766-05-12",
"date_sdn": 2366210,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E0282",
"media": [],
"part_family": [],
"part_person": [
1061
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1898",
"media": [],
"part_family": [],
"part_person": [
1065
],
"place": 227,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1771",
"date_sdn": 2367905,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1899",
"media": [],
"part_family": [],
"part_person": [
1065
],
"place": 747,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1900",
"media": [],
"part_family": [],
"part_person": [
1065
],
"place": 646,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1756-02-15",
"date_sdn": 2362471,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"gid": "E1910",
"media": [],
"part_family": [],
"part_person": [
1066
],
"place": 550,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1801-08-11",
"date_sdn": 2379084,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"gid": "E1911",
"media": [],
"part_family": [],
"part_person": [
1066
],
"place": 20,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1790-01-29",
"date_sdn": 2374873,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1916",
"media": [],
"part_family": [],
"part_person": [
1067
],
"place": 718,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-06-27",
"date_sdn": 2396571,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1917",
"media": [],
"part_family": [],
"part_person": [
1067
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1849-06-29",
"date_sdn": 2396573,
"descr": "Burial of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1918",
"media": [],
"part_family": [],
"part_person": [
1067
],
"place": 624,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1846-08-17",
"date_sdn": 2395526,
"descr": "Birth of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1467",
"media": [],
"part_family": [],
"part_person": [
1068
],
"place": 252,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1891-10-31",
"date_sdn": 2412037,
"descr": "Death of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1468",
"media": [],
"part_family": [],
"part_person": [
1068
],
"place": 613,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1891-11-01",
"date_sdn": 2412038,
"descr": "Burial of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1469",
"media": [],
"part_family": [],
"part_person": [
1068
],
"place": 613,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1795-11-06",
"date_sdn": 2376980,
"descr": "Birth of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1354",
"media": [],
"part_family": [],
"part_person": [
1069
],
"place": 33,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875-12-12",
"date_sdn": 2406235,
"descr": "Death of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1355",
"media": [],
"part_family": [],
"part_person": [
1069
],
"place": 828,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1356",
"media": [],
"part_family": [],
"part_person": [
1069
],
"place": 88,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1768-01-04",
"date_sdn": 2366812,
"descr": "Birth of \u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"gid": "E0846",
"media": [],
"part_family": [],
"part_person": [
1071
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-12-21",
"date_sdn": 2389078,
"descr": "Death of \u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"gid": "E0847",
"media": [],
"part_family": [],
"part_person": [
1071
],
"place": 286,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858",
"date_sdn": 2399681,
"descr": "Birth of \u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"gid": "E0235",
"media": [],
"part_family": [],
"part_person": [
1072
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-09-02",
"date_sdn": 2420013,
"descr": "Death of \u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"gid": "E0236",
"media": [],
"part_family": [],
"part_person": [
1072
],
"place": 359,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1520",
"date_sdn": 2276228,
"descr": "Birth of \u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432, ??",
"gid": "E0014",
"media": [],
"part_family": [],
"part_person": [
1073
],
"place": 692,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1972-08-08",
"date_sdn": 2441538,
"descr": "Death of \u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432, Hanora",
"gid": "E0941",
"media": [],
"part_family": [],
"part_person": [
1076
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041b\u0435\u0431\u0435\u0434\u0435\u0432, Trustum",
"gid": "E1072",
"media": [],
"part_family": [],
"part_person": [
1078
],
"place": 404,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u043a\u0430\u0440\u043e\u0432, Joseph",
"gid": "E0332",
"media": [],
"part_family": [],
"part_person": [
1080
],
"place": 119,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1749-10-25",
"date_sdn": 2360167,
"descr": "Death of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Christina",
"gid": "E1872",
"media": [],
"part_family": [],
"part_person": [
1083
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2513",
"media": [],
"part_family": [],
"part_person": [
1085
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-05-08",
"date_sdn": 2396521,
"descr": "Death of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2514",
"media": [],
"part_family": [],
"part_person": [
1085
],
"place": 647,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1849-05-09",
"date_sdn": 2396522,
"descr": "Burial of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2515",
"media": [],
"part_family": [],
"part_person": [
1085
],
"place": 294,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1420",
"date_sdn": 2239704,
"descr": "Birth of \u041c\u0430\u043b\u044c\u0446\u0435\u0432, Joan",
"gid": "E0055",
"media": [],
"part_family": [],
"part_person": [
1086
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"gid": "E2164",
"media": [],
"part_family": [],
"part_person": [
1087
],
"place": 13,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1829-07-19",
"date_sdn": 2389288,
"descr": "Death of \u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"gid": "E2165",
"media": [],
"part_family": [],
"part_person": [
1087
],
"place": 511,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Birth of \u041c\u043e\u0440\u043e\u0437\u043e\u0432, Mary Elizabeth",
"gid": "E0354",
"media": [],
"part_family": [],
"part_person": [
1089
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1704-01-26",
"date_sdn": 2343458,
"descr": "Birth of \u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Maria Catharina",
"gid": "E2266",
"media": [],
"part_family": [],
"part_person": [
1091
],
"place": 188,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1660",
"date_sdn": 2327363,
"descr": "Birth of \u041d\u043e\u0432\u0438\u043a\u043e\u0432, Sarah",
"gid": "E1133",
"media": [],
"part_family": [],
"part_person": [
1093
],
"place": 65,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1080",
"date_sdn": 2115522,
"descr": "Birth of \u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"gid": "E0028",
"media": [],
"part_family": [],
"part_person": [
1096
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1168",
"date_sdn": 2147663,
"descr": "Death of \u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"gid": "E0029",
"media": [],
"part_family": [],
"part_person": [
1096
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1645",
"date_sdn": 2321885,
"descr": "Birth of \u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"gid": "E2597",
"media": [],
"part_family": [],
"part_person": [
1099
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1699-03-02",
"date_sdn": 2341668,
"descr": "Death of \u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"gid": "E2598",
"media": [],
"part_family": [],
"part_person": [
1099
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1014",
"date_sdn": 2091416,
"descr": "Birth of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Eudo",
"gid": "E0017",
"media": [],
"part_family": [],
"part_person": [
1100
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1050",
"date_sdn": 2104565,
"descr": "Birth of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"gid": "E0022",
"media": [],
"part_family": [],
"part_person": [
1101
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1121",
"date_sdn": 2130497,
"descr": "Death of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"gid": "E0023",
"media": [],
"part_family": [],
"part_person": [
1101
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "after 1824",
"date_sdn": 2387262,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432",
"gid": "E0191",
"media": [],
"part_family": [],
"part_person": [
1104
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, John P.",
"gid": "E0189",
"media": [],
"part_family": [],
"part_person": [
1105
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1812-03-07",
"date_sdn": 2382945,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0184",
"media": [],
"part_family": [],
"part_person": [
1106
],
"place": 220,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880-11-27",
"date_sdn": 2408047,
"descr": "Death of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0185",
"media": [],
"part_family": [],
"part_person": [
1106
],
"place": 754,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1880-11-29",
"date_sdn": 2408049,
"descr": "Burial of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0186",
"media": [],
"part_family": [],
"part_person": [
1106
],
"place": 7,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1825-07-29",
"date_sdn": 2387837,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Sarah Jane",
"gid": "E0190",
"media": [],
"part_family": [],
"part_person": [
1107
],
"place": 762,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1813-02-04",
"date_sdn": 2383279,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0181",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 516,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-01-16",
"date_sdn": 2406636,
"descr": "Death of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0182",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 375,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "about 1877-01-18",
"date_sdn": 2406638,
"descr": "Burial of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0183",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 375,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1864-01-27",
"date_sdn": 2401898,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1754",
"media": [],
"part_family": [],
"part_person": [
1109
],
"place": 608,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-11-27",
"date_sdn": 2416446,
"descr": "Death of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1755",
"media": [],
"part_family": [],
"part_person": [
1109
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1903-11-29",
"date_sdn": 2416448,
"descr": "Burial of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1756",
"media": [],
"part_family": [],
"part_person": [
1109
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, John",
"gid": "E2176",
"media": [],
"part_family": [],
"part_person": [
1110
],
"place": 359,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Mary Ellen",
"gid": "E2177",
"media": [],
"part_family": [],
"part_person": [
1111
],
"place": 359,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1827",
"date_sdn": 2388358,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2548",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 248,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1872",
"date_sdn": 2404794,
"descr": "Death of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2549",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2550",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 450,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Myles",
"gid": "E2174",
"media": [],
"part_family": [],
"part_person": [
1113
],
"place": 359,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1657-02-00",
"date_sdn": 2326299,
"descr": "Birth of \u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"gid": "E2228",
"media": [],
"part_family": [],
"part_person": [
1115
],
"place": 93,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1747-09-03",
"date_sdn": 2359384,
"descr": "Death of \u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"gid": "E2229",
"media": [],
"part_family": [],
"part_person": [
1115
],
"place": 24,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1928",
"date_sdn": 2425247,
"descr": "Death of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Louis",
"gid": "E0754",
"media": [],
"part_family": [],
"part_person": [
1116
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1883-08-09",
"date_sdn": 2409032,
"descr": "Birth of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"gid": "E0547",
"media": [],
"part_family": [],
"part_person": [
1118
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1973-12-08",
"date_sdn": 2442025,
"descr": "Death of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"gid": "E0548",
"media": [],
"part_family": [],
"part_person": [
1118
],
"place": 796,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1325",
"date_sdn": 2205007,
"descr": "Birth of \u0427\u0435\u0440\u043d\u043e\u0432, Maud",
"gid": "E0051",
"media": [],
"part_family": [],
"part_person": [
1119
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1734-09-04",
"date_sdn": 2354637,
"descr": "Birth of \u0428\u0430\u0434\u0440\u0438\u043d, Mary",
"gid": "E1914",
"media": [],
"part_family": [],
"part_person": [
1120
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1784-09-00",
"date_sdn": 2372897,
"descr": "Birth of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2679",
"media": [],
"part_family": [],
"part_person": [
1121
],
"place": 80,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-03-09",
"date_sdn": 2401940,
"descr": "Death of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2680",
"media": [],
"part_family": [],
"part_person": [
1121
],
"place": 605,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1864-03-00",
"date_sdn": 2401932,
"descr": "Burial of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2681",
"media": [],
"part_family": [],
"part_person": [
1121
],
"place": 520,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "204 (Islamic)",
"date_sdn": 2020376,
"descr": "",
"gid": "E3408",
"media": [],
"part_family": [],
"part_person": [
0,
1122
],
"place": -1,
"text": "",
"type": "Marriage"
},
{
"cita": [],
"date": "234 (Islamic)",
"date_sdn": 2031007,
"descr": "",
"gid": "E3410",
"media": [],
"part_family": [],
"part_person": [
1122
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "estimated about 1850",
"date_sdn": 2396759,
"descr": "",
"gid": "E3414",
"media": [],
"part_family": [],
"part_person": [
1123
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1941-02-16",
"date_sdn": 2430042,
"descr": "Death of \u4f0a\u85e4, Mary",
"gid": "E0234",
"media": [],
"part_family": [],
"part_person": [
1125
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1643-07-10",
"date_sdn": 2321344,
"descr": "Birth of \u5c71\u672c, Antoine Desaure Perronett",
"gid": "E2267",
"media": [],
"part_family": [],
"part_person": [
1126
],
"place": 701,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1672-10-12",
"date_sdn": 2332031,
"descr": "Birth of \u5c71\u672c, Gabriel Gustav",
"gid": "E0713",
"media": [],
"part_family": [],
"part_person": [
1127
],
"place": 779,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1675",
"date_sdn": 2332842,
"descr": "Birth of \u658e\u85e4, Zariakius Cyriacus",
"gid": "E2260",
"media": [],
"part_family": [],
"part_person": [
1129
],
"place": 120,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1748-07-01",
"date_sdn": 2359686,
"descr": "Death of \u658e\u85e4, Zariakius Cyriacus",
"gid": "E2261",
"media": [],
"part_family": [],
"part_person": [
1129
],
"place": 46,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1802-06-15",
"date_sdn": 2379392,
"descr": "Birth of \u6e21\u8fba, Mary (Polly)",
"gid": "E2365",
"media": [],
"part_family": [],
"part_person": [
1130
],
"place": 379,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-01-25",
"date_sdn": 2403723,
"descr": "Death of \u6e21\u8fba, Mary (Polly)",
"gid": "E2366",
"media": [],
"part_family": [],
"part_person": [
1130
],
"place": 608,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u6e21\u8fba, Mary (Polly)",
"gid": "E2367",
"media": [],
"part_family": [],
"part_person": [
1130
],
"place": 258,
"text": "",
"type": "Burial"
}
],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_I_events_0.js');
