// This file is generated

M_bkf_0 = [
[],
[],
[],
[
{
"bk_idx": 163,
"cita": [
1612,
1613,
1613
],
"note": "<div>\n<p>\n<b>Identification Number</b>: 12345\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/8/e/f0qigqft275jfj75e8.png"
}
],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_M_bkf_0.js');
