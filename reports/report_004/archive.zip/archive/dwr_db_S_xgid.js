// This file is generated

S_xgid = {}
Dwr.ScriptLoaded('dwr_db_S_xgid.js');
