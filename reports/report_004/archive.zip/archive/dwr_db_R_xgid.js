// This file is generated

R_xgid = {}
Dwr.ScriptLoaded('dwr_db_R_xgid.js');
