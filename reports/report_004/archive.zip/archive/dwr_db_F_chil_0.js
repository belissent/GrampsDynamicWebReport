// This file is generated

F_chil_0 = [
[
{
"cita": [],
"index": 5,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 3,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 8,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 11,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 10,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 14,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 38,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 35,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 32,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 33,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 41,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 40,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 36,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 37,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 45,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 49,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 888,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 52,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 62,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 56,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 57,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 53,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 61,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 55,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 54,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 58,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 59,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 60,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 83,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 80,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 88,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 81,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 77,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 450,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 75,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 82,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 72,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 87,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 71,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 76,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 79,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 86,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 78,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 73,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 74,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 85,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 327,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 338,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 326,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 336,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 316,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 333,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 322,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 324,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 319,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 331,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 104,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 93,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 114,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 103,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 101,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 102,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 96,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 107,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 92,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 91,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 473,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 469,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 480,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 476,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 485,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 471,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 486,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 482,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 95,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 119,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 124,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 133,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 147,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 527,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 150,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 129,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 125,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 135,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 136,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 148,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 142,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 130,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 141,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 128,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 139,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 140,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 137,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 143,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 146,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 151,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 144,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 138,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 178,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 174,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 167,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 153,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 157,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 159,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 173,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 161,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 171,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 160,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 166,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 169,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 175,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 164,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 182,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 193,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 198,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 192,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 194,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 190,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 196,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 191,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 187,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 197,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 195,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 188,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 207,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 205,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 208,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 203,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 204,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 209,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 217,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 215,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 222,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 223,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 231,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 229,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 224,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 230,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 221,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 226,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 232,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 227,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 243,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 242,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 246,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 253,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 251,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 254,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 1053,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 269,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 266,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 264,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 260,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 268,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 261,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 265,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 262,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 276,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 277,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 273,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 275,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 289,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 287,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 286,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 295,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 284,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 299,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 293,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 288,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 283,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 303,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 280,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 290,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 399,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 285,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 281,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 291,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 301,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 304,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 306,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 838,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 847,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 834,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 828,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 832,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 848,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 829,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 843,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 840,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 837,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 841,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 396,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 387,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 375,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 323,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 334,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 330,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 337,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 339,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 332,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 320,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 325,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 328,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 317,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 335,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 318,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 321,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 329,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 821,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 557,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 561,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 558,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 341,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 349,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 812,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 361,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 360,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 358,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 362,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 42,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 357,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 366,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 364,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 367,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 383,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 386,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 393,
"note": "",
"to_father": "Birth",
"to_mother": "Adopted"
},
{
"cita": [],
"index": 385,
"note": "",
"to_father": "Adopted",
"to_mother": "Birth"
},
{
"cita": [],
"index": 397,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 381,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 378,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 388,
"note": "",
"to_father": "Custom relationship to father",
"to_mother": "Custom relationship to mother"
},
{
"cita": [],
"index": 392,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 390,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 391,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 374,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 394,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 214,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 384,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 395,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 382,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 376,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 377,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 409,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 225,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 417,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 420,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 421,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 419,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 418,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 427,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 430,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 632,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 433,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 432,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 429,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 547,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 365,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 445,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 461,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 468,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 483,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 477,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 487,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 479,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 478,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 474,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 475,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 467,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 484,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 470,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 496,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 497,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 492,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 491,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 490,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 494,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 488,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 493,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 495,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 498,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 515,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 525,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 517,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 503,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 526,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 513,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 520,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 506,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 507,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 501,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 519,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 510,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 512,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 516,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 518,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 523,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 514,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 508,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 521,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 505,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 502,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 511,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 524,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 522,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 504,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 530,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 710,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 713,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 721,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 716,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 715,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 708,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 717,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 719,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 542,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 545,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 544,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 548,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 559,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 564,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 566,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 563,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 571,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 570,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1022,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 580,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 577,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 582,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 583,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 579,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 578,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 581,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 586,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 587,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 584,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 603,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 598,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 609,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 607,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 601,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 596,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 606,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 608,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 602,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 605,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 599,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 614,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 228,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 618,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 859,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 640,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 668,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 656,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 645,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 647,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 662,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 644,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 663,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 667,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 654,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 665,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 658,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 652,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 661,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 659,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 660,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 639,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 642,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 648,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 666,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 655,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 641,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 664,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 649,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 657,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 646,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 651,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 650,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 653,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 638,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 636,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 637,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 673,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 674,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 679,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 671,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 672,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 678,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 676,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 677,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 675,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1085,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 683,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 685,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 686,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 687,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 689,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 691,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 692,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 693,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 688,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 21,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 28,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 19,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 30,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 23,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 26,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 698,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 24,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 20,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 17,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 25,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 22,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 29,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 27,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 18,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 699,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 711,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 709,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 707,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 712,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 714,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 720,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 726,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 733,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 734,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 731,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 729,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 730,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 735,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 728,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 737,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 747,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 744,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 743,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 754,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 752,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 750,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 751,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 746,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 753,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 742,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 749,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 745,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 761,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 759,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 763,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 776,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 554,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 556,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 551,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 552,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 555,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 553,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 782,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 783,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 787,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 778,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 780,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 796,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 789,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 794,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 792,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 785,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 791,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 793,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 63,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 807,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 810,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 804,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 356,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 818,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 820,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 815,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 816,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 819,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 94,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 115,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 99,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 113,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 98,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 835,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 844,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 839,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 842,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 830,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 833,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 845,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 836,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 846,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 831,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"index": 854,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 123,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 573,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 861,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 216,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1074,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 177,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 158,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 165,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 170,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 597,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 610,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 604,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 600,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 869,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 873,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 874,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 878,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 131,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 270,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 894,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 892,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 891,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 902,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 905,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 915,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 911,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 912,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 916,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 908,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 919,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 910,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 913,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 906,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 918,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 909,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 927,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 969,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 941,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 955,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 950,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 934,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 932,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 949,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 965,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 953,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 936,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 946,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 960,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 931,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 967,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 938,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 970,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 948,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 939,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 959,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 954,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 971,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 942,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 978,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 968,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 947,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 973,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 958,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 929,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 977,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 951,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 972,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 930,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 940,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 966,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 944,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 963,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 937,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 962,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 975,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 943,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 924,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 935,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 952,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 933,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 964,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 961,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"index": 1004,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1013,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1005,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1001,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 998,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1002,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 993,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 983,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1012,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1011,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1009,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1006,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1016,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1014,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 986,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 997,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 996,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1010,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 984,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1003,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1000,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1015,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 990,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 988,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 994,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1008,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 985,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1007,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 992,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 991,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 987,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 999,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 995,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 572,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 1028,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1031,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1030,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"index": 1041,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1039,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1044,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1047,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 1061,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1052,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1058,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1057,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1054,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1056,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1055,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 1066,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1067,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1068,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 920,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 1081,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1083,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1129,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[],
[
{
"cita": [],
"index": 437,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1101,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1096,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 1109,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1113,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1110,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1111,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 46,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1116,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1117,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1032,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1108,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1106,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1105,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1107,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1104,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[
{
"cita": [],
"index": 105,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 100,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 112,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 106,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 110,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 97,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
},
{
"cita": [],
"index": 1127,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1126,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[
{
"cita": [],
"index": 1091,
"note": "",
"to_father": "Birth",
"to_mother": "Birth"
}
],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_F_chil_0.js');
