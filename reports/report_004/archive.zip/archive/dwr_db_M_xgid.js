// This file is generated

M_xgid = {}
Dwr.ScriptLoaded('dwr_db_M_xgid.js');
