// This file is generated

I_events_0 = [
[
{
"cita": [],
"date": "164-03-00 (Islamic)",
"date_sdn": 2006261,
"descr": "",
"gid": "E3406",
"media": [],
"part_family": [],
"part_person": [
0
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "204 (Islamic)",
"date_sdn": 2020376,
"descr": "",
"gid": "E3408",
"media": [],
"part_family": [],
"part_person": [
0,
2115
],
"place": -1,
"text": "",
"type": "Marriage"
},
{
"cita": [],
"date": "241-03-12 (Islamic)",
"date_sdn": 2033558,
"descr": "",
"gid": "E3409",
"media": [],
"part_family": [],
"part_person": [
0
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "203 (Islamic)",
"date_sdn": 2020022,
"descr": "",
"gid": "E3413",
"media": [],
"part_family": [],
"part_person": [
5
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "610",
"date_sdn": 1943858,
"descr": "",
"gid": "E3405",
"media": [],
"part_family": [],
"part_person": [
6,
9
],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[],
[
{
"cita": [],
"date": "213 (Islamic)",
"date_sdn": 2023566,
"descr": "",
"gid": "E3411",
"media": [],
"part_family": [],
"part_person": [
8
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "290 (Islamic)",
"date_sdn": 2050852,
"descr": "",
"gid": "E3412",
"media": [],
"part_family": [],
"part_person": [
8
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "570-04-19",
"date_sdn": 1929357,
"descr": "",
"gid": "E3403",
"media": [],
"part_family": [],
"part_person": [
9
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "632-06-08",
"date_sdn": 1952052,
"descr": "",
"gid": "E3404",
"media": [],
"part_family": [],
"part_person": [
9
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "610",
"date_sdn": 1943858,
"descr": "",
"gid": "E3405",
"media": [],
"part_family": [],
"part_person": [
6,
9
],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "about 1592",
"date_sdn": 2302526,
"descr": "Birth of Abbott, Frances",
"gid": "E0013",
"media": [],
"part_family": [],
"part_person": [
10
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1642-01-00",
"date_sdn": 2320789,
"descr": "Death of Abbott, Frances",
"gid": "E3415",
"media": [],
"part_family": [],
"part_person": [
10
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "between 1746 and 1755",
"date_sdn": 2358774,
"descr": "Birth of Adams, Jane",
"gid": "E1896",
"media": [],
"part_family": [],
"part_person": [
11
],
"place": 936,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "estimated from 1800 to 1805",
"date_sdn": 2378497,
"descr": "Death of Adams, Jane",
"gid": "E1897",
"media": [],
"part_family": [],
"part_person": [
11
],
"place": 558,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1700-10-26",
"date_sdn": 2342271,
"descr": "Birth of Adams, William",
"gid": "E2158",
"media": [],
"part_family": [],
"part_person": [
12
],
"place": 331,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1787-03-10",
"date_sdn": 2373817,
"descr": "Death of Adams, William",
"gid": "E2159",
"media": [],
"part_family": [],
"part_person": [
12
],
"place": 488,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1787",
"date_sdn": 2373749,
"descr": "Burial of Adams, William",
"gid": "E2160",
"media": [],
"part_family": [],
"part_person": [
12
],
"place": 918,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "after 1737-10-01",
"date_sdn": 2355760,
"descr": "Birth of Adkins, John",
"gid": "E1894",
"media": [],
"part_family": [],
"part_person": [
13
],
"place": 729,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1787-05-20",
"date_sdn": 2373888,
"descr": "Death of Adkins, John",
"gid": "E1895",
"media": [],
"part_family": [],
"part_person": [
13
],
"place": 1270,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1763-06-20",
"date_sdn": 2365153,
"descr": "Birth of Adkins, Martha",
"gid": "E1906",
"media": [],
"part_family": [],
"part_person": [
14
],
"place": 1064,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-09-05",
"date_sdn": 2388971,
"descr": "Death of Adkins, Martha",
"gid": "E1907",
"media": [],
"part_family": [],
"part_person": [
14
],
"place": 558,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Adkins, Martha",
"gid": "E1908",
"media": [],
"part_family": [],
"part_person": [
14
],
"place": 558,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Adkins, Minnie",
"gid": "E0555",
"media": [],
"part_family": [],
"part_person": [
15
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Adkins, Robert Sr.",
"gid": "E1893",
"media": [],
"part_family": [],
"part_person": [
16
],
"place": 587,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "after 1717",
"date_sdn": 2348182,
"descr": "Birth of Aguilar, Eleanor",
"gid": "E2161",
"media": [],
"part_family": [],
"part_person": [
17
],
"place": 499,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1760-02-00",
"date_sdn": 2363918,
"descr": "Death of Aguilar, Eleanor",
"gid": "E2162",
"media": [],
"part_family": [],
"part_person": [
17
],
"place": 936,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1665",
"date_sdn": 2329190,
"descr": "Birth of Aguilar, John",
"gid": "E2624",
"media": [],
"part_family": [],
"part_person": [
18
],
"place": 587,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1745-02-00",
"date_sdn": 2358440,
"descr": "Death of Aguilar, John",
"gid": "E2625",
"media": [],
"part_family": [],
"part_person": [
18
],
"place": 1270,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1690",
"date_sdn": 2338321,
"descr": "Birth of Allen, Abigail",
"gid": "E1134",
"media": [],
"part_family": [],
"part_person": [
20
],
"place": 1156,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1700",
"date_sdn": 2341973,
"descr": "Birth of Allen, Benjamin",
"gid": "E1142",
"media": [],
"part_family": [],
"part_person": [
21
],
"place": 1156,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762-03-10",
"date_sdn": 2364686,
"descr": "Death of Allen, Benjamin",
"gid": "E1143",
"media": [],
"part_family": [],
"part_person": [
21
],
"place": 269,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1667",
"date_sdn": 2329920,
"descr": "Birth of Allen, Enos",
"gid": "E1119",
"media": [],
"part_family": [],
"part_person": [
22
],
"place": 90,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1689-11-21",
"date_sdn": 2338280,
"descr": "Death of Allen, Enos",
"gid": "E1120",
"media": [],
"part_family": [],
"part_person": [
22
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1685",
"date_sdn": 2336495,
"descr": "Birth of Allen, Gershom",
"gid": "E1151",
"media": [],
"part_family": [],
"part_person": [
23
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1711",
"date_sdn": 2345990,
"descr": "Death of Allen, Gershom",
"gid": "E1152",
"media": [],
"part_family": [],
"part_person": [
23
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1670-08-00",
"date_sdn": 2331228,
"descr": "Birth of Allen, Joanna",
"gid": "E2126",
"media": [],
"part_family": [],
"part_person": [
24
],
"place": 947,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1694-06-09",
"date_sdn": 2339941,
"descr": "Birth of Allen, Job",
"gid": "E1136",
"media": [],
"part_family": [],
"part_person": [
25
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1674-05-24",
"date_sdn": 2332620,
"descr": "Birth of Allen, John",
"gid": "E1123",
"media": [],
"part_family": [],
"part_person": [
26
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Allen, John",
"gid": "E1124",
"media": [],
"part_family": [],
"part_person": [
26
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1683-05-29",
"date_sdn": 2335912,
"descr": "Birth of Allen, Jonathan",
"gid": "E1149",
"media": [],
"part_family": [],
"part_person": [
27
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1733-05-08",
"date_sdn": 2354153,
"descr": "Death of Allen, Jonathan",
"gid": "E1150",
"media": [],
"part_family": [],
"part_person": [
27
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1692-05-17",
"date_sdn": 2339188,
"descr": "Birth of Allen, Joseph",
"gid": "E1135",
"media": [],
"part_family": [],
"part_person": [
28
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1679-01-01",
"date_sdn": 2334303,
"descr": "Birth of Allen, Lediah",
"gid": "E1144",
"media": [],
"part_family": [],
"part_person": [
29
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1680",
"date_sdn": 2334668,
"descr": "Death of Allen, Lediah",
"gid": "E1145",
"media": [],
"part_family": [],
"part_person": [
29
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1698-04-28",
"date_sdn": 2341360,
"descr": "Birth of Allen, Lydia",
"gid": "E1141",
"media": [],
"part_family": [],
"part_person": [
30
],
"place": 1156,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1666-12-07",
"date_sdn": 2329895,
"descr": "Birth of Allen, Mary",
"gid": "E1118",
"media": [],
"part_family": [],
"part_person": [
31
],
"place": 90,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1696-05-12",
"date_sdn": 2340644,
"descr": "Birth of Allen, Rachel",
"gid": "E1137",
"media": [],
"part_family": [],
"part_person": [
32
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1747",
"date_sdn": 2359139,
"descr": "Death of Allen, Rachel",
"gid": "E1138",
"media": [],
"part_family": [],
"part_person": [
32
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1668-01-00",
"date_sdn": 2330285,
"descr": "Birth of Allen, Sarah",
"gid": "E1121",
"media": [],
"part_family": [],
"part_person": [
33
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1702",
"date_sdn": 2342703,
"descr": "Death of Allen, Sarah",
"gid": "E1122",
"media": [],
"part_family": [],
"part_person": [
33
],
"place": 1156,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alonso, Joseph",
"gid": "E2374",
"media": [],
"part_family": [],
"part_person": [
34
],
"place": 298,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1989",
"date_sdn": 2447528,
"descr": "Birth of Alonso, Laura",
"gid": "E2376",
"media": [],
"part_family": [],
"part_person": [
35
],
"place": 359,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1985",
"date_sdn": 2446067,
"descr": "Birth of Alonso, Roisine",
"gid": "E2375",
"media": [],
"part_family": [],
"part_person": [
36
],
"place": 359,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1984-04-04",
"date_sdn": 2445795,
"descr": "Birth of Alvarado, Andrew David",
"gid": "E1451",
"media": [],
"part_family": [],
"part_person": [
37
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1452",
"media": [],
"part_family": [],
"part_person": [
37
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Cadwallader",
"gid": "E2003",
"media": [],
"part_family": [],
"part_person": [
38
],
"place": 887,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Alvarado, Cadwallader",
"gid": "E2004",
"media": [],
"part_family": [],
"part_person": [
38
],
"place": 211,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Charles",
"gid": "E0639",
"media": [],
"part_family": [],
"part_person": [
39
],
"place": 250,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Alvarado, Charles",
"gid": "E0640",
"media": [],
"part_family": [],
"part_person": [
39
],
"place": 250,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Col. Charles",
"gid": "E1737",
"media": [],
"part_family": [],
"part_person": [
40
],
"place": 773,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-02-00",
"date_sdn": 2401903,
"descr": "Death of Alvarado, Col. Charles",
"gid": "E1738",
"media": [],
"part_family": [],
"part_person": [
40
],
"place": 719,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1864-02-00",
"date_sdn": 2401903,
"descr": "Burial of Alvarado, Col. Charles",
"gid": "E1739",
"media": [],
"part_family": [],
"part_person": [
40
],
"place": 719,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1971-04-15",
"date_sdn": 2441057,
"descr": "Birth of Alvarado, Douglas David",
"gid": "E1449",
"media": [],
"part_family": [],
"part_person": [
42
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1450",
"media": [],
"part_family": [],
"part_person": [
42
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Eliza",
"gid": "E0619",
"media": [],
"part_family": [],
"part_person": [
43
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Franklin",
"gid": "E0620",
"media": [],
"part_family": [],
"part_person": [
44
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1947-06-00",
"date_sdn": 2432338,
"descr": "Birth of Alvarado, Jack D.",
"gid": "E1442",
"media": [],
"part_family": [],
"part_person": [
45
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1443",
"media": [],
"part_family": [],
"part_person": [
45
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1821-01-25",
"date_sdn": 2386191,
"descr": "Birth of Alvarado, Jacob W.",
"gid": "E0616",
"media": [],
"part_family": [],
"part_person": [
46
],
"place": 722,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Alvarado, Jacob W.",
"gid": "E0617",
"media": [],
"part_family": [],
"part_person": [
46
],
"place": 970,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, James",
"gid": "E0626",
"media": [],
"part_family": [],
"part_person": [
48
],
"place": 250,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Alvarado, James",
"gid": "E0627",
"media": [],
"part_family": [],
"part_person": [
48
],
"place": 250,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1955-04-15",
"date_sdn": 2435213,
"descr": "Birth of Alvarado, Jeffery",
"gid": "E0154",
"media": [],
"part_family": [],
"part_person": [
49
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0155",
"media": [],
"part_family": [],
"part_person": [
49
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1825-03-13",
"date_sdn": 2387699,
"descr": "Birth of Alvarado, John",
"gid": "E0618",
"media": [],
"part_family": [],
"part_person": [
51
],
"place": 722,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Marsha",
"gid": "E0641",
"media": [],
"part_family": [],
"part_person": [
52
],
"place": 389,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Alvarado, Marsha",
"gid": "E0642",
"media": [],
"part_family": [],
"part_person": [
52
],
"place": 250,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Marshall",
"gid": "E0625",
"media": [],
"part_family": [],
"part_person": [
53
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Mary",
"gid": "E1858",
"media": [],
"part_family": [],
"part_person": [
54
],
"place": 998,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1760-01-17",
"date_sdn": 2363903,
"descr": "Death of Alvarado, Mary",
"gid": "E1859",
"media": [],
"part_family": [],
"part_person": [
54
],
"place": 947,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1986-04-05",
"date_sdn": 2446526,
"descr": "Birth of Alvarado, Matthew Vincent",
"gid": "E1453",
"media": [],
"part_family": [],
"part_person": [
55
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1454",
"media": [],
"part_family": [],
"part_person": [
55
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1968-09-30",
"date_sdn": 2440130,
"descr": "Birth of Alvarado, Michelle Lynn",
"gid": "E1447",
"media": [],
"part_family": [],
"part_person": [
56
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1448",
"media": [],
"part_family": [],
"part_person": [
56
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Nancy",
"gid": "E1735",
"media": [],
"part_family": [],
"part_person": [
57
],
"place": 815,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1861-03-12",
"date_sdn": 2400847,
"descr": "Death of Alvarado, Nancy",
"gid": "E1736",
"media": [],
"part_family": [],
"part_person": [
57
],
"place": 213,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, Thomas C.",
"gid": "E0622",
"media": [],
"part_family": [],
"part_person": [
60
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarado, William",
"gid": "E0621",
"media": [],
"part_family": [],
"part_person": [
62
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Alvarez, Mary",
"gid": "E1806",
"media": [],
"part_family": [],
"part_person": [
64
],
"place": 1172,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Alvarez, Mary",
"gid": "E1807",
"media": [],
"part_family": [],
"part_person": [
64
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Andersen, Samuel",
"gid": "E1186",
"media": [],
"part_family": [],
"part_person": [
68
],
"place": 712,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1858-02-00",
"date_sdn": 2399712,
"descr": "Death of Andersen, Samuel",
"gid": "E1187",
"media": [],
"part_family": [],
"part_person": [
68
],
"place": 744,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1719",
"date_sdn": 2348912,
"descr": "Birth of Anderson, Mary Molly",
"gid": "E1817",
"media": [],
"part_family": [],
"part_person": [
71
],
"place": 1062,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1795-04-20",
"date_sdn": 2376780,
"descr": "Death of Anderson, Mary Molly",
"gid": "E1818",
"media": [],
"part_family": [],
"part_person": [
71
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1685",
"date_sdn": 2336495,
"descr": "Birth of Anderson, Rev. John",
"gid": "E2132",
"media": [],
"part_family": [],
"part_person": [
72
],
"place": 762,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1774-11-27",
"date_sdn": 2369331,
"descr": "Death of Anderson, Rev. John",
"gid": "E2133",
"media": [],
"part_family": [],
"part_person": [
72
],
"place": 932,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1654",
"date_sdn": 2325172,
"descr": "Birth of Anderson, Samuel",
"gid": "E2226",
"media": [],
"part_family": [],
"part_person": [
73
],
"place": 80,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Anderson, Samuel",
"gid": "E2227",
"media": [],
"part_family": [],
"part_person": [
73
],
"place": 434,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1628",
"date_sdn": 2315675,
"descr": "Birth of Anderson, Thomas",
"gid": "E2223",
"media": [],
"part_family": [],
"part_person": [
74
],
"place": 624,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1687",
"date_sdn": 2337225,
"descr": "Death of Anderson, Thomas",
"gid": "E2224",
"media": [],
"part_family": [],
"part_person": [
74
],
"place": 396,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Andrews, Harold",
"gid": "E2078",
"media": [],
"part_family": [],
"part_person": [
75
],
"place": 19,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1933-11-24",
"date_sdn": 2427401,
"descr": "Birth of Andrews, William Arthur",
"gid": "E2093",
"media": [],
"part_family": [],
"part_person": [
76
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2094",
"media": [],
"part_family": [],
"part_person": [
76
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1906-07-24",
"date_sdn": 2417416,
"descr": "Birth of Armstrong, Teddy C.",
"gid": "E0586",
"media": [],
"part_family": [],
"part_person": [
79
],
"place": 1254,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1995-07-09",
"date_sdn": 2449908,
"descr": "Death of Armstrong, Teddy C.",
"gid": "E0587",
"media": [],
"part_family": [],
"part_person": [
79
],
"place": 24,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1632-05-15",
"date_sdn": 2317271,
"descr": "Birth of Austin, Johannas",
"gid": "E2589",
"media": [],
"part_family": [],
"part_person": [
82
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1667-05-00",
"date_sdn": 2330040,
"descr": "Birth of Baker, Margaret",
"gid": "E2606",
"media": [],
"part_family": [],
"part_person": [
83
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1741-10-25",
"date_sdn": 2357245,
"descr": "Death of Baker, Margaret",
"gid": "E2607",
"media": [],
"part_family": [],
"part_person": [
83
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1656",
"date_sdn": 2325902,
"descr": "Birth of Baldwin, Anne",
"gid": "E2703",
"media": [],
"part_family": [],
"part_person": [
84
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Baldwin, Anne",
"gid": "E2704",
"media": [],
"part_family": [],
"part_person": [
84
],
"place": 679,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Baldwin, Anne",
"gid": "E2705",
"media": [],
"part_family": [],
"part_person": [
84
],
"place": 679,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1869-07-08",
"date_sdn": 2403887,
"descr": "Birth of Ball, Abigail",
"gid": "E1233",
"media": [],
"part_family": [],
"part_person": [
86
],
"place": 900,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-04-21",
"date_sdn": 2430471,
"descr": "Death of Ball, Abigail",
"gid": "E1234",
"media": [],
"part_family": [],
"part_person": [
86
],
"place": 598,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1942-04-23",
"date_sdn": 2430473,
"descr": "Burial of Ball, Abigail",
"gid": "E1235",
"media": [],
"part_family": [],
"part_person": [
86
],
"place": 494,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ball, Ezekiel",
"gid": "E1904",
"media": [],
"part_family": [],
"part_person": [
87
],
"place": 800,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Ball, Ezekiel",
"gid": "E1905",
"media": [],
"part_family": [],
"part_person": [
87
],
"place": 800,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1876-03-17",
"date_sdn": 2406331,
"descr": "Birth of Ball, Ida B.",
"gid": "E1088",
"media": [],
"part_family": [],
"part_person": [
88
],
"place": 246,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1848-07-09",
"date_sdn": 2396218,
"descr": "Birth of Ball, Jane",
"gid": "E1090",
"media": [],
"part_family": [],
"part_person": [
90
],
"place": 1195,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1846-12-14",
"date_sdn": 2395645,
"descr": "Birth of Ball, Jasper",
"gid": "E1444",
"media": [],
"part_family": [],
"part_person": [
91
],
"place": 1230,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1906-08-04",
"date_sdn": 2417427,
"descr": "Death of Ball, Jasper",
"gid": "E1445",
"media": [],
"part_family": [],
"part_person": [
91
],
"place": 900,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1906-08-06",
"date_sdn": 2417429,
"descr": "Burial of Ball, Jasper",
"gid": "E1446",
"media": [],
"part_family": [],
"part_person": [
91
],
"place": 900,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1870-10-09",
"date_sdn": 2404345,
"descr": "Birth of Ball, Katie E.",
"gid": "E1085",
"media": [],
"part_family": [],
"part_person": [
93
],
"place": 246,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1870-11-11",
"date_sdn": 2404378,
"descr": "Death of Ball, Katie E.",
"gid": "E1086",
"media": [],
"part_family": [],
"part_person": [
93
],
"place": 70,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ball, Lucy A.",
"gid": "E1087",
"media": [],
"part_family": [],
"part_person": [
94
],
"place": 246,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1878-11-21",
"date_sdn": 2407310,
"descr": "Birth of Ball, Margaret",
"gid": "E1089",
"media": [],
"part_family": [],
"part_person": [
95
],
"place": 246,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1852-03-02",
"date_sdn": 2397550,
"descr": "Birth of Ball, Martha",
"gid": "E1091",
"media": [],
"part_family": [],
"part_person": [
96
],
"place": 1195,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1840-01-13",
"date_sdn": 2393118,
"descr": "Birth of Ball, Matthias",
"gid": "E1095",
"media": [],
"part_family": [],
"part_person": [
98
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1767-03-11",
"date_sdn": 2366513,
"descr": "Birth of Ball, Matthias Sr.",
"gid": "E1919",
"media": [],
"part_family": [],
"part_person": [
99
],
"place": 203,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1848-01-22",
"date_sdn": 2396049,
"descr": "Death of Ball, Matthias Sr.",
"gid": "E1920",
"media": [],
"part_family": [],
"part_person": [
99
],
"place": 845,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1810-08-07",
"date_sdn": 2382367,
"descr": "Birth of Ball, Matthias, Jr.",
"gid": "E1322",
"media": [],
"part_family": [],
"part_person": [
100
],
"place": 33,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1887-12-23",
"date_sdn": 2410629,
"descr": "Death of Ball, Matthias, Jr.",
"gid": "E1323",
"media": [],
"part_family": [],
"part_person": [
100
],
"place": 953,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1887-12-24",
"date_sdn": 2410630,
"descr": "Burial of Ball, Matthias, Jr.",
"gid": "E1324",
"media": [],
"part_family": [],
"part_person": [
100
],
"place": 914,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ball, Maude Waldon",
"gid": "E1083",
"media": [],
"part_family": [],
"part_person": [
101
],
"place": 246,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ball, Maude Waldon",
"gid": "E1084",
"media": [],
"part_family": [],
"part_person": [
101
],
"place": 509,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1871-10-14",
"date_sdn": 2404715,
"descr": "Birth of Ball, Robert Lee",
"gid": "E1082",
"media": [],
"part_family": [],
"part_person": [
103
],
"place": 117,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1728-04-18",
"date_sdn": 2352307,
"descr": "Birth of Ball, Thomas",
"gid": "E1915",
"media": [],
"part_family": [],
"part_person": [
104
],
"place": 800,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1861-10-19",
"date_sdn": 2401068,
"descr": "Birth of Ballard, Judith Ellen",
"gid": "E0339",
"media": [],
"part_family": [],
"part_person": [
107
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-05-20",
"date_sdn": 2416255,
"descr": "Death of Ballard, Judith Ellen",
"gid": "E0340",
"media": [],
"part_family": [],
"part_person": [
107
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1925-06-08",
"date_sdn": 2424310,
"descr": "Birth of Barber, Mary Elizabeth",
"gid": "E0598",
"media": [],
"part_family": [],
"part_person": [
108
],
"place": 551,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0599",
"media": [],
"part_family": [],
"part_person": [
108
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Barnes, Ernestina",
"gid": "E2306",
"media": [],
"part_family": [],
"part_person": [
110
],
"place": 74,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-04-15",
"date_sdn": 2438866,
"descr": "Death of Barnes, Ernestina",
"gid": "E2307",
"media": [],
"part_family": [],
"part_person": [
110
],
"place": 243,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Barnes, Ernestina",
"gid": "E2308",
"media": [],
"part_family": [],
"part_person": [
110
],
"place": 735,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1752",
"date_sdn": 2360965,
"descr": "Birth of Barnett, Anna Gertrude",
"gid": "E0395",
"media": [],
"part_family": [],
"part_person": [
111
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1600",
"date_sdn": 2305448,
"descr": "Birth of Barrett, Anne",
"gid": "E1839",
"media": [],
"part_family": [],
"part_person": [
112
],
"place": 327,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Bass, Mary",
"gid": "E1912",
"media": [],
"part_family": [],
"part_person": [
113
],
"place": 756,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1823-10-04",
"date_sdn": 2387173,
"descr": "Death of Bass, Mary",
"gid": "E1913",
"media": [],
"part_family": [],
"part_person": [
113
],
"place": 1034,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1984-10-29",
"date_sdn": 2446003,
"descr": "Birth of Bates, John Allen",
"gid": "E1465",
"media": [],
"part_family": [],
"part_person": [
114
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1466",
"media": [],
"part_family": [],
"part_person": [
114
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1982-08-03",
"date_sdn": 2445185,
"descr": "Birth of Bates, Stephen Michael",
"gid": "E1463",
"media": [],
"part_family": [],
"part_person": [
115
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1464",
"media": [],
"part_family": [],
"part_person": [
115
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-03-14",
"date_sdn": 2443217,
"descr": "Birth of Bates, Timothy Christian",
"gid": "E1461",
"media": [],
"part_family": [],
"part_person": [
116
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1462",
"media": [],
"part_family": [],
"part_person": [
116
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-08-04",
"date_sdn": 2433498,
"descr": "Birth of Bates, William Robert",
"gid": "E1459",
"media": [],
"part_family": [],
"part_person": [
117
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1460",
"media": [],
"part_family": [],
"part_person": [
117
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Birth of Beaulieu, Anna Catharina",
"gid": "E0411",
"media": [],
"part_family": [],
"part_person": [
118
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1706",
"date_sdn": 2344164,
"descr": "Birth of Beaulieu, Anna Elisabeth",
"gid": "E0404",
"media": [],
"part_family": [],
"part_person": [
119
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1772",
"date_sdn": 2368270,
"descr": "Death of Beaulieu, Anna Elisabeth",
"gid": "E0405",
"media": [],
"part_family": [],
"part_person": [
119
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1724",
"date_sdn": 2350738,
"descr": "Birth of Beaulieu, Anna Eva",
"gid": "E0423",
"media": [],
"part_family": [],
"part_person": [
120
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1760",
"date_sdn": 2363887,
"descr": "Death of Beaulieu, Anna Eva",
"gid": "E0424",
"media": [],
"part_family": [],
"part_person": [
120
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1726",
"date_sdn": 2351469,
"descr": "Birth of Beaulieu, Anna Margaretha",
"gid": "E0428",
"media": [],
"part_family": [],
"part_person": [
121
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1755",
"date_sdn": 2362061,
"descr": "Birth of Beaulieu, Anna Margaretha",
"gid": "E0401",
"media": [],
"part_family": [],
"part_person": [
122
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1796",
"date_sdn": 2377036,
"descr": "Death of Beaulieu, Anna Margaretha",
"gid": "E0402",
"media": [],
"part_family": [],
"part_person": [
122
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of Beaulieu, Anna Maria",
"gid": "E0412",
"media": [],
"part_family": [],
"part_person": [
123
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762",
"date_sdn": 2364618,
"descr": "Death of Beaulieu, Anna Maria",
"gid": "E0413",
"media": [],
"part_family": [],
"part_person": [
123
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1749",
"date_sdn": 2359870,
"descr": "Birth of Beaulieu, Anna Maria",
"gid": "E0396",
"media": [],
"part_family": [],
"part_person": [
124
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Death of Beaulieu, Anna Maria",
"gid": "E0397",
"media": [],
"part_family": [],
"part_person": [
124
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1722",
"date_sdn": 2350008,
"descr": "Birth of Beaulieu, Anna Ottilia",
"gid": "E0421",
"media": [],
"part_family": [],
"part_person": [
125
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1793",
"date_sdn": 2375941,
"descr": "Death of Beaulieu, Anna Ottilia",
"gid": "E0422",
"media": [],
"part_family": [],
"part_person": [
125
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1717",
"date_sdn": 2348182,
"descr": "Birth of Beaulieu, Johann Adam",
"gid": "E0415",
"media": [],
"part_family": [],
"part_person": [
126
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1803",
"date_sdn": 2379592,
"descr": "Death of Beaulieu, Johann Adam",
"gid": "E0416",
"media": [],
"part_family": [],
"part_person": [
126
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1738",
"date_sdn": 2355852,
"descr": "Birth of Beaulieu, Johann Adam",
"gid": "E0388",
"media": [],
"part_family": [],
"part_person": [
127
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1745",
"date_sdn": 2358409,
"descr": "Birth of Beaulieu, Johann Franciskus",
"gid": "E0391",
"media": [],
"part_family": [],
"part_person": [
128
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1826",
"date_sdn": 2387993,
"descr": "Death of Beaulieu, Johann Franciskus",
"gid": "E0392",
"media": [],
"part_family": [],
"part_person": [
128
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1711",
"date_sdn": 2345990,
"descr": "Birth of Beaulieu, Johann Michael",
"gid": "E0357",
"media": [],
"part_family": [],
"part_person": [
129
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0355",
"media": [],
"part_family": [],
"part_person": [
130
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1682",
"date_sdn": 2335399,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0359",
"media": [],
"part_family": [],
"part_person": [
131
],
"place": 566,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1728",
"date_sdn": 2352199,
"descr": "Birth of Beaulieu, Johann Simon",
"gid": "E0430",
"media": [],
"part_family": [],
"part_person": [
132
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1771",
"date_sdn": 2367905,
"descr": "Death of Beaulieu, Johann Simon",
"gid": "E0431",
"media": [],
"part_family": [],
"part_person": [
132
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1719",
"date_sdn": 2348912,
"descr": "Birth of Beaulieu, Johann Theobald",
"gid": "E0418",
"media": [],
"part_family": [],
"part_person": [
133
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Death of Beaulieu, Johann Theobald",
"gid": "E0419",
"media": [],
"part_family": [],
"part_person": [
133
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1708",
"date_sdn": 2344894,
"descr": "Birth of Beaulieu, Johann Valentin",
"gid": "E0406",
"media": [],
"part_family": [],
"part_person": [
134
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1802",
"date_sdn": 2379227,
"descr": "Death of Beaulieu, Johann Valentin",
"gid": "E0407",
"media": [],
"part_family": [],
"part_person": [
134
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1735",
"date_sdn": 2354756,
"descr": "Birth of Beaulieu, Johann Valentin",
"gid": "E0389",
"media": [],
"part_family": [],
"part_person": [
135
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1965-10-17",
"date_sdn": 2439051,
"descr": "Birth of B\u00e9langer, Amy Jo",
"gid": "E0613",
"media": [],
"part_family": [],
"part_person": [
140
],
"place": 708,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1944-05-16",
"date_sdn": 2431227,
"descr": "Birth of B\u00e9langer, Donald",
"gid": "E0612",
"media": [],
"part_family": [],
"part_person": [
141
],
"place": 708,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1916-04-06",
"date_sdn": 2420960,
"descr": "Birth of B\u00e9langer, James",
"gid": "E2084",
"media": [],
"part_family": [],
"part_person": [
142
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1964-07-02",
"date_sdn": 2438579,
"descr": "Death of B\u00e9langer, James",
"gid": "E2085",
"media": [],
"part_family": [],
"part_person": [
142
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of B\u00e9langer, James",
"gid": "E2086",
"media": [],
"part_family": [],
"part_person": [
142
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1940-12-30",
"date_sdn": 2429994,
"descr": "Birth of B\u00e9langer, Linda Ellen",
"gid": "E2109",
"media": [],
"part_family": [],
"part_person": [
143
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2110",
"media": [],
"part_family": [],
"part_person": [
143
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1946-03-10",
"date_sdn": 2431890,
"descr": "Birth of B\u00e9langer, Pamela Ann",
"gid": "E2111",
"media": [],
"part_family": [],
"part_person": [
144
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2112",
"media": [],
"part_family": [],
"part_person": [
144
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1980-02-12",
"date_sdn": 2444282,
"descr": "Birth of Bell, Brandy Nichole",
"gid": "E1688",
"media": [],
"part_family": [],
"part_person": [
145
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1689",
"media": [],
"part_family": [],
"part_person": [
145
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-09-06",
"date_sdn": 2433531,
"descr": "Birth of Bell, Gary Richard",
"gid": "E1650",
"media": [],
"part_family": [],
"part_person": [
146
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1651",
"media": [],
"part_family": [],
"part_person": [
146
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-04-26",
"date_sdn": 2443260,
"descr": "Birth of Bell, William Austin",
"gid": "E1686",
"media": [],
"part_family": [],
"part_person": [
147
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1687",
"media": [],
"part_family": [],
"part_person": [
147
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1786-08-17",
"date_sdn": 2373612,
"descr": "Birth of Benson, Col. David",
"gid": "E2278",
"media": [],
"part_family": [],
"part_person": [
150
],
"place": 1186,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1836-03-06",
"date_sdn": 2391710,
"descr": "Death of Benson, Col. David",
"gid": "E2279",
"media": [],
"part_family": [],
"part_person": [
150
],
"place": 507,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1742-05-07",
"date_sdn": 2357439,
"descr": "Birth of Benson, Col. Joseph",
"gid": "E2273",
"media": [],
"part_family": [],
"part_person": [
151
],
"place": 878,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1730",
"date_sdn": 2352930,
"descr": "Birth of Benson, David",
"gid": "E2275",
"media": [],
"part_family": [],
"part_person": [
152
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1777",
"date_sdn": 2370097,
"descr": "Death of Benson, David",
"gid": "E2276",
"media": [],
"part_family": [],
"part_person": [
152
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1715-01-30",
"date_sdn": 2347480,
"descr": "Birth of Benson, Elizabeth",
"gid": "E0704",
"media": [],
"part_family": [],
"part_person": [
153
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1685-04-13",
"date_sdn": 2336597,
"descr": "Birth of Benson, Elizabeth",
"gid": "E0712",
"media": [],
"part_family": [],
"part_person": [
154
],
"place": 920,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1674-11-20",
"date_sdn": 2332800,
"descr": "Birth of Benson, James",
"gid": "E0706",
"media": [],
"part_family": [],
"part_person": [
157
],
"place": 920,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1711-11-00",
"date_sdn": 2346294,
"descr": "Birth of Benson, James Edwin",
"gid": "E0702",
"media": [],
"part_family": [],
"part_person": [
158
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1713-11-00",
"date_sdn": 2347025,
"descr": "Birth of Benson, Jason Spotswood",
"gid": "E0703",
"media": [],
"part_family": [],
"part_person": [
159
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1707-06-10",
"date_sdn": 2344689,
"descr": "Birth of Benson, John",
"gid": "E0701",
"media": [],
"part_family": [],
"part_person": [
160
],
"place": 512,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Birth of Benson, John",
"gid": "E2277",
"media": [],
"part_family": [],
"part_person": [
161
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1702-05-06",
"date_sdn": 2342828,
"descr": "Birth of Benson, Joseph Louis(Jr.)",
"gid": "E2204",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": 253,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Benson, Joseph Louis(Jr.)",
"gid": "E2205",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": 38,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Benson, Joseph Louis(Jr.)",
"gid": "E2206",
"media": [],
"part_family": [],
"part_person": [
162
],
"place": 38,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1676-01-09",
"date_sdn": 2333215,
"descr": "Birth of Benson, Joseph Louis(Sr.)",
"gid": "E2268",
"media": [],
"part_family": [],
"part_person": [
163
],
"place": 542,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1680-03-15",
"date_sdn": 2334742,
"descr": "Birth of Benson, Louise DeSoix",
"gid": "E0710",
"media": [],
"part_family": [],
"part_person": [
164
],
"place": 920,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1719-09-10",
"date_sdn": 2349164,
"descr": "Birth of Benson, Martha Ellen",
"gid": "E0705",
"media": [],
"part_family": [],
"part_person": [
165
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1747",
"date_sdn": 2359139,
"descr": "Birth of Benson, Martha Ellen M.",
"gid": "E1750",
"media": [],
"part_family": [],
"part_person": [
166
],
"place": 628,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1806",
"date_sdn": 2380688,
"descr": "Death of Benson, Martha Ellen M.",
"gid": "E1751",
"media": [],
"part_family": [],
"part_person": [
166
],
"place": 282,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1682-02-20",
"date_sdn": 2335449,
"descr": "Birth of Benson, Mary Frances",
"gid": "E0711",
"media": [],
"part_family": [],
"part_person": [
168
],
"place": 920,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Benson, Robert",
"gid": "E0714",
"media": [],
"part_family": [],
"part_person": [
170
],
"place": 913,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1678-07-18",
"date_sdn": 2334136,
"descr": "Birth of Benson, Robert Watkins",
"gid": "E0707",
"media": [],
"part_family": [],
"part_person": [
171
],
"place": 920,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1740-03-00",
"date_sdn": 2356642,
"descr": "Birth of Benson, Samuel Sr.",
"gid": "E0715",
"media": [],
"part_family": [],
"part_person": [
172
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1704-03-09",
"date_sdn": 2343501,
"descr": "Birth of Benson, Thomas Stewart",
"gid": "E0700",
"media": [],
"part_family": [],
"part_person": [
173
],
"place": 253,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1709-08-10",
"date_sdn": 2345481,
"descr": "Birth of Benson, William",
"gid": "E2274",
"media": [],
"part_family": [],
"part_person": [
175
],
"place": 1207,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Bergeron, John Henry",
"gid": "E1705",
"media": [],
"part_family": [],
"part_person": [
176
],
"place": 983,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Bergeron, John Henry",
"gid": "E1706",
"media": [],
"part_family": [],
"part_person": [
176
],
"place": 366,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1922-12-30",
"date_sdn": 2423419,
"descr": "Death of Bernier, Margaret",
"gid": "E0239",
"media": [],
"part_family": [],
"part_person": [
178
],
"place": 1171,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1847-10-07",
"date_sdn": 2395942,
"descr": "Birth of Berry, Honorah",
"gid": "E1563",
"media": [],
"part_family": [],
"part_person": [
180
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1897-10-07",
"date_sdn": 2414205,
"descr": "Death of Berry, Honorah",
"gid": "E1564",
"media": [],
"part_family": [],
"part_person": [
180
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1664-09-29",
"date_sdn": 2329096,
"descr": "Birth of Bishop, Anna Barbara",
"gid": "E2262",
"media": [],
"part_family": [],
"part_person": [
181
],
"place": 518,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1717",
"date_sdn": 2348182,
"descr": "Death of Bishop, Anna Barbara",
"gid": "E2263",
"media": [],
"part_family": [],
"part_person": [
181
],
"place": 1226,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "after 1626",
"date_sdn": 2314945,
"descr": "Birth of Bishop, Quirinus",
"gid": "E0295",
"media": [],
"part_family": [],
"part_person": [
182
],
"place": 10,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1683-05-17",
"date_sdn": 2335900,
"descr": "Death of Bishop, Quirinus",
"gid": "E0296",
"media": [],
"part_family": [],
"part_person": [
182
],
"place": 10,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1584",
"date_sdn": 2299604,
"descr": "Birth of Black, Jane",
"gid": "E0012",
"media": [],
"part_family": [],
"part_person": [
183
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1803-05-23",
"date_sdn": 2379734,
"descr": "Birth of Blair, Jane",
"gid": "E0734",
"media": [],
"part_family": [],
"part_person": [
184
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-03-10",
"date_sdn": 2402671,
"descr": "Death of Blair, Jane",
"gid": "E0735",
"media": [],
"part_family": [],
"part_person": [
184
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Blake, Conrad",
"gid": "E1717",
"media": [],
"part_family": [],
"part_person": [
186
],
"place": 628,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Blake, Conrad",
"gid": "E1718",
"media": [],
"part_family": [],
"part_person": [
186
],
"place": 275,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1806-07-11",
"date_sdn": 2380879,
"descr": "Birth of Blake, George",
"gid": "E1711",
"media": [],
"part_family": [],
"part_person": [
187
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1885-06-27",
"date_sdn": 2409720,
"descr": "Death of Blake, George",
"gid": "E1712",
"media": [],
"part_family": [],
"part_person": [
187
],
"place": 1017,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Blake, George",
"gid": "E1713",
"media": [],
"part_family": [],
"part_person": [
187
],
"place": 467,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1832-09-05",
"date_sdn": 2390432,
"descr": "Birth of Blake, M. Susannah",
"gid": "E2113",
"media": [],
"part_family": [],
"part_person": [
188
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-05-25",
"date_sdn": 2422835,
"descr": "Death of Blake, M. Susannah",
"gid": "E2114",
"media": [],
"part_family": [],
"part_person": [
188
],
"place": 467,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-05-27",
"date_sdn": 2422837,
"descr": "Burial of Blake, M. Susannah",
"gid": "E2115",
"media": [],
"part_family": [],
"part_person": [
188
],
"place": 467,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1555",
"date_sdn": 2289012,
"descr": "Birth of Blanco, Bendicht",
"gid": "E2574",
"media": [],
"part_family": [],
"part_person": [
191
],
"place": 764,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1752",
"date_sdn": 2360965,
"descr": "Birth of Blanco, Daniel",
"gid": "E0795",
"media": [],
"part_family": [],
"part_person": [
193
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805",
"date_sdn": 2380323,
"descr": "Death of Blanco, Daniel",
"gid": "E0796",
"media": [],
"part_family": [],
"part_person": [
193
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1718-01-27",
"date_sdn": 2348573,
"descr": "Birth of Blanco, Gerhard",
"gid": "E2553",
"media": [],
"part_family": [],
"part_person": [
195
],
"place": 861,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1783-04-26",
"date_sdn": 2372403,
"descr": "Death of Blanco, Gerhard",
"gid": "E2554",
"media": [],
"part_family": [],
"part_person": [
195
],
"place": 789,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1528",
"date_sdn": 2279150,
"descr": "Birth of Blanco, Hans",
"gid": "E2572",
"media": [],
"part_family": [],
"part_person": [
196
],
"place": 1158,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1582-01-07",
"date_sdn": 2298880,
"descr": "Birth of Blanco, Hans",
"gid": "E2575",
"media": [],
"part_family": [],
"part_person": [
197
],
"place": 764,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1494",
"date_sdn": 2266733,
"descr": "Birth of Blanco, Hans",
"gid": "E2571",
"media": [],
"part_family": [],
"part_person": [
198
],
"place": 18,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1680-03-28",
"date_sdn": 2334755,
"descr": "Birth of Blanco, Hans(Johannes)",
"gid": "E2582",
"media": [],
"part_family": [],
"part_person": [
199
],
"place": 177,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Blanco, Hans(Johannes)",
"gid": "E2583",
"media": [],
"part_family": [],
"part_person": [
199
],
"place": 936,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1639-11-10",
"date_sdn": 2320006,
"descr": "Birth of Blanco, Heinrich",
"gid": "E2577",
"media": [],
"part_family": [],
"part_person": [
200
],
"place": 764,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1847",
"date_sdn": 2395663,
"descr": "Death of Blanco, Henry",
"gid": "E0788",
"media": [],
"part_family": [],
"part_person": [
201
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1779",
"date_sdn": 2370827,
"descr": "Birth of Blanco, John Sr.",
"gid": "E2558",
"media": [],
"part_family": [],
"part_person": [
202
],
"place": 162,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Blanco, John Sr.",
"gid": "E2559",
"media": [],
"part_family": [],
"part_person": [
202
],
"place": 663,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Blanco, John Sr.",
"gid": "E2560",
"media": [],
"part_family": [],
"part_person": [
202
],
"place": 151,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1838",
"date_sdn": 2392376,
"descr": "Birth of Blanco, John W.",
"gid": "E2479",
"media": [],
"part_family": [],
"part_person": [
203
],
"place": 1042,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1856",
"date_sdn": 2398950,
"descr": "Birth of Blanco, L. J.",
"gid": "E2492",
"media": [],
"part_family": [],
"part_person": [
204
],
"place": 164,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1849-01-25",
"date_sdn": 2396418,
"descr": "Birth of Blanco, Lucinda Catherine",
"gid": "E2145",
"media": [],
"part_family": [],
"part_person": [
205
],
"place": 685,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1932-10-21",
"date_sdn": 2427002,
"descr": "Death of Blanco, Lucinda Catherine",
"gid": "E2146",
"media": [],
"part_family": [],
"part_person": [
205
],
"place": 899,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1932-10-23",
"date_sdn": 2427004,
"descr": "Burial of Blanco, Lucinda Catherine",
"gid": "E2147",
"media": [],
"part_family": [],
"part_person": [
205
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1836-11-15",
"date_sdn": 2391964,
"descr": "Birth of Blanco, Malvina",
"gid": "E2476",
"media": [],
"part_family": [],
"part_person": [
206
],
"place": 1042,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-03-07",
"date_sdn": 2421660,
"descr": "Death of Blanco, Malvina",
"gid": "E2477",
"media": [],
"part_family": [],
"part_person": [
206
],
"place": 824,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1918-03-09",
"date_sdn": 2421662,
"descr": "Burial of Blanco, Malvina",
"gid": "E2478",
"media": [],
"part_family": [],
"part_person": [
206
],
"place": 166,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Blanco, Mary F.",
"gid": "E2480",
"media": [],
"part_family": [],
"part_person": [
209
],
"place": 1042,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1854",
"date_sdn": 2398220,
"descr": "Birth of Blanco, Milton",
"gid": "E2488",
"media": [],
"part_family": [],
"part_person": [
210
],
"place": 1106,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1462",
"date_sdn": 2255045,
"descr": "Birth of Blanco, Mr.",
"gid": "E2570",
"media": [],
"part_family": [],
"part_person": [
211
],
"place": 18,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Blanco, Paris",
"gid": "E2481",
"media": [],
"part_family": [],
"part_person": [
212
],
"place": 1042,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "20",
"date_sdn": 1728365,
"descr": "Birth of Blanco, Rufus",
"gid": "E1978",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 162,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-11-04",
"date_sdn": 2402910,
"descr": "Death of Blanco, Rufus",
"gid": "E1979",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 104,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1866-11-06",
"date_sdn": 2402912,
"descr": "Burial of Blanco, Rufus",
"gid": "E1980",
"media": [],
"part_family": [],
"part_person": [
215
],
"place": 1022,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1759-01-02",
"date_sdn": 2363523,
"descr": "Birth of Blanco, Samuel",
"gid": "E0793",
"media": [],
"part_family": [],
"part_person": [
216
],
"place": 789,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1840-01-14",
"date_sdn": 2393119,
"descr": "Death of Blanco, Samuel",
"gid": "E0794",
"media": [],
"part_family": [],
"part_person": [
216
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1851-04-14",
"date_sdn": 2397227,
"descr": "Birth of Blanco, Stephen",
"gid": "E2485",
"media": [],
"part_family": [],
"part_person": [
217
],
"place": 152,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-04-08",
"date_sdn": 2416213,
"descr": "Death of Blanco, Stephen",
"gid": "E2486",
"media": [],
"part_family": [],
"part_person": [
217
],
"place": 252,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1903-04-10",
"date_sdn": 2416215,
"descr": "Burial of Blanco, Stephen",
"gid": "E2487",
"media": [],
"part_family": [],
"part_person": [
217
],
"place": 142,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1968",
"date_sdn": 2439857,
"descr": "Birth of Boucher, Agnes",
"gid": "E2388",
"media": [],
"part_family": [],
"part_person": [
219
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2389",
"media": [],
"part_family": [],
"part_person": [
219
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1962",
"date_sdn": 2437666,
"descr": "Birth of Boucher, Anne",
"gid": "E2377",
"media": [],
"part_family": [],
"part_person": [
220
],
"place": 586,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2378",
"media": [],
"part_family": [],
"part_person": [
220
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Bishop Patrick",
"gid": "E0869",
"media": [],
"part_family": [],
"part_person": [
221
],
"place": 350,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1850-05-14",
"date_sdn": 2396892,
"descr": "Birth of Boucher, Bridget",
"gid": "E1569",
"media": [],
"part_family": [],
"part_person": [
222
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1922-05-11",
"date_sdn": 2423186,
"descr": "Death of Boucher, Bridget",
"gid": "E1570",
"media": [],
"part_family": [],
"part_person": [
222
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Bridget",
"gid": "E2333",
"media": [],
"part_family": [],
"part_person": [
223
],
"place": 40,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1965",
"date_sdn": 2438762,
"descr": "Birth of Boucher, Bridget",
"gid": "E2386",
"media": [],
"part_family": [],
"part_person": [
224
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2387",
"media": [],
"part_family": [],
"part_person": [
224
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1816",
"date_sdn": 2384340,
"descr": "Birth of Boucher, Catherine",
"gid": "E2327",
"media": [],
"part_family": [],
"part_person": [
225
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1857",
"date_sdn": 2399316,
"descr": "Death of Boucher, Catherine",
"gid": "E2328",
"media": [],
"part_family": [],
"part_person": [
225
],
"place": 504,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1857",
"date_sdn": 2399316,
"descr": "Burial of Boucher, Catherine",
"gid": "E2329",
"media": [],
"part_family": [],
"part_person": [
225
],
"place": 1177,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1869-07-05",
"date_sdn": 2403884,
"descr": "Birth of Boucher, Catherine",
"gid": "E1565",
"media": [],
"part_family": [],
"part_person": [
226
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1890-01-19",
"date_sdn": 2411387,
"descr": "Death of Boucher, Catherine",
"gid": "E1566",
"media": [],
"part_family": [],
"part_person": [
226
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1961-12-05",
"date_sdn": 2437639,
"descr": "Birth of Boucher, Cynthia Louise",
"gid": "E2538",
"media": [],
"part_family": [],
"part_person": [
230
],
"place": 28,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2539",
"media": [],
"part_family": [],
"part_person": [
230
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, David",
"gid": "E2321",
"media": [],
"part_family": [],
"part_person": [
231
],
"place": 335,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, David",
"gid": "E2322",
"media": [],
"part_family": [],
"part_person": [
231
],
"place": 373,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, David",
"gid": "E2323",
"media": [],
"part_family": [],
"part_person": [
231
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1976",
"date_sdn": 2442779,
"descr": "Birth of Boucher, Flannan",
"gid": "E2339",
"media": [],
"part_family": [],
"part_person": [
235
],
"place": 586,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2340",
"media": [],
"part_family": [],
"part_person": [
235
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Fr. Daniel Gabriel",
"gid": "E2411",
"media": [],
"part_family": [],
"part_person": [
236
],
"place": 1120,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, Fr. Daniel Gabriel",
"gid": "E2412",
"media": [],
"part_family": [],
"part_person": [
236
],
"place": 354,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Fr. Patrick",
"gid": "E2410",
"media": [],
"part_family": [],
"part_person": [
237
],
"place": 1120,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1896-07-24",
"date_sdn": 2413765,
"descr": "Birth of Boucher, Fr.Lawrence M.",
"gid": "E1800",
"media": [],
"part_family": [],
"part_person": [
238
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1972-05-03",
"date_sdn": 2441441,
"descr": "Death of Boucher, Fr.Lawrence M.",
"gid": "E1801",
"media": [],
"part_family": [],
"part_person": [
238
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Fr.Lawrence M.",
"gid": "E1802",
"media": [],
"part_family": [],
"part_person": [
238
],
"place": 1051,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Birth of Boucher, Honora",
"gid": "E2641",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-09",
"date_sdn": 2413234,
"descr": "Death of Boucher, Honora",
"gid": "E2642",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1895-02-00",
"date_sdn": 2413226,
"descr": "Burial of Boucher, Honora",
"gid": "E2643",
"media": [],
"part_family": [],
"part_person": [
241
],
"place": 657,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, James",
"gid": "E1550",
"media": [],
"part_family": [],
"part_person": [
244
],
"place": 893,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1929",
"date_sdn": 2425613,
"descr": "Birth of Boucher, John",
"gid": "E1778",
"media": [],
"part_family": [],
"part_person": [
246
],
"place": 487,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1779",
"media": [],
"part_family": [],
"part_person": [
246
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1991-04-16",
"date_sdn": 2448363,
"descr": "Birth of Boucher, Kyle Joseph",
"gid": "E2542",
"media": [],
"part_family": [],
"part_person": [
247
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2543",
"media": [],
"part_family": [],
"part_person": [
247
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1963",
"date_sdn": 2438031,
"descr": "Birth of Boucher, Martha",
"gid": "E2384",
"media": [],
"part_family": [],
"part_person": [
249
],
"place": 586,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2385",
"media": [],
"part_family": [],
"part_person": [
249
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0902",
"media": [],
"part_family": [],
"part_person": [
251
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1963",
"date_sdn": 2438031,
"descr": "Birth of Boucher, Mary",
"gid": "E2379",
"media": [],
"part_family": [],
"part_person": [
253
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2380",
"media": [],
"part_family": [],
"part_person": [
253
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1890-02-17",
"date_sdn": 2411416,
"descr": "Birth of Boucher, Mary Cecilia",
"gid": "E1889",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1945-06-03",
"date_sdn": 2431610,
"descr": "Death of Boucher, Mary Cecilia",
"gid": "E1890",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1945-06-05",
"date_sdn": 2431612,
"descr": "Burial of Boucher, Mary Cecilia",
"gid": "E1891",
"media": [],
"part_family": [],
"part_person": [
254
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1885",
"date_sdn": 2409543,
"descr": "Birth of Boucher, Mary Josephine",
"gid": "E0859",
"media": [],
"part_family": [],
"part_person": [
255
],
"place": 1120,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1920-02-18",
"date_sdn": 2422373,
"descr": "Death of Boucher, Michael",
"gid": "E1562",
"media": [],
"part_family": [],
"part_person": [
256
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1820",
"date_sdn": 2385801,
"descr": "Birth of Boucher, Michael",
"gid": "E2619",
"media": [],
"part_family": [],
"part_person": [
257
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1859-01-09",
"date_sdn": 2400054,
"descr": "Death of Boucher, Michael",
"gid": "E2620",
"media": [],
"part_family": [],
"part_person": [
257
],
"place": 85,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1859",
"date_sdn": 2400046,
"descr": "Burial of Boucher, Michael",
"gid": "E2621",
"media": [],
"part_family": [],
"part_person": [
257
],
"place": 657,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0898",
"media": [],
"part_family": [],
"part_person": [
259
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Michael",
"gid": "E2346",
"media": [],
"part_family": [],
"part_person": [
260
],
"place": 40,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1883",
"date_sdn": 2408812,
"descr": "Birth of Boucher, Michael",
"gid": "E1775",
"media": [],
"part_family": [],
"part_person": [
261
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, Michael",
"gid": "E1776",
"media": [],
"part_family": [],
"part_person": [
261
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Michael",
"gid": "E1777",
"media": [],
"part_family": [],
"part_person": [
261
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-05-10",
"date_sdn": 2408941,
"descr": "Birth of Boucher, Michael J.",
"gid": "E1547",
"media": [],
"part_family": [],
"part_person": [
262
],
"place": 893,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Michael Shannon",
"gid": "E0866",
"media": [],
"part_family": [],
"part_person": [
263
],
"place": 1255,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0899",
"media": [],
"part_family": [],
"part_person": [
264
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973",
"date_sdn": 2441684,
"descr": "Birth of Boucher, Miread",
"gid": "E2341",
"media": [],
"part_family": [],
"part_person": [
265
],
"place": 586,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2342",
"media": [],
"part_family": [],
"part_person": [
265
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1879-07-18",
"date_sdn": 2407549,
"descr": "Birth of Boucher, Nora A.",
"gid": "E1545",
"media": [],
"part_family": [],
"part_person": [
267
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1939-08-15",
"date_sdn": 2429491,
"descr": "Death of Boucher, Nora A.",
"gid": "E1546",
"media": [],
"part_family": [],
"part_person": [
267
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1970",
"date_sdn": 2440588,
"descr": "Birth of Boucher, Norene",
"gid": "E2390",
"media": [],
"part_family": [],
"part_person": [
268
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2391",
"media": [],
"part_family": [],
"part_person": [
268
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Patrick",
"gid": "E2330",
"media": [],
"part_family": [],
"part_person": [
269
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, Patrick",
"gid": "E2331",
"media": [],
"part_family": [],
"part_person": [
269
],
"place": 949,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Patrick",
"gid": "E2332",
"media": [],
"part_family": [],
"part_person": [
269
],
"place": 183,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Patrick",
"gid": "E0862",
"media": [],
"part_family": [],
"part_person": [
270
],
"place": 1120,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1886",
"date_sdn": 2409908,
"descr": "Birth of Boucher, Prof. William Joseph",
"gid": "E2413",
"media": [],
"part_family": [],
"part_person": [
271
],
"place": 1120,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1977-01-26",
"date_sdn": 2443170,
"descr": "Death of Boucher, Prof. William Joseph",
"gid": "E2414",
"media": [],
"part_family": [],
"part_person": [
271
],
"place": 354,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1940-01-04",
"date_sdn": 2429633,
"descr": "Birth of Boucher, Roger Joseph",
"gid": "E2523",
"media": [],
"part_family": [],
"part_person": [
272
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2524",
"media": [],
"part_family": [],
"part_person": [
272
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1926-09-15",
"date_sdn": 2424774,
"descr": "Birth of Boucher, Rose Mary",
"gid": "E2356",
"media": [],
"part_family": [],
"part_person": [
273
],
"place": 923,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2357",
"media": [],
"part_family": [],
"part_person": [
273
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1837",
"date_sdn": 2392011,
"descr": "Birth of Boucher, Sean",
"gid": "E1772",
"media": [],
"part_family": [],
"part_person": [
274
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, Sean",
"gid": "E1773",
"media": [],
"part_family": [],
"part_person": [
274
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Sean",
"gid": "E1774",
"media": [],
"part_family": [],
"part_person": [
274
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1943-11-26",
"date_sdn": 2431055,
"descr": "Birth of Boucher, Sharon",
"gid": "E1793",
"media": [],
"part_family": [],
"part_person": [
275
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1973-06-11",
"date_sdn": 2441845,
"descr": "Death of Boucher, Sharon",
"gid": "E1794",
"media": [],
"part_family": [],
"part_person": [
275
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Stephen Francis",
"gid": "E2353",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 1120,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1975-08-24",
"date_sdn": 2442649,
"descr": "Death of Boucher, Stephen Francis",
"gid": "E2354",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 1120,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1975-08-00",
"date_sdn": 2442626,
"descr": "Burial of Boucher, Stephen Francis",
"gid": "E2355",
"media": [],
"part_family": [],
"part_person": [
276
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1963-07-17",
"date_sdn": 2438228,
"descr": "Birth of Boucher, Steven Joseph",
"gid": "E2540",
"media": [],
"part_family": [],
"part_person": [
277
],
"place": 1187,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2541",
"media": [],
"part_family": [],
"part_person": [
277
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, Thomas",
"gid": "E1769",
"media": [],
"part_family": [],
"part_person": [
279
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, Thomas",
"gid": "E1770",
"media": [],
"part_family": [],
"part_person": [
279
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, Thomas",
"gid": "E1771",
"media": [],
"part_family": [],
"part_person": [
279
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1840-12-24",
"date_sdn": 2393464,
"descr": "Birth of Boucher, Thomas",
"gid": "E1556",
"media": [],
"part_family": [],
"part_person": [
280
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1885-07-29",
"date_sdn": 2409752,
"descr": "Death of Boucher, Thomas",
"gid": "E1557",
"media": [],
"part_family": [],
"part_person": [
280
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1888-12-06",
"date_sdn": 2410978,
"descr": "Birth of Boucher, Thomas W.",
"gid": "E1548",
"media": [],
"part_family": [],
"part_person": [
283
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-04-02",
"date_sdn": 2430452,
"descr": "Death of Boucher, Thomas W.",
"gid": "E1549",
"media": [],
"part_family": [],
"part_person": [
283
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1984",
"date_sdn": 2445701,
"descr": "Birth of Boucher, Tony",
"gid": "E0900",
"media": [],
"part_family": [],
"part_person": [
284
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0901",
"media": [],
"part_family": [],
"part_person": [
284
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0903",
"media": [],
"part_family": [],
"part_person": [
285
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1870-09-10",
"date_sdn": 2404316,
"descr": "Birth of Boucher, William",
"gid": "E1567",
"media": [],
"part_family": [],
"part_person": [
287
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-06-26",
"date_sdn": 2430902,
"descr": "Death of Boucher, William",
"gid": "E1568",
"media": [],
"part_family": [],
"part_person": [
287
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, William",
"gid": "E2334",
"media": [],
"part_family": [],
"part_person": [
288
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, William",
"gid": "E2335",
"media": [],
"part_family": [],
"part_person": [
288
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, William",
"gid": "E2336",
"media": [],
"part_family": [],
"part_person": [
288
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, William",
"gid": "E2347",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 40,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Boucher, William",
"gid": "E2348",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 1120,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Boucher, William",
"gid": "E2349",
"media": [],
"part_family": [],
"part_person": [
289
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1851-02-07",
"date_sdn": 2397161,
"descr": "Birth of Boucher, William",
"gid": "E2350",
"media": [],
"part_family": [],
"part_person": [
290
],
"place": 1120,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-08-02",
"date_sdn": 2434227,
"descr": "Death of Boucher, William",
"gid": "E2351",
"media": [],
"part_family": [],
"part_person": [
290
],
"place": 1120,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1952-08-03",
"date_sdn": 2434228,
"descr": "Burial of Boucher, William",
"gid": "E2352",
"media": [],
"part_family": [],
"part_person": [
290
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1854-01-25",
"date_sdn": 2398244,
"descr": "Birth of Boucher, William Bernard",
"gid": "E1811",
"media": [],
"part_family": [],
"part_person": [
291
],
"place": 1175,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-27",
"date_sdn": 2425608,
"descr": "Death of Boucher, William Bernard",
"gid": "E1812",
"media": [],
"part_family": [],
"part_person": [
291
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1928-12-29",
"date_sdn": 2425610,
"descr": "Burial of Boucher, William Bernard",
"gid": "E1813",
"media": [],
"part_family": [],
"part_person": [
291
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1944-01-13",
"date_sdn": 2431103,
"descr": "Death of Boucher, William C.",
"gid": "E1558",
"media": [],
"part_family": [],
"part_person": [
292
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Boucher, William Donel",
"gid": "E2415",
"media": [],
"part_family": [],
"part_person": [
293
],
"place": 255,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1941-01-11",
"date_sdn": 2430006,
"descr": "Birth of Boucher, William J.",
"gid": "E1790",
"media": [],
"part_family": [],
"part_person": [
295
],
"place": 847,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1994-10-31",
"date_sdn": 2449657,
"descr": "Death of Boucher, William J.",
"gid": "E1791",
"media": [],
"part_family": [],
"part_person": [
295
],
"place": 781,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1994-11-03",
"date_sdn": 2449660,
"descr": "Burial of Boucher, William J.",
"gid": "E1792",
"media": [],
"part_family": [],
"part_person": [
295
],
"place": 683,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1971",
"date_sdn": 2440953,
"descr": "Birth of Boucher, William J.",
"gid": "E2736",
"media": [],
"part_family": [],
"part_person": [
296
],
"place": 528,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1897-08-14",
"date_sdn": 2414151,
"descr": "Birth of Boyd, Carmen Alberta",
"gid": "E1155",
"media": [],
"part_family": [],
"part_person": [
300
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1949-06-17",
"date_sdn": 2433085,
"descr": "Death of Boyd, Carmen Alberta",
"gid": "E1156",
"media": [],
"part_family": [],
"part_person": [
300
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1868-03-27",
"date_sdn": 2403419,
"descr": "Birth of Boyd, Charles Newton",
"gid": "E0466",
"media": [],
"part_family": [],
"part_person": [
301
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1920-03-21",
"date_sdn": 2422405,
"descr": "Death of Boyd, Charles Newton",
"gid": "E0467",
"media": [],
"part_family": [],
"part_person": [
301
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1901-07-08",
"date_sdn": 2415574,
"descr": "Birth of Boyd, Lauretta Esther",
"gid": "E1157",
"media": [],
"part_family": [],
"part_person": [
302
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1789",
"date_sdn": 2374480,
"descr": "Birth of Bradley, Mary",
"gid": "E0372",
"media": [],
"part_family": [],
"part_person": [
303
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0881",
"media": [],
"part_family": [],
"part_person": [
304
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0875",
"media": [],
"part_family": [],
"part_person": [
306
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0882",
"media": [],
"part_family": [],
"part_person": [
307
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0873",
"media": [],
"part_family": [],
"part_person": [
308
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1988",
"date_sdn": 2447162,
"descr": "Birth of Brady, Roisin",
"gid": "E0879",
"media": [],
"part_family": [],
"part_person": [
309
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0880",
"media": [],
"part_family": [],
"part_person": [
309
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0874",
"media": [],
"part_family": [],
"part_person": [
310
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0878",
"media": [],
"part_family": [],
"part_person": [
311
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1939-08-05",
"date_sdn": 2429481,
"descr": "Birth of Briggs, Joyce Inez",
"gid": "E1638",
"media": [],
"part_family": [],
"part_person": [
312
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1985",
"date_sdn": 2446067,
"descr": "Death of Briggs, Joyce Inez",
"gid": "E1639",
"media": [],
"part_family": [],
"part_person": [
312
],
"place": 543,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1971-11-10",
"date_sdn": 2441266,
"descr": "Birth of Brock, Celeste Ellen",
"gid": "E2453",
"media": [],
"part_family": [],
"part_person": [
313
],
"place": 1103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2454",
"media": [],
"part_family": [],
"part_person": [
313
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1969-11-13",
"date_sdn": 2440539,
"descr": "Birth of Brock, Lance Edward",
"gid": "E2451",
"media": [],
"part_family": [],
"part_person": [
314
],
"place": 202,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2452",
"media": [],
"part_family": [],
"part_person": [
314
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-06-20",
"date_sdn": 2432723,
"descr": "Birth of Brock, Stephen",
"gid": "E2442",
"media": [],
"part_family": [],
"part_person": [
315
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2443",
"media": [],
"part_family": [],
"part_person": [
315
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Brooks, Elizabeth&#8220;Betty&#8221;",
"gid": "E2638",
"media": [],
"part_family": [],
"part_person": [
316
],
"place": 328,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Brooks, Elizabeth&#8220;Betty&#8221;",
"gid": "E2639",
"media": [],
"part_family": [],
"part_person": [
316
],
"place": 308,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Brooks, Elizabeth&#8220;Betty&#8221;",
"gid": "E2640",
"media": [],
"part_family": [],
"part_person": [
316
],
"place": 1001,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1642",
"date_sdn": 2320789,
"descr": "Birth of Brooks, Guillaume de",
"gid": "E0174",
"media": [],
"part_family": [],
"part_person": [
319
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Brooks, Major Marquis II",
"gid": "E2633",
"media": [],
"part_family": [],
"part_person": [
322
],
"place": 95,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1755-05-10",
"date_sdn": 2362190,
"descr": "Death of Brooks, Major Marquis II",
"gid": "E2634",
"media": [],
"part_family": [],
"part_person": [
322
],
"place": 322,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1675",
"date_sdn": 2332842,
"descr": "Birth of Brooks, Marquis I",
"gid": "E2631",
"media": [],
"part_family": [],
"part_person": [
323
],
"place": 1134,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1741",
"date_sdn": 2356948,
"descr": "Death of Brooks, Marquis I",
"gid": "E2632",
"media": [],
"part_family": [],
"part_person": [
323
],
"place": 726,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1755-02-26",
"date_sdn": 2362117,
"descr": "Birth of Brooks, Marquis IV",
"gid": "E0166",
"media": [],
"part_family": [],
"part_person": [
324
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1839-02-09",
"date_sdn": 2392780,
"descr": "Death of Brooks, Marquis IV",
"gid": "E0167",
"media": [],
"part_family": [],
"part_person": [
324
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1727-01-18",
"date_sdn": 2351851,
"descr": "Birth of Brooks, William Waller",
"gid": "E0162",
"media": [],
"part_family": [],
"part_person": [
328
],
"place": 726,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1773-09-19",
"date_sdn": 2368897,
"descr": "Death of Brooks, William Waller",
"gid": "E0163",
"media": [],
"part_family": [],
"part_person": [
328
],
"place": 322,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1584-09-27",
"date_sdn": 2299874,
"descr": "Birth of Buchanan, Elsbeth",
"gid": "E2576",
"media": [],
"part_family": [],
"part_person": [
331
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Burns, Jonathan",
"gid": "E1888",
"media": [],
"part_family": [],
"part_person": [
334
],
"place": 466,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1781-07-22",
"date_sdn": 2371760,
"descr": "Birth of Burns, Margaret",
"gid": "E1278",
"media": [],
"part_family": [],
"part_person": [
335
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-01-17",
"date_sdn": 2396410,
"descr": "Death of Burns, Margaret",
"gid": "E1279",
"media": [],
"part_family": [],
"part_person": [
335
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1846",
"date_sdn": 2395298,
"descr": "Birth of Bush, James",
"gid": "E0864",
"media": [],
"part_family": [],
"part_person": [
339
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1879-04-00",
"date_sdn": 2407441,
"descr": "Birth of Bush, Patrick",
"gid": "E0865",
"media": [],
"part_family": [],
"part_person": [
342
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1984",
"date_sdn": 2445701,
"descr": "Birth of Caldwell, Colm",
"gid": "E0884",
"media": [],
"part_family": [],
"part_person": [
345
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0885",
"media": [],
"part_family": [],
"part_person": [
345
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1986",
"date_sdn": 2446432,
"descr": "Birth of Caldwell, Fergl",
"gid": "E0888",
"media": [],
"part_family": [],
"part_person": [
346
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0889",
"media": [],
"part_family": [],
"part_person": [
346
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1985",
"date_sdn": 2446067,
"descr": "Birth of Caldwell, Niall",
"gid": "E0886",
"media": [],
"part_family": [],
"part_person": [
347
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0887",
"media": [],
"part_family": [],
"part_person": [
347
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0883",
"media": [],
"part_family": [],
"part_person": [
348
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1633",
"date_sdn": 2317502,
"descr": "Birth of Carpenter, Sarah",
"gid": "E2225",
"media": [],
"part_family": [],
"part_person": [
351
],
"place": 135,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1858-12-31",
"date_sdn": 2400045,
"descr": "Birth of Carr, Zelpha Josephine",
"gid": "E0203",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 144,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-08",
"date_sdn": 2413233,
"descr": "Death of Carr, Zelpha Josephine",
"gid": "E0204",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 87,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1895-02-10",
"date_sdn": 2413235,
"descr": "Burial of Carr, Zelpha Josephine",
"gid": "E0205",
"media": [],
"part_family": [],
"part_person": [
352
],
"place": 1115,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1791-12-20",
"date_sdn": 2375563,
"descr": "Birth of Carroll, Grace",
"gid": "E2000",
"media": [],
"part_family": [],
"part_person": [
353
],
"place": 207,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1863-02-01",
"date_sdn": 2401538,
"descr": "Death of Carroll, Grace",
"gid": "E2001",
"media": [],
"part_family": [],
"part_person": [
353
],
"place": 722,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1863-02-03",
"date_sdn": 2401540,
"descr": "Burial of Carroll, Grace",
"gid": "E2002",
"media": [],
"part_family": [],
"part_person": [
353
],
"place": 719,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Carroll, Jacob A.",
"gid": "E2264",
"media": [],
"part_family": [],
"part_person": [
354
],
"place": 16,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1763",
"date_sdn": 2364983,
"descr": "Death of Carroll, Jacob A.",
"gid": "E2265",
"media": [],
"part_family": [],
"part_person": [
354
],
"place": 1038,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Carroll, Matthias Sr.",
"gid": "E1998",
"media": [],
"part_family": [],
"part_person": [
355
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of Carroll, Matthias Sr.",
"gid": "E1999",
"media": [],
"part_family": [],
"part_person": [
355
],
"place": 752,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1954-09-30",
"date_sdn": 2435016,
"descr": "Birth of Carter, Debra J.",
"gid": "E1440",
"media": [],
"part_family": [],
"part_person": [
356
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1441",
"media": [],
"part_family": [],
"part_person": [
356
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Castro, ???",
"gid": "E2508",
"media": [],
"part_family": [],
"part_person": [
358
],
"place": 282,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1495",
"date_sdn": 2267098,
"descr": "Birth of Christiansen, Christopher",
"gid": "E0062",
"media": [],
"part_family": [],
"part_person": [
361
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1570",
"date_sdn": 2294491,
"descr": "Death of Christiansen, Christopher",
"gid": "E0063",
"media": [],
"part_family": [],
"part_person": [
361
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1530",
"date_sdn": 2279881,
"descr": "Birth of Christiansen, Christopher",
"gid": "E1836",
"media": [],
"part_family": [],
"part_person": [
362
],
"place": 502,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1588",
"date_sdn": 2301065,
"descr": "Death of Christiansen, Christopher",
"gid": "E1837",
"media": [],
"part_family": [],
"part_person": [
362
],
"place": 347,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Christiansen, Christopher",
"gid": "E1838",
"media": [],
"part_family": [],
"part_person": [
362
],
"place": 502,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1583",
"date_sdn": 2299239,
"descr": "Birth of Christiansen, Edward",
"gid": "E1842",
"media": [],
"part_family": [],
"part_person": [
363
],
"place": 261,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1614",
"date_sdn": 2310562,
"descr": "Death of Christiansen, Edward",
"gid": "E1843",
"media": [],
"part_family": [],
"part_person": [
363
],
"place": 1006,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Christiansen, Edward",
"gid": "E1844",
"media": [],
"part_family": [],
"part_person": [
363
],
"place": 502,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Christiansen, Edward",
"gid": "E1845",
"media": [],
"part_family": [],
"part_person": [
364
],
"place": 36,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1684",
"date_sdn": 2336129,
"descr": "Death of Christiansen, Edward",
"gid": "E1846",
"media": [],
"part_family": [],
"part_person": [
364
],
"place": 617,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1796-07-06",
"date_sdn": 2377223,
"descr": "Death of Christiansen, Frances",
"gid": "E1879",
"media": [],
"part_family": [],
"part_person": [
365
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1688-02-04",
"date_sdn": 2337624,
"descr": "Birth of Christiansen, Hannah",
"gid": "E2127",
"media": [],
"part_family": [],
"part_person": [
366
],
"place": 617,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1742-06-26",
"date_sdn": 2357489,
"descr": "Death of Christiansen, Hannah",
"gid": "E2128",
"media": [],
"part_family": [],
"part_person": [
366
],
"place": 974,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1662-02-01",
"date_sdn": 2328125,
"descr": "Birth of Christiansen, John",
"gid": "E2230",
"media": [],
"part_family": [],
"part_person": [
367
],
"place": 935,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Death of Christiansen, John",
"gid": "E2231",
"media": [],
"part_family": [],
"part_person": [
367
],
"place": 947,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1455",
"date_sdn": 2252488,
"descr": "Birth of Christiansen, John",
"gid": "E0056",
"media": [],
"part_family": [],
"part_person": [
368
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1514",
"date_sdn": 2274037,
"descr": "Death of Christiansen, John",
"gid": "E0057",
"media": [],
"part_family": [],
"part_person": [
368
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1655-03-01",
"date_sdn": 2325596,
"descr": "Birth of Christiansen, Joseph",
"gid": "E2124",
"media": [],
"part_family": [],
"part_person": [
369
],
"place": 935,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1726-01-00",
"date_sdn": 2351469,
"descr": "Death of Christiansen, Joseph",
"gid": "E2125",
"media": [],
"part_family": [],
"part_person": [
369
],
"place": 617,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1703",
"date_sdn": 2343068,
"descr": "Birth of Christiansen, Joseph",
"gid": "E1870",
"media": [],
"part_family": [],
"part_person": [
370
],
"place": 947,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Christiansen, Joseph",
"gid": "E1871",
"media": [],
"part_family": [],
"part_person": [
370
],
"place": 203,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1693-04-25",
"date_sdn": 2339531,
"descr": "Birth of Christiansen, Martha",
"gid": "E2134",
"media": [],
"part_family": [],
"part_person": [
371
],
"place": 947,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1766-04-18",
"date_sdn": 2366186,
"descr": "Death of Christiansen, Martha",
"gid": "E2135",
"media": [],
"part_family": [],
"part_person": [
371
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1642-05-15",
"date_sdn": 2320923,
"descr": "Birth of Christiansen, Nathaniel",
"gid": "E1851",
"media": [],
"part_family": [],
"part_person": [
372
],
"place": 935,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1713-11-21",
"date_sdn": 2347045,
"descr": "Death of Christiansen, Nathaniel",
"gid": "E1852",
"media": [],
"part_family": [],
"part_person": [
372
],
"place": 947,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1668",
"date_sdn": 2330285,
"descr": "Birth of Christiansen, Samuel",
"gid": "E1856",
"media": [],
"part_family": [],
"part_person": [
373
],
"place": 935,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-06-25",
"date_sdn": 2361871,
"descr": "Death of Christiansen, Samuel",
"gid": "E1857",
"media": [],
"part_family": [],
"part_person": [
373
],
"place": 947,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1785-03-31",
"date_sdn": 2373108,
"descr": "Birth of Clark, Sarah",
"gid": "E1925",
"media": [],
"part_family": [],
"part_person": [
374
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1727-08-15",
"date_sdn": 2352060,
"descr": "Birth of Cole, Eurydice",
"gid": "E2282",
"media": [],
"part_family": [],
"part_person": [
376
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1757",
"date_sdn": 2362792,
"descr": "Death of Cole, Susannah",
"gid": "E2257",
"media": [],
"part_family": [],
"part_person": [
377
],
"place": 54,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1926",
"date_sdn": 2424517,
"descr": "Birth of Coleman, Marilyn",
"gid": "E2501",
"media": [],
"part_family": [],
"part_person": [
379
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2502",
"media": [],
"part_family": [],
"part_person": [
379
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1812",
"date_sdn": 2382879,
"descr": "Birth of Coleman, Mary",
"gid": "E1294",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 205,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Coleman, Mary",
"gid": "E1295",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 858,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Coleman, Mary",
"gid": "E1296",
"media": [],
"part_family": [],
"part_person": [
380
],
"place": 320,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "about 1196",
"date_sdn": 2157890,
"descr": "Birth of Copeland, Mary",
"gid": "E0036",
"media": [],
"part_family": [],
"part_person": [
385
],
"place": 473,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1964-12-12",
"date_sdn": 2438742,
"descr": "Birth of C\u00f4t\u00e9, Raymond Patrick",
"gid": "E1968",
"media": [],
"part_family": [],
"part_person": [
386
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1969",
"media": [],
"part_family": [],
"part_person": [
386
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Couture, Honora",
"gid": "E1315",
"media": [],
"part_family": [],
"part_person": [
387
],
"place": 39,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "about 1610",
"date_sdn": 2309101,
"descr": "Birth of Crawford, Margaret",
"gid": "E0266",
"media": [],
"part_family": [],
"part_person": [
391
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1669",
"date_sdn": 2330651,
"descr": "Death of Crawford, Margaret",
"gid": "E0267",
"media": [],
"part_family": [],
"part_person": [
391
],
"place": 461,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1896-07-13",
"date_sdn": 2413754,
"descr": "Birth of Cross, Alta M.",
"gid": "E0572",
"media": [],
"part_family": [],
"part_person": [
392
],
"place": 618,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1988-05-16",
"date_sdn": 2447298,
"descr": "Death of Cross, Alta M.",
"gid": "E0573",
"media": [],
"part_family": [],
"part_person": [
392
],
"place": 798,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1988-05-18",
"date_sdn": 2447300,
"descr": "Burial of Cross, Alta M.",
"gid": "E0574",
"media": [],
"part_family": [],
"part_person": [
392
],
"place": 1218,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Evelyn",
"gid": "E0578",
"media": [],
"part_family": [],
"part_person": [
393
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1911-02-14",
"date_sdn": 2419082,
"descr": "Birth of Cross, Gertrude",
"gid": "E0583",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 1254,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1992-07-16",
"date_sdn": 2448820,
"descr": "Death of Cross, Gertrude",
"gid": "E0584",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 443,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1992-07-18",
"date_sdn": 2448822,
"descr": "Burial of Cross, Gertrude",
"gid": "E0585",
"media": [],
"part_family": [],
"part_person": [
394
],
"place": 443,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, John",
"gid": "E0582",
"media": [],
"part_family": [],
"part_person": [
395
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Loraine (Fanny)",
"gid": "E0577",
"media": [],
"part_family": [],
"part_person": [
396
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Louise",
"gid": "E0581",
"media": [],
"part_family": [],
"part_person": [
397
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Ralph (Scotty)",
"gid": "E0576",
"media": [],
"part_family": [],
"part_person": [
398
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cross, Thomas",
"gid": "E0571",
"media": [],
"part_family": [],
"part_person": [
399
],
"place": 306,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1968-11-17",
"date_sdn": 2440178,
"descr": "Birth of Cruz, Ann Lynn",
"gid": "E1659",
"media": [],
"part_family": [],
"part_person": [
400
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1660",
"media": [],
"part_family": [],
"part_person": [
400
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1921-03-04",
"date_sdn": 2422753,
"descr": "Birth of Cruz, Arthur Ray",
"gid": "E1227",
"media": [],
"part_family": [],
"part_person": [
401
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1228",
"media": [],
"part_family": [],
"part_person": [
401
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-11-11",
"date_sdn": 2432501,
"descr": "Birth of Cruz, Dale Eugene",
"gid": "E1225",
"media": [],
"part_family": [],
"part_person": [
402
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1226",
"media": [],
"part_family": [],
"part_person": [
402
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-01-25",
"date_sdn": 2432576,
"descr": "Birth of Cruz, David Wayne",
"gid": "E1244",
"media": [],
"part_family": [],
"part_person": [
403
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1245",
"media": [],
"part_family": [],
"part_person": [
403
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1894-04-24",
"date_sdn": 2412943,
"descr": "Birth of Cruz, Everett",
"gid": "E1215",
"media": [],
"part_family": [],
"part_person": [
404
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1975-09-17",
"date_sdn": 2442673,
"descr": "Birth of Cruz, Gayle Joan",
"gid": "E1623",
"media": [],
"part_family": [],
"part_person": [
405
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1624",
"media": [],
"part_family": [],
"part_person": [
405
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1944-01-09",
"date_sdn": 2431099,
"descr": "Birth of Cruz, Gerald Ray",
"gid": "E1231",
"media": [],
"part_family": [],
"part_person": [
406
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1232",
"media": [],
"part_family": [],
"part_person": [
406
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1925-02-14",
"date_sdn": 2424196,
"descr": "Birth of Cruz, Ivan Wayne",
"gid": "E1240",
"media": [],
"part_family": [],
"part_person": [
407
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1241",
"media": [],
"part_family": [],
"part_person": [
407
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-04-11",
"date_sdn": 2433383,
"descr": "Birth of Cruz, James Richard",
"gid": "E1238",
"media": [],
"part_family": [],
"part_person": [
408
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1239",
"media": [],
"part_family": [],
"part_person": [
408
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1972-03-04",
"date_sdn": 2441381,
"descr": "Birth of Cruz, Jane Elizabeth",
"gid": "E1661",
"media": [],
"part_family": [],
"part_person": [
409
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1662",
"media": [],
"part_family": [],
"part_person": [
409
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-01-10",
"date_sdn": 2432196,
"descr": "Birth of Cruz, Janis Marlene",
"gid": "E1236",
"media": [],
"part_family": [],
"part_person": [
410
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1237",
"media": [],
"part_family": [],
"part_person": [
410
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990-12-29",
"date_sdn": 2448255,
"descr": "Birth of Cruz, Jesse Christopher",
"gid": "E1767",
"media": [],
"part_family": [],
"part_person": [
411
],
"place": 1283,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1768",
"media": [],
"part_family": [],
"part_person": [
411
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-11-19",
"date_sdn": 2442006,
"descr": "Birth of Cruz, Jill Suzanne",
"gid": "E1621",
"media": [],
"part_family": [],
"part_person": [
412
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1622",
"media": [],
"part_family": [],
"part_person": [
412
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1971-06-28",
"date_sdn": 2441131,
"descr": "Birth of Cruz, Joella Lynn",
"gid": "E1619",
"media": [],
"part_family": [],
"part_person": [
413
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1620",
"media": [],
"part_family": [],
"part_person": [
413
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1978-03-14",
"date_sdn": 2443582,
"descr": "Birth of Cruz, Joy Leanne",
"gid": "E1625",
"media": [],
"part_family": [],
"part_person": [
414
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1626",
"media": [],
"part_family": [],
"part_person": [
414
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1949-03-07",
"date_sdn": 2432983,
"descr": "Birth of Cruz, Joyce Marie",
"gid": "E1250",
"media": [],
"part_family": [],
"part_person": [
415
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1251",
"media": [],
"part_family": [],
"part_person": [
415
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1952-11-29",
"date_sdn": 2434346,
"descr": "Birth of Cruz, Judy Denise",
"gid": "E1252",
"media": [],
"part_family": [],
"part_person": [
416
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1253",
"media": [],
"part_family": [],
"part_person": [
416
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1975-09-08",
"date_sdn": 2442664,
"descr": "Birth of Cruz, Karen Kay",
"gid": "E1677",
"media": [],
"part_family": [],
"part_person": [
417
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1678",
"media": [],
"part_family": [],
"part_person": [
417
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1972-06-29",
"date_sdn": 2441498,
"descr": "Birth of Cruz, Karla Sue",
"gid": "E1675",
"media": [],
"part_family": [],
"part_person": [
418
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1676",
"media": [],
"part_family": [],
"part_person": [
418
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-04-30",
"date_sdn": 2441803,
"descr": "Birth of Cruz, Laura Joy",
"gid": "E1669",
"media": [],
"part_family": [],
"part_person": [
419
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1670",
"media": [],
"part_family": [],
"part_person": [
419
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1942-02-06",
"date_sdn": 2430397,
"descr": "Birth of Cruz, Linda Helen",
"gid": "E1223",
"media": [],
"part_family": [],
"part_person": [
420
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1224",
"media": [],
"part_family": [],
"part_person": [
420
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1968-10-04",
"date_sdn": 2440134,
"descr": "Birth of Cruz, Marsha Ann",
"gid": "E1673",
"media": [],
"part_family": [],
"part_person": [
421
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1674",
"media": [],
"part_family": [],
"part_person": [
421
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1956-12-18",
"date_sdn": 2435826,
"descr": "Birth of Cruz, Melinda Lou",
"gid": "E1528",
"media": [],
"part_family": [],
"part_person": [
422
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1529",
"media": [],
"part_family": [],
"part_person": [
422
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1959-08-14",
"date_sdn": 2436795,
"descr": "Birth of Cruz, Patti Jo",
"gid": "E1652",
"media": [],
"part_family": [],
"part_person": [
423
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1653",
"media": [],
"part_family": [],
"part_person": [
423
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1918-11-03",
"date_sdn": 2421901,
"descr": "Birth of Cruz, Paul Eugene",
"gid": "E1216",
"media": [],
"part_family": [],
"part_person": [
424
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1217",
"media": [],
"part_family": [],
"part_person": [
424
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1976-08-07",
"date_sdn": 2442998,
"descr": "Birth of Cruz, Susan Marguerite",
"gid": "E1671",
"media": [],
"part_family": [],
"part_person": [
425
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1672",
"media": [],
"part_family": [],
"part_person": [
425
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1940-10-15",
"date_sdn": 2429918,
"descr": "Birth of Cruz, Thomas Everett",
"gid": "E1221",
"media": [],
"part_family": [],
"part_person": [
426
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1222",
"media": [],
"part_family": [],
"part_person": [
426
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1927-04-05",
"date_sdn": 2424976,
"descr": "Birth of Cruz, William Everett",
"gid": "E1246",
"media": [],
"part_family": [],
"part_person": [
427
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1247",
"media": [],
"part_family": [],
"part_person": [
427
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Cunningham, Peter Sr.",
"gid": "E1726",
"media": [],
"part_family": [],
"part_person": [
429
],
"place": 868,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1832-05-00",
"date_sdn": 2390305,
"descr": "Death of Cunningham, Peter Sr.",
"gid": "E1727",
"media": [],
"part_family": [],
"part_person": [
429
],
"place": 717,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1832-05-00",
"date_sdn": 2390305,
"descr": "Burial of Cunningham, Peter Sr.",
"gid": "E1728",
"media": [],
"part_family": [],
"part_person": [
429
],
"place": 1078,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1805-09-25",
"date_sdn": 2380590,
"descr": "Birth of Cunningham, Sally Sarah",
"gid": "E1714",
"media": [],
"part_family": [],
"part_person": [
430
],
"place": 169,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1867-02-19",
"date_sdn": 2403017,
"descr": "Death of Cunningham, Sally Sarah",
"gid": "E1715",
"media": [],
"part_family": [],
"part_person": [
430
],
"place": 1017,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Cunningham, Sally Sarah",
"gid": "E1716",
"media": [],
"part_family": [],
"part_person": [
430
],
"place": 467,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1765-04-05",
"date_sdn": 2365808,
"descr": "Birth of Cunningham, William Philip",
"gid": "E1722",
"media": [],
"part_family": [],
"part_person": [
431
],
"place": 1269,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1871-04-28",
"date_sdn": 2404546,
"descr": "Death of Cunningham, William Philip",
"gid": "E1723",
"media": [],
"part_family": [],
"part_person": [
431
],
"place": 806,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1871-04-29",
"date_sdn": 2404547,
"descr": "Burial of Cunningham, William Philip",
"gid": "E1724",
"media": [],
"part_family": [],
"part_person": [
431
],
"place": 129,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1478",
"date_sdn": 2260889,
"descr": "Birth of Curtis, Margaret",
"gid": "E0251",
"media": [],
"part_family": [],
"part_person": [
434
],
"place": 926,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Daniels, Phoebe",
"gid": "E2682",
"media": [],
"part_family": [],
"part_person": [
437
],
"place": 116,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1894-09-27",
"date_sdn": 2413099,
"descr": "Birth of Davidson, Bernice",
"gid": "E2035",
"media": [],
"part_family": [],
"part_person": [
438
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1980-05-24",
"date_sdn": 2444384,
"descr": "Death of Davidson, Bernice",
"gid": "E2036",
"media": [],
"part_family": [],
"part_person": [
438
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1743-08-09",
"date_sdn": 2357898,
"descr": "Birth of Davis, Jonathan",
"gid": "E1877",
"media": [],
"part_family": [],
"part_person": [
441
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-12-28",
"date_sdn": 2387624,
"descr": "Death of Davis, Jonathan",
"gid": "E1878",
"media": [],
"part_family": [],
"part_person": [
441
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1762-09-06",
"date_sdn": 2364866,
"descr": "Birth of Davis, Sabra",
"gid": "E1885",
"media": [],
"part_family": [],
"part_person": [
442
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1845-11-01",
"date_sdn": 2395237,
"descr": "Death of Davis, Sabra",
"gid": "E1886",
"media": [],
"part_family": [],
"part_person": [
442
],
"place": 579,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Davis, Sabra",
"gid": "E1887",
"media": [],
"part_family": [],
"part_person": [
442
],
"place": 579,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Delgado",
"gid": "E2724",
"media": [],
"part_family": [],
"part_person": [
447
],
"place": 999,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Delgado",
"gid": "E2725",
"media": [],
"part_family": [],
"part_person": [
447
],
"place": 999,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Delgado, Catherine",
"gid": "E0773",
"media": [],
"part_family": [],
"part_person": [
448
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1825",
"date_sdn": 2387628,
"descr": "Birth of Delgado, Mary Ann",
"gid": "E2732",
"media": [],
"part_family": [],
"part_person": [
449
],
"place": 693,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Delgado, Mary Ann",
"gid": "E2733",
"media": [],
"part_family": [],
"part_person": [
449
],
"place": 673,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1932-12-03",
"date_sdn": 2427045,
"descr": "Death of Dennis, Susan",
"gid": "E0863",
"media": [],
"part_family": [],
"part_person": [
453
],
"place": 1120,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1761-08-07",
"date_sdn": 2364471,
"descr": "Birth of Diaz, Frances",
"gid": "E2674",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": 238,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1851-10-06",
"date_sdn": 2397402,
"descr": "Death of Diaz, Frances",
"gid": "E2675",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": 547,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1851-10-08",
"date_sdn": 2397404,
"descr": "Burial of Diaz, Frances",
"gid": "E2676",
"media": [],
"part_family": [],
"part_person": [
458
],
"place": 547,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1763-04-15",
"date_sdn": 2365087,
"descr": "Birth of Diaz, James",
"gid": "E1020",
"media": [],
"part_family": [],
"part_person": [
459
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Diaz, James",
"gid": "E1021",
"media": [],
"part_family": [],
"part_person": [
459
],
"place": 1154,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Diaz, James",
"gid": "E1022",
"media": [],
"part_family": [],
"part_person": [
459
],
"place": 1261,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1631-02-01",
"date_sdn": 2316802,
"descr": "Death of Diaz, John",
"gid": "E0310",
"media": [],
"part_family": [],
"part_person": [
461
],
"place": 976,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Diaz, Mary Polly",
"gid": "E1040",
"media": [],
"part_family": [],
"part_person": [
463
],
"place": 1282,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1822",
"date_sdn": 2386532,
"descr": "Death of Diaz, Mary Polly",
"gid": "E1041",
"media": [],
"part_family": [],
"part_person": [
463
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1648",
"date_sdn": 2322980,
"descr": "Birth of Diaz, William",
"gid": "E2701",
"media": [],
"part_family": [],
"part_person": [
466
],
"place": 421,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1700-09-16",
"date_sdn": 2342231,
"descr": "Death of Diaz, William",
"gid": "E2702",
"media": [],
"part_family": [],
"part_person": [
466
],
"place": 231,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1530",
"date_sdn": 2279881,
"descr": "Birth of Diaz, William (Rev.)",
"gid": "E0308",
"media": [],
"part_family": [],
"part_person": [
467
],
"place": 582,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1587-10-12",
"date_sdn": 2300984,
"descr": "Death of Diaz, William (Rev.)",
"gid": "E0309",
"media": [],
"part_family": [],
"part_person": [
467
],
"place": 736,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1972-10-10",
"date_sdn": 2441601,
"descr": "Birth of D\u00edez, William George Jr.",
"gid": "E0099",
"media": [],
"part_family": [],
"part_person": [
469
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0100",
"media": [],
"part_family": [],
"part_person": [
469
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1671",
"date_sdn": 2331381,
"descr": "Birth of Dixon, Thomas",
"gid": "E1064",
"media": [],
"part_family": [],
"part_person": [
470
],
"place": 477,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1811",
"date_sdn": 2382514,
"descr": "Birth of Dom\u00ednguez, George",
"gid": "E2509",
"media": [],
"part_family": [],
"part_person": [
472
],
"place": 669,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Dom\u00ednguez, Mahala",
"gid": "E0488",
"media": [],
"part_family": [],
"part_person": [
473
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1839-03-15",
"date_sdn": 2392814,
"descr": "Birth of Dom\u00ednguez, Mary E.",
"gid": "E1614",
"media": [],
"part_family": [],
"part_person": [
474
],
"place": 815,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1893-09-30",
"date_sdn": 2412737,
"descr": "Death of Dom\u00ednguez, Mary E.",
"gid": "E1615",
"media": [],
"part_family": [],
"part_person": [
474
],
"place": 348,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1893-10-01",
"date_sdn": 2412738,
"descr": "Burial of Dom\u00ednguez, Mary E.",
"gid": "E1616",
"media": [],
"part_family": [],
"part_person": [
474
],
"place": 917,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Dom\u00ednguez, Zorada",
"gid": "E0461",
"media": [],
"part_family": [],
"part_person": [
475
],
"place": 846,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1821-02-17",
"date_sdn": 2386214,
"descr": "Birth of Douglas, Abraham",
"gid": "E1732",
"media": [],
"part_family": [],
"part_person": [
478
],
"place": 372,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1901-01-12",
"date_sdn": 2415397,
"descr": "Death of Douglas, Abraham",
"gid": "E1733",
"media": [],
"part_family": [],
"part_person": [
478
],
"place": 310,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1901-01-14",
"date_sdn": 2415399,
"descr": "Burial of Douglas, Abraham",
"gid": "E1734",
"media": [],
"part_family": [],
"part_person": [
478
],
"place": 310,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1827-05-01",
"date_sdn": 2388478,
"descr": "Birth of Douglas, Alfred",
"gid": "E0650",
"media": [],
"part_family": [],
"part_person": [
479
],
"place": 722,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-06-26",
"date_sdn": 2419945,
"descr": "Death of Douglas, Alfred",
"gid": "E0651",
"media": [],
"part_family": [],
"part_person": [
479
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Arthur",
"gid": "E0638",
"media": [],
"part_family": [],
"part_person": [
481
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1818-04-09",
"date_sdn": 2385169,
"descr": "Birth of Douglas, Catherine",
"gid": "E0649",
"media": [],
"part_family": [],
"part_person": [
484
],
"place": 948,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Charles",
"gid": "E0632",
"media": [],
"part_family": [],
"part_person": [
485
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1850-08-07",
"date_sdn": 2396977,
"descr": "Birth of Douglas, Eliza Jane",
"gid": "E0630",
"media": [],
"part_family": [],
"part_person": [
487
],
"place": 250,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1915",
"date_sdn": 2420499,
"descr": "Death of Douglas, Eliza Jane",
"gid": "E0631",
"media": [],
"part_family": [],
"part_person": [
487
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1853-02-26",
"date_sdn": 2397911,
"descr": "Birth of Douglas, Elizabeth",
"gid": "E1559",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 310,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1890-02-14",
"date_sdn": 2411413,
"descr": "Death of Douglas, Elizabeth",
"gid": "E1560",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 939,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1890-02-16",
"date_sdn": 2411415,
"descr": "Burial of Douglas, Elizabeth",
"gid": "E1561",
"media": [],
"part_family": [],
"part_person": [
489
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1808-09-20",
"date_sdn": 2381681,
"descr": "Birth of Douglas, Elizabeth",
"gid": "E0643",
"media": [],
"part_family": [],
"part_person": [
490
],
"place": 948,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1830-05-24",
"date_sdn": 2389597,
"descr": "Birth of Douglas, Ellen",
"gid": "E0652",
"media": [],
"part_family": [],
"part_person": [
491
],
"place": 722,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Frank",
"gid": "E0635",
"media": [],
"part_family": [],
"part_person": [
492
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, Frederick",
"gid": "E2734",
"media": [],
"part_family": [],
"part_person": [
495
],
"place": 316,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Hans Peter",
"gid": "E1926",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 16,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, Hans Peter",
"gid": "E1927",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 1142,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Douglas, Hans Peter",
"gid": "E1928",
"media": [],
"part_family": [],
"part_person": [
496
],
"place": 402,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1813-08-21",
"date_sdn": 2383477,
"descr": "Birth of Douglas, Jacob",
"gid": "E0647",
"media": [],
"part_family": [],
"part_person": [
498
],
"place": 948,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, Jacob",
"gid": "E0648",
"media": [],
"part_family": [],
"part_person": [
498
],
"place": 310,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, Jacob",
"gid": "E0633",
"media": [],
"part_family": [],
"part_person": [
499
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1824-10-17",
"date_sdn": 2387552,
"descr": "Birth of Douglas, John",
"gid": "E0656",
"media": [],
"part_family": [],
"part_person": [
502
],
"place": 722,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, John",
"gid": "E0657",
"media": [],
"part_family": [],
"part_person": [
502
],
"place": 93,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1761",
"date_sdn": 2364253,
"descr": "Birth of Douglas, John Jr.",
"gid": "E1937",
"media": [],
"part_family": [],
"part_person": [
503
],
"place": 116,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, John Jr.",
"gid": "E1938",
"media": [],
"part_family": [],
"part_person": [
503
],
"place": 1000,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1739-11-25",
"date_sdn": 2356545,
"descr": "Birth of Douglas, John Sr.",
"gid": "E1929",
"media": [],
"part_family": [],
"part_person": [
504
],
"place": 234,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-10-00",
"date_sdn": 2386440,
"descr": "Death of Douglas, John Sr.",
"gid": "E1930",
"media": [],
"part_family": [],
"part_person": [
504
],
"place": 1050,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Douglas, John Sr.",
"gid": "E1931",
"media": [],
"part_family": [],
"part_person": [
504
],
"place": 1278,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1787-09-07",
"date_sdn": 2373998,
"descr": "Birth of Douglas, Joseph",
"gid": "E1995",
"media": [],
"part_family": [],
"part_person": [
506
],
"place": 1107,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1857-03-09",
"date_sdn": 2399383,
"descr": "Death of Douglas, Joseph",
"gid": "E1996",
"media": [],
"part_family": [],
"part_person": [
506
],
"place": 722,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1857-03-11",
"date_sdn": 2399385,
"descr": "Burial of Douglas, Joseph",
"gid": "E1997",
"media": [],
"part_family": [],
"part_person": [
506
],
"place": 719,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1833-05-06",
"date_sdn": 2390675,
"descr": "Birth of Douglas, Lucinda J.",
"gid": "E0653",
"media": [],
"part_family": [],
"part_person": [
507
],
"place": 722,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1785-04-27",
"date_sdn": 2373135,
"descr": "Birth of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2567",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 653,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-08-30",
"date_sdn": 2394078,
"descr": "Death of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2568",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 1167,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1842-09-01",
"date_sdn": 2394080,
"descr": "Burial of Douglas, Mary&#8220;Polly&#8221;",
"gid": "E2569",
"media": [],
"part_family": [],
"part_person": [
508
],
"place": 532,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1815-06-19",
"date_sdn": 2384144,
"descr": "Birth of Douglas, Samuel",
"gid": "E0654",
"media": [],
"part_family": [],
"part_person": [
510
],
"place": 948,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1836-12-01",
"date_sdn": 2391980,
"descr": "Birth of Douglas, Susan",
"gid": "E0655",
"media": [],
"part_family": [],
"part_person": [
512
],
"place": 722,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, William",
"gid": "E0634",
"media": [],
"part_family": [],
"part_person": [
513
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Douglas, William",
"gid": "E0628",
"media": [],
"part_family": [],
"part_person": [
514
],
"place": 250,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Douglas, William",
"gid": "E0629",
"media": [],
"part_family": [],
"part_person": [
514
],
"place": 250,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1773-09-21",
"date_sdn": 2368899,
"descr": "Birth of Doyle, Robert Gove",
"gid": "E1042",
"media": [],
"part_family": [],
"part_person": [
515
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1786",
"date_sdn": 2373384,
"descr": "Birth of Dub\u00e9, Elizabeth",
"gid": "E0387",
"media": [],
"part_family": [],
"part_person": [
516
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1996",
"date_sdn": 2450084,
"descr": "Death of Duncan",
"gid": "E0954",
"media": [],
"part_family": [],
"part_person": [
519
],
"place": 244,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0958",
"media": [],
"part_family": [],
"part_person": [
520
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0961",
"media": [],
"part_family": [],
"part_person": [
521
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1978",
"date_sdn": 2443510,
"descr": "Birth of Duncan, Michael",
"gid": "E0955",
"media": [],
"part_family": [],
"part_person": [
522
],
"place": 244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0956",
"media": [],
"part_family": [],
"part_person": [
522
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0957",
"media": [],
"part_family": [],
"part_person": [
523
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Dunn, Margaret Mary?",
"gid": "E2315",
"media": [],
"part_family": [],
"part_person": [
524
],
"place": 1014,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1799-01-17",
"date_sdn": 2378148,
"descr": "Birth of Edwards, Lucy",
"gid": "E0090",
"media": [],
"part_family": [],
"part_person": [
525
],
"place": 554,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1879-04-02",
"date_sdn": 2407442,
"descr": "Death of Edwards, Lucy",
"gid": "E0091",
"media": [],
"part_family": [],
"part_person": [
525
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1879-04-04",
"date_sdn": 2407444,
"descr": "Burial of Edwards, Lucy",
"gid": "E0092",
"media": [],
"part_family": [],
"part_person": [
525
],
"place": 672,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1969-05-26",
"date_sdn": 2440368,
"descr": "Birth of Evans, Christian Anne",
"gid": "E2192",
"media": [],
"part_family": [],
"part_person": [
531
],
"place": 910,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2193",
"media": [],
"part_family": [],
"part_person": [
531
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-07-12",
"date_sdn": 2443337,
"descr": "Birth of Evans, Heather Lee",
"gid": "E2194",
"media": [],
"part_family": [],
"part_person": [
532
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2195",
"media": [],
"part_family": [],
"part_person": [
532
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1945-10-02",
"date_sdn": 2431731,
"descr": "Birth of Evans, James Patrick",
"gid": "E2184",
"media": [],
"part_family": [],
"part_person": [
533
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2185",
"media": [],
"part_family": [],
"part_person": [
533
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-03-05",
"date_sdn": 2441747,
"descr": "Birth of Evans, Michael Patrick",
"gid": "E2188",
"media": [],
"part_family": [],
"part_person": [
534
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2189",
"media": [],
"part_family": [],
"part_person": [
534
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1976-01-19",
"date_sdn": 2442797,
"descr": "Birth of Evans, Patricia Kay",
"gid": "E2186",
"media": [],
"part_family": [],
"part_person": [
535
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2187",
"media": [],
"part_family": [],
"part_person": [
535
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1786",
"date_sdn": 2373384,
"descr": "Birth of Farmer, Anna Marie",
"gid": "E0375",
"media": [],
"part_family": [],
"part_person": [
536
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1812-01-03",
"date_sdn": 2382881,
"descr": "Birth of Farmer, Benjamin H.",
"gid": "E2444",
"media": [],
"part_family": [],
"part_person": [
537
],
"place": 936,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1873-08-13",
"date_sdn": 2405384,
"descr": "Death of Farmer, Benjamin H.",
"gid": "E2445",
"media": [],
"part_family": [],
"part_person": [
537
],
"place": 412,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1873-08-14",
"date_sdn": 2405385,
"descr": "Burial of Farmer, Benjamin H.",
"gid": "E2446",
"media": [],
"part_family": [],
"part_person": [
537
],
"place": 193,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1818",
"date_sdn": 2385071,
"descr": "Birth of Farmer, Caroline",
"gid": "E0366",
"media": [],
"part_family": [],
"part_person": [
538
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1798",
"date_sdn": 2377767,
"descr": "Birth of Farmer, Catharine",
"gid": "E0385",
"media": [],
"part_family": [],
"part_person": [
539
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Farmer, Cyrus Melville",
"gid": "E1525",
"media": [],
"part_family": [],
"part_person": [
540
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1792",
"date_sdn": 2375575,
"descr": "Birth of Farmer, Elizabeth",
"gid": "E0378",
"media": [],
"part_family": [],
"part_person": [
542
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1850-06-09",
"date_sdn": 2396918,
"descr": "Birth of Farmer, Elizabeth Ellen",
"gid": "E2489",
"media": [],
"part_family": [],
"part_person": [
543
],
"place": 1010,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1931-08-03",
"date_sdn": 2426557,
"descr": "Death of Farmer, Elizabeth Ellen",
"gid": "E2490",
"media": [],
"part_family": [],
"part_person": [
543
],
"place": 769,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1931-08-00",
"date_sdn": 2426555,
"descr": "Burial of Farmer, Elizabeth Ellen",
"gid": "E2491",
"media": [],
"part_family": [],
"part_person": [
543
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1796",
"date_sdn": 2377036,
"descr": "Birth of Farmer, Eva",
"gid": "E0383",
"media": [],
"part_family": [],
"part_person": [
544
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1883",
"date_sdn": 2408812,
"descr": "Death of Farmer, Eva",
"gid": "E0384",
"media": [],
"part_family": [],
"part_person": [
544
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858-02-19",
"date_sdn": 2399730,
"descr": "Birth of Farmer, Flora Alice",
"gid": "E1526",
"media": [],
"part_family": [],
"part_person": [
545
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1777",
"date_sdn": 2370097,
"descr": "Birth of Farmer, Jacob",
"gid": "E0353",
"media": [],
"part_family": [],
"part_person": [
547
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1860-03-17",
"date_sdn": 2400487,
"descr": "Birth of Farmer, John",
"gid": "E1527",
"media": [],
"part_family": [],
"part_person": [
548
],
"place": 1159,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Farmer, Magdalena",
"gid": "E0367",
"media": [],
"part_family": [],
"part_person": [
549
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1842-08-09",
"date_sdn": 2394057,
"descr": "Birth of Farmer, Mary Ann",
"gid": "E1521",
"media": [],
"part_family": [],
"part_person": [
550
],
"place": 1146,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1775",
"date_sdn": 2369366,
"descr": "Birth of Farmer, Michael",
"gid": "E0386",
"media": [],
"part_family": [],
"part_person": [
551
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1852-09-27",
"date_sdn": 2397759,
"descr": "Birth of Farmer, Miranda Keziah",
"gid": "E1524",
"media": [],
"part_family": [],
"part_person": [
552
],
"place": 1146,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1790",
"date_sdn": 2374845,
"descr": "Birth of Farmer, Peter Simon",
"gid": "E0376",
"media": [],
"part_family": [],
"part_person": [
553
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1845",
"date_sdn": 2394933,
"descr": "Death of Farmer, Peter Simon",
"gid": "E0377",
"media": [],
"part_family": [],
"part_person": [
553
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1840-05-07",
"date_sdn": 2393233,
"descr": "Birth of Farmer, Sarah Jane",
"gid": "E1517",
"media": [],
"part_family": [],
"part_person": [
554
],
"place": 1146,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1815",
"date_sdn": 2383975,
"descr": "Birth of Farmer, Simon",
"gid": "E0363",
"media": [],
"part_family": [],
"part_person": [
555
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875",
"date_sdn": 2405890,
"descr": "Death of Farmer, Simon",
"gid": "E0364",
"media": [],
"part_family": [],
"part_person": [
555
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1784",
"date_sdn": 2372653,
"descr": "Birth of Farmer, Susanna",
"gid": "E0373",
"media": [],
"part_family": [],
"part_person": [
556
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-12-02",
"date_sdn": 2394903,
"descr": "Birth of Farmer, Susanne Delilah",
"gid": "E1522",
"media": [],
"part_family": [],
"part_person": [
557
],
"place": 1146,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1779",
"date_sdn": 2370827,
"descr": "Birth of Farmer, Valentine",
"gid": "E0368",
"media": [],
"part_family": [],
"part_person": [
558
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1833",
"date_sdn": 2390550,
"descr": "Death of Farmer, Valentine",
"gid": "E0369",
"media": [],
"part_family": [],
"part_person": [
558
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1847-07-29",
"date_sdn": 2395872,
"descr": "Birth of Farmer, Winfield Scott",
"gid": "E1523",
"media": [],
"part_family": [],
"part_person": [
559
],
"place": 1146,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ferguson, Lord Samuel",
"gid": "E2254",
"media": [],
"part_family": [],
"part_person": [
560
],
"place": 1030,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Fernandez, Michael",
"gid": "E0908",
"media": [],
"part_family": [],
"part_person": [
562
],
"place": 1273,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1825-11-27",
"date_sdn": 2387958,
"descr": "Birth of Fernandez, Thomas",
"gid": "E2671",
"media": [],
"part_family": [],
"part_person": [
563
],
"place": 361,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-11-26",
"date_sdn": 2416080,
"descr": "Death of Fernandez, Thomas",
"gid": "E2672",
"media": [],
"part_family": [],
"part_person": [
563
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902",
"date_sdn": 2415751,
"descr": "Burial of Fernandez, Thomas",
"gid": "E2673",
"media": [],
"part_family": [],
"part_person": [
563
],
"place": 1145,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1787",
"date_sdn": 2373749,
"descr": "Birth of Fernandez, Thomas",
"gid": "E2716",
"media": [],
"part_family": [],
"part_person": [
564
],
"place": 627,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Fernandez, Thomas",
"gid": "E2717",
"media": [],
"part_family": [],
"part_person": [
564
],
"place": 890,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Fields, Bridget M.",
"gid": "E2392",
"media": [],
"part_family": [],
"part_person": [
565
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Fields, Bridget M.",
"gid": "E2393",
"media": [],
"part_family": [],
"part_person": [
565
],
"place": 684,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fields, Bridget M.",
"gid": "E2394",
"media": [],
"part_family": [],
"part_person": [
565
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1559",
"date_sdn": 2290473,
"descr": "Birth of Fisher, Bendichtli",
"gid": "E2573",
"media": [],
"part_family": [],
"part_person": [
580
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1959-10-23",
"date_sdn": 2436865,
"descr": "Birth of Flores, Jamie Lee",
"gid": "E0206",
"media": [],
"part_family": [],
"part_person": [
582
],
"place": 1009,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0207",
"media": [],
"part_family": [],
"part_person": [
582
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1985-04-18",
"date_sdn": 2446174,
"descr": "Birth of Floyd, Christopher Randall",
"gid": "E1474",
"media": [],
"part_family": [],
"part_person": [
584
],
"place": 203,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1475",
"media": [],
"part_family": [],
"part_person": [
584
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1983-04-18",
"date_sdn": 2445443,
"descr": "Birth of Floyd, Gregory Scott",
"gid": "E1472",
"media": [],
"part_family": [],
"part_person": [
585
],
"place": 514,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-06-15",
"date_sdn": 2445501,
"descr": "Death of Floyd, Gregory Scott",
"gid": "E1473",
"media": [],
"part_family": [],
"part_person": [
585
],
"place": 514,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1988-07-25",
"date_sdn": 2447368,
"descr": "Birth of Floyd, Joan Louise",
"gid": "E1476",
"media": [],
"part_family": [],
"part_person": [
587
],
"place": 174,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1477",
"media": [],
"part_family": [],
"part_person": [
587
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1802",
"date_sdn": 2379227,
"descr": "Birth of Floyd, John S.",
"gid": "E1291",
"media": [],
"part_family": [],
"part_person": [
589
],
"place": 621,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1893",
"date_sdn": 2412465,
"descr": "Death of Floyd, John S.",
"gid": "E1292",
"media": [],
"part_family": [],
"part_person": [
589
],
"place": 858,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Floyd, John S.",
"gid": "E1293",
"media": [],
"part_family": [],
"part_person": [
589
],
"place": 320,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1843-05-13",
"date_sdn": 2394334,
"descr": "Birth of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2592",
"media": [],
"part_family": [],
"part_person": [
590
],
"place": 960,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-04-17",
"date_sdn": 2419875,
"descr": "Death of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2593",
"media": [],
"part_family": [],
"part_person": [
590
],
"place": 1129,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1913-04-19",
"date_sdn": 2419877,
"descr": "Burial of Floyd, Martha Frances &#8220;Fannie&#8221;",
"gid": "E2594",
"media": [],
"part_family": [],
"part_person": [
590
],
"place": 257,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1774-01-01",
"date_sdn": 2369001,
"descr": "Birth of Floyd, Nancy",
"gid": "E0756",
"media": [],
"part_family": [],
"part_person": [
591
],
"place": 1111,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-11-26",
"date_sdn": 2396723,
"descr": "Death of Floyd, Nancy",
"gid": "E0757",
"media": [],
"part_family": [],
"part_person": [
591
],
"place": 888,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1950-07-27",
"date_sdn": 2433490,
"descr": "Birth of Floyd, Robert William",
"gid": "E1470",
"media": [],
"part_family": [],
"part_person": [
592
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1471",
"media": [],
"part_family": [],
"part_person": [
592
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Floyd, Sarah (Sally)",
"gid": "E1582",
"media": [],
"part_family": [],
"part_person": [
593
],
"place": 877,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Floyd, Sarah (Sally)",
"gid": "E1583",
"media": [],
"part_family": [],
"part_person": [
593
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1916-10-31",
"date_sdn": 2421168,
"descr": "Birth of Ford, Lorinda Catherine",
"gid": "E1584",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": 580,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-11-27",
"date_sdn": 2445666,
"descr": "Death of Ford, Lorinda Catherine",
"gid": "E1585",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ford, Lorinda Catherine",
"gid": "E1586",
"media": [],
"part_family": [],
"part_person": [
596
],
"place": 406,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0822",
"media": [],
"part_family": [],
"part_person": [
597
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1664",
"date_sdn": 2328824,
"descr": "Birth of Fortin, Matthias",
"gid": "E2604",
"media": [],
"part_family": [],
"part_person": [
602
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1744-06-23",
"date_sdn": 2358217,
"descr": "Death of Fortin, Matthias",
"gid": "E2605",
"media": [],
"part_family": [],
"part_person": [
602
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1653",
"date_sdn": 2324807,
"descr": "Birth of Foster, David",
"gid": "E1060",
"media": [],
"part_family": [],
"part_person": [
603
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1555",
"date_sdn": 2289012,
"descr": "Birth of Foster, John",
"gid": "E0072",
"media": [],
"part_family": [],
"part_person": [
604
],
"place": 1260,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1598-01-31",
"date_sdn": 2304748,
"descr": "Death of Foster, John",
"gid": "E0073",
"media": [],
"part_family": [],
"part_person": [
604
],
"place": 1260,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1504",
"date_sdn": 2270384,
"descr": "Birth of Foster, John",
"gid": "E0066",
"media": [],
"part_family": [],
"part_person": [
605
],
"place": 502,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Foster, Thomas",
"gid": "E0068",
"media": [],
"part_family": [],
"part_person": [
606
],
"place": 67,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1557-06-23",
"date_sdn": 2289916,
"descr": "Death of Foster, Thomas",
"gid": "E0069",
"media": [],
"part_family": [],
"part_person": [
606
],
"place": 502,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1582-04-14",
"date_sdn": 2298977,
"descr": "Birth of Foster, Thomas",
"gid": "E0010",
"media": [],
"part_family": [],
"part_person": [
607
],
"place": 1260,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1658-06-01",
"date_sdn": 2326784,
"descr": "Death of Foster, Thomas",
"gid": "E0011",
"media": [],
"part_family": [],
"part_person": [
607
],
"place": 950,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1625",
"date_sdn": 2314580,
"descr": "Birth of Foster, William",
"gid": "E2120",
"media": [],
"part_family": [],
"part_person": [
608
],
"place": 1172,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1738",
"date_sdn": 2355852,
"descr": "Birth of Fox, David",
"gid": "E1827",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 71,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Fox, David",
"gid": "E1828",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 1147,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fox, David",
"gid": "E1829",
"media": [],
"part_family": [],
"part_person": [
610
],
"place": 1147,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1798-07-22",
"date_sdn": 2377969,
"descr": "Birth of Fox, David",
"gid": "E1288",
"media": [],
"part_family": [],
"part_person": [
611
],
"place": 1213,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1868-07-31",
"date_sdn": 2403545,
"descr": "Death of Fox, David",
"gid": "E1289",
"media": [],
"part_family": [],
"part_person": [
611
],
"place": 51,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1868-08-02",
"date_sdn": 2403547,
"descr": "Burial of Fox, David",
"gid": "E1290",
"media": [],
"part_family": [],
"part_person": [
611
],
"place": 398,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1769-02-00",
"date_sdn": 2367206,
"descr": "Birth of Fox, Jacob, Sr.",
"gid": "E1830",
"media": [],
"part_family": [],
"part_person": [
612
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-09-03",
"date_sdn": 2387508,
"descr": "Death of Fox, Jacob, Sr.",
"gid": "E1831",
"media": [],
"part_family": [],
"part_person": [
612
],
"place": 1087,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1823-12-25",
"date_sdn": 2387255,
"descr": "Birth of Fox, Julia Colville",
"gid": "E1423",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 642,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-02-12",
"date_sdn": 2416523,
"descr": "Death of Fox, Julia Colville",
"gid": "E1424",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 137,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1904",
"date_sdn": 2416481,
"descr": "Burial of Fox, Julia Colville",
"gid": "E1425",
"media": [],
"part_family": [],
"part_person": [
613
],
"place": 398,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1700",
"date_sdn": 2341973,
"descr": "Birth of Fox, Samuel",
"gid": "E1824",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 1281,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1744",
"date_sdn": 2358043,
"descr": "Death of Fox, Samuel",
"gid": "E1825",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 916,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fox, Samuel",
"gid": "E1826",
"media": [],
"part_family": [],
"part_person": [
614
],
"place": 1147,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Fox, William",
"gid": "E2136",
"media": [],
"part_family": [],
"part_person": [
615
],
"place": 1066,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Death of Fox, William",
"gid": "E2137",
"media": [],
"part_family": [],
"part_person": [
615
],
"place": 971,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Fox, William",
"gid": "E2138",
"media": [],
"part_family": [],
"part_person": [
615
],
"place": 48,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Francis, Elizabeth",
"gid": "E2622",
"media": [],
"part_family": [],
"part_person": [
616
],
"place": 666,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Francis, Elizabeth",
"gid": "E2623",
"media": [],
"part_family": [],
"part_person": [
616
],
"place": 666,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Frank, ???",
"gid": "E2210",
"media": [],
"part_family": [],
"part_person": [
617
],
"place": 282,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1746",
"date_sdn": 2358774,
"descr": "Birth of Frazier, Johann Adam",
"gid": "E0400",
"media": [],
"part_family": [],
"part_person": [
618
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1748",
"date_sdn": 2359504,
"descr": "Birth of Frazier, Johann Walter",
"gid": "E0403",
"media": [],
"part_family": [],
"part_person": [
619
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1712",
"date_sdn": 2346355,
"descr": "Birth of Frazier, Maria Margaretha",
"gid": "E0408",
"media": [],
"part_family": [],
"part_person": [
620
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1981-08-06",
"date_sdn": 2444823,
"descr": "Birth of French, Erin Jenny",
"gid": "E1376",
"media": [],
"part_family": [],
"part_person": [
621
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1377",
"media": [],
"part_family": [],
"part_person": [
621
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-04-06",
"date_sdn": 2432282,
"descr": "Birth of French, Jimmy Michael",
"gid": "E1372",
"media": [],
"part_family": [],
"part_person": [
622
],
"place": 825,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1373",
"media": [],
"part_family": [],
"part_person": [
622
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-07-03",
"date_sdn": 2441867,
"descr": "Birth of French, Kevin Wayne",
"gid": "E1374",
"media": [],
"part_family": [],
"part_person": [
623
],
"place": 1136,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1375",
"media": [],
"part_family": [],
"part_person": [
623
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "before 1901",
"date_sdn": 2415386,
"descr": "Death of Gagn\u00e9, Thomas",
"gid": "E1053",
"media": [],
"part_family": [],
"part_person": [
624
],
"place": 814,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1923-10-22",
"date_sdn": 2423715,
"descr": "Birth of Gagnon, Bettie Lou",
"gid": "E1242",
"media": [],
"part_family": [],
"part_person": [
625
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1243",
"media": [],
"part_family": [],
"part_person": [
625
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garc\u00eda, Maude",
"gid": "E2091",
"media": [],
"part_family": [],
"part_person": [
626
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Gardner, Mary",
"gid": "E2398",
"media": [],
"part_family": [],
"part_person": [
627
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Gardner, Mary",
"gid": "E2399",
"media": [],
"part_family": [],
"part_person": [
627
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Gardner, Mary",
"gid": "E2400",
"media": [],
"part_family": [],
"part_person": [
627
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1963-01-10",
"date_sdn": 2438040,
"descr": "Death of Gardner, Mary Jane",
"gid": "E2471",
"media": [],
"part_family": [],
"part_person": [
628
],
"place": 1247,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1963-01-12",
"date_sdn": 2438042,
"descr": "Burial of Gardner, Mary Jane",
"gid": "E2472",
"media": [],
"part_family": [],
"part_person": [
628
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Gardner, Michael",
"gid": "E2416",
"media": [],
"part_family": [],
"part_person": [
629
],
"place": 680,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1997-12-26",
"date_sdn": 2450809,
"descr": "Birth of Garner, Alecia &#8220;Allie&#8221; Clare",
"gid": "E0434",
"media": [],
"part_family": [],
"part_person": [
632
],
"place": 380,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0435",
"media": [],
"part_family": [],
"part_person": [
632
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1984-03-20",
"date_sdn": 2445780,
"descr": "Birth of Garner, Allison Renee",
"gid": "E0114",
"media": [],
"part_family": [],
"part_person": [
633
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0115",
"media": [],
"part_family": [],
"part_person": [
633
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1989-04-11",
"date_sdn": 2447628,
"descr": "Birth of Garner, Amy Elizabeth",
"gid": "E0116",
"media": [],
"part_family": [],
"part_person": [
634
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0117",
"media": [],
"part_family": [],
"part_person": [
634
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1825-01-28",
"date_sdn": 2387655,
"descr": "Birth of Garner, Anderson",
"gid": "E0178",
"media": [],
"part_family": [],
"part_person": [
635
],
"place": 1111,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1887-04-07",
"date_sdn": 2410369,
"descr": "Death of Garner, Anderson",
"gid": "E0179",
"media": [],
"part_family": [],
"part_person": [
635
],
"place": 866,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1887-04-08",
"date_sdn": 2410370,
"descr": "Burial of Garner, Anderson",
"gid": "E0180",
"media": [],
"part_family": [],
"part_person": [
635
],
"place": 866,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1999-04-11",
"date_sdn": 2451280,
"descr": "Birth of Garner, Andrew Joseph",
"gid": "E1174",
"media": [],
"part_family": [],
"part_person": [
636
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1175",
"media": [],
"part_family": [],
"part_person": [
636
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1870-06-13",
"date_sdn": 2404227,
"descr": "Birth of Garner, Anetta",
"gid": "E0217",
"media": [],
"part_family": [],
"part_person": [
637
],
"place": 186,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1900-10-04",
"date_sdn": 2415297,
"descr": "Death of Garner, Anetta",
"gid": "E0218",
"media": [],
"part_family": [],
"part_person": [
637
],
"place": 242,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1900-10-00",
"date_sdn": 2415294,
"descr": "Burial of Garner, Anetta",
"gid": "E0219",
"media": [],
"part_family": [],
"part_person": [
637
],
"place": 1115,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1950-09-10",
"date_sdn": 2433535,
"descr": "Birth of Garner, Anne Therese",
"gid": "E0716",
"media": [],
"part_family": [],
"part_person": [
638
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0717",
"media": [],
"part_family": [],
"part_person": [
638
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1870-06-13",
"date_sdn": 2404227,
"descr": "Birth of Garner, Antoinette",
"gid": "E0220",
"media": [],
"part_family": [],
"part_person": [
639
],
"place": 1100,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1880",
"date_sdn": 2407716,
"descr": "Death of Garner, Antoinette",
"gid": "E0221",
"media": [],
"part_family": [],
"part_person": [
639
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1949-11-08",
"date_sdn": 2433229,
"descr": "Birth of Garner, Barbara Jo",
"gid": "E0906",
"media": [],
"part_family": [],
"part_person": [
640
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0907",
"media": [],
"part_family": [],
"part_person": [
640
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-12-14",
"date_sdn": 2432900,
"descr": "Birth of Garner, Barry Joseph",
"gid": "E0659",
"media": [],
"part_family": [],
"part_person": [
641
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0660",
"media": [],
"part_family": [],
"part_person": [
641
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1957-08-31",
"date_sdn": 2436082,
"descr": "Birth of Garner, Bernadette",
"gid": "E0959",
"media": [],
"part_family": [],
"part_person": [
642
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0960",
"media": [],
"part_family": [],
"part_person": [
642
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1912-10-21",
"date_sdn": 2419697,
"descr": "Birth of Garner, Bernetha Ellen",
"gid": "E2066",
"media": [],
"part_family": [],
"part_person": [
643
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2067",
"media": [],
"part_family": [],
"part_person": [
643
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1888-03-13",
"date_sdn": 2410710,
"descr": "Birth of Garner, Bertha P.",
"gid": "E2051",
"media": [],
"part_family": [],
"part_person": [
644
],
"place": 471,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-04-05",
"date_sdn": 2421689,
"descr": "Death of Garner, Bertha P.",
"gid": "E2052",
"media": [],
"part_family": [],
"part_person": [
644
],
"place": 242,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1918-04-00",
"date_sdn": 2421685,
"descr": "Burial of Garner, Bertha P.",
"gid": "E2053",
"media": [],
"part_family": [],
"part_person": [
644
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1920-08-25",
"date_sdn": 2422562,
"descr": "Birth of Garner, Betty Jane",
"gid": "E2073",
"media": [],
"part_family": [],
"part_person": [
645
],
"place": 302,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2074",
"media": [],
"part_family": [],
"part_person": [
645
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1908-03-13",
"date_sdn": 2418014,
"descr": "Birth of Garner, Cecile Elizabeth",
"gid": "E2061",
"media": [],
"part_family": [],
"part_person": [
646
],
"place": 742,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1975-03-22",
"date_sdn": 2442494,
"descr": "Death of Garner, Cecile Elizabeth",
"gid": "E2062",
"media": [],
"part_family": [],
"part_person": [
646
],
"place": 73,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garner, Cecile Elizabeth",
"gid": "E2063",
"media": [],
"part_family": [],
"part_person": [
646
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1960-07-14",
"date_sdn": 2437130,
"descr": "Birth of Garner, Cecilia",
"gid": "E0975",
"media": [],
"part_family": [],
"part_person": [
647
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0976",
"media": [],
"part_family": [],
"part_person": [
647
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1914-09-07",
"date_sdn": 2420383,
"descr": "Birth of Garner, Daniel Burton",
"gid": "E2068",
"media": [],
"part_family": [],
"part_person": [
648
],
"place": 112,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-10-02",
"date_sdn": 2421139,
"descr": "Death of Garner, Daniel Burton",
"gid": "E2069",
"media": [],
"part_family": [],
"part_person": [
648
],
"place": 912,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garner, Daniel Burton",
"gid": "E2070",
"media": [],
"part_family": [],
"part_person": [
648
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1985-02-11",
"date_sdn": 2446108,
"descr": "Birth of Garner, Daniel Patrick",
"gid": "E0345",
"media": [],
"part_family": [],
"part_person": [
649
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0346",
"media": [],
"part_family": [],
"part_person": [
649
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1883-09-30",
"date_sdn": 2409084,
"descr": "Birth of Garner, Daniel Webster",
"gid": "E2048",
"media": [],
"part_family": [],
"part_person": [
650
],
"place": 510,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1936-03-02",
"date_sdn": 2428230,
"descr": "Death of Garner, Daniel Webster",
"gid": "E2049",
"media": [],
"part_family": [],
"part_person": [
650
],
"place": 430,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1936-03-04",
"date_sdn": 2428232,
"descr": "Burial of Garner, Daniel Webster",
"gid": "E2050",
"media": [],
"part_family": [],
"part_person": [
650
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1956-12-21",
"date_sdn": 2435829,
"descr": "Birth of Garner, David Walter",
"gid": "E0925",
"media": [],
"part_family": [],
"part_person": [
651
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0926",
"media": [],
"part_family": [],
"part_person": [
651
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1883",
"date_sdn": 2408812,
"descr": "Birth of Garner, Elizabeth",
"gid": "E2054",
"media": [],
"part_family": [],
"part_person": [
652
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Garner, Elizabeth",
"gid": "E2055",
"media": [],
"part_family": [],
"part_person": [
652
],
"place": 490,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1868-08-18",
"date_sdn": 2403563,
"descr": "Birth of Garner, Emma A.",
"gid": "E0214",
"media": [],
"part_family": [],
"part_person": [
653
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-02-23",
"date_sdn": 2403752,
"descr": "Death of Garner, Emma A.",
"gid": "E0215",
"media": [],
"part_family": [],
"part_person": [
653
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-02-00",
"date_sdn": 2403730,
"descr": "Burial of Garner, Emma A.",
"gid": "E0216",
"media": [],
"part_family": [],
"part_person": [
653
],
"place": 1115,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1895-12-01",
"date_sdn": 2413529,
"descr": "Birth of Garner, Eugene Stanley",
"gid": "E1702",
"media": [],
"part_family": [],
"part_person": [
654
],
"place": 954,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-03-01",
"date_sdn": 2445761,
"descr": "Death of Garner, Eugene Stanley",
"gid": "E1703",
"media": [],
"part_family": [],
"part_person": [
654
],
"place": 1169,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1984-03-03",
"date_sdn": 2445763,
"descr": "Burial of Garner, Eugene Stanley",
"gid": "E1704",
"media": [],
"part_family": [],
"part_person": [
654
],
"place": 1169,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Garner, Eugene Stanley, Jr.",
"gid": "E0457",
"media": [],
"part_family": [],
"part_person": [
655
],
"place": 1194,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0458",
"media": [],
"part_family": [],
"part_person": [
655
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1945-01-03",
"date_sdn": 2431459,
"descr": "Birth of Garner, Francis William",
"gid": "E0867",
"media": [],
"part_family": [],
"part_person": [
656
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0868",
"media": [],
"part_family": [],
"part_person": [
656
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1955-07-31",
"date_sdn": 2435320,
"descr": "Birth of Garner, Gerard Stephen",
"gid": "E0808",
"media": [],
"part_family": [],
"part_person": [
657
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0809",
"media": [],
"part_family": [],
"part_person": [
657
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1972-03-14",
"date_sdn": 2441391,
"descr": "Birth of Garner, Heather Jo",
"gid": "E0084",
"media": [],
"part_family": [],
"part_person": [
658
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0085",
"media": [],
"part_family": [],
"part_person": [
658
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1909-11-05",
"date_sdn": 2418616,
"descr": "Birth of Garner, Helen Bernice",
"gid": "E2064",
"media": [],
"part_family": [],
"part_person": [
659
],
"place": 943,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2065",
"media": [],
"part_family": [],
"part_person": [
659
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1928-07-09",
"date_sdn": 2425437,
"descr": "Birth of Garner, Howard Lane",
"gid": "E0002",
"media": [],
"part_family": [],
"part_person": [
660
],
"place": 614,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1860-11-01",
"date_sdn": 2400716,
"descr": "Birth of Garner, Iola Elizabeth Betty",
"gid": "E0208",
"media": [],
"part_family": [],
"part_person": [
661
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1941-04-17",
"date_sdn": 2430102,
"descr": "Death of Garner, Iola Elizabeth Betty",
"gid": "E0209",
"media": [],
"part_family": [],
"part_person": [
661
],
"place": 590,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1941-04-19",
"date_sdn": 2430104,
"descr": "Burial of Garner, Iola Elizabeth Betty",
"gid": "E0210",
"media": [],
"part_family": [],
"part_person": [
661
],
"place": 232,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1950-04-27",
"date_sdn": 2433399,
"descr": "Birth of Garner, Jane McClellan",
"gid": "E2116",
"media": [],
"part_family": [],
"part_person": [
662
],
"place": 862,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2117",
"media": [],
"part_family": [],
"part_person": [
662
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1975-10-20",
"date_sdn": 2442706,
"descr": "Birth of Garner, Jason Richard",
"gid": "E0088",
"media": [],
"part_family": [],
"part_person": [
663
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0089",
"media": [],
"part_family": [],
"part_person": [
663
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1880-09-11",
"date_sdn": 2407970,
"descr": "Birth of Garner, Jennie S.",
"gid": "E2042",
"media": [],
"part_family": [],
"part_person": [
664
],
"place": 912,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1964-06-20",
"date_sdn": 2438567,
"descr": "Death of Garner, Jennie S.",
"gid": "E2043",
"media": [],
"part_family": [],
"part_person": [
664
],
"place": 242,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1964-06-00",
"date_sdn": 2438548,
"descr": "Burial of Garner, Jennie S.",
"gid": "E2044",
"media": [],
"part_family": [],
"part_person": [
664
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1876-06-18",
"date_sdn": 2406424,
"descr": "Birth of Garner, Jesse V.",
"gid": "E2037",
"media": [],
"part_family": [],
"part_person": [
665
],
"place": 912,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1929-01-21",
"date_sdn": 2425633,
"descr": "Death of Garner, Jesse V.",
"gid": "E2038",
"media": [],
"part_family": [],
"part_person": [
665
],
"place": 181,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1929",
"date_sdn": 2425613,
"descr": "Burial of Garner, Jesse V.",
"gid": "E2039",
"media": [],
"part_family": [],
"part_person": [
665
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1961-08-15",
"date_sdn": 2437527,
"descr": "Birth of Garner, John Joseph",
"gid": "E0994",
"media": [],
"part_family": [],
"part_person": [
666
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0995",
"media": [],
"part_family": [],
"part_person": [
666
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1925-10-29",
"date_sdn": 2424453,
"descr": "Birth of Garner, John Roger",
"gid": "E0471",
"media": [],
"part_family": [],
"part_person": [
667
],
"place": 613,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0472",
"media": [],
"part_family": [],
"part_person": [
667
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1792",
"date_sdn": 2375575,
"descr": "Birth of Garner, Joseph",
"gid": "E0076",
"media": [],
"part_family": [],
"part_person": [
668
],
"place": 1111,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Garner, Joseph",
"gid": "E0077",
"media": [],
"part_family": [],
"part_person": [
668
],
"place": 1060,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1952-09-10",
"date_sdn": 2434266,
"descr": "Birth of Garner, Kathryn Mary",
"gid": "E0927",
"media": [],
"part_family": [],
"part_person": [
669
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0928",
"media": [],
"part_family": [],
"part_person": [
669
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1823-11-18",
"date_sdn": 2387218,
"descr": "Birth of Garner, Lewis",
"gid": "E0175",
"media": [],
"part_family": [],
"part_person": [
670
],
"place": 807,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1911-01-21",
"date_sdn": 2419058,
"descr": "Death of Garner, Lewis",
"gid": "E0176",
"media": [],
"part_family": [],
"part_person": [
670
],
"place": 1169,
"text": "<div>\n<p>\n<b>Age</b>: 88 years\n</p>\n</div>",
"type": "Death"
},
{
"cita": [],
"date": "1911-01-23",
"date_sdn": 2419060,
"descr": "Burial of Garner, Lewis",
"gid": "E0177",
"media": [],
"part_family": [],
"part_person": [
670
],
"place": 597,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [
0,
2834,
2843,
2844
],
"date": "1855-06-21",
"date_sdn": 2398756,
"descr": "Birth of Garner, Lewis Anderson",
"gid": "E1656",
"media": [
{
"cita": [
2845,
2846
],
"m_idx": 0,
"note": "<div>\n<p>\n<b>Father's Age</b>: 25\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/1/2/b39fe1cfc1305ac4a21.png"
}
],
"part_family": [],
"part_person": [
671
],
"place": 451,
"text": "<div>\n<p>\n<b>Time</b>: 10:00 pm\n</p>\n<p>\n<b>Father's Age</b>: 28\n</p>\n</div>",
"type": "Birth"
},
{
"cita": [],
"date": "1911-06-28",
"date_sdn": 2419216,
"descr": "Death of Garner, Lewis Anderson",
"gid": "E1657",
"media": [],
"part_family": [],
"part_person": [
671
],
"place": 1169,
"text": "<div>\n<i class=\"NoteType\">\nEvent Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\n<span style=\"text-decoration:underline;\">How</span> did he die? <span style=\"color:#ff0909;\"></span><span style=\"font-size:14px;\"><span style=\"color:#ff0909;\">We need to find out!</span></span><span style=\"color:#ff0909;\"></span>\n</p>\n<p>\nPerhaps we find info in <strong></strong><span style=\"background-color:#fbd50a;\"><strong>the new york</strong></span><strong></strong> library\n</p>\n</div>\n<p>\n<b>Cause</b>: Laughter\n</p>\n</div>",
"type": "Death"
},
{
"cita": [],
"date": "1911-07-01",
"date_sdn": 2419219,
"descr": "Burial of Garner, Lewis Anderson",
"gid": "E1658",
"media": [],
"part_family": [],
"part_person": [
671
],
"place": 1169,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Garner, Louella Marie",
"gid": "E0968",
"media": [],
"part_family": [],
"part_person": [
672
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0969",
"media": [],
"part_family": [],
"part_person": [
672
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1951-07-18",
"date_sdn": 2433846,
"descr": "Birth of Garner, Margaret Ann",
"gid": "E0074",
"media": [],
"part_family": [],
"part_person": [
673
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-02-10",
"date_sdn": 2434053,
"descr": "Death of Garner, Margaret Ann",
"gid": "E0075",
"media": [],
"part_family": [],
"part_person": [
673
],
"place": 893,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1962-10-16",
"date_sdn": 2437954,
"descr": "Birth of Garner, Mark Gerard",
"gid": "E0986",
"media": [],
"part_family": [],
"part_person": [
676
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0987",
"media": [],
"part_family": [],
"part_person": [
676
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1851-10-12",
"date_sdn": 2397408,
"descr": "Birth of Garner, Mary J.",
"gid": "E0194",
"media": [],
"part_family": [],
"part_person": [
677
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1852-04-01",
"date_sdn": 2397580,
"descr": "Death of Garner, Mary J.",
"gid": "E0195",
"media": [],
"part_family": [],
"part_person": [
677
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1858-04-00",
"date_sdn": 2399771,
"descr": "Burial of Garner, Mary J.",
"gid": "E0196",
"media": [],
"part_family": [],
"part_person": [
677
],
"place": 1115,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1851-10-12",
"date_sdn": 2397408,
"descr": "Birth of Garner, Mary M.",
"gid": "E0197",
"media": [],
"part_family": [],
"part_person": [
678
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1858-05-24",
"date_sdn": 2399824,
"descr": "Death of Garner, Mary M.",
"gid": "E0198",
"media": [],
"part_family": [],
"part_person": [
678
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1858-05-00",
"date_sdn": 2399801,
"descr": "Burial of Garner, Mary M.",
"gid": "E0199",
"media": [],
"part_family": [],
"part_person": [
678
],
"place": 1115,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1978-07-17",
"date_sdn": 2443707,
"descr": "Birth of Garner, Megan Ann",
"gid": "E0097",
"media": [],
"part_family": [],
"part_person": [
680
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0098",
"media": [],
"part_family": [],
"part_person": [
680
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1969-12-03",
"date_sdn": 2440559,
"descr": "Birth of Garner, Melissa Sue",
"gid": "E0080",
"media": [],
"part_family": [],
"part_person": [
681
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0081",
"media": [],
"part_family": [],
"part_person": [
681
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1975-06-01",
"date_sdn": 2442565,
"descr": "Birth of Garner, Michael Christopher",
"gid": "E0095",
"media": [],
"part_family": [],
"part_person": [
682
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0096",
"media": [],
"part_family": [],
"part_person": [
682
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-06-12",
"date_sdn": 2432715,
"descr": "Birth of Garner, Michael Stanley",
"gid": "E0892",
"media": [],
"part_family": [],
"part_person": [
683
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0893",
"media": [],
"part_family": [],
"part_person": [
683
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1954-08-05",
"date_sdn": 2434960,
"descr": "Birth of Garner, Peter George",
"gid": "E0946",
"media": [],
"part_family": [],
"part_person": [
684
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0947",
"media": [],
"part_family": [],
"part_person": [
684
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1850",
"date_sdn": 2396759,
"descr": "Birth of Garner, Phebe",
"gid": "E0192",
"media": [],
"part_family": [],
"part_person": [
685
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1860",
"date_sdn": 2400411,
"descr": "Death of Garner, Phebe",
"gid": "E0193",
"media": [],
"part_family": [],
"part_person": [
685
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1878-09-16",
"date_sdn": 2407244,
"descr": "Birth of Garner, Raymond E.",
"gid": "E2040",
"media": [],
"part_family": [],
"part_person": [
686
],
"place": 912,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-05-02",
"date_sdn": 2422812,
"descr": "Death of Garner, Raymond E.",
"gid": "E2041",
"media": [],
"part_family": [],
"part_person": [
686
],
"place": 55,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1956-03-05",
"date_sdn": 2435538,
"descr": "Birth of Garner, Raymond Scott",
"gid": "E2118",
"media": [],
"part_family": [],
"part_person": [
687
],
"place": 242,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2119",
"media": [],
"part_family": [],
"part_person": [
687
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1918-02-17",
"date_sdn": 2421642,
"descr": "Birth of Garner, Raymond Webster",
"gid": "E2071",
"media": [],
"part_family": [],
"part_person": [
688
],
"place": 242,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2072",
"media": [],
"part_family": [],
"part_person": [
688
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1857-05-30",
"date_sdn": 2399465,
"descr": "Birth of Garner, Rebecca Catharine",
"gid": "E0200",
"media": [],
"part_family": [],
"part_person": [
689
],
"place": 302,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1937-04-09",
"date_sdn": 2428633,
"descr": "Death of Garner, Rebecca Catharine",
"gid": "E0201",
"media": [],
"part_family": [],
"part_person": [
689
],
"place": 25,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1937-04-11",
"date_sdn": 2428635,
"descr": "Burial of Garner, Rebecca Catharine",
"gid": "E0202",
"media": [],
"part_family": [],
"part_person": [
689
],
"place": 716,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1973-08-27",
"date_sdn": 2441922,
"descr": "Birth of Garner, Regina Lynne",
"gid": "E0086",
"media": [],
"part_family": [],
"part_person": [
690
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0087",
"media": [],
"part_family": [],
"part_person": [
690
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-02-28",
"date_sdn": 2432245,
"descr": "Birth of Garner, Richard Eugene",
"gid": "E0876",
"media": [],
"part_family": [],
"part_person": [
691
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0877",
"media": [],
"part_family": [],
"part_person": [
691
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1952-09-07",
"date_sdn": 2434263,
"descr": "Birth of Garner, Rita Marie",
"gid": "E1981",
"media": [],
"part_family": [],
"part_person": [
692
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1982",
"media": [],
"part_family": [],
"part_person": [
692
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1863-04-04",
"date_sdn": 2401600,
"descr": "Birth of Garner, Robert F.",
"gid": "E0211",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": 912,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-12-25",
"date_sdn": 2425240,
"descr": "Marriage of W\u00f3jcik, Arnold and Garner, Helen Bernice",
"gid": "E2829",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": -1,
"text": "",
"type": "Marriage (Witness)"
},
{
"cita": [],
"date": "1940-02-17",
"date_sdn": 2429677,
"descr": "Death of Garner, Robert F.",
"gid": "E0212",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": 724,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1940-02-19",
"date_sdn": 2429679,
"descr": "Burial of Garner, Robert F.",
"gid": "E0213",
"media": [],
"part_family": [],
"part_person": [
693
],
"place": 302,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1826/7-04-24 (Julian)",
"date_sdn": 2388483,
"descr": "Birth of Garner, Robert W.",
"gid": "E0105",
"media": [],
"part_family": [],
"part_person": [
694
],
"place": 1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-03",
"date_sdn": 2420897,
"descr": "Death of Garner, Robert W.",
"gid": "E0106",
"media": [],
"part_family": [],
"part_person": [
694
],
"place": 954,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1916-02-05 (Mar25)",
"date_sdn": 2420899,
"descr": "Burial of Garner, Robert W.",
"gid": "E0107",
"media": [],
"part_family": [],
"part_person": [
694
],
"place": 597,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1983-10-05",
"date_sdn": 2445613,
"descr": "Birth of Garner, Stephen Gerard",
"gid": "E0336",
"media": [],
"part_family": [],
"part_person": [
695
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0337",
"media": [],
"part_family": [],
"part_person": [
695
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1965-12-10",
"date_sdn": 2439105,
"descr": "Birth of Garner, Thomas James",
"gid": "E1016",
"media": [],
"part_family": [],
"part_person": [
696
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1017",
"media": [],
"part_family": [],
"part_person": [
696
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1993-10-01",
"date_sdn": 2449262,
"descr": "Birth of Garner, Vanichia Elaine",
"gid": "E0093",
"media": [],
"part_family": [],
"part_person": [
697
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0094",
"media": [],
"part_family": [],
"part_person": [
697
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1882-02-17",
"date_sdn": 2408494,
"descr": "Birth of Garner, Walter E.",
"gid": "E2045",
"media": [],
"part_family": [],
"part_person": [
700
],
"place": 912,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1946-10-23",
"date_sdn": 2432117,
"descr": "Death of Garner, Walter E.",
"gid": "E2046",
"media": [],
"part_family": [],
"part_person": [
700
],
"place": 81,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1946-10-00",
"date_sdn": 2432095,
"descr": "Burial of Garner, Walter E.",
"gid": "E2047",
"media": [],
"part_family": [],
"part_person": [
700
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1923-12-08",
"date_sdn": 2423762,
"descr": "Birth of Garrett, Carmen Eloise",
"gid": "E1258",
"media": [],
"part_family": [],
"part_person": [
701
],
"place": 439,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1997-03-25",
"date_sdn": 2450533,
"descr": "Death of Garrett, Carmen Eloise",
"gid": "E1259",
"media": [],
"part_family": [],
"part_person": [
701
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1950-08-22",
"date_sdn": 2433516,
"descr": "Birth of Garrett, Doris Mae",
"gid": "E1269",
"media": [],
"part_family": [],
"part_person": [
702
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1270",
"media": [],
"part_family": [],
"part_person": [
702
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1952-11-01",
"date_sdn": 2434318,
"descr": "Birth of Garrett, Keith William",
"gid": "E1271",
"media": [],
"part_family": [],
"part_person": [
703
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1272",
"media": [],
"part_family": [],
"part_person": [
703
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1936-08-29",
"date_sdn": 2428410,
"descr": "Birth of Garrett, Lloyd Willis",
"gid": "E1273",
"media": [],
"part_family": [],
"part_person": [
704
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1274",
"media": [],
"part_family": [],
"part_person": [
704
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1956-04-14",
"date_sdn": 2435578,
"descr": "Birth of Garrett, Terry Lee",
"gid": "E2289",
"media": [],
"part_family": [],
"part_person": [
705
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1998-04-23",
"date_sdn": 2450927,
"descr": "Death of Garrett, Terry Lee",
"gid": "E2290",
"media": [],
"part_family": [],
"part_person": [
705
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1961-11-21",
"date_sdn": 2437625,
"descr": "Birth of Garrett, Wayne Allen",
"gid": "E2293",
"media": [],
"part_family": [],
"part_person": [
706
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1967-01-00",
"date_sdn": 2439492,
"descr": "Death of Garrett, Wayne Allen",
"gid": "E2294",
"media": [],
"part_family": [],
"part_person": [
706
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1927-05-13",
"date_sdn": 2425014,
"descr": "Birth of Garrett, William Forest",
"gid": "E1266",
"media": [],
"part_family": [],
"part_person": [
707
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1267",
"media": [],
"part_family": [],
"part_person": [
707
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1890-11-07",
"date_sdn": 2411679,
"descr": "Birth of Garrett, William Walker",
"gid": "E1254",
"media": [],
"part_family": [],
"part_person": [
708
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1987-11-07",
"date_sdn": 2447107,
"descr": "Birth of Garza, Jeffrey Adam Ramos",
"gid": "E1480",
"media": [],
"part_family": [],
"part_person": [
709
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1481",
"media": [],
"part_family": [],
"part_person": [
709
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1810-12-20",
"date_sdn": 2382502,
"descr": "Birth of Gauthier, Julius",
"gid": "E0646",
"media": [],
"part_family": [],
"part_person": [
710
],
"place": 948,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1957-01-31",
"date_sdn": 2435870,
"descr": "Birth of George, Elizabeth",
"gid": "E0323",
"media": [],
"part_family": [],
"part_person": [
711
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0324",
"media": [],
"part_family": [],
"part_person": [
711
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1943-02-08",
"date_sdn": 2430764,
"descr": "Birth of Gibbs, Connie",
"gid": "E0078",
"media": [],
"part_family": [],
"part_person": [
714
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0079",
"media": [],
"part_family": [],
"part_person": [
714
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1979-10-01",
"date_sdn": 2444148,
"descr": "Death of Gibbs, Elizabeth",
"gid": "E0978",
"media": [],
"part_family": [],
"part_person": [
716
],
"place": 591,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Gibbs, Jennie",
"gid": "E1004",
"media": [],
"part_family": [],
"part_person": [
717
],
"place": 1074,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "about 1460",
"date_sdn": 2254314,
"descr": "Birth of Gibbs, Margaret",
"gid": "E0252",
"media": [],
"part_family": [],
"part_person": [
721
],
"place": 301,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0962",
"media": [],
"part_family": [],
"part_person": [
722
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1936-01-29",
"date_sdn": 2428197,
"descr": "Death of Gibbs, Mary",
"gid": "E0937",
"media": [],
"part_family": [],
"part_person": [
724
],
"place": 1272,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1167",
"media": [],
"part_family": [],
"part_person": [
727
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Gil, Nora",
"gid": "E2401",
"media": [],
"part_family": [],
"part_person": [
730
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Gil, Nora",
"gid": "E2402",
"media": [],
"part_family": [],
"part_person": [
730
],
"place": 40,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Gil, Nora",
"gid": "E2403",
"media": [],
"part_family": [],
"part_person": [
730
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Gill, Avery",
"gid": "E1096",
"media": [],
"part_family": [],
"part_person": [
732
],
"place": 1224,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1097",
"media": [],
"part_family": [],
"part_person": [
732
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1968-10-26",
"date_sdn": 2440156,
"descr": "Birth of Gill, Lawrence",
"gid": "E1596",
"media": [],
"part_family": [],
"part_person": [
734
],
"place": 505,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1597",
"media": [],
"part_family": [],
"part_person": [
734
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1946-11-10",
"date_sdn": 2432135,
"descr": "Birth of Gill, Linda",
"gid": "E1642",
"media": [],
"part_family": [],
"part_person": [
735
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1643",
"media": [],
"part_family": [],
"part_person": [
735
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1967",
"date_sdn": 2439492,
"descr": "Birth of Gill, Lorie Ann",
"gid": "E1598",
"media": [],
"part_family": [],
"part_person": [
736
],
"place": 1114,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1599",
"media": [],
"part_family": [],
"part_person": [
736
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1473",
"date_sdn": 2259063,
"descr": "Birth of Gomez, Culthbert",
"gid": "E0061",
"media": [],
"part_family": [],
"part_person": [
739
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1499",
"date_sdn": 2268559,
"descr": "Birth of Gomez, Jane Joane",
"gid": "E0064",
"media": [],
"part_family": [],
"part_person": [
740
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1573",
"date_sdn": 2295587,
"descr": "Death of Gomez, Jane Joane",
"gid": "E0065",
"media": [],
"part_family": [],
"part_person": [
740
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1949",
"date_sdn": 2432918,
"descr": "Birth of Gonzales, Linda S.",
"gid": "E2503",
"media": [],
"part_family": [],
"part_person": [
741
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2504",
"media": [],
"part_family": [],
"part_person": [
741
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1952",
"date_sdn": 2434013,
"descr": "Birth of Gonzales, Mark R.",
"gid": "E2505",
"media": [],
"part_family": [],
"part_person": [
742
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2506",
"media": [],
"part_family": [],
"part_person": [
742
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1708-06-01",
"date_sdn": 2345046,
"descr": "Birth of Gonz\u00e1lez, Elizabeth",
"gid": "E1866",
"media": [],
"part_family": [],
"part_person": [
745
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Goodman, Ralph",
"gid": "E0272",
"media": [],
"part_family": [],
"part_person": [
747
],
"place": 465,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1626-06-25",
"date_sdn": 2315120,
"descr": "Burial of Goodman, Ralph",
"gid": "E0273",
"media": [],
"part_family": [],
"part_person": [
747
],
"place": 771,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Goodwin, Sarah",
"gid": "E2531",
"media": [],
"part_family": [],
"part_person": [
750
],
"place": 1063,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Goodwin, Sarah",
"gid": "E2532",
"media": [],
"part_family": [],
"part_person": [
750
],
"place": 1063,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1886",
"date_sdn": 2409908,
"descr": "Burial of Goodwin, Sarah",
"gid": "E2533",
"media": [],
"part_family": [],
"part_person": [
750
],
"place": 680,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1988-07-10",
"date_sdn": 2447353,
"descr": "Birth of Gosselin, Andrea Lynn",
"gid": "E0274",
"media": [],
"part_family": [],
"part_person": [
752
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0275",
"media": [],
"part_family": [],
"part_person": [
752
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990-12-20",
"date_sdn": 2448246,
"descr": "Birth of Gosselin, Craig Richard",
"gid": "E1763",
"media": [],
"part_family": [],
"part_person": [
753
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1764",
"media": [],
"part_family": [],
"part_person": [
753
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1983-08-02",
"date_sdn": 2445549,
"descr": "Birth of Gosselin, David Martin",
"gid": "E0249",
"media": [],
"part_family": [],
"part_person": [
754
],
"place": 1103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0250",
"media": [],
"part_family": [],
"part_person": [
754
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1985-10-03",
"date_sdn": 2446342,
"descr": "Birth of Gosselin, Joel Thomas",
"gid": "E0258",
"media": [],
"part_family": [],
"part_person": [
755
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0259",
"media": [],
"part_family": [],
"part_person": [
755
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1958-09-30",
"date_sdn": 2436477,
"descr": "Birth of Gosselin, Martin Kelly",
"gid": "E0237",
"media": [],
"part_family": [],
"part_person": [
756
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0238",
"media": [],
"part_family": [],
"part_person": [
756
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1798-08-16",
"date_sdn": 2377994,
"descr": "Birth of Graves, Martha",
"gid": "E2021",
"media": [],
"part_family": [],
"part_person": [
760
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1862-12-12",
"date_sdn": 2401487,
"descr": "Death of Graves, Martha",
"gid": "E2022",
"media": [],
"part_family": [],
"part_person": [
760
],
"place": 403,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Graves, Martha",
"gid": "E2023",
"media": [],
"part_family": [],
"part_person": [
760
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1050",
"date_sdn": 2104565,
"descr": "Birth of Gray, Beatrix",
"gid": "E0024",
"media": [],
"part_family": [],
"part_person": [
761
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1112",
"date_sdn": 2127209,
"descr": "Death of Gray, Beatrix",
"gid": "E0025",
"media": [],
"part_family": [],
"part_person": [
761
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1685-06-06",
"date_sdn": 2336651,
"descr": "Birth of Green, Edward",
"gid": "E1873",
"media": [],
"part_family": [],
"part_person": [
762
],
"place": 92,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1756-10-20",
"date_sdn": 2362719,
"descr": "Death of Green, Edward",
"gid": "E1874",
"media": [],
"part_family": [],
"part_person": [
762
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Green, Edward",
"gid": "E1863",
"media": [],
"part_family": [],
"part_person": [
763
],
"place": 587,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1688-07-31",
"date_sdn": 2337802,
"descr": "Death of Green, Edward",
"gid": "E1864",
"media": [],
"part_family": [],
"part_person": [
763
],
"place": 775,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1804-07-22",
"date_sdn": 2380160,
"descr": "Birth of Green, Frances",
"gid": "E1309",
"media": [],
"part_family": [],
"part_person": [
764
],
"place": 947,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1886-07-31",
"date_sdn": 2410119,
"descr": "Death of Green, Frances",
"gid": "E1310",
"media": [],
"part_family": [],
"part_person": [
764
],
"place": 51,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1886-08-02",
"date_sdn": 2410121,
"descr": "Burial of Green, Frances",
"gid": "E1311",
"media": [],
"part_family": [],
"part_person": [
764
],
"place": 398,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1739-04-07",
"date_sdn": 2356313,
"descr": "Birth of Green, James",
"gid": "E1880",
"media": [],
"part_family": [],
"part_person": [
765
],
"place": 775,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805-11-28",
"date_sdn": 2380654,
"descr": "Death of Green, James",
"gid": "E1881",
"media": [],
"part_family": [],
"part_person": [
765
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1768-03-17",
"date_sdn": 2366885,
"descr": "Birth of Green, Randolph",
"gid": "E1882",
"media": [],
"part_family": [],
"part_person": [
766
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-03-17",
"date_sdn": 2392451,
"descr": "Death of Green, Randolph",
"gid": "E1883",
"media": [],
"part_family": [],
"part_person": [
766
],
"place": 579,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Green, Randolph",
"gid": "E1884",
"media": [],
"part_family": [],
"part_person": [
766
],
"place": 579,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1683-10-24",
"date_sdn": 2336060,
"descr": "Death of Green, Yelverton",
"gid": "E2423",
"media": [],
"part_family": [],
"part_person": [
767
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1605",
"date_sdn": 2307275,
"descr": "Birth of Grenier, Joseph",
"gid": "E2241",
"media": [],
"part_family": [],
"part_person": [
771
],
"place": 502,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1647-12-04",
"date_sdn": 2322952,
"descr": "Death of Grenier, Joseph",
"gid": "E2242",
"media": [],
"part_family": [],
"part_person": [
771
],
"place": 1002,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Grenier, Joseph",
"gid": "E2243",
"media": [],
"part_family": [],
"part_person": [
771
],
"place": 325,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1638",
"date_sdn": 2319328,
"descr": "Birth of Grenier, Mary",
"gid": "E1849",
"media": [],
"part_family": [],
"part_person": [
772
],
"place": 622,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1703-07-12",
"date_sdn": 2343260,
"descr": "Death of Grenier, Mary",
"gid": "E1850",
"media": [],
"part_family": [],
"part_person": [
772
],
"place": 947,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1405",
"date_sdn": 2234226,
"descr": "Birth of Guerrero, Robert",
"gid": "E0255",
"media": [],
"part_family": [],
"part_person": [
775
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1430",
"date_sdn": 2243357,
"descr": "Birth of Guerrero, Robert",
"gid": "E0254",
"media": [],
"part_family": [],
"part_person": [
776
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1380",
"date_sdn": 2225095,
"descr": "Birth of Guerrero, Walter",
"gid": "E0256",
"media": [],
"part_family": [],
"part_person": [
778
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1350",
"date_sdn": 2214138,
"descr": "Birth of Guerrero, Walter",
"gid": "E0257",
"media": [],
"part_family": [],
"part_person": [
779
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Gutierrez, Catherine",
"gid": "E1551",
"media": [],
"part_family": [],
"part_person": [
780
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Gutierrez, Catherine",
"gid": "E1552",
"media": [],
"part_family": [],
"part_person": [
780
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1924-02-01",
"date_sdn": 2423817,
"descr": "Birth of Guti\u00e9rrez, Dorothy Jean",
"gid": "E1161",
"media": [],
"part_family": [],
"part_person": [
781
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1927-01-18",
"date_sdn": 2424899,
"descr": "Birth of Guti\u00e9rrez, Joan Arlene",
"gid": "E1162",
"media": [],
"part_family": [],
"part_person": [
782
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1921-07-01",
"date_sdn": 2422872,
"descr": "Birth of Guti\u00e9rrez, Virginia Elizabeth",
"gid": "E1160",
"media": [],
"part_family": [],
"part_person": [
784
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1896-05-09",
"date_sdn": 2413689,
"descr": "Birth of Guti\u00e9rrez, Walter Harmon",
"gid": "E1159",
"media": [],
"part_family": [],
"part_person": [
785
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1695",
"date_sdn": 2340147,
"descr": "Birth of Guzman, Isabella",
"gid": "E0172",
"media": [],
"part_family": [],
"part_person": [
786
],
"place": 736,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1700",
"date_sdn": 2341973,
"descr": "Death of Guzman, Isabella",
"gid": "E0173",
"media": [],
"part_family": [],
"part_person": [
786
],
"place": 736,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1982-10-03",
"date_sdn": 2445246,
"descr": "Birth of Hale, Gina Marie",
"gid": "E0311",
"media": [],
"part_family": [],
"part_person": [
787
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0312",
"media": [],
"part_family": [],
"part_person": [
787
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1988-12-23",
"date_sdn": 2447519,
"descr": "Birth of Hale, Jeffrey Brian",
"gid": "E0316",
"media": [],
"part_family": [],
"part_person": [
788
],
"place": 558,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0317",
"media": [],
"part_family": [],
"part_person": [
788
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1975-07-17",
"date_sdn": 2442611,
"descr": "Birth of Hale, Joseph Brendan",
"gid": "E0298",
"media": [],
"part_family": [],
"part_person": [
789
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0299",
"media": [],
"part_family": [],
"part_person": [
789
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-10-30",
"date_sdn": 2433585,
"descr": "Birth of Hale, Lawrence Paul",
"gid": "E0286",
"media": [],
"part_family": [],
"part_person": [
790
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0287",
"media": [],
"part_family": [],
"part_person": [
790
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-07-27",
"date_sdn": 2443352,
"descr": "Birth of Hale, Michael Patrick",
"gid": "E0306",
"media": [],
"part_family": [],
"part_person": [
791
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0307",
"media": [],
"part_family": [],
"part_person": [
791
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "before 1745",
"date_sdn": 2358409,
"descr": "Death of Hall, Elizabeth",
"gid": "E2647",
"media": [],
"part_family": [],
"part_person": [
792
],
"place": 322,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Hall, Elizabeth",
"gid": "E2648",
"media": [],
"part_family": [],
"part_person": [
792
],
"place": 322,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1968",
"date_sdn": 2439857,
"descr": "Birth of Hamilton, John",
"gid": "E0870",
"media": [],
"part_family": [],
"part_person": [
793
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0871",
"media": [],
"part_family": [],
"part_person": [
793
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1982",
"date_sdn": 2444971,
"descr": "Birth of Hansen, Barry",
"gid": "E2372",
"media": [],
"part_family": [],
"part_person": [
795
],
"place": 879,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Hansen, Irene",
"gid": "E2363",
"media": [],
"part_family": [],
"part_person": [
796
],
"place": 1149,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1979",
"date_sdn": 2443875,
"descr": "Birth of Hansen, Kevin",
"gid": "E2373",
"media": [],
"part_family": [],
"part_person": [
797
],
"place": 879,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Hansen, Monica",
"gid": "E2364",
"media": [],
"part_family": [],
"part_person": [
798
],
"place": 1149,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1953-12-00",
"date_sdn": 2434713,
"descr": "Birth of Hansen, Noel",
"gid": "E2360",
"media": [],
"part_family": [],
"part_person": [
799
],
"place": 1149,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2361",
"media": [],
"part_family": [],
"part_person": [
799
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Hansen, Nula",
"gid": "E2362",
"media": [],
"part_family": [],
"part_person": [
800
],
"place": 1149,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Hansen, Thomas",
"gid": "E2358",
"media": [],
"part_family": [],
"part_person": [
801
],
"place": 1255,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2359",
"media": [],
"part_family": [],
"part_person": [
801
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1110",
"date_sdn": 2126479,
"descr": "Birth of Hanson, Robert",
"gid": "E0030",
"media": [],
"part_family": [],
"part_person": [
802
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1185",
"date_sdn": 2153873,
"descr": "Death of Hanson, Robert",
"gid": "E0031",
"media": [],
"part_family": [],
"part_person": [
802
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of Hardy, Jakob",
"gid": "E0414",
"media": [],
"part_family": [],
"part_person": [
803
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1671",
"date_sdn": 2331381,
"descr": "Birth of Harmon, Martha",
"gid": "E2232",
"media": [],
"part_family": [],
"part_person": [
804
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1986-07-10",
"date_sdn": 2446622,
"descr": "Birth of Harrison, Benjamin Allen",
"gid": "E1484",
"media": [],
"part_family": [],
"part_person": [
812
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1485",
"media": [],
"part_family": [],
"part_person": [
812
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1988-01-19",
"date_sdn": 2447180,
"descr": "Birth of Harrison, Douglas Glenn",
"gid": "E1606",
"media": [],
"part_family": [],
"part_person": [
813
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1607",
"media": [],
"part_family": [],
"part_person": [
813
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1958-10-26",
"date_sdn": 2436503,
"descr": "Birth of Harrison, Paul Allen",
"gid": "E1482",
"media": [],
"part_family": [],
"part_person": [
815
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1483",
"media": [],
"part_family": [],
"part_person": [
815
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0890",
"media": [],
"part_family": [],
"part_person": [
816
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0891",
"media": [],
"part_family": [],
"part_person": [
817
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0896",
"media": [],
"part_family": [],
"part_person": [
818
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0897",
"media": [],
"part_family": [],
"part_person": [
819
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1986",
"date_sdn": 2446432,
"descr": "Birth of Hart, Raymond",
"gid": "E0894",
"media": [],
"part_family": [],
"part_person": [
820
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0895",
"media": [],
"part_family": [],
"part_person": [
820
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1929-09-24",
"date_sdn": 2425879,
"descr": "Birth of Hawkins, Ellen Marie",
"gid": "E1248",
"media": [],
"part_family": [],
"part_person": [
824
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1249",
"media": [],
"part_family": [],
"part_person": [
824
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1168",
"media": [],
"part_family": [],
"part_person": [
825
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1171",
"media": [],
"part_family": [],
"part_person": [
826
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1172",
"media": [],
"part_family": [],
"part_person": [
827
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1169",
"media": [],
"part_family": [],
"part_person": [
828
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1173",
"media": [],
"part_family": [],
"part_person": [
829
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973",
"date_sdn": 2441684,
"descr": "Birth of Hawkins, Jennifer Leigh",
"gid": "E2459",
"media": [],
"part_family": [],
"part_person": [
830
],
"place": 528,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2460",
"media": [],
"part_family": [],
"part_person": [
830
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1163",
"media": [],
"part_family": [],
"part_person": [
831
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1926-03-09",
"date_sdn": 2424584,
"descr": "Birth of Hawkins, William Melvin",
"gid": "E1164",
"media": [],
"part_family": [],
"part_person": [
832
],
"place": 484,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1999-03-25",
"date_sdn": 2451263,
"descr": "Death of Hawkins, William Melvin",
"gid": "E1165",
"media": [],
"part_family": [],
"part_person": [
832
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1999-03-29",
"date_sdn": 2451267,
"descr": "Burial of Hawkins, William Melvin",
"gid": "E1166",
"media": [],
"part_family": [],
"part_person": [
832
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1969-06-23",
"date_sdn": 2440396,
"descr": "Birth of Hayes, LeAnn",
"gid": "E0148",
"media": [],
"part_family": [],
"part_person": [
833
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0149",
"media": [],
"part_family": [],
"part_person": [
833
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1986-12-06",
"date_sdn": 2446771,
"descr": "Birth of Haynes, David William Sigfred",
"gid": "E1391",
"media": [],
"part_family": [],
"part_person": [
834
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1392",
"media": [],
"part_family": [],
"part_person": [
834
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1980-11-18",
"date_sdn": 2444562,
"descr": "Birth of Haynes, Elizabeth Ellen",
"gid": "E1389",
"media": [],
"part_family": [],
"part_person": [
835
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1390",
"media": [],
"part_family": [],
"part_person": [
835
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-01-29",
"date_sdn": 2433311,
"descr": "Birth of Haynes, Marc W.",
"gid": "E1385",
"media": [],
"part_family": [],
"part_person": [
836
],
"place": 1019,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1386",
"media": [],
"part_family": [],
"part_person": [
836
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990",
"date_sdn": 2447893,
"descr": "Birth of Haynes, Melany",
"gid": "E2697",
"media": [],
"part_family": [],
"part_person": [
837
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2698",
"media": [],
"part_family": [],
"part_person": [
837
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-09-05",
"date_sdn": 2443392,
"descr": "Birth of Haynes, Michael Walter",
"gid": "E1387",
"media": [],
"part_family": [],
"part_person": [
838
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1388",
"media": [],
"part_family": [],
"part_person": [
838
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of H\u00e9bert, Mr.",
"gid": "E0736",
"media": [],
"part_family": [],
"part_person": [
839
],
"place": 170,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of H\u00e9bert, Ruth Ann",
"gid": "E2688",
"media": [],
"part_family": [],
"part_person": [
840
],
"place": 49,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1843",
"date_sdn": 2394202,
"descr": "Death of H\u00e9bert, Ruth Ann",
"gid": "E2689",
"media": [],
"part_family": [],
"part_person": [
840
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1965-05-08",
"date_sdn": 2438889,
"descr": "Birth of Henderson, Cathy Sue",
"gid": "E2024",
"media": [],
"part_family": [],
"part_person": [
841
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2025",
"media": [],
"part_family": [],
"part_person": [
841
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1770-04-00",
"date_sdn": 2367630,
"descr": "Birth of Henry, Elizabeth",
"gid": "E2318",
"media": [],
"part_family": [],
"part_person": [
842
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1836-05-14",
"date_sdn": 2391779,
"descr": "Death of Henry, Elizabeth",
"gid": "E2319",
"media": [],
"part_family": [],
"part_person": [
842
],
"place": 1086,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1836-05-15",
"date_sdn": 2391780,
"descr": "Burial of Henry, Elizabeth",
"gid": "E2320",
"media": [],
"part_family": [],
"part_person": [
842
],
"place": 383,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1751",
"date_sdn": 2360600,
"descr": "Birth of Hicks, Anna Eva",
"gid": "E0398",
"media": [],
"part_family": [],
"part_person": [
847
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of Hicks, Anna Eva",
"gid": "E0399",
"media": [],
"part_family": [],
"part_person": [
847
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1682",
"date_sdn": 2335399,
"descr": "Birth of Higgins, Charity",
"gid": "E1067",
"media": [],
"part_family": [],
"part_person": [
848
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1977-03-12",
"date_sdn": 2443215,
"descr": "Birth of Hill, Jo Lynn",
"gid": "E0118",
"media": [],
"part_family": [],
"part_person": [
850
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0119",
"media": [],
"part_family": [],
"part_person": [
850
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1979-01-23",
"date_sdn": 2443897,
"descr": "Birth of Hill, Leigh Ann",
"gid": "E0120",
"media": [],
"part_family": [],
"part_person": [
851
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0121",
"media": [],
"part_family": [],
"part_person": [
851
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1980-05-10",
"date_sdn": 2444370,
"descr": "Birth of Hill, Sean Michael",
"gid": "E0122",
"media": [],
"part_family": [],
"part_person": [
852
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0123",
"media": [],
"part_family": [],
"part_person": [
852
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1685",
"date_sdn": 2336495,
"descr": "Birth of Holland, Anna Margaretha",
"gid": "E0362",
"media": [],
"part_family": [],
"part_person": [
856
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1956-09-30",
"date_sdn": 2435747,
"descr": "Birth of Holloway, Gail",
"gid": "E2291",
"media": [],
"part_family": [],
"part_person": [
857
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2292",
"media": [],
"part_family": [],
"part_person": [
857
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Holloway, John(?)",
"gid": "E0103",
"media": [],
"part_family": [],
"part_person": [
858
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Holloway, John(?)",
"gid": "E0104",
"media": [],
"part_family": [],
"part_person": [
858
],
"place": 298,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1795-09-10",
"date_sdn": 2376923,
"descr": "Birth of Holloway, Sarah",
"gid": "E0135",
"media": [],
"part_family": [],
"part_person": [
859
],
"place": 108,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Holloway, Sarah",
"gid": "E0136",
"media": [],
"part_family": [],
"part_person": [
859
],
"place": 298,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1829-12-00",
"date_sdn": 2389423,
"descr": "Birth of Holt, Bridget",
"gid": "E2561",
"media": [],
"part_family": [],
"part_person": [
860
],
"place": 705,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-02-14",
"date_sdn": 2416525,
"descr": "Death of Holt, Bridget",
"gid": "E2562",
"media": [],
"part_family": [],
"part_person": [
860
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Holt, Bridget",
"gid": "E2563",
"media": [],
"part_family": [],
"part_person": [
860
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1786-05-11",
"date_sdn": 2373514,
"descr": "Birth of Hopkins, Joseph",
"gid": "E1921",
"media": [],
"part_family": [],
"part_person": [
861
],
"place": 641,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Hopkins, Joseph",
"gid": "E1922",
"media": [],
"part_family": [],
"part_person": [
861
],
"place": 1027,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1805-10-18",
"date_sdn": 2380613,
"descr": "Birth of Hopkins, Mary Eve",
"gid": "E1380",
"media": [],
"part_family": [],
"part_person": [
862
],
"place": 49,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1865-05-11",
"date_sdn": 2402368,
"descr": "Death of Hopkins, Mary Eve",
"gid": "E1381",
"media": [],
"part_family": [],
"part_person": [
862
],
"place": 1200,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1865-05-13",
"date_sdn": 2402370,
"descr": "Burial of Hopkins, Mary Eve",
"gid": "E1382",
"media": [],
"part_family": [],
"part_person": [
862
],
"place": 126,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1790-06-21",
"date_sdn": 2375016,
"descr": "Birth of Houston, Ellender",
"gid": "E0130",
"media": [],
"part_family": [],
"part_person": [
863
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1855-07-30",
"date_sdn": 2398795,
"descr": "Death of Houston, Ellender",
"gid": "E0131",
"media": [],
"part_family": [],
"part_person": [
863
],
"place": 1112,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Houston, Ellender",
"gid": "E0132",
"media": [],
"part_family": [],
"part_person": [
863
],
"place": 784,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Howell, John",
"gid": "E2710",
"media": [],
"part_family": [],
"part_person": [
866
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Howell, John",
"gid": "E2711",
"media": [],
"part_family": [],
"part_person": [
866
],
"place": 298,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Howell, John",
"gid": "E2712",
"media": [],
"part_family": [],
"part_person": [
866
],
"place": 298,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1615",
"date_sdn": 2310927,
"descr": "Birth of Howell, JOHN",
"gid": "E2626",
"media": [],
"part_family": [],
"part_person": [
867
],
"place": 371,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1644-12-28",
"date_sdn": 2321881,
"descr": "Death of Howell, JOHN",
"gid": "E2627",
"media": [],
"part_family": [],
"part_person": [
867
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Howell, Marie",
"gid": "E1789",
"media": [],
"part_family": [],
"part_person": [
868
],
"place": 847,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1945-11-17",
"date_sdn": 2431777,
"descr": "Birth of Howell, Mary",
"gid": "E0911",
"media": [],
"part_family": [],
"part_person": [
869
],
"place": 880,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0912",
"media": [],
"part_family": [],
"part_person": [
869
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1641-02-12",
"date_sdn": 2320466,
"descr": "Birth of Howell, Mary (Sarah)",
"gid": "E2238",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 871,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1686",
"date_sdn": 2336860,
"descr": "Death of Howell, Mary (Sarah)",
"gid": "E2239",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 37,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Howell, Mary (Sarah)",
"gid": "E2240",
"media": [],
"part_family": [],
"part_person": [
870
],
"place": 37,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0604",
"media": [],
"part_family": [],
"part_person": [
871
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1220",
"date_sdn": 2166656,
"descr": "Birth of Huff, Bertrama",
"gid": "E0039",
"media": [],
"part_family": [],
"part_person": [
875
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1300",
"date_sdn": 2195876,
"descr": "Birth of Huff, Isabel",
"gid": "E0048",
"media": [],
"part_family": [],
"part_person": [
876
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1625",
"date_sdn": 2314580,
"descr": "Birth of Ingram, Mary",
"gid": "E2213",
"media": [],
"part_family": [],
"part_person": [
879
],
"place": 414,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1688-07-29",
"date_sdn": 2337800,
"descr": "Death of Ingram, Mary",
"gid": "E2214",
"media": [],
"part_family": [],
"part_person": [
879
],
"place": 1128,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jackson, Cora Ellen",
"gid": "E2059",
"media": [],
"part_family": [],
"part_person": [
880
],
"place": 302,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Jackson, Cora Ellen",
"gid": "E2060",
"media": [],
"part_family": [],
"part_person": [
880
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of James",
"gid": "E0683",
"media": [],
"part_family": [],
"part_person": [
883
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1768",
"date_sdn": 2366809,
"descr": "Birth of James, Hugh Jr.",
"gid": "E0684",
"media": [],
"part_family": [],
"part_person": [
885
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1768",
"date_sdn": 2366809,
"descr": "Death of James, Hugh Jr.",
"gid": "E0685",
"media": [],
"part_family": [],
"part_person": [
885
],
"place": 1226,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1705",
"date_sdn": 2343799,
"descr": "Birth of James, Hugh Sr.",
"gid": "E1752",
"media": [],
"part_family": [],
"part_person": [
886
],
"place": 216,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1785",
"date_sdn": 2373019,
"descr": "Death of James, Hugh Sr.",
"gid": "E1753",
"media": [],
"part_family": [],
"part_person": [
886
],
"place": 230,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Isaac",
"gid": "E0690",
"media": [],
"part_family": [],
"part_person": [
887
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Jane",
"gid": "E1746",
"media": [],
"part_family": [],
"part_person": [
889
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-09-03",
"date_sdn": 2395543,
"descr": "Death of James, Jane",
"gid": "E1747",
"media": [],
"part_family": [],
"part_person": [
889
],
"place": 722,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1739",
"date_sdn": 2356217,
"descr": "Birth of James, Jane",
"gid": "E0679",
"media": [],
"part_family": [],
"part_person": [
890
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1741",
"date_sdn": 2356948,
"descr": "Birth of James, John",
"gid": "E0680",
"media": [],
"part_family": [],
"part_person": [
891
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1773-03-03",
"date_sdn": 2368697,
"descr": "Birth of James, Joseph",
"gid": "E0687",
"media": [],
"part_family": [],
"part_person": [
892
],
"place": 1226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Death of James, Joseph",
"gid": "E0688",
"media": [],
"part_family": [],
"part_person": [
892
],
"place": 888,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1737",
"date_sdn": 2355487,
"descr": "Birth of James, Martha",
"gid": "E0678",
"media": [],
"part_family": [],
"part_person": [
894
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1735",
"date_sdn": 2354756,
"descr": "Birth of James, Mary",
"gid": "E0677",
"media": [],
"part_family": [],
"part_person": [
895
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1770",
"date_sdn": 2367540,
"descr": "Birth of James, Molly",
"gid": "E0686",
"media": [],
"part_family": [],
"part_person": [
896
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1729",
"date_sdn": 2352565,
"descr": "Birth of James, Robert",
"gid": "E0675",
"media": [],
"part_family": [],
"part_person": [
899
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Thomas",
"gid": "E0689",
"media": [],
"part_family": [],
"part_person": [
901
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1745",
"date_sdn": 2358409,
"descr": "Birth of James, Thomas Sr.",
"gid": "E1748",
"media": [],
"part_family": [],
"part_person": [
902
],
"place": 922,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of James, Thomas Sr.",
"gid": "E1749",
"media": [],
"part_family": [],
"part_person": [
902
],
"place": 722,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of James, Walter Crockett",
"gid": "E0691",
"media": [],
"part_family": [],
"part_person": [
903
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1733",
"date_sdn": 2354026,
"descr": "Birth of James, William",
"gid": "E0676",
"media": [],
"part_family": [],
"part_person": [
904
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1886-08-10",
"date_sdn": 2410129,
"descr": "Birth of Jankowski, David",
"gid": "E0542",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1951-04-10",
"date_sdn": 2433747,
"descr": "Death of Jankowski, David",
"gid": "E0543",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1957-04-12",
"date_sdn": 2435941,
"descr": "Burial of Jankowski, David",
"gid": "E0544",
"media": [],
"part_family": [],
"part_person": [
905
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1847-01-01",
"date_sdn": 2395663,
"descr": "Birth of Jankowski, George",
"gid": "E0516",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1930-02-01",
"date_sdn": 2426009,
"descr": "Death of Jankowski, George",
"gid": "E0517",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1930-02-03",
"date_sdn": 2426011,
"descr": "Burial of Jankowski, George",
"gid": "E0518",
"media": [],
"part_family": [],
"part_person": [
906
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1882-03-28",
"date_sdn": 2408533,
"descr": "Birth of Jankowski, George Jr.",
"gid": "E0533",
"media": [],
"part_family": [],
"part_person": [
907
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-11-17",
"date_sdn": 2430681,
"descr": "Death of Jankowski, George Jr.",
"gid": "E0534",
"media": [],
"part_family": [],
"part_person": [
907
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1942-11-19",
"date_sdn": 2430683,
"descr": "Burial of Jankowski, George Jr.",
"gid": "E0535",
"media": [],
"part_family": [],
"part_person": [
907
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1878-03-20",
"date_sdn": 2407064,
"descr": "Birth of Jankowski, Isabella Belle",
"gid": "E0531",
"media": [],
"part_family": [],
"part_person": [
908
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-03-31",
"date_sdn": 2424241,
"descr": "Death of Jankowski, Isabella Belle",
"gid": "E0532",
"media": [],
"part_family": [],
"part_person": [
908
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1876-04-01",
"date_sdn": 2406346,
"descr": "Birth of Jankowski, John",
"gid": "E0528",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1939-10-15",
"date_sdn": 2429552,
"descr": "Death of Jankowski, John",
"gid": "E0529",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1939-10-15",
"date_sdn": 2429552,
"descr": "Burial of Jankowski, John",
"gid": "E0530",
"media": [],
"part_family": [],
"part_person": [
909
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1889-05-28",
"date_sdn": 2411151,
"descr": "Birth of Jankowski, Margaret Jane &#8220;Maggie&#8221;",
"gid": "E0545",
"media": [],
"part_family": [],
"part_person": [
910
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1960-01-05",
"date_sdn": 2436939,
"descr": "Death of Jankowski, Margaret Jane &#8220;Maggie&#8221;",
"gid": "E0546",
"media": [],
"part_family": [],
"part_person": [
910
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1885-06-07",
"date_sdn": 2409700,
"descr": "Birth of Jankowski, Matilda",
"gid": "E0536",
"media": [],
"part_family": [],
"part_person": [
911
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-01-22",
"date_sdn": 2424173,
"descr": "Death of Jankowski, Matilda",
"gid": "E0537",
"media": [],
"part_family": [],
"part_person": [
911
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1892-05-24",
"date_sdn": 2412243,
"descr": "Birth of Jankowski, Minnie",
"gid": "E0549",
"media": [],
"part_family": [],
"part_person": [
912
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-01-08",
"date_sdn": 2445708,
"descr": "Death of Jankowski, Minnie",
"gid": "E0550",
"media": [],
"part_family": [],
"part_person": [
912
],
"place": 908,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1872-08-27",
"date_sdn": 2405033,
"descr": "Birth of Jankowski, Robert",
"gid": "E0519",
"media": [],
"part_family": [],
"part_person": [
913
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-01-02",
"date_sdn": 2430727,
"descr": "Death of Jankowski, Robert",
"gid": "E0520",
"media": [],
"part_family": [],
"part_person": [
913
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1943-01-04",
"date_sdn": 2430729,
"descr": "Burial of Jankowski, Robert",
"gid": "E0521",
"media": [],
"part_family": [],
"part_person": [
913
],
"place": 1220,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1874-12-08",
"date_sdn": 2405866,
"descr": "Birth of Jankowski, Sarah",
"gid": "E0522",
"media": [],
"part_family": [],
"part_person": [
914
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1948-02-17",
"date_sdn": 2432599,
"descr": "Death of Jankowski, Sarah",
"gid": "E0523",
"media": [],
"part_family": [],
"part_person": [
914
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jankowski, Willie",
"gid": "E0526",
"media": [],
"part_family": [],
"part_person": [
915
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Jankowski, Willie",
"gid": "E0527",
"media": [],
"part_family": [],
"part_person": [
915
],
"place": 908,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1630-02-00",
"date_sdn": 2316437,
"descr": "Birth of Jenkins, Margaret",
"gid": "E2590",
"media": [],
"part_family": [],
"part_person": [
916
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1708-07-25",
"date_sdn": 2345100,
"descr": "Death of Jenkins, Margaret",
"gid": "E2591",
"media": [],
"part_family": [],
"part_person": [
916
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Jenkins, Peter",
"gid": "E2585",
"media": [],
"part_family": [],
"part_person": [
917
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1680-10-14",
"date_sdn": 2334955,
"descr": "Death of Jenkins, Peter",
"gid": "E2586",
"media": [],
"part_family": [],
"part_person": [
917
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1835-07-13",
"date_sdn": 2391473,
"descr": "Birth of Jim\u00e9nez, Amanda E.",
"gid": "E0441",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1883-04-25",
"date_sdn": 2408926,
"descr": "Death of Jim\u00e9nez, Amanda E.",
"gid": "E0442",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": 717,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1835-07-15",
"date_sdn": 2391475,
"descr": "Burial of Jim\u00e9nez, Amanda E.",
"gid": "E0443",
"media": [],
"part_family": [],
"part_person": [
920
],
"place": 1113,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1792-01-21",
"date_sdn": 2375595,
"descr": "Birth of Jim\u00e9nez, Andrew",
"gid": "E0725",
"media": [],
"part_family": [],
"part_person": [
921
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Armand E.",
"gid": "E0483",
"media": [],
"part_family": [],
"part_person": [
922
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1805-07-27",
"date_sdn": 2380530,
"descr": "Birth of Jim\u00e9nez, Cornelius",
"gid": "E0732",
"media": [],
"part_family": [],
"part_person": [
923
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1866-03-05",
"date_sdn": 2402666,
"descr": "Death of Jim\u00e9nez, Cornelius",
"gid": "E0733",
"media": [],
"part_family": [],
"part_person": [
923
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1790-11-28",
"date_sdn": 2375176,
"descr": "Birth of Jim\u00e9nez, Elizabeth",
"gid": "E0721",
"media": [],
"part_family": [],
"part_person": [
924
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-04-00",
"date_sdn": 2388814,
"descr": "Death of Jim\u00e9nez, Elizabeth",
"gid": "E0722",
"media": [],
"part_family": [],
"part_person": [
924
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, George H.",
"gid": "E0487",
"media": [],
"part_family": [],
"part_person": [
925
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1826-08-15",
"date_sdn": 2388219,
"descr": "Birth of Jim\u00e9nez, George Henry, III",
"gid": "E2095",
"media": [],
"part_family": [],
"part_person": [
926
],
"place": 7,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1907-10-25",
"date_sdn": 2417874,
"descr": "Death of Jim\u00e9nez, George Henry, III",
"gid": "E2096",
"media": [],
"part_family": [],
"part_person": [
926
],
"place": 1028,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1802-09-29",
"date_sdn": 2379498,
"descr": "Birth of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2081",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 1086,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-02-19",
"date_sdn": 2403748,
"descr": "Death of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2082",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 467,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-02-21",
"date_sdn": 2403750,
"descr": "Burial of Jim\u00e9nez, George Henry, Jr.",
"gid": "E2083",
"media": [],
"part_family": [],
"part_person": [
927
],
"place": 279,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1760-02-10",
"date_sdn": 2363927,
"descr": "Birth of Jim\u00e9nez, George, Sr.",
"gid": "E1708",
"media": [],
"part_family": [],
"part_person": [
928
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1827-07-28",
"date_sdn": 2388566,
"descr": "Death of Jim\u00e9nez, George, Sr.",
"gid": "E1709",
"media": [],
"part_family": [],
"part_person": [
928
],
"place": 342,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1827-07-29",
"date_sdn": 2388567,
"descr": "Burial of Jim\u00e9nez, George, Sr.",
"gid": "E1710",
"media": [],
"part_family": [],
"part_person": [
928
],
"place": 383,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1839-08-06",
"date_sdn": 2392958,
"descr": "Birth of Jim\u00e9nez, James T.",
"gid": "E0447",
"media": [],
"part_family": [],
"part_person": [
929
],
"place": 846,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1839-08-06",
"date_sdn": 2392958,
"descr": "Death of Jim\u00e9nez, James T.",
"gid": "E0448",
"media": [],
"part_family": [],
"part_person": [
929
],
"place": 717,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1839-08-07",
"date_sdn": 2392959,
"descr": "Burial of Jim\u00e9nez, James T.",
"gid": "E0449",
"media": [],
"part_family": [],
"part_person": [
929
],
"place": 401,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1794-11-05",
"date_sdn": 2376614,
"descr": "Birth of Jim\u00e9nez, John",
"gid": "E0726",
"media": [],
"part_family": [],
"part_person": [
930
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-01-28",
"date_sdn": 2386194,
"descr": "Death of Jim\u00e9nez, John",
"gid": "E0727",
"media": [],
"part_family": [],
"part_person": [
930
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1829-08-30",
"date_sdn": 2389330,
"descr": "Birth of Jim\u00e9nez, John T. L.",
"gid": "E0450",
"media": [],
"part_family": [],
"part_person": [
931
],
"place": 717,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1851-06-20",
"date_sdn": 2397294,
"descr": "Death of Jim\u00e9nez, John T. L.",
"gid": "E0451",
"media": [],
"part_family": [],
"part_person": [
931
],
"place": 846,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1851-06-21",
"date_sdn": 2397295,
"descr": "Burial of Jim\u00e9nez, John T. L.",
"gid": "E0452",
"media": [],
"part_family": [],
"part_person": [
931
],
"place": 581,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Lincoln F.",
"gid": "E0485",
"media": [],
"part_family": [],
"part_person": [
932
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Lucinda",
"gid": "E0460",
"media": [],
"part_family": [],
"part_person": [
933
],
"place": 717,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1870-02-05",
"date_sdn": 2404099,
"descr": "Birth of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1591",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 467,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1949-02-21",
"date_sdn": 2432969,
"descr": "Death of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1592",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 580,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1949-02-00",
"date_sdn": 2432949,
"descr": "Burial of Jim\u00e9nez, Lucinda Ellen",
"gid": "E1593",
"media": [],
"part_family": [],
"part_person": [
934
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1849-12-08",
"date_sdn": 2396735,
"descr": "Birth of Jim\u00e9nez, Mary C.",
"gid": "E0453",
"media": [],
"part_family": [],
"part_person": [
935
],
"place": 717,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-10-10",
"date_sdn": 2403981,
"descr": "Death of Jim\u00e9nez, Mary C.",
"gid": "E0454",
"media": [],
"part_family": [],
"part_person": [
935
],
"place": 717,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-10-11",
"date_sdn": 2403982,
"descr": "Burial of Jim\u00e9nez, Mary C.",
"gid": "E0455",
"media": [],
"part_family": [],
"part_person": [
935
],
"place": 401,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Mary C.",
"gid": "E0479",
"media": [],
"part_family": [],
"part_person": [
936
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Nancy E.",
"gid": "E0456",
"media": [],
"part_family": [],
"part_person": [
937
],
"place": 717,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-10-10",
"date_sdn": 2394850,
"descr": "Birth of Jim\u00e9nez, Nathan M.",
"gid": "E0444",
"media": [],
"part_family": [],
"part_person": [
938
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1848-07-01",
"date_sdn": 2396210,
"descr": "Death of Jim\u00e9nez, Nathan M.",
"gid": "E0445",
"media": [],
"part_family": [],
"part_person": [
938
],
"place": 846,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1848-07-03",
"date_sdn": 2396212,
"descr": "Burial of Jim\u00e9nez, Nathan M.",
"gid": "E0446",
"media": [],
"part_family": [],
"part_person": [
938
],
"place": 279,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Philip",
"gid": "E0486",
"media": [],
"part_family": [],
"part_person": [
939
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1788-09-24",
"date_sdn": 2374381,
"descr": "Birth of Jim\u00e9nez, Polly Mary",
"gid": "E0720",
"media": [],
"part_family": [],
"part_person": [
940
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1799-09-12",
"date_sdn": 2378386,
"descr": "Birth of Jim\u00e9nez, Rebecca",
"gid": "E0729",
"media": [],
"part_family": [],
"part_person": [
941
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Richard? Cornelius",
"gid": "E0459",
"media": [],
"part_family": [],
"part_person": [
942
],
"place": 717,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1797-04-20",
"date_sdn": 2377511,
"descr": "Birth of Jim\u00e9nez, Sarah",
"gid": "E0728",
"media": [],
"part_family": [],
"part_person": [
943
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Sarah M.",
"gid": "E0478",
"media": [],
"part_family": [],
"part_person": [
944
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Jim\u00e9nez, Tolbert A.",
"gid": "E0484",
"media": [],
"part_family": [],
"part_person": [
945
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1750-05-04",
"date_sdn": 2360358,
"descr": "Birth of Johansen, John",
"gid": "E0791",
"media": [],
"part_family": [],
"part_person": [
946
],
"place": 45,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1835",
"date_sdn": 2391280,
"descr": "Death of Johansen, John",
"gid": "E0792",
"media": [],
"part_family": [],
"part_person": [
946
],
"place": 848,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Johnson, Elizabeth",
"gid": "E1994",
"media": [],
"part_family": [],
"part_person": [
947
],
"place": 224,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1917-01-13",
"date_sdn": 2421242,
"descr": "Birth of Johnson, Richard F.",
"gid": "E2075",
"media": [],
"part_family": [],
"part_person": [
949
],
"place": 1164,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1982-09-22",
"date_sdn": 2445235,
"descr": "Death of Johnson, Richard F.",
"gid": "E2076",
"media": [],
"part_family": [],
"part_person": [
949
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Johnson, Richard F.",
"gid": "E2077",
"media": [],
"part_family": [],
"part_person": [
949
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1550",
"date_sdn": 2287186,
"descr": "Birth of Jones, Ann",
"gid": "E0016",
"media": [],
"part_family": [],
"part_person": [
951
],
"place": 1006,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1518",
"date_sdn": 2275498,
"descr": "Birth of Jones, Hugh",
"gid": "E0015",
"media": [],
"part_family": [],
"part_person": [
952
],
"place": 1006,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1876-08-24",
"date_sdn": 2406491,
"descr": "Birth of Jones, Martha Elizabeth",
"gid": "E1158",
"media": [],
"part_family": [],
"part_person": [
953
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1966-11-24",
"date_sdn": 2439454,
"descr": "Birth of J\u00f8rgensen, Jeffrey",
"gid": "E1608",
"media": [],
"part_family": [],
"part_person": [
955
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1609",
"media": [],
"part_family": [],
"part_person": [
955
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1993-08-20",
"date_sdn": 2449220,
"descr": "Birth of J\u00f8rgensen, Maggie Leigh",
"gid": "E2677",
"media": [],
"part_family": [],
"part_person": [
956
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2678",
"media": [],
"part_family": [],
"part_person": [
956
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990-07-27",
"date_sdn": 2448100,
"descr": "Birth of J\u00f8rgensen, Molly Marie",
"gid": "E1761",
"media": [],
"part_family": [],
"part_person": [
957
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1762",
"media": [],
"part_family": [],
"part_person": [
957
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Kaczmarek, Isabella",
"gid": "E2056",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 123,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1904-04-21",
"date_sdn": 2416592,
"descr": "Death of Kaczmarek, Isabella",
"gid": "E2057",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 939,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1904-04-23",
"date_sdn": 2416594,
"descr": "Burial of Kaczmarek, Isabella",
"gid": "E2058",
"media": [],
"part_family": [],
"part_person": [
964
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1990-06-06",
"date_sdn": 2448049,
"descr": "Birth of Kelly, Ashley Diane",
"gid": "E2287",
"media": [],
"part_family": [],
"part_person": [
970
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2288",
"media": [],
"part_family": [],
"part_person": [
970
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1885-12-25",
"date_sdn": 2409901,
"descr": "Birth of Klein, Alma Katherine",
"gid": "E0058",
"media": [],
"part_family": [],
"part_person": [
975
],
"place": 967,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-11-22",
"date_sdn": 2420094,
"descr": "Death of Klein, Alma Katherine",
"gid": "E0059",
"media": [],
"part_family": [],
"part_person": [
975
],
"place": 904,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1913-11-24",
"date_sdn": 2420096,
"descr": "Burial of Klein, Alma Katherine",
"gid": "E0060",
"media": [],
"part_family": [],
"part_person": [
975
],
"place": 867,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1325",
"date_sdn": 2205007,
"descr": "Birth of Knudsen, John",
"gid": "E0049",
"media": [],
"part_family": [],
"part_person": [
977
],
"place": 56,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1368",
"date_sdn": 2220712,
"descr": "Death of Knudsen, John",
"gid": "E0050",
"media": [],
"part_family": [],
"part_person": [
977
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1345",
"date_sdn": 2212312,
"descr": "Birth of Knudsen, John",
"gid": "E0052",
"media": [],
"part_family": [],
"part_person": [
978
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1388",
"date_sdn": 2228017,
"descr": "Death of Knudsen, John",
"gid": "E0053",
"media": [],
"part_family": [],
"part_person": [
978
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1250",
"date_sdn": 2177614,
"descr": "Birth of Knudsen, Ralph",
"gid": "E0043",
"media": [],
"part_family": [],
"part_person": [
979
],
"place": 56,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1316",
"date_sdn": 2201719,
"descr": "Death of Knudsen, Ralph",
"gid": "E0044",
"media": [],
"part_family": [],
"part_person": [
979
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1300",
"date_sdn": 2195876,
"descr": "Birth of Knudsen, Ralph",
"gid": "E0046",
"media": [],
"part_family": [],
"part_person": [
980
],
"place": 99,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1343",
"date_sdn": 2211581,
"descr": "Death of Knudsen, Ralph",
"gid": "E0047",
"media": [],
"part_family": [],
"part_person": [
980
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1220",
"date_sdn": 2166656,
"descr": "Birth of Knudsen, Ranulf",
"gid": "E0037",
"media": [],
"part_family": [],
"part_person": [
981
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1294",
"date_sdn": 2193685,
"descr": "Death of Knudsen, Ranulf",
"gid": "E0038",
"media": [],
"part_family": [],
"part_person": [
981
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1192",
"date_sdn": 2156429,
"descr": "Birth of Knudsen, Robert",
"gid": "E0034",
"media": [],
"part_family": [],
"part_person": [
982
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1252-12-07",
"date_sdn": 2178685,
"descr": "Death of Knudsen, Robert",
"gid": "E0035",
"media": [],
"part_family": [],
"part_person": [
982
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1590",
"date_sdn": 2301796,
"descr": "Birth of Kowalski, Hannah",
"gid": "E0240",
"media": [],
"part_family": [],
"part_person": [
983
],
"place": 150,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Kowalski, Hannah",
"gid": "E0241",
"media": [],
"part_family": [],
"part_person": [
983
],
"place": 26,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1560",
"date_sdn": 2290838,
"descr": "Birth of Kowalski, John",
"gid": "E0242",
"media": [],
"part_family": [],
"part_person": [
984
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1630-08-30",
"date_sdn": 2316647,
"descr": "Death of Kowalski, John",
"gid": "E0243",
"media": [],
"part_family": [],
"part_person": [
984
],
"place": 150,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Kowalski, Thomas",
"gid": "E0246",
"media": [],
"part_family": [],
"part_person": [
985
],
"place": 296,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1535",
"date_sdn": 2281707,
"descr": "Birth of Koz\u0142owski, Margret",
"gid": "E0070",
"media": [],
"part_family": [],
"part_person": [
986
],
"place": 1260,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1598",
"date_sdn": 2304718,
"descr": "Death of Koz\u0142owski, Margret",
"gid": "E0071",
"media": [],
"part_family": [],
"part_person": [
986
],
"place": 1260,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1956-06-14",
"date_sdn": 2435639,
"descr": "Birth of Krawczyk, Douglas",
"gid": "E1654",
"media": [],
"part_family": [],
"part_person": [
987
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1655",
"media": [],
"part_family": [],
"part_person": [
987
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1899-09-19",
"date_sdn": 2414917,
"descr": "Birth of Kristensen, Anna June",
"gid": "E1958",
"media": [],
"part_family": [],
"part_person": [
988
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1988-11-17",
"date_sdn": 2447483,
"descr": "Death of Kristensen, Anna June",
"gid": "E1959",
"media": [],
"part_family": [],
"part_person": [
988
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1988-11-19",
"date_sdn": 2447485,
"descr": "Burial of Kristensen, Anna June",
"gid": "E1960",
"media": [],
"part_family": [],
"part_person": [
988
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1892-02-22",
"date_sdn": 2412151,
"descr": "Birth of Kristensen, Catherine Virginia",
"gid": "E1948",
"media": [],
"part_family": [],
"part_person": [
989
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-03-01",
"date_sdn": 2424576,
"descr": "Death of Kristensen, Catherine Virginia",
"gid": "E1949",
"media": [],
"part_family": [],
"part_person": [
989
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1889-10-10",
"date_sdn": 2411286,
"descr": "Birth of Kristensen, John Francis&#8220;Chick&#8221;",
"gid": "E1950",
"media": [],
"part_family": [],
"part_person": [
990
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-10-23",
"date_sdn": 2429195,
"descr": "Death of Kristensen, John Francis&#8220;Chick&#8221;",
"gid": "E1951",
"media": [],
"part_family": [],
"part_person": [
990
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1894-12-02",
"date_sdn": 2413165,
"descr": "Birth of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1955",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1974-07-21",
"date_sdn": 2442250,
"descr": "Death of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1956",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1974-07-23",
"date_sdn": 2442252,
"descr": "Burial of Kristensen, Margaret Agnes&#8220;Maudy&#8221;",
"gid": "E1957",
"media": [],
"part_family": [],
"part_person": [
991
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1887-06-14",
"date_sdn": 2410437,
"descr": "Birth of Kristensen, Mary Elizabeth",
"gid": "E1942",
"media": [],
"part_family": [],
"part_person": [
992
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918-10-22",
"date_sdn": 2421889,
"descr": "Death of Kristensen, Mary Elizabeth",
"gid": "E1943",
"media": [],
"part_family": [],
"part_person": [
992
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1897-01-01",
"date_sdn": 2413926,
"descr": "Birth of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1952",
"media": [],
"part_family": [],
"part_person": [
993
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1971-10-19",
"date_sdn": 2441244,
"descr": "Death of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1953",
"media": [],
"part_family": [],
"part_person": [
993
],
"place": 58,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1971-10-21",
"date_sdn": 2441246,
"descr": "Burial of Kristensen, Miles Joseph&#8220;Dutch&#8221;",
"gid": "E1954",
"media": [],
"part_family": [],
"part_person": [
993
],
"place": 172,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1885-06-25",
"date_sdn": 2409718,
"descr": "Birth of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1945",
"media": [],
"part_family": [],
"part_person": [
994
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-01-04",
"date_sdn": 2424520,
"descr": "Death of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1946",
"media": [],
"part_family": [],
"part_person": [
994
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1926-01-05",
"date_sdn": 2424521,
"descr": "Burial of Kristensen, Sarah &#8220;Sr. Sabina&#8221;",
"gid": "E1947",
"media": [],
"part_family": [],
"part_person": [
994
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1912-11-03",
"date_sdn": 2419710,
"descr": "Birth of Lachance, Helen",
"gid": "E1765",
"media": [],
"part_family": [],
"part_person": [
996
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1766",
"media": [],
"part_family": [],
"part_person": [
996
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1917-09-19",
"date_sdn": 2421491,
"descr": "Birth of Lambert, Marguerite",
"gid": "E1218",
"media": [],
"part_family": [],
"part_person": [
997
],
"place": 772,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1991-07-14",
"date_sdn": 2448452,
"descr": "Death of Lambert, Marguerite",
"gid": "E1219",
"media": [],
"part_family": [],
"part_person": [
997
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Lambert, Marguerite",
"gid": "E1220",
"media": [],
"part_family": [],
"part_person": [
997
],
"place": 241,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1900-03-06",
"date_sdn": 2415085,
"descr": "Birth of Landry, Alice",
"gid": "E1316",
"media": [],
"part_family": [],
"part_person": [
998
],
"place": 23,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1317",
"media": [],
"part_family": [],
"part_person": [
998
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1895-04-28",
"date_sdn": 2413312,
"descr": "Birth of Landry, Catherine M.",
"gid": "E1307",
"media": [],
"part_family": [],
"part_person": [
999
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1308",
"media": [],
"part_family": [],
"part_person": [
999
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1922-08-06",
"date_sdn": 2423273,
"descr": "Birth of Landry, Charles Doyle",
"gid": "E1327",
"media": [],
"part_family": [],
"part_person": [
1000
],
"place": 1043,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1328",
"media": [],
"part_family": [],
"part_person": [
1000
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1894-06-18",
"date_sdn": 2412998,
"descr": "Birth of Landry, Charles M.",
"gid": "E1305",
"media": [],
"part_family": [],
"part_person": [
1001
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1306",
"media": [],
"part_family": [],
"part_person": [
1001
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1864-12-00",
"date_sdn": 2402207,
"descr": "Birth of Landry, Eleanor (Nellie) Therese",
"gid": "E1797",
"media": [],
"part_family": [],
"part_person": [
1002
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1935-12-12",
"date_sdn": 2428149,
"descr": "Death of Landry, Eleanor (Nellie) Therese",
"gid": "E1798",
"media": [],
"part_family": [],
"part_person": [
1002
],
"place": 6,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1935-12-14",
"date_sdn": 2428151,
"descr": "Burial of Landry, Eleanor (Nellie) Therese",
"gid": "E1799",
"media": [],
"part_family": [],
"part_person": [
1002
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1924-02-16",
"date_sdn": 2423832,
"descr": "Birth of Landry, Eleanor Jean",
"gid": "E1329",
"media": [],
"part_family": [],
"part_person": [
1003
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1330",
"media": [],
"part_family": [],
"part_person": [
1003
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1906-10-16",
"date_sdn": 2417500,
"descr": "Birth of Landry, Helen Margaret",
"gid": "E1320",
"media": [],
"part_family": [],
"part_person": [
1004
],
"place": 23,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Landry, Helen Margaret",
"gid": "E1321",
"media": [],
"part_family": [],
"part_person": [
1004
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1897-09-14",
"date_sdn": 2414182,
"descr": "Birth of Landry, John Anthony",
"gid": "E1312",
"media": [],
"part_family": [],
"part_person": [
1005
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1313",
"media": [],
"part_family": [],
"part_person": [
1005
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1926-11-07",
"date_sdn": 2424827,
"descr": "Birth of Landry, John Chandler",
"gid": "E1331",
"media": [],
"part_family": [],
"part_person": [
1006
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1332",
"media": [],
"part_family": [],
"part_person": [
1006
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1902-06-15",
"date_sdn": 2415916,
"descr": "Birth of Landry, Josephine Grace",
"gid": "E1318",
"media": [],
"part_family": [],
"part_person": [
1007
],
"place": 23,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1319",
"media": [],
"part_family": [],
"part_person": [
1007
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1889-05-28",
"date_sdn": 2411151,
"descr": "Birth of Landry, Mary A.",
"gid": "E1301",
"media": [],
"part_family": [],
"part_person": [
1009
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1955-11-18",
"date_sdn": 2435430,
"descr": "Death of Landry, Mary A.",
"gid": "E1302",
"media": [],
"part_family": [],
"part_person": [
1009
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1891-07-11",
"date_sdn": 2411925,
"descr": "Birth of Landry, Maurice T.",
"gid": "E1303",
"media": [],
"part_family": [],
"part_person": [
1010
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1304",
"media": [],
"part_family": [],
"part_person": [
1010
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1921-01-11",
"date_sdn": 2422701,
"descr": "Birth of Landry, Maurice, Jr.",
"gid": "E1325",
"media": [],
"part_family": [],
"part_person": [
1011
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1326",
"media": [],
"part_family": [],
"part_person": [
1011
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1855-05-27",
"date_sdn": 2398731,
"descr": "Birth of Landry, Michael Edward",
"gid": "E1297",
"media": [],
"part_family": [],
"part_person": [
1012
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-08-23",
"date_sdn": 2425116,
"descr": "Death of Landry, Michael Edward",
"gid": "E1298",
"media": [],
"part_family": [],
"part_person": [
1012
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Landry, Michael Edward",
"gid": "E1299",
"media": [],
"part_family": [],
"part_person": [
1012
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1857",
"date_sdn": 2399316,
"descr": "Birth of Landry, Sarah",
"gid": "E1314",
"media": [],
"part_family": [],
"part_person": [
1015
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1886-11-26",
"date_sdn": 2410237,
"descr": "Birth of Landry, Theresa A.",
"gid": "E1300",
"media": [],
"part_family": [],
"part_person": [
1016
],
"place": 893,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1972-07-12",
"date_sdn": 2441511,
"descr": "Birth of Lane, Anthony David",
"gid": "E1785",
"media": [],
"part_family": [],
"part_person": [
1017
],
"place": 1069,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1786",
"media": [],
"part_family": [],
"part_person": [
1017
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1974-09-10",
"date_sdn": 2442301,
"descr": "Birth of Lane, Donna Elizabeth",
"gid": "E1787",
"media": [],
"part_family": [],
"part_person": [
1018
],
"place": 83,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1788",
"media": [],
"part_family": [],
"part_person": [
1018
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1943-10-10",
"date_sdn": 2431008,
"descr": "Birth of Lane, Joseph Edward",
"gid": "E1202",
"media": [],
"part_family": [],
"part_person": [
1019
],
"place": 766,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1203",
"media": [],
"part_family": [],
"part_person": [
1019
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1908-12-13",
"date_sdn": 2418289,
"descr": "Birth of Lane, Joseph Robert",
"gid": "E1194",
"media": [],
"part_family": [],
"part_person": [
1020
],
"place": 277,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1988-12-27",
"date_sdn": 2447523,
"descr": "Death of Lane, Joseph Robert",
"gid": "E1195",
"media": [],
"part_family": [],
"part_person": [
1020
],
"place": 766,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Lane, Joseph Robert",
"gid": "E1196",
"media": [],
"part_family": [],
"part_person": [
1020
],
"place": 735,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lane, Remo",
"gid": "E2303",
"media": [],
"part_family": [],
"part_person": [
1021
],
"place": 74,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-01-19",
"date_sdn": 2421978,
"descr": "Death of Lane, Remo",
"gid": "E2304",
"media": [],
"part_family": [],
"part_person": [
1021
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Lane, Remo",
"gid": "E2305",
"media": [],
"part_family": [],
"part_person": [
1021
],
"place": 735,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1718",
"date_sdn": 2348547,
"descr": "Birth of Lapointe, Lucy aka Sarah",
"gid": "E2708",
"media": [],
"part_family": [],
"part_person": [
1023
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1741",
"date_sdn": 2356948,
"descr": "Death of Lapointe, Lucy aka Sarah",
"gid": "E2709",
"media": [],
"part_family": [],
"part_person": [
1023
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1834-11-18",
"date_sdn": 2391236,
"descr": "Death of Larson, Christena Wiseman",
"gid": "E0669",
"media": [],
"part_family": [],
"part_person": [
1027
],
"place": 988,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1834-11-20",
"date_sdn": 2391238,
"descr": "Burial of Larson, Christena Wiseman",
"gid": "E0670",
"media": [],
"part_family": [],
"part_person": [
1027
],
"place": 43,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lefebvre, Joseph",
"gid": "E1862",
"media": [],
"part_family": [],
"part_person": [
1037
],
"place": 1265,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1654-03-22",
"date_sdn": 2325252,
"descr": "Birth of Lefebvre, Mary",
"gid": "E1865",
"media": [],
"part_family": [],
"part_person": [
1038
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1584-12-20",
"date_sdn": 2299958,
"descr": "Birth of Lefebvre, Rev. John L.",
"gid": "E1860",
"media": [],
"part_family": [],
"part_person": [
1039
],
"place": 159,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1653-11-03",
"date_sdn": 2325113,
"descr": "Death of Lefebvre, Rev. John L.",
"gid": "E1861",
"media": [],
"part_family": [],
"part_person": [
1039
],
"place": 935,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1511",
"date_sdn": 2272941,
"descr": "Birth of Lefebvre, Robert",
"gid": "E2141",
"media": [],
"part_family": [],
"part_person": [
1040
],
"place": 926,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1558-10-20",
"date_sdn": 2290400,
"descr": "Death of Lefebvre, Robert",
"gid": "E2142",
"media": [],
"part_family": [],
"part_person": [
1040
],
"place": 159,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard",
"gid": "E0858",
"media": [],
"part_family": [],
"part_person": [
1042
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard, ???",
"gid": "E2507",
"media": [],
"part_family": [],
"part_person": [
1043
],
"place": 815,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1904-07-30",
"date_sdn": 2416692,
"descr": "Birth of Lessard, Carl Tolbert",
"gid": "E1490",
"media": [],
"part_family": [],
"part_person": [
1044
],
"place": 1028,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1985-07-04",
"date_sdn": 2446251,
"descr": "Death of Lessard, Carl Tolbert",
"gid": "E1491",
"media": [],
"part_family": [],
"part_person": [
1044
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1985-07-08",
"date_sdn": 2446255,
"descr": "Burial of Lessard, Carl Tolbert",
"gid": "E1492",
"media": [],
"part_family": [],
"part_person": [
1044
],
"place": 120,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1926-09-29",
"date_sdn": 2424788,
"descr": "Birth of Lessard, Dorothy Louise",
"gid": "E0409",
"media": [],
"part_family": [],
"part_person": [
1045
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0410",
"media": [],
"part_family": [],
"part_person": [
1045
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1931-07-10",
"date_sdn": 2426533,
"descr": "Birth of Lessard, Elinor Jane",
"gid": "E2316",
"media": [],
"part_family": [],
"part_person": [
1046
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2317",
"media": [],
"part_family": [],
"part_person": [
1046
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1868-08-00",
"date_sdn": 2403546,
"descr": "Birth of Lessard, Emma Jane",
"gid": "E0436",
"media": [],
"part_family": [],
"part_person": [
1047
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1933-08-00",
"date_sdn": 2427286,
"descr": "Death of Lessard, Emma Jane",
"gid": "E0437",
"media": [],
"part_family": [],
"part_person": [
1047
],
"place": 317,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1908-02-22",
"date_sdn": 2417994,
"descr": "Birth of Lessard, Helen Belle",
"gid": "E1011",
"media": [],
"part_family": [],
"part_person": [
1048
],
"place": 801,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1997-01-29",
"date_sdn": 2450478,
"descr": "Death of Lessard, Helen Belle",
"gid": "E1012",
"media": [],
"part_family": [],
"part_person": [
1048
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1871-06-15",
"date_sdn": 2404594,
"descr": "Birth of Lessard, Ira Willis",
"gid": "E1575",
"media": [],
"part_family": [],
"part_person": [
1049
],
"place": 690,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1924-12-15",
"date_sdn": 2424135,
"descr": "Death of Lessard, Ira Willis",
"gid": "E1576",
"media": [],
"part_family": [],
"part_person": [
1049
],
"place": 870,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1924-12-18",
"date_sdn": 2424138,
"descr": "Burial of Lessard, Ira Willis",
"gid": "E1577",
"media": [],
"part_family": [],
"part_person": [
1049
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1828-10-00",
"date_sdn": 2388997,
"descr": "Birth of Lessard, Isaac",
"gid": "E1613",
"media": [],
"part_family": [],
"part_person": [
1050
],
"place": 815,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Lessard, Izora",
"gid": "E0464",
"media": [],
"part_family": [],
"part_person": [
1051
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-05-06",
"date_sdn": 2415876,
"descr": "Death of Lessard, Izora",
"gid": "E0465",
"media": [],
"part_family": [],
"part_person": [
1051
],
"place": 615,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1898-07-22",
"date_sdn": 2414493,
"descr": "Birth of Lessard, Laura Eloise",
"gid": "E1018",
"media": [],
"part_family": [],
"part_person": [
1052
],
"place": 340,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1975",
"date_sdn": 2442414,
"descr": "Death of Lessard, Laura Eloise",
"gid": "E1019",
"media": [],
"part_family": [],
"part_person": [
1052
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1937-01-17",
"date_sdn": 2428551,
"descr": "Birth of Lessard, Mary Alice",
"gid": "E0425",
"media": [],
"part_family": [],
"part_person": [
1053
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0426",
"media": [],
"part_family": [],
"part_person": [
1053
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1895-07-20",
"date_sdn": 2413395,
"descr": "Birth of Lessard, Ralph Raymond",
"gid": "E1001",
"media": [],
"part_family": [],
"part_person": [
1054
],
"place": 1028,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-07-08",
"date_sdn": 2440411,
"descr": "Death of Lessard, Ralph Raymond",
"gid": "E1002",
"media": [],
"part_family": [],
"part_person": [
1054
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1896-09-20",
"date_sdn": 2413823,
"descr": "Birth of Lessard, Susanna Marie",
"gid": "E1007",
"media": [],
"part_family": [],
"part_person": [
1056
],
"place": 1028,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1981-10-16",
"date_sdn": 2444894,
"descr": "Death of Lessard, Susanna Marie",
"gid": "E1008",
"media": [],
"part_family": [],
"part_person": [
1056
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Clarence",
"gid": "E0476",
"media": [],
"part_family": [],
"part_person": [
1057
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1893-01-00",
"date_sdn": 2412465,
"descr": "Birth of L\u00e9vesque, Elsie",
"gid": "E0473",
"media": [],
"part_family": [],
"part_person": [
1058
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1899-10-00",
"date_sdn": 2414929,
"descr": "Birth of L\u00e9vesque, Howard",
"gid": "E0477",
"media": [],
"part_family": [],
"part_person": [
1059
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1866-03-00",
"date_sdn": 2402662,
"descr": "Birth of L\u00e9vesque, James W.",
"gid": "E0462",
"media": [],
"part_family": [],
"part_person": [
1060
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1918",
"date_sdn": 2421595,
"descr": "Death of L\u00e9vesque, James W.",
"gid": "E0463",
"media": [],
"part_family": [],
"part_person": [
1060
],
"place": 1189,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1890-08-00",
"date_sdn": 2411581,
"descr": "Birth of L\u00e9vesque, Jennie",
"gid": "E0469",
"media": [],
"part_family": [],
"part_person": [
1061
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1898-11-00",
"date_sdn": 2414595,
"descr": "Birth of L\u00e9vesque, John C.",
"gid": "E0475",
"media": [],
"part_family": [],
"part_person": [
1062
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1896-10-00",
"date_sdn": 2413834,
"descr": "Birth of L\u00e9vesque, Mary",
"gid": "E0474",
"media": [],
"part_family": [],
"part_person": [
1063
],
"place": 888,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Olive",
"gid": "E0468",
"media": [],
"part_family": [],
"part_person": [
1064
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of L\u00e9vesque, Wilma",
"gid": "E0470",
"media": [],
"part_family": [],
"part_person": [
1065
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1982-03-23",
"date_sdn": 2445052,
"descr": "Birth of Long, Elisa Ann",
"gid": "E1418",
"media": [],
"part_family": [],
"part_person": [
1074
],
"place": 613,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1419",
"media": [],
"part_family": [],
"part_person": [
1074
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of L\u00f3pez, Anna Elisabeth",
"gid": "E0358",
"media": [],
"part_family": [],
"part_person": [
1075
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1959-11-26",
"date_sdn": 2436899,
"descr": "Birth of Lopez, John Warren",
"gid": "E1344",
"media": [],
"part_family": [],
"part_person": [
1077
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1345",
"media": [],
"part_family": [],
"part_person": [
1077
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1958-06-10",
"date_sdn": 2436365,
"descr": "Birth of Lopez, Lee William",
"gid": "E1342",
"media": [],
"part_family": [],
"part_person": [
1078
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1343",
"media": [],
"part_family": [],
"part_person": [
1078
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Love",
"gid": "E1006",
"media": [],
"part_family": [],
"part_person": [
1079
],
"place": 805,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Birth of Lucas, Christina",
"gid": "E2564",
"media": [],
"part_family": [],
"part_person": [
1080
],
"place": 162,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Lucas, Christina",
"gid": "E2565",
"media": [],
"part_family": [],
"part_person": [
1080
],
"place": 98,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Lucas, Christina",
"gid": "E2566",
"media": [],
"part_family": [],
"part_person": [
1080
],
"place": 98,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0615",
"media": [],
"part_family": [],
"part_person": [
1082
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1759-11-09",
"date_sdn": 2363834,
"descr": "Birth of Maldonado, Eunice",
"gid": "E1821",
"media": [],
"part_family": [],
"part_person": [
1086
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Maldonado, Eunice",
"gid": "E1822",
"media": [],
"part_family": [],
"part_person": [
1086
],
"place": 444,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Maldonado, Eunice",
"gid": "E1823",
"media": [],
"part_family": [],
"part_person": [
1086
],
"place": 444,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mann, Agnes",
"gid": "E2163",
"media": [],
"part_family": [],
"part_person": [
1088
],
"place": 738,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1940-09-05",
"date_sdn": 2429878,
"descr": "Birth of Manning, Judith Ann",
"gid": "E1966",
"media": [],
"part_family": [],
"part_person": [
1089
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1967",
"media": [],
"part_family": [],
"part_person": [
1089
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1895-08-27",
"date_sdn": 2413433,
"descr": "Birth of Mar\u00edn, Albert",
"gid": "E1111",
"media": [],
"part_family": [],
"part_person": [
1090
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-06-14",
"date_sdn": 2438926,
"descr": "Death of Mar\u00edn, Albert",
"gid": "E1112",
"media": [],
"part_family": [],
"part_person": [
1090
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Albert",
"gid": "E1113",
"media": [],
"part_family": [],
"part_person": [
1090
],
"place": 778,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2578",
"media": [],
"part_family": [],
"part_person": [
1091
],
"place": 902,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-12-25",
"date_sdn": 2402231,
"descr": "Death of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2579",
"media": [],
"part_family": [],
"part_person": [
1091
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1860-12-27",
"date_sdn": 2400772,
"descr": "Burial of Mar\u00edn, Alfred Franklin(Frank)",
"gid": "E2580",
"media": [],
"part_family": [],
"part_person": [
1091
],
"place": 314,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1928-10-11",
"date_sdn": 2425531,
"descr": "Birth of Mar\u00edn, Elizabeth Therese",
"gid": "E0438",
"media": [],
"part_family": [],
"part_person": [
1093
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-29",
"date_sdn": 2425610,
"descr": "Death of Mar\u00edn, Elizabeth Therese",
"gid": "E0439",
"media": [],
"part_family": [],
"part_person": [
1093
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Elizabeth Therese",
"gid": "E0440",
"media": [],
"part_family": [],
"part_person": [
1093
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1813-03-25",
"date_sdn": 2383328,
"descr": "Birth of Mar\u00edn, Frances Coppage",
"gid": "E1107",
"media": [],
"part_family": [],
"part_person": [
1094
],
"place": 894,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1891-10-01",
"date_sdn": 2412007,
"descr": "Death of Mar\u00edn, Frances Coppage",
"gid": "E1108",
"media": [],
"part_family": [],
"part_person": [
1094
],
"place": 1082,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1891-10-03",
"date_sdn": 2412009,
"descr": "Burial of Mar\u00edn, Frances Coppage",
"gid": "E1109",
"media": [],
"part_family": [],
"part_person": [
1094
],
"place": 1082,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1956-10-00",
"date_sdn": 2435748,
"descr": "Death of Mar\u00edn, Frank",
"gid": "E1100",
"media": [],
"part_family": [],
"part_person": [
1095
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Frank",
"gid": "E1101",
"media": [],
"part_family": [],
"part_person": [
1095
],
"place": 35,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1920-10-27",
"date_sdn": 2422625,
"descr": "Birth of Mar\u00edn, Joseph William",
"gid": "E0513",
"media": [],
"part_family": [],
"part_person": [
1096
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Mar\u00edn, Joseph William",
"gid": "E0514",
"media": [],
"part_family": [],
"part_person": [
1096
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Joseph William",
"gid": "E0515",
"media": [],
"part_family": [],
"part_person": [
1096
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-02-26",
"date_sdn": 2408868,
"descr": "Birth of Mar\u00edn, Lilla Estella",
"gid": "E1153",
"media": [],
"part_family": [],
"part_person": [
1097
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1961-02-25",
"date_sdn": 2437356,
"descr": "Death of Mar\u00edn, Lilla Estella",
"gid": "E1154",
"media": [],
"part_family": [],
"part_person": [
1097
],
"place": 766,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1927-01-13",
"date_sdn": 2424894,
"descr": "Birth of Mar\u00edn, Mary Anne",
"gid": "E0168",
"media": [],
"part_family": [],
"part_person": [
1098
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0169",
"media": [],
"part_family": [],
"part_person": [
1098
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1862-04-08",
"date_sdn": 2401239,
"descr": "Birth of Mar\u00edn, Moses Wallace",
"gid": "E1780",
"media": [],
"part_family": [],
"part_person": [
1099
],
"place": 989,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1909-08-08",
"date_sdn": 2418527,
"descr": "Death of Mar\u00edn, Moses Wallace",
"gid": "E1781",
"media": [],
"part_family": [],
"part_person": [
1099
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1909-08-10",
"date_sdn": 2418529,
"descr": "Burial of Mar\u00edn, Moses Wallace",
"gid": "E1782",
"media": [],
"part_family": [],
"part_person": [
1099
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mar\u00edn, Nancy H.",
"gid": "E1287",
"media": [],
"part_family": [],
"part_person": [
1100
],
"place": 913,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1897-06-21",
"date_sdn": 2414097,
"descr": "Birth of Mar\u00edn, Thomas Willis",
"gid": "E1130",
"media": [],
"part_family": [],
"part_person": [
1103
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-06-28",
"date_sdn": 2437844,
"descr": "Death of Mar\u00edn, Thomas Willis",
"gid": "E1131",
"media": [],
"part_family": [],
"part_person": [
1103
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, Thomas Willis",
"gid": "E1132",
"media": [],
"part_family": [],
"part_person": [
1103
],
"place": 1091,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1893-12-29",
"date_sdn": 2412827,
"descr": "Birth of Mar\u00edn, Walter Matthew",
"gid": "E1867",
"media": [],
"part_family": [],
"part_person": [
1104
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-01-16",
"date_sdn": 2440238,
"descr": "Death of Mar\u00edn, Walter Matthew",
"gid": "E1868",
"media": [],
"part_family": [],
"part_person": [
1104
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1969-01-18",
"date_sdn": 2440240,
"descr": "Burial of Mar\u00edn, Walter Matthew",
"gid": "E1869",
"media": [],
"part_family": [],
"part_person": [
1104
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1906-10-00",
"date_sdn": 2417485,
"descr": "Death of Mar\u00edn, Wilbur",
"gid": "E1139",
"media": [],
"part_family": [],
"part_person": [
1105
],
"place": 528,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1906-10-22",
"date_sdn": 2417506,
"descr": "Burial of Mar\u00edn, Wilbur",
"gid": "E1140",
"media": [],
"part_family": [],
"part_person": [
1105
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Mar\u00edn, William",
"gid": "E2614",
"media": [],
"part_family": [],
"part_person": [
1106
],
"place": 650,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mar\u00edn, William",
"gid": "E2615",
"media": [],
"part_family": [],
"part_person": [
1106
],
"place": 1065,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1822-11-11",
"date_sdn": 2386846,
"descr": "Birth of Mar\u00edn, Willis H.",
"gid": "E1284",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 840,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1894-01-02",
"date_sdn": 2412831,
"descr": "Death of Mar\u00edn, Willis H.",
"gid": "E1285",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1894-01-03",
"date_sdn": 2412832,
"descr": "Burial of Mar\u00edn, Willis H.",
"gid": "E1286",
"media": [],
"part_family": [],
"part_person": [
1108
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1612",
"date_sdn": 2309831,
"descr": "Birth of Marsh, Margaret",
"gid": "E2587",
"media": [],
"part_family": [],
"part_person": [
1109
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1680-05-20",
"date_sdn": 2334808,
"descr": "Death of Marsh, Margaret",
"gid": "E2588",
"media": [],
"part_family": [],
"part_person": [
1109
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1805-10-27",
"date_sdn": 2380622,
"descr": "Birth of Martel, Henry",
"gid": "E2685",
"media": [],
"part_family": [],
"part_person": [
1111
],
"place": 1229,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-01-18",
"date_sdn": 2415768,
"descr": "Death of Martel, Henry",
"gid": "E2686",
"media": [],
"part_family": [],
"part_person": [
1111
],
"place": 492,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902",
"date_sdn": 2415751,
"descr": "Burial of Martel, Henry",
"gid": "E2687",
"media": [],
"part_family": [],
"part_person": [
1111
],
"place": 492,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1852-01-23",
"date_sdn": 2397511,
"descr": "Birth of Martel, Luella Jacques",
"gid": "E1679",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 364,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-04-28",
"date_sdn": 2422808,
"descr": "Death of Martel, Luella Jacques",
"gid": "E1680",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 826,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-04-30",
"date_sdn": 2422810,
"descr": "Burial of Martel, Luella Jacques",
"gid": "E1681",
"media": [],
"part_family": [],
"part_person": [
1112
],
"place": 826,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "1993-11-29",
"date_sdn": 2449321,
"descr": "Birth of Mart\u00edn, Tyler William",
"gid": "E0082",
"media": [],
"part_family": [],
"part_person": [
1115
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0083",
"media": [],
"part_family": [],
"part_person": [
1115
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1420",
"date_sdn": 2239704,
"descr": "Birth of Massey, John",
"gid": "E0054",
"media": [],
"part_family": [],
"part_person": [
1120
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1995-07-11",
"date_sdn": 2449910,
"descr": "Birth of Matthews, Nicholas Ian",
"gid": "E0140",
"media": [],
"part_family": [],
"part_person": [
1122
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0141",
"media": [],
"part_family": [],
"part_person": [
1122
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1632",
"date_sdn": 2317136,
"descr": "Birth of Mazur, Elizabeth",
"gid": "E0263",
"media": [],
"part_family": [],
"part_person": [
1125
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Mazur, Elizabeth",
"gid": "E0264",
"media": [],
"part_family": [],
"part_person": [
1125
],
"place": 461,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1606",
"date_sdn": 2307640,
"descr": "Birth of Mazur, William",
"gid": "E0265",
"media": [],
"part_family": [],
"part_person": [
1126
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1954-05-22",
"date_sdn": 2434885,
"descr": "Birth of Mcbride, Paul",
"gid": "E1604",
"media": [],
"part_family": [],
"part_person": [
1127
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1605",
"media": [],
"part_family": [],
"part_person": [
1127
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of McCarthy, Mary",
"gid": "E1991",
"media": [],
"part_family": [],
"part_person": [
1128
],
"place": 704,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of McCarthy, Mary",
"gid": "E1992",
"media": [],
"part_family": [],
"part_person": [
1128
],
"place": 677,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of McCarthy, Mary",
"gid": "E1993",
"media": [],
"part_family": [],
"part_person": [
1128
],
"place": 1117,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0977",
"media": [],
"part_family": [],
"part_person": [
1131
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1975-07-18",
"date_sdn": 2442612,
"descr": "Birth of McCoy, Canice Oliver",
"gid": "E0919",
"media": [],
"part_family": [],
"part_person": [
1132
],
"place": 1133,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0920",
"media": [],
"part_family": [],
"part_person": [
1132
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1971-01-20",
"date_sdn": 2440972,
"descr": "Birth of McCoy, Celine Bridget",
"gid": "E0913",
"media": [],
"part_family": [],
"part_person": [
1133
],
"place": 1133,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0914",
"media": [],
"part_family": [],
"part_person": [
1133
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1890-05-23",
"date_sdn": 2411511,
"descr": "Birth of McCoy, Francis",
"gid": "E0931",
"media": [],
"part_family": [],
"part_person": [
1135
],
"place": 973,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-05-19",
"date_sdn": 2437804,
"descr": "Death of McCoy, Francis",
"gid": "E0932",
"media": [],
"part_family": [],
"part_person": [
1135
],
"place": 365,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1984-04-12",
"date_sdn": 2445803,
"descr": "Birth of McCoy, Orla Sarah",
"gid": "E0929",
"media": [],
"part_family": [],
"part_person": [
1136
],
"place": 1133,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0930",
"media": [],
"part_family": [],
"part_person": [
1136
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1979-02-07",
"date_sdn": 2443912,
"descr": "Birth of McCoy, Paula",
"gid": "E0921",
"media": [],
"part_family": [],
"part_person": [
1137
],
"place": 1133,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-07-03",
"date_sdn": 2445519,
"descr": "Death of McCoy, Paula",
"gid": "E0922",
"media": [],
"part_family": [],
"part_person": [
1137
],
"place": 489,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1940-07-06",
"date_sdn": 2429817,
"descr": "Birth of McCoy, Thomas Michael",
"gid": "E0909",
"media": [],
"part_family": [],
"part_person": [
1138
],
"place": 973,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0910",
"media": [],
"part_family": [],
"part_person": [
1138
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mcdaniel, Margaret",
"gid": "E0554",
"media": [],
"part_family": [],
"part_person": [
1139
],
"place": 981,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Mendez, Martha",
"gid": "E2005",
"media": [],
"part_family": [],
"part_person": [
1141
],
"place": 702,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Mendez, Martha",
"gid": "E2006",
"media": [],
"part_family": [],
"part_person": [
1141
],
"place": 719,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mendez, Martha",
"gid": "E2007",
"media": [],
"part_family": [],
"part_person": [
1141
],
"place": 394,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1825-06-19",
"date_sdn": 2387797,
"descr": "Birth of Meyer, Catherine",
"gid": "E0040",
"media": [],
"part_family": [],
"part_person": [
1143
],
"place": 632,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1911-01-30",
"date_sdn": 2419067,
"descr": "Death of Meyer, Catherine",
"gid": "E0041",
"media": [],
"part_family": [],
"part_person": [
1143
],
"place": 158,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1911-02-01",
"date_sdn": 2419069,
"descr": "Burial of Meyer, Catherine",
"gid": "E0042",
"media": [],
"part_family": [],
"part_person": [
1143
],
"place": 395,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Meyer, P.D.",
"gid": "E1985",
"media": [],
"part_family": [],
"part_person": [
1144
],
"place": 577,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Meyer, P.D.",
"gid": "E1986",
"media": [],
"part_family": [],
"part_person": [
1144
],
"place": 577,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Meyer, P.D.",
"gid": "E1987",
"media": [],
"part_family": [],
"part_person": [
1144
],
"place": 577,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1716",
"date_sdn": 2347816,
"descr": "Birth of Michaud, Anna Eva",
"gid": "E0417",
"media": [],
"part_family": [],
"part_person": [
1145
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1715",
"date_sdn": 2347451,
"descr": "Birth of Michaud, Valentin",
"gid": "E0427",
"media": [],
"part_family": [],
"part_person": [
1146
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1818-01-05",
"date_sdn": 2385075,
"descr": "Birth of Mills, Isabella",
"gid": "E2466",
"media": [],
"part_family": [],
"part_person": [
1149
],
"place": 936,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1874-08-20",
"date_sdn": 2405756,
"descr": "Death of Mills, Isabella",
"gid": "E2467",
"media": [],
"part_family": [],
"part_person": [
1149
],
"place": 788,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1874-08-21",
"date_sdn": 2405757,
"descr": "Burial of Mills, Isabella",
"gid": "E2468",
"media": [],
"part_family": [],
"part_person": [
1149
],
"place": 193,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1740-02-23",
"date_sdn": 2356635,
"descr": "Birth of Mitchell, Mary",
"gid": "E1875",
"media": [],
"part_family": [],
"part_person": [
1150
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1824-12-28",
"date_sdn": 2387624,
"descr": "Death of Mitchell, Mary",
"gid": "E1876",
"media": [],
"part_family": [],
"part_person": [
1150
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1450",
"date_sdn": 2250662,
"descr": "Birth of Molina, Robert",
"gid": "E0253",
"media": [],
"part_family": [],
"part_person": [
1151
],
"place": 926,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1686",
"date_sdn": 2336860,
"descr": "Birth of Montgomery, Mary",
"gid": "E1078",
"media": [],
"part_family": [],
"part_person": [
1152
],
"place": 1156,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1952-12-20",
"date_sdn": 2434367,
"descr": "Birth of Morales, Penelope Margot",
"gid": "E1636",
"media": [],
"part_family": [],
"part_person": [
1155
],
"place": 1280,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1637",
"media": [],
"part_family": [],
"part_person": [
1155
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moran, Andrew",
"gid": "E1932",
"media": [],
"part_family": [],
"part_person": [
1156
],
"place": 761,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Moran, Andrew",
"gid": "E1933",
"media": [],
"part_family": [],
"part_person": [
1156
],
"place": 706,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Moran, Andrew",
"gid": "E1934",
"media": [],
"part_family": [],
"part_person": [
1156
],
"place": 698,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moran, Ann Delilah &#8220;Tilley&#8221;",
"gid": "E1935",
"media": [],
"part_family": [],
"part_person": [
1157
],
"place": 508,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1801",
"date_sdn": 2378862,
"descr": "Death of Moran, Ann Delilah &#8220;Tilley&#8221;",
"gid": "E1936",
"media": [],
"part_family": [],
"part_person": [
1157
],
"place": 630,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1784-02-05",
"date_sdn": 2372688,
"descr": "Birth of Moreno, Aaron",
"gid": "E2008",
"media": [],
"part_family": [],
"part_person": [
1161
],
"place": 479,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-02-18",
"date_sdn": 2395346,
"descr": "Death of Moreno, Aaron",
"gid": "E2009",
"media": [],
"part_family": [],
"part_person": [
1161
],
"place": 213,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1846-02-20",
"date_sdn": 2395348,
"descr": "Burial of Moreno, Aaron",
"gid": "E2010",
"media": [],
"part_family": [],
"part_person": [
1161
],
"place": 367,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1823-03-13",
"date_sdn": 2386968,
"descr": "Birth of Moreno, Abigail Chapman",
"gid": "E1335",
"media": [],
"part_family": [],
"part_person": [
1162
],
"place": 109,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853-06-02",
"date_sdn": 2398007,
"descr": "Death of Moreno, Abigail Chapman",
"gid": "E1336",
"media": [],
"part_family": [],
"part_person": [
1162
],
"place": 527,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1853-06-04",
"date_sdn": 2398009,
"descr": "Burial of Moreno, Abigail Chapman",
"gid": "E1337",
"media": [],
"part_family": [],
"part_person": [
1162
],
"place": 914,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1786-01-13",
"date_sdn": 2373396,
"descr": "Birth of Moreno, Absalom",
"gid": "E1205",
"media": [],
"part_family": [],
"part_person": [
1163
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-04-15",
"date_sdn": 2392480,
"descr": "Death of Moreno, Absalom",
"gid": "E1206",
"media": [],
"part_family": [],
"part_person": [
1163
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1838-04-17",
"date_sdn": 2392482,
"descr": "Burial of Moreno, Absalom",
"gid": "E1207",
"media": [],
"part_family": [],
"part_person": [
1163
],
"place": 900,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1693",
"date_sdn": 2339417,
"descr": "Birth of Moreno, Christian, I",
"gid": "E1939",
"media": [],
"part_family": [],
"part_person": [
1165
],
"place": 594,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1772-04-16",
"date_sdn": 2368376,
"descr": "Death of Moreno, Christian, I",
"gid": "E1940",
"media": [],
"part_family": [],
"part_person": [
1165
],
"place": 1083,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Moreno, Christian, I",
"gid": "E1941",
"media": [],
"part_family": [],
"part_person": [
1165
],
"place": 606,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1825-08-18",
"date_sdn": 2387857,
"descr": "Birth of Moreno, Cyrus W.",
"gid": "E1189",
"media": [],
"part_family": [],
"part_person": [
1166
],
"place": 913,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1828-03-21",
"date_sdn": 2388803,
"descr": "Birth of Moreno, Darius",
"gid": "E1182",
"media": [],
"part_family": [],
"part_person": [
1167
],
"place": 1199,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1818-01-05",
"date_sdn": 2385075,
"descr": "Birth of Moreno, Delilah",
"gid": "E1184",
"media": [],
"part_family": [],
"part_person": [
1169
],
"place": 913,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1871-01-08",
"date_sdn": 2404436,
"descr": "Death of Moreno, Delilah",
"gid": "E1185",
"media": [],
"part_family": [],
"part_person": [
1169
],
"place": 598,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1799-11-29",
"date_sdn": 2378464,
"descr": "Birth of Moreno, Enoch T.",
"gid": "E1214",
"media": [],
"part_family": [],
"part_person": [
1172
],
"place": 113,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1790-01-17",
"date_sdn": 2374861,
"descr": "Birth of Moreno, Esau",
"gid": "E1213",
"media": [],
"part_family": [],
"part_person": [
1173
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1860-06-26",
"date_sdn": 2400588,
"descr": "Birth of Moreno, Flora E.",
"gid": "E1199",
"media": [],
"part_family": [],
"part_person": [
1174
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1844-11-24",
"date_sdn": 2394895,
"descr": "Birth of Moreno, Green P.",
"gid": "E1183",
"media": [],
"part_family": [],
"part_person": [
1175
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Moreno, Herman",
"gid": "E1909",
"media": [],
"part_family": [],
"part_person": [
1176
],
"place": 168,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1726-11-15",
"date_sdn": 2351787,
"descr": "Birth of Moreno, Johann Christian II",
"gid": "E1961",
"media": [],
"part_family": [],
"part_person": [
1177
],
"place": 16,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1797-12-10",
"date_sdn": 2377745,
"descr": "Death of Moreno, Johann Christian II",
"gid": "E1962",
"media": [],
"part_family": [],
"part_person": [
1177
],
"place": 479,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moreno, Johann Henrich",
"gid": "E1923",
"media": [],
"part_family": [],
"part_person": [
1178
],
"place": 738,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Moreno, Johann Henrich",
"gid": "E1924",
"media": [],
"part_family": [],
"part_person": [
1178
],
"place": 168,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1782-01-07",
"date_sdn": 2371929,
"descr": "Birth of Moreno, John",
"gid": "E1204",
"media": [],
"part_family": [],
"part_person": [
1179
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1816-01-26",
"date_sdn": 2384365,
"descr": "Birth of Moreno, Joseph McDowell",
"gid": "E1177",
"media": [],
"part_family": [],
"part_person": [
1180
],
"place": 913,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-06-28",
"date_sdn": 2394015,
"descr": "Death of Moreno, Joseph McDowell",
"gid": "E1178",
"media": [],
"part_family": [],
"part_person": [
1180
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1794-09-10",
"date_sdn": 2376558,
"descr": "Birth of Moreno, Leah",
"gid": "E1208",
"media": [],
"part_family": [],
"part_person": [
1181
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875-11-05",
"date_sdn": 2406198,
"descr": "Death of Moreno, Leah",
"gid": "E1209",
"media": [],
"part_family": [],
"part_person": [
1181
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858-12-12",
"date_sdn": 2400026,
"descr": "Birth of Moreno, Lelia L.",
"gid": "E1198",
"media": [],
"part_family": [],
"part_person": [
1182
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1864-04-15",
"date_sdn": 2401977,
"descr": "Birth of Moreno, Lydia M.",
"gid": "E1201",
"media": [],
"part_family": [],
"part_person": [
1183
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1752-11-23",
"date_sdn": 2361292,
"descr": "Birth of Moreno, Maj. Christopher",
"gid": "E1983",
"media": [],
"part_family": [],
"part_person": [
1184
],
"place": 990,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1823-09-14",
"date_sdn": 2387153,
"descr": "Death of Moreno, Maj. Christopher",
"gid": "E1984",
"media": [],
"part_family": [],
"part_person": [
1184
],
"place": 1034,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1862-11-11",
"date_sdn": 2401456,
"descr": "Birth of Moreno, Martha A.",
"gid": "E1200",
"media": [],
"part_family": [],
"part_person": [
1185
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1820-08-20",
"date_sdn": 2386033,
"descr": "Birth of Moreno, Mary H.",
"gid": "E1188",
"media": [],
"part_family": [],
"part_person": [
1187
],
"place": 913,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1830-03-17",
"date_sdn": 2389529,
"descr": "Birth of Moreno, Minerva",
"gid": "E1192",
"media": [],
"part_family": [],
"part_person": [
1188
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1856-08-07",
"date_sdn": 2399169,
"descr": "Birth of Moreno, Phebe J.",
"gid": "E1197",
"media": [],
"part_family": [],
"part_person": [
1190
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1832-12-26",
"date_sdn": 2390544,
"descr": "Birth of Moreno, Solon",
"gid": "E1193",
"media": [],
"part_family": [],
"part_person": [
1192
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1814-08-22",
"date_sdn": 2383843,
"descr": "Birth of Moreno, Thomas H.",
"gid": "E1176",
"media": [],
"part_family": [],
"part_person": [
1193
],
"place": 913,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1742",
"date_sdn": 2357313,
"descr": "Birth of Morgan, Elisabeth Margaretha",
"gid": "E0390",
"media": [],
"part_family": [],
"part_person": [
1194
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Morin",
"gid": "E0594",
"media": [],
"part_family": [],
"part_person": [
1195
],
"place": 15,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1795",
"date_sdn": 2376671,
"descr": "Death of Morris, Adam",
"gid": "E2017",
"media": [],
"part_family": [],
"part_person": [
1196
],
"place": 956,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1830",
"date_sdn": 2389454,
"descr": "Birth of Morris, Carlisle",
"gid": "E1099",
"media": [],
"part_family": [],
"part_person": [
1197
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Morris, Cyrus",
"gid": "E1102",
"media": [],
"part_family": [],
"part_person": [
1198
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "20",
"date_sdn": 1728365,
"descr": "Birth of Morris, Cyrus",
"gid": "E2018",
"media": [],
"part_family": [],
"part_person": [
1199
],
"place": 991,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1852-08-10",
"date_sdn": 2397711,
"descr": "Death of Morris, Cyrus",
"gid": "E2019",
"media": [],
"part_family": [],
"part_person": [
1199
],
"place": 1071,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Morris, Cyrus",
"gid": "E2020",
"media": [],
"part_family": [],
"part_person": [
1199
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1822-11-20",
"date_sdn": 2386855,
"descr": "Birth of Morris, Jane",
"gid": "E2407",
"media": [],
"part_family": [],
"part_person": [
1200
],
"place": 188,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-04-23",
"date_sdn": 2406733,
"descr": "Death of Morris, Jane",
"gid": "E2408",
"media": [],
"part_family": [],
"part_person": [
1200
],
"place": 379,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Morris, Jane",
"gid": "E2409",
"media": [],
"part_family": [],
"part_person": [
1200
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1841",
"date_sdn": 2393472,
"descr": "Birth of Morris, John",
"gid": "E1106",
"media": [],
"part_family": [],
"part_person": [
1201
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1837",
"date_sdn": 2392011,
"descr": "Birth of Morris, Martha",
"gid": "E1104",
"media": [],
"part_family": [],
"part_person": [
1202
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1839",
"date_sdn": 2392741,
"descr": "Birth of Morris, Mary",
"gid": "E1105",
"media": [],
"part_family": [],
"part_person": [
1203
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1835",
"date_sdn": 2391280,
"descr": "Birth of Morris, Robert",
"gid": "E1103",
"media": [],
"part_family": [],
"part_person": [
1204
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1824",
"date_sdn": 2387262,
"descr": "Birth of Morris, Roland",
"gid": "E1098",
"media": [],
"part_family": [],
"part_person": [
1205
],
"place": 904,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Morrison, Nancy",
"gid": "E2324",
"media": [],
"part_family": [],
"part_person": [
1206
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Morrison, Nancy",
"gid": "E2325",
"media": [],
"part_family": [],
"part_person": [
1206
],
"place": 373,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Morrison, Nancy",
"gid": "E2326",
"media": [],
"part_family": [],
"part_person": [
1206
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1951-11-21",
"date_sdn": 2433972,
"descr": "Birth of Mortensen, Daniel",
"gid": "E1408",
"media": [],
"part_family": [],
"part_person": [
1207
],
"place": 273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1409",
"media": [],
"part_family": [],
"part_person": [
1207
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-07-01",
"date_sdn": 2444787,
"descr": "Birth of Mortensen, Maria Christine",
"gid": "E1412",
"media": [],
"part_family": [],
"part_person": [
1208
],
"place": 813,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1413",
"media": [],
"part_family": [],
"part_person": [
1208
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1980-01-04",
"date_sdn": 2444243,
"descr": "Birth of Mortensen, Robert Alan",
"gid": "E1410",
"media": [],
"part_family": [],
"part_person": [
1209
],
"place": 813,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1411",
"media": [],
"part_family": [],
"part_person": [
1209
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Moss, Christy",
"gid": "E0597",
"media": [],
"part_family": [],
"part_person": [
1211
],
"place": 163,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Florence",
"gid": "E0741",
"media": [],
"part_family": [],
"part_person": [
1212
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Fred",
"gid": "E0737",
"media": [],
"part_family": [],
"part_person": [
1213
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Henry",
"gid": "E0739",
"media": [],
"part_family": [],
"part_person": [
1214
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Mary",
"gid": "E0740",
"media": [],
"part_family": [],
"part_person": [
1215
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Mattie",
"gid": "E0742",
"media": [],
"part_family": [],
"part_person": [
1216
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Moss, Thomas",
"gid": "E0738",
"media": [],
"part_family": [],
"part_person": [
1217
],
"place": 163,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1789",
"date_sdn": 2374480,
"descr": "Birth of Mullins, Robert?",
"gid": "E0127",
"media": [],
"part_family": [],
"part_person": [
1218
],
"place": 628,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-08-13",
"date_sdn": 2388948,
"descr": "Death of Mullins, Robert?",
"gid": "E0128",
"media": [],
"part_family": [],
"part_person": [
1218
],
"place": 323,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Mullins, Robert?",
"gid": "E0129",
"media": [],
"part_family": [],
"part_person": [
1218
],
"place": 784,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Munoz, Moses Romulus?",
"gid": "E1114",
"media": [],
"part_family": [],
"part_person": [
1222
],
"place": 1221,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Munoz, Robert",
"gid": "E1115",
"media": [],
"part_family": [],
"part_person": [
1223
],
"place": 1221,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Munoz, Willis E.",
"gid": "E1116",
"media": [],
"part_family": [],
"part_person": [
1225
],
"place": 1221,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1617",
"date_sdn": 2311658,
"descr": "Birth of Murray, Nicholas",
"gid": "E0280",
"media": [],
"part_family": [],
"part_person": [
1226
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1647",
"date_sdn": 2322615,
"descr": "Birth of Murray, Susannah",
"gid": "E0262",
"media": [],
"part_family": [],
"part_person": [
1227
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1813",
"date_sdn": 2383245,
"descr": "Birth of Myers, James",
"gid": "E2493",
"media": [],
"part_family": [],
"part_person": [
1228
],
"place": 1287,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1896-06-04",
"date_sdn": 2413715,
"descr": "Death of Myers, James",
"gid": "E2494",
"media": [],
"part_family": [],
"part_person": [
1228
],
"place": 1104,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1896",
"date_sdn": 2413560,
"descr": "Burial of Myers, James",
"gid": "E2495",
"media": [],
"part_family": [],
"part_person": [
1228
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1857-12-22",
"date_sdn": 2399671,
"descr": "Birth of Myers, James Joseph Jr.",
"gid": "E2496",
"media": [],
"part_family": [],
"part_person": [
1229
],
"place": 1104,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1934-04-05",
"date_sdn": 2427533,
"descr": "Death of Myers, James Joseph Jr.",
"gid": "E2497",
"media": [],
"part_family": [],
"part_person": [
1229
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1934",
"date_sdn": 2427439,
"descr": "Burial of Myers, James Joseph Jr.",
"gid": "E2498",
"media": [],
"part_family": [],
"part_person": [
1229
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1897",
"date_sdn": 2413926,
"descr": "Birth of Myers, Nina Mae",
"gid": "E2499",
"media": [],
"part_family": [],
"part_person": [
1230
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2500",
"media": [],
"part_family": [],
"part_person": [
1230
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Nadeau, John Franklin",
"gid": "E1110",
"media": [],
"part_family": [],
"part_person": [
1231
],
"place": 399,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Andrew",
"gid": "E0492",
"media": [],
"part_family": [],
"part_person": [
1233
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Belle",
"gid": "E0493",
"media": [],
"part_family": [],
"part_person": [
1234
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903",
"date_sdn": 2416116,
"descr": "Death of Neal, Belle",
"gid": "E0494",
"media": [],
"part_family": [],
"part_person": [
1234
],
"place": 849,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, David",
"gid": "E0507",
"media": [],
"part_family": [],
"part_person": [
1235
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1916-08-30",
"date_sdn": 2421106,
"descr": "Birth of Neal, Helen M.",
"gid": "E0611",
"media": [],
"part_family": [],
"part_person": [
1236
],
"place": 443,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, James",
"gid": "E0498",
"media": [],
"part_family": [],
"part_person": [
1237
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, James",
"gid": "E0491",
"media": [],
"part_family": [],
"part_person": [
1238
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1872-09-11",
"date_sdn": 2405048,
"descr": "Birth of Neal, John",
"gid": "E0499",
"media": [],
"part_family": [],
"part_person": [
1239
],
"place": 267,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-12-26",
"date_sdn": 2425607,
"descr": "Death of Neal, John",
"gid": "E0500",
"media": [],
"part_family": [],
"part_person": [
1239
],
"place": 849,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Neal, Margaret",
"gid": "E0501",
"media": [],
"part_family": [],
"part_person": [
1240
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1877-02-09",
"date_sdn": 2406660,
"descr": "Birth of Neal, Matilda",
"gid": "E0502",
"media": [],
"part_family": [],
"part_person": [
1241
],
"place": 737,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1946",
"date_sdn": 2431822,
"descr": "Death of Neal, Matilda",
"gid": "E0503",
"media": [],
"part_family": [],
"part_person": [
1241
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1982-11-10",
"date_sdn": 2445284,
"descr": "Birth of Nguyen, Elizabeth Diane",
"gid": "E1434",
"media": [],
"part_family": [],
"part_person": [
1244
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1435",
"media": [],
"part_family": [],
"part_person": [
1244
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-11-25",
"date_sdn": 2432515,
"descr": "Birth of Nguyen, John Harry",
"gid": "E1430",
"media": [],
"part_family": [],
"part_person": [
1245
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1431",
"media": [],
"part_family": [],
"part_person": [
1245
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-07-04",
"date_sdn": 2444790,
"descr": "Birth of Nguyen, Laurie Ann",
"gid": "E1432",
"media": [],
"part_family": [],
"part_person": [
1246
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1433",
"media": [],
"part_family": [],
"part_person": [
1246
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1711-01-03",
"date_sdn": 2345992,
"descr": "Birth of Nichols, Elizabeth",
"gid": "E1074",
"media": [],
"part_family": [],
"part_person": [
1247
],
"place": 1256,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1768-04-15",
"date_sdn": 2366914,
"descr": "Death of Nichols, Elizabeth",
"gid": "E1075",
"media": [],
"part_family": [],
"part_person": [
1247
],
"place": 1256,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1914-10-16",
"date_sdn": 2420422,
"descr": "Birth of Norman, Dorothy Louise",
"gid": "E2517",
"media": [],
"part_family": [],
"part_person": [
1252
],
"place": 29,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2518",
"media": [],
"part_family": [],
"part_person": [
1252
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1679",
"date_sdn": 2334303,
"descr": "Birth of Norris, Elizabeth",
"gid": "E1146",
"media": [],
"part_family": [],
"part_person": [
1253
],
"place": 1070,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1731-05-10",
"date_sdn": 2353424,
"descr": "Death of Norris, Elizabeth",
"gid": "E1147",
"media": [],
"part_family": [],
"part_person": [
1253
],
"place": 427,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1731-05-12",
"date_sdn": 2353426,
"descr": "Burial of Norris, Elizabeth",
"gid": "E1148",
"media": [],
"part_family": [],
"part_person": [
1253
],
"place": 1073,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1633-09-08",
"date_sdn": 2317752,
"descr": "Birth of Norris, John",
"gid": "E2235",
"media": [],
"part_family": [],
"part_person": [
1254
],
"place": 987,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1712-08-27",
"date_sdn": 2346594,
"descr": "Death of Norris, John",
"gid": "E2236",
"media": [],
"part_family": [],
"part_person": [
1254
],
"place": 37,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1712",
"date_sdn": 2346355,
"descr": "Burial of Norris, John",
"gid": "E2237",
"media": [],
"part_family": [],
"part_person": [
1254
],
"place": 579,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1600",
"date_sdn": 2305448,
"descr": "Birth of Norris, William",
"gid": "E1117",
"media": [],
"part_family": [],
"part_person": [
1255
],
"place": 925,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1983-12-17",
"date_sdn": 2445686,
"descr": "Birth of Norton, Christina",
"gid": "E1455",
"media": [],
"part_family": [],
"part_person": [
1256
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1456",
"media": [],
"part_family": [],
"part_person": [
1256
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1945-11-25",
"date_sdn": 2431785,
"descr": "Birth of Norton, Dorothy",
"gid": "E2436",
"media": [],
"part_family": [],
"part_person": [
1257
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2437",
"media": [],
"part_family": [],
"part_person": [
1257
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Nowak, John H.",
"gid": "E0748",
"media": [],
"part_family": [],
"part_person": [
1258
],
"place": 904,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1948-09-12",
"date_sdn": 2432807,
"descr": "Birth of Nunez, Barbara Ann",
"gid": "E1644",
"media": [],
"part_family": [],
"part_person": [
1259
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1645",
"media": [],
"part_family": [],
"part_person": [
1259
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-09-03",
"date_sdn": 2444851,
"descr": "Birth of Obrien, Kieran Thomas",
"gid": "E0923",
"media": [],
"part_family": [],
"part_person": [
1260
],
"place": 1133,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0924",
"media": [],
"part_family": [],
"part_person": [
1260
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Oliver, Elizabeth",
"gid": "E2015",
"media": [],
"part_family": [],
"part_person": [
1261
],
"place": 1144,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Oliver, Elizabeth",
"gid": "E2016",
"media": [],
"part_family": [],
"part_person": [
1261
],
"place": 218,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Oliver, Harmonas I",
"gid": "E2011",
"media": [],
"part_family": [],
"part_person": [
1263
],
"place": 994,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Oliver, Harmonas I",
"gid": "E2012",
"media": [],
"part_family": [],
"part_person": [
1263
],
"place": 828,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Oliver, Harmonas I",
"gid": "E2013",
"media": [],
"part_family": [],
"part_person": [
1263
],
"place": 828,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Oliver, Harmonas II",
"gid": "E2014",
"media": [],
"part_family": [],
"part_person": [
1264
],
"place": 828,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1843",
"date_sdn": 2394202,
"descr": "Birth of Ortega, Catherine",
"gid": "E2693",
"media": [],
"part_family": [],
"part_person": [
1266
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1876",
"date_sdn": 2406255,
"descr": "Death of Ortega, Catherine",
"gid": "E2694",
"media": [],
"part_family": [],
"part_person": [
1266
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0614",
"media": [],
"part_family": [],
"part_person": [
1267
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1993-09-23",
"date_sdn": 2449254,
"descr": "Birth of Osborne, Aaron Patrick",
"gid": "E2690",
"media": [],
"part_family": [],
"part_person": [
1270
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1995-02-15",
"date_sdn": 2449764,
"descr": "Death of Osborne, Aaron Patrick",
"gid": "E2691",
"media": [],
"part_family": [],
"part_person": [
1270
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Osborne, Aaron Patrick",
"gid": "E2692",
"media": [],
"part_family": [],
"part_person": [
1270
],
"place": 110,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1996-10-20",
"date_sdn": 2450377,
"descr": "Birth of Osborne, Andrew Cole",
"gid": "E1700",
"media": [],
"part_family": [],
"part_person": [
1271
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1701",
"media": [],
"part_family": [],
"part_person": [
1271
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1961-06-21",
"date_sdn": 2437472,
"descr": "Birth of Osborne, Anita June",
"gid": "E1093",
"media": [],
"part_family": [],
"part_person": [
1272
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1094",
"media": [],
"part_family": [],
"part_person": [
1272
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1933-12-31",
"date_sdn": 2427438,
"descr": "Birth of Osborne, Dwight Billington",
"gid": "E0540",
"media": [],
"part_family": [],
"part_person": [
1273
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0541",
"media": [],
"part_family": [],
"part_person": [
1273
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1967-10-06",
"date_sdn": 2439770,
"descr": "Birth of Osborne, Julia Marie",
"gid": "E0851",
"media": [],
"part_family": [],
"part_person": [
1274
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0852",
"media": [],
"part_family": [],
"part_person": [
1274
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1998-09-19",
"date_sdn": 2451076,
"descr": "Birth of Osborne, Madeline Kathleen",
"gid": "E1046",
"media": [],
"part_family": [],
"part_person": [
1275
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1047",
"media": [],
"part_family": [],
"part_person": [
1275
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1963-05-18",
"date_sdn": 2438168,
"descr": "Birth of Osborne, Paul Daniel",
"gid": "E0838",
"media": [],
"part_family": [],
"part_person": [
1276
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0839",
"media": [],
"part_family": [],
"part_person": [
1276
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1887-02-05",
"date_sdn": 2410308,
"descr": "Birth of Page, Andrew Vincent",
"gid": "E1055",
"media": [],
"part_family": [],
"part_person": [
1280
],
"place": 891,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-09-27",
"date_sdn": 2444144,
"descr": "Death of Page, Andrew Vincent",
"gid": "E1056",
"media": [],
"part_family": [],
"part_person": [
1280
],
"place": 352,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1979-09-29",
"date_sdn": 2444146,
"descr": "Burial of Page, Andrew Vincent",
"gid": "E1057",
"media": [],
"part_family": [],
"part_person": [
1280
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1867",
"date_sdn": 2402968,
"descr": "Birth of Page, Anna",
"gid": "E0570",
"media": [],
"part_family": [],
"part_person": [
1281
],
"place": 908,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Belle",
"gid": "E0592",
"media": [],
"part_family": [],
"part_person": [
1282
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, Belle",
"gid": "E0593",
"media": [],
"part_family": [],
"part_person": [
1282
],
"place": 15,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1982-11-23",
"date_sdn": 2445297,
"descr": "Birth of Page, Brandon Kelly",
"gid": "E0769",
"media": [],
"part_family": [],
"part_person": [
1283
],
"place": 154,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0770",
"media": [],
"part_family": [],
"part_person": [
1283
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1889-10-14",
"date_sdn": 2411290,
"descr": "Birth of Page, Clara Belle",
"gid": "E1534",
"media": [],
"part_family": [],
"part_person": [
1284
],
"place": 891,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1969-12-20",
"date_sdn": 2440576,
"descr": "Death of Page, Clara Belle",
"gid": "E1535",
"media": [],
"part_family": [],
"part_person": [
1284
],
"place": 1044,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1969-12-23",
"date_sdn": 2440579,
"descr": "Burial of Page, Clara Belle",
"gid": "E1536",
"media": [],
"part_family": [],
"part_person": [
1284
],
"place": 494,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1967-03-02",
"date_sdn": 2439552,
"descr": "Birth of Page, Darvin Ray",
"gid": "E2546",
"media": [],
"part_family": [],
"part_person": [
1285
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2547",
"media": [],
"part_family": [],
"part_person": [
1285
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1850-01-01",
"date_sdn": 2396759,
"descr": "Birth of Page, David",
"gid": "E1553",
"media": [],
"part_family": [],
"part_person": [
1286
],
"place": 1228,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1922-10-13",
"date_sdn": 2423341,
"descr": "Death of Page, David",
"gid": "E1554",
"media": [],
"part_family": [],
"part_person": [
1286
],
"place": 939,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1922-10-15",
"date_sdn": 2423343,
"descr": "Burial of Page, David",
"gid": "E1555",
"media": [],
"part_family": [],
"part_person": [
1286
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, David",
"gid": "E0750",
"media": [],
"part_family": [],
"part_person": [
1287
],
"place": 1159,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1909",
"date_sdn": 2418308,
"descr": "Death of Page, David",
"gid": "E0751",
"media": [],
"part_family": [],
"part_person": [
1287
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1981-05-28",
"date_sdn": 2444753,
"descr": "Birth of Page, David Alan",
"gid": "E2527",
"media": [],
"part_family": [],
"part_person": [
1288
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2528",
"media": [],
"part_family": [],
"part_person": [
1288
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1963-02-15",
"date_sdn": 2438076,
"descr": "Birth of Page, Debra Dale",
"gid": "E2544",
"media": [],
"part_family": [],
"part_person": [
1289
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2545",
"media": [],
"part_family": [],
"part_person": [
1289
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-04-04",
"date_sdn": 2433376,
"descr": "Birth of Page, Dwayne Alan",
"gid": "E2519",
"media": [],
"part_family": [],
"part_person": [
1290
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2520",
"media": [],
"part_family": [],
"part_person": [
1290
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1885-05-27",
"date_sdn": 2409689,
"descr": "Birth of Page, Edith Mae",
"gid": "E1079",
"media": [],
"part_family": [],
"part_person": [
1292
],
"place": 891,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-05-00",
"date_sdn": 2438882,
"descr": "Death of Page, Edith Mae",
"gid": "E1080",
"media": [],
"part_family": [],
"part_person": [
1292
],
"place": 213,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1965-05-00",
"date_sdn": 2438882,
"descr": "Burial of Page, Edith Mae",
"gid": "E1081",
"media": [],
"part_family": [],
"part_person": [
1292
],
"place": 82,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1921-03-25",
"date_sdn": 2422774,
"descr": "Birth of Page, Eleanor Irene",
"gid": "E1696",
"media": [],
"part_family": [],
"part_person": [
1293
],
"place": 128,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1697",
"media": [],
"part_family": [],
"part_person": [
1293
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1883-10-04",
"date_sdn": 2409088,
"descr": "Birth of Page, Eleanor Maude",
"gid": "E1068",
"media": [],
"part_family": [],
"part_person": [
1294
],
"place": 891,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, Eleanor Maude",
"gid": "E1069",
"media": [],
"part_family": [],
"part_person": [
1294
],
"place": 213,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Page, Eleanor Maude",
"gid": "E1070",
"media": [],
"part_family": [],
"part_person": [
1294
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1841",
"date_sdn": 2393472,
"descr": "Birth of Page, Elizabeth",
"gid": "E0489",
"media": [],
"part_family": [],
"part_person": [
1295
],
"place": 1228,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1915",
"date_sdn": 2420499,
"descr": "Death of Page, Elizabeth",
"gid": "E0490",
"media": [],
"part_family": [],
"part_person": [
1295
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Everett Glenn (Ezra)",
"gid": "E0563",
"media": [],
"part_family": [],
"part_person": [
1297
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Ferne",
"gid": "E0556",
"media": [],
"part_family": [],
"part_person": [
1298
],
"place": 381,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Florence",
"gid": "E0558",
"media": [],
"part_family": [],
"part_person": [
1299
],
"place": 970,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, Florence",
"gid": "E0559",
"media": [],
"part_family": [],
"part_person": [
1299
],
"place": 139,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1914-09-28",
"date_sdn": 2420404,
"descr": "Birth of Page, George Kenneth (Red)",
"gid": "E0560",
"media": [],
"part_family": [],
"part_person": [
1300
],
"place": 970,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1936-03-18",
"date_sdn": 2428246,
"descr": "Death of Page, George Kenneth (Red)",
"gid": "E0561",
"media": [],
"part_family": [],
"part_person": [
1300
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1936-03-20",
"date_sdn": 2428248,
"descr": "Burial of Page, George Kenneth (Red)",
"gid": "E0562",
"media": [],
"part_family": [],
"part_person": [
1300
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, John",
"gid": "E2030",
"media": [],
"part_family": [],
"part_person": [
1302
],
"place": 821,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, John",
"gid": "E2031",
"media": [],
"part_family": [],
"part_person": [
1302
],
"place": 939,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Page, John",
"gid": "E2032",
"media": [],
"part_family": [],
"part_person": [
1302
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, John",
"gid": "E0747",
"media": [],
"part_family": [],
"part_person": [
1303
],
"place": 122,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, John James",
"gid": "E0551",
"media": [],
"part_family": [],
"part_person": [
1304
],
"place": 267,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1943-11-18",
"date_sdn": 2431047,
"descr": "Death of Page, John James",
"gid": "E0552",
"media": [],
"part_family": [],
"part_person": [
1304
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1943-11-20",
"date_sdn": 2431049,
"descr": "Burial of Page, John James",
"gid": "E0553",
"media": [],
"part_family": [],
"part_person": [
1304
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1951-09-17",
"date_sdn": 2433907,
"descr": "Birth of Page, Kenneth Fritz",
"gid": "E0767",
"media": [],
"part_family": [],
"part_person": [
1305
],
"place": 133,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Margaret",
"gid": "E0743",
"media": [],
"part_family": [],
"part_person": [
1306
],
"place": 30,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1851-02-10",
"date_sdn": 2397164,
"descr": "Birth of Page, Margaret",
"gid": "E0510",
"media": [],
"part_family": [],
"part_person": [
1307
],
"place": 821,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-11-22",
"date_sdn": 2424477,
"descr": "Death of Page, Margaret",
"gid": "E0511",
"media": [],
"part_family": [],
"part_person": [
1307
],
"place": 849,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1925-11-24",
"date_sdn": 2424479,
"descr": "Burial of Page, Margaret",
"gid": "E0512",
"media": [],
"part_family": [],
"part_person": [
1307
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1941-07-30",
"date_sdn": 2430206,
"descr": "Birth of Page, Marvin Ray",
"gid": "E2525",
"media": [],
"part_family": [],
"part_person": [
1308
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2526",
"media": [],
"part_family": [],
"part_person": [
1308
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Birth of Page, Mary",
"gid": "E0588",
"media": [],
"part_family": [],
"part_person": [
1309
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Death of Page, Mary",
"gid": "E0589",
"media": [],
"part_family": [],
"part_person": [
1309
],
"place": 908,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Matilda",
"gid": "E0746",
"media": [],
"part_family": [],
"part_person": [
1310
],
"place": 30,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Matilda",
"gid": "E0595",
"media": [],
"part_family": [],
"part_person": [
1311
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, Matilda",
"gid": "E0596",
"media": [],
"part_family": [],
"part_person": [
1311
],
"place": 163,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1900-09-21",
"date_sdn": 2415284,
"descr": "Birth of Page, Maude",
"gid": "E0565",
"media": [],
"part_family": [],
"part_person": [
1312
],
"place": 258,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1987-03-24",
"date_sdn": 2446879,
"descr": "Death of Page, Maude",
"gid": "E0566",
"media": [],
"part_family": [],
"part_person": [
1312
],
"place": 138,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1987-03-26",
"date_sdn": 2446881,
"descr": "Burial of Page, Maude",
"gid": "E0567",
"media": [],
"part_family": [],
"part_person": [
1312
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Page, Mildred",
"gid": "E0564",
"media": [],
"part_family": [],
"part_person": [
1313
],
"place": 970,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1983-08-17",
"date_sdn": 2445564,
"descr": "Birth of Page, Mitchell Lee",
"gid": "E2534",
"media": [],
"part_family": [],
"part_person": [
1314
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2535",
"media": [],
"part_family": [],
"part_person": [
1314
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Birth of Page, Rebecca",
"gid": "E0590",
"media": [],
"part_family": [],
"part_person": [
1316
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880",
"date_sdn": 2407716,
"descr": "Death of Page, Rebecca",
"gid": "E0591",
"media": [],
"part_family": [],
"part_person": [
1316
],
"place": 908,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1974-11-00",
"date_sdn": 2442353,
"descr": "Death of Page, Richard C.",
"gid": "E0755",
"media": [],
"part_family": [],
"part_person": [
1317
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1847-06-11",
"date_sdn": 2395824,
"descr": "Birth of Page, Robert",
"gid": "E0508",
"media": [],
"part_family": [],
"part_person": [
1318
],
"place": 908,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1928-03-22",
"date_sdn": 2425328,
"descr": "Death of Page, Robert",
"gid": "E0509",
"media": [],
"part_family": [],
"part_person": [
1318
],
"place": 849,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Page, Robert Francis",
"gid": "E0557",
"media": [],
"part_family": [],
"part_person": [
1319
],
"place": 381,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1939-08-21",
"date_sdn": 2429497,
"descr": "Birth of Page, Sylvia Louise",
"gid": "E2521",
"media": [],
"part_family": [],
"part_person": [
1322
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2522",
"media": [],
"part_family": [],
"part_person": [
1322
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1992-01-10",
"date_sdn": 2448632,
"descr": "Birth of Page, Todd Christopher",
"gid": "E2536",
"media": [],
"part_family": [],
"part_person": [
1323
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2537",
"media": [],
"part_family": [],
"part_person": [
1323
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1911-02-26",
"date_sdn": 2419094,
"descr": "Birth of Page, Vernett Gail",
"gid": "E1694",
"media": [],
"part_family": [],
"part_person": [
1324
],
"place": 425,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1998-08-29",
"date_sdn": 2451055,
"descr": "Death of Page, Vernett Gail",
"gid": "E1695",
"media": [],
"part_family": [],
"part_person": [
1324
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1819-10-09",
"date_sdn": 2385717,
"descr": "Death of Palmer, Sarah",
"gid": "E1835",
"media": [],
"part_family": [],
"part_person": [
1328
],
"place": 1087,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Parent, Capt.Jacob C.",
"gid": "E1743",
"media": [],
"part_family": [],
"part_person": [
1330
],
"place": 723,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1811-11-09",
"date_sdn": 2382826,
"descr": "Death of Parent, Capt.Jacob C.",
"gid": "E1744",
"media": [],
"part_family": [],
"part_person": [
1330
],
"place": 215,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1811-11-11",
"date_sdn": 2382828,
"descr": "Burial of Parent, Capt.Jacob C.",
"gid": "E1745",
"media": [],
"part_family": [],
"part_person": [
1330
],
"place": 304,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1799-05-09",
"date_sdn": 2378260,
"descr": "Birth of Parent, Eleanor",
"gid": "E1740",
"media": [],
"part_family": [],
"part_person": [
1331
],
"place": 1033,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Parent, Eleanor",
"gid": "E1741",
"media": [],
"part_family": [],
"part_person": [
1331
],
"place": 719,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Parent, Eleanor",
"gid": "E1742",
"media": [],
"part_family": [],
"part_person": [
1331
],
"place": 719,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1797",
"date_sdn": 2377402,
"descr": "Birth of Parent, Montgomery",
"gid": "E0658",
"media": [],
"part_family": [],
"part_person": [
1337
],
"place": 1026,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1871-04-28",
"date_sdn": 2404546,
"descr": "Death of Park, Susannah",
"gid": "E1725",
"media": [],
"part_family": [],
"part_person": [
1342
],
"place": 815,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0823",
"media": [],
"part_family": [],
"part_person": [
1344
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1999-04-18",
"date_sdn": 2451287,
"descr": "Death of Patrick, Robert",
"gid": "E2157",
"media": [],
"part_family": [],
"part_person": [
1347
],
"place": 1216,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1772-08-08",
"date_sdn": 2368490,
"descr": "Birth of Payne, Elizabeth",
"gid": "E1025",
"media": [],
"part_family": [],
"part_person": [
1351
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Payne, Elizabeth",
"gid": "E1026",
"media": [],
"part_family": [],
"part_person": [
1351
],
"place": 1057,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1788-01-03",
"date_sdn": 2374116,
"descr": "Birth of Payne, Fielding",
"gid": "E1009",
"media": [],
"part_family": [],
"part_person": [
1352
],
"place": 288,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1747-08-22",
"date_sdn": 2359372,
"descr": "Birth of Payne, George",
"gid": "E2628",
"media": [],
"part_family": [],
"part_person": [
1354
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1821-07-09",
"date_sdn": 2386356,
"descr": "Death of Payne, George",
"gid": "E2629",
"media": [],
"part_family": [],
"part_person": [
1354
],
"place": 547,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1821-07-11",
"date_sdn": 2386358,
"descr": "Burial of Payne, George",
"gid": "E2630",
"media": [],
"part_family": [],
"part_person": [
1354
],
"place": 547,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, James",
"gid": "E1013",
"media": [],
"part_family": [],
"part_person": [
1355
],
"place": 1111,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, Jane Coppage",
"gid": "E2196",
"media": [],
"part_family": [],
"part_person": [
1356
],
"place": 628,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1873-06-07",
"date_sdn": 2405317,
"descr": "Death of Payne, Jane Coppage",
"gid": "E2197",
"media": [],
"part_family": [],
"part_person": [
1356
],
"place": 858,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1873-06-07",
"date_sdn": 2405317,
"descr": "Burial of Payne, Jane Coppage",
"gid": "E2198",
"media": [],
"part_family": [],
"part_person": [
1356
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1655",
"date_sdn": 2325537,
"descr": "Birth of Payne, Leonard",
"gid": "E2644",
"media": [],
"part_family": [],
"part_person": [
1357
],
"place": 397,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1745-10-00",
"date_sdn": 2358682,
"descr": "Death of Payne, Leonard",
"gid": "E2645",
"media": [],
"part_family": [],
"part_person": [
1357
],
"place": 322,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1745",
"date_sdn": 2358409,
"descr": "Burial of Payne, Leonard",
"gid": "E2646",
"media": [],
"part_family": [],
"part_person": [
1357
],
"place": 322,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "before 1720",
"date_sdn": 2349277,
"descr": "Birth of Payne, Leonard?",
"gid": "E2649",
"media": [],
"part_family": [],
"part_person": [
1358
],
"place": 322,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1757",
"date_sdn": 2362792,
"descr": "Death of Payne, Leonard?",
"gid": "E2650",
"media": [],
"part_family": [],
"part_person": [
1358
],
"place": 322,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Payne, Leonard?",
"gid": "E2651",
"media": [],
"part_family": [],
"part_person": [
1358
],
"place": 322,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Payne, Winifred",
"gid": "E1010",
"media": [],
"part_family": [],
"part_person": [
1363
],
"place": 288,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1930-04-03",
"date_sdn": 2426070,
"descr": "Birth of Pearson, Eileen Ruth",
"gid": "E0568",
"media": [],
"part_family": [],
"part_person": [
1364
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0569",
"media": [],
"part_family": [],
"part_person": [
1364
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1922-09-07",
"date_sdn": 2423305,
"descr": "Birth of Pelletier, Josephine",
"gid": "E0860",
"media": [],
"part_family": [],
"part_person": [
1367
],
"place": 649,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1998-09-15",
"date_sdn": 2451072,
"descr": "Death of Pelletier, Josephine",
"gid": "E0861",
"media": [],
"part_family": [],
"part_person": [
1367
],
"place": 1273,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1926-03-12",
"date_sdn": 2424587,
"descr": "Birth of Perkins, Wilma Mae",
"gid": "E1268",
"media": [],
"part_family": [],
"part_person": [
1371
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1979-05-26",
"date_sdn": 2444020,
"descr": "Birth of Peters, Elissa Marie",
"gid": "E1684",
"media": [],
"part_family": [],
"part_person": [
1376
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1685",
"media": [],
"part_family": [],
"part_person": [
1376
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-06-02",
"date_sdn": 2444758,
"descr": "Death of Peters, Frank O.",
"gid": "E0575",
"media": [],
"part_family": [],
"part_person": [
1377
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "before 1583",
"date_sdn": 2299239,
"descr": "Birth of Peters, George Sr.",
"gid": "E2428",
"media": [],
"part_family": [],
"part_person": [
1378
],
"place": 1012,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1648",
"date_sdn": 2322980,
"descr": "Death of Peters, George Sr.",
"gid": "E2429",
"media": [],
"part_family": [],
"part_person": [
1378
],
"place": 622,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Peters, George Sr.",
"gid": "E2430",
"media": [],
"part_family": [],
"part_person": [
1378
],
"place": 675,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1946-05-10",
"date_sdn": 2431951,
"descr": "Birth of Peters, John C.",
"gid": "E1648",
"media": [],
"part_family": [],
"part_person": [
1380
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1649",
"media": [],
"part_family": [],
"part_person": [
1380
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1608",
"date_sdn": 2308370,
"descr": "Birth of Peters, Rose",
"gid": "E2244",
"media": [],
"part_family": [],
"part_person": [
1381
],
"place": 502,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1695",
"date_sdn": 2340147,
"descr": "Death of Peters, Rose",
"gid": "E2245",
"media": [],
"part_family": [],
"part_person": [
1381
],
"place": 388,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Peters, Rose",
"gid": "E2246",
"media": [],
"part_family": [],
"part_person": [
1381
],
"place": 325,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1947-07-16",
"date_sdn": 2432383,
"descr": "Birth of Phillips, Anita Irene",
"gid": "E0158",
"media": [],
"part_family": [],
"part_person": [
1383
],
"place": 295,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0159",
"media": [],
"part_family": [],
"part_person": [
1383
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1613",
"date_sdn": 2310197,
"descr": "Birth of Piotrowski, John",
"gid": "E2190",
"media": [],
"part_family": [],
"part_person": [
1385
],
"place": 281,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1670",
"date_sdn": 2331016,
"descr": "Death of Piotrowski, John",
"gid": "E2191",
"media": [],
"part_family": [],
"part_person": [
1385
],
"place": 54,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1677",
"date_sdn": 2333573,
"descr": "Death of Piotrowski, John Jr.",
"gid": "E2222",
"media": [],
"part_family": [],
"part_person": [
1386
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Piotrowski, Sir John",
"gid": "E2199",
"media": [],
"part_family": [],
"part_person": [
1388
],
"place": 502,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Piotrowski, Sir John",
"gid": "E2200",
"media": [],
"part_family": [],
"part_person": [
1388
],
"place": 502,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Piotrowski, Sir Michael",
"gid": "E2201",
"media": [],
"part_family": [],
"part_person": [
1389
],
"place": 502,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Piotrowski, Sir Michael",
"gid": "E2202",
"media": [],
"part_family": [],
"part_person": [
1389
],
"place": 502,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0768",
"media": [],
"part_family": [],
"part_person": [
1390
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1971-08-02",
"date_sdn": 2441166,
"descr": "Birth of Poirier, Janelle Marie",
"gid": "E1426",
"media": [],
"part_family": [],
"part_person": [
1392
],
"place": 319,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1427",
"media": [],
"part_family": [],
"part_person": [
1392
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1974-07-09",
"date_sdn": 2442238,
"descr": "Birth of Poirier, Jeffrey Alan",
"gid": "E1428",
"media": [],
"part_family": [],
"part_person": [
1393
],
"place": 31,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1429",
"media": [],
"part_family": [],
"part_person": [
1393
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1957-04-24",
"date_sdn": 2435953,
"descr": "Death of Pope, John",
"gid": "E1944",
"media": [],
"part_family": [],
"part_person": [
1398
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1986-12-30",
"date_sdn": 2446795,
"descr": "Birth of Poulsen, Chelsea Dawn",
"gid": "E1690",
"media": [],
"part_family": [],
"part_person": [
1406
],
"place": 1187,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1691",
"media": [],
"part_family": [],
"part_person": [
1406
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1991-12-08",
"date_sdn": 2448599,
"descr": "Birth of Poulsen, Cole Randall",
"gid": "E0146",
"media": [],
"part_family": [],
"part_person": [
1407
],
"place": 1187,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0147",
"media": [],
"part_family": [],
"part_person": [
1407
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1988-08-19",
"date_sdn": 2447393,
"descr": "Birth of Poulsen, Curtis Theobald",
"gid": "E1692",
"media": [],
"part_family": [],
"part_person": [
1408
],
"place": 1187,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1693",
"media": [],
"part_family": [],
"part_person": [
1408
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1963-01-25",
"date_sdn": 2438055,
"descr": "Birth of Poulsen, Randall Lee",
"gid": "E1665",
"media": [],
"part_family": [],
"part_person": [
1409
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1666",
"media": [],
"part_family": [],
"part_person": [
1409
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Powell, Martha",
"gid": "E0276",
"media": [],
"part_family": [],
"part_person": [
1410
],
"place": 248,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1611-01-11",
"date_sdn": 2309476,
"descr": "Burial of Powell, Martha",
"gid": "E0277",
"media": [],
"part_family": [],
"part_person": [
1410
],
"place": 771,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1945-08-28",
"date_sdn": 2431696,
"descr": "Birth of Powers, Nancy Lou",
"gid": "E1363",
"media": [],
"part_family": [],
"part_person": [
1411
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1364",
"media": [],
"part_family": [],
"part_person": [
1411
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1838-04-25",
"date_sdn": 2392490,
"descr": "Birth of Quinn, Abraham",
"gid": "E0783",
"media": [],
"part_family": [],
"part_person": [
1414
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-18",
"date_sdn": 2420912,
"descr": "Death of Quinn, Abraham",
"gid": "E0784",
"media": [],
"part_family": [],
"part_person": [
1414
],
"place": 979,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1838-04-25",
"date_sdn": 2392490,
"descr": "Birth of Quinn, Abram",
"gid": "E2482",
"media": [],
"part_family": [],
"part_person": [
1415
],
"place": 815,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1916-02-18",
"date_sdn": 2420912,
"descr": "Death of Quinn, Abram",
"gid": "E2483",
"media": [],
"part_family": [],
"part_person": [
1415
],
"place": 300,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1916-02-00",
"date_sdn": 2420895,
"descr": "Burial of Quinn, Abram",
"gid": "E2484",
"media": [],
"part_family": [],
"part_person": [
1415
],
"place": 59,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1867-02-24",
"date_sdn": 2403022,
"descr": "Birth of Quinn, Elizabeth Marium",
"gid": "E0785",
"media": [],
"part_family": [],
"part_person": [
1416
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Quinn, Elizabeth Marium",
"gid": "E0786",
"media": [],
"part_family": [],
"part_person": [
1416
],
"place": 979,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Ramirez, Helen",
"gid": "E2371",
"media": [],
"part_family": [],
"part_person": [
1417
],
"place": 298,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1526",
"date_sdn": 2278420,
"descr": "Birth of Ramos, John",
"gid": "E0248",
"media": [],
"part_family": [],
"part_person": [
1419
],
"place": 736,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1556",
"date_sdn": 2289377,
"descr": "Birth of Ramos, Mary",
"gid": "E2249",
"media": [],
"part_family": [],
"part_person": [
1420
],
"place": 644,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1588-01-07",
"date_sdn": 2301071,
"descr": "Death of Ramos, Mary",
"gid": "E2250",
"media": [],
"part_family": [],
"part_person": [
1420
],
"place": 159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ramos, Mary",
"gid": "E2251",
"media": [],
"part_family": [],
"part_person": [
1420
],
"place": 1223,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1944-09-11",
"date_sdn": 2431345,
"descr": "Birth of Rasmussen, Marilyn Joan",
"gid": "E1617",
"media": [],
"part_family": [],
"part_person": [
1422
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1618",
"media": [],
"part_family": [],
"part_person": [
1422
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1878-08-25",
"date_sdn": 2407222,
"descr": "Birth of Reed",
"gid": "E0990",
"media": [],
"part_family": [],
"part_person": [
1423
],
"place": 1079,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1914",
"date_sdn": 2420134,
"descr": "Birth of Reed, Anastasia",
"gid": "E0965",
"media": [],
"part_family": [],
"part_person": [
1424
],
"place": 591,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1885-02-24",
"date_sdn": 2409597,
"descr": "Birth of Reed, Bridget Ann",
"gid": "E0981",
"media": [],
"part_family": [],
"part_person": [
1427
],
"place": 22,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reed, Bridget Ann",
"gid": "E0982",
"media": [],
"part_family": [],
"part_person": [
1427
],
"place": 578,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1850-01-19",
"date_sdn": 2396777,
"descr": "Birth of Reed, Bridgette",
"gid": "E2170",
"media": [],
"part_family": [],
"part_person": [
1428
],
"place": 468,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1901-08-13",
"date_sdn": 2415610,
"descr": "Death of Reed, Bridgette",
"gid": "E2171",
"media": [],
"part_family": [],
"part_person": [
1428
],
"place": 24,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1938-02-00",
"date_sdn": 2428931,
"descr": "Birth of Reed, Carmel",
"gid": "E0950",
"media": [],
"part_family": [],
"part_person": [
1429
],
"place": 852,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0951",
"media": [],
"part_family": [],
"part_person": [
1429
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1842-01-09",
"date_sdn": 2393845,
"descr": "Birth of Reed, Catherine",
"gid": "E0230",
"media": [],
"part_family": [],
"part_person": [
1431
],
"place": 468,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reed, Catherine",
"gid": "E0231",
"media": [],
"part_family": [],
"part_person": [
1431
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1901",
"date_sdn": 2415386,
"descr": "Birth of Reed, Catherine",
"gid": "E0966",
"media": [],
"part_family": [],
"part_person": [
1432
],
"place": 311,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1994-05-02",
"date_sdn": 2449475,
"descr": "Death of Reed, Catherine",
"gid": "E0967",
"media": [],
"part_family": [],
"part_person": [
1432
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1847-06-28",
"date_sdn": 2395841,
"descr": "Birth of Reed, Edward",
"gid": "E0226",
"media": [],
"part_family": [],
"part_person": [
1434
],
"place": 344,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1892-03-05",
"date_sdn": 2412163,
"descr": "Death of Reed, Edward",
"gid": "E0227",
"media": [],
"part_family": [],
"part_person": [
1434
],
"place": 937,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Ellen",
"gid": "E0228",
"media": [],
"part_family": [],
"part_person": [
1436
],
"place": 552,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1902-07-08",
"date_sdn": 2415939,
"descr": "Birth of Reed, Frances Lucille (Babe)",
"gid": "E1853",
"media": [],
"part_family": [],
"part_person": [
1437
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1988-08-09",
"date_sdn": 2447383,
"descr": "Death of Reed, Frances Lucille (Babe)",
"gid": "E1854",
"media": [],
"part_family": [],
"part_person": [
1437
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1988-08-11",
"date_sdn": 2447385,
"descr": "Burial of Reed, Frances Lucille (Babe)",
"gid": "E1855",
"media": [],
"part_family": [],
"part_person": [
1437
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1857-05-02",
"date_sdn": 2399437,
"descr": "Birth of Reed, Francis Vincent",
"gid": "E1729",
"media": [],
"part_family": [],
"part_person": [
1438
],
"place": 812,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1945-03-02",
"date_sdn": 2431517,
"descr": "Death of Reed, Francis Vincent",
"gid": "E1730",
"media": [],
"part_family": [],
"part_person": [
1438
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1945-03-04",
"date_sdn": 2431519,
"descr": "Burial of Reed, Francis Vincent",
"gid": "E1731",
"media": [],
"part_family": [],
"part_person": [
1438
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1991",
"date_sdn": 2448258,
"descr": "Birth of Reed, Hannah",
"gid": "E0973",
"media": [],
"part_family": [],
"part_person": [
1439
],
"place": 262,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0974",
"media": [],
"part_family": [],
"part_person": [
1439
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1853-06-13",
"date_sdn": 2398018,
"descr": "Birth of Reed, Hugh",
"gid": "E2166",
"media": [],
"part_family": [],
"part_person": [
1440
],
"place": 812,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1917-04-24",
"date_sdn": 2421343,
"descr": "Death of Reed, Hugh",
"gid": "E2167",
"media": [],
"part_family": [],
"part_person": [
1440
],
"place": 893,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1898",
"date_sdn": 2414291,
"descr": "Birth of Reed, Jane",
"gid": "E0970",
"media": [],
"part_family": [],
"part_person": [
1443
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1976-02-25",
"date_sdn": 2442834,
"descr": "Death of Reed, Jane",
"gid": "E0971",
"media": [],
"part_family": [],
"part_person": [
1443
],
"place": 957,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Jenny",
"gid": "E0996",
"media": [],
"part_family": [],
"part_person": [
1444
],
"place": 591,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1943-05-13",
"date_sdn": 2430858,
"descr": "Birth of Reed, Joan",
"gid": "E0944",
"media": [],
"part_family": [],
"part_person": [
1445
],
"place": 852,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0945",
"media": [],
"part_family": [],
"part_person": [
1445
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, John",
"gid": "E2510",
"media": [],
"part_family": [],
"part_person": [
1446
],
"place": 1063,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1886-08-11",
"date_sdn": 2410130,
"descr": "Death of Reed, John",
"gid": "E2511",
"media": [],
"part_family": [],
"part_person": [
1446
],
"place": 1063,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1886-08-00",
"date_sdn": 2410120,
"descr": "Burial of Reed, John",
"gid": "E2512",
"media": [],
"part_family": [],
"part_person": [
1446
],
"place": 1063,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1844-05-19",
"date_sdn": 2394706,
"descr": "Birth of Reed, John",
"gid": "E2168",
"media": [],
"part_family": [],
"part_person": [
1447
],
"place": 297,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1926-03-28",
"date_sdn": 2424603,
"descr": "Death of Reed, John",
"gid": "E2169",
"media": [],
"part_family": [],
"part_person": [
1447
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Kate",
"gid": "E0998",
"media": [],
"part_family": [],
"part_person": [
1449
],
"place": 591,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1839-03-08",
"date_sdn": 2392807,
"descr": "Birth of Reed, Mary",
"gid": "E2172",
"media": [],
"part_family": [],
"part_person": [
1450
],
"place": 812,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reed, Mary",
"gid": "E2173",
"media": [],
"part_family": [],
"part_person": [
1450
],
"place": 812,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1878-05-10",
"date_sdn": 2407115,
"descr": "Birth of Reed, Mary",
"gid": "E0989",
"media": [],
"part_family": [],
"part_person": [
1451
],
"place": 245,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1847",
"date_sdn": 2395663,
"descr": "Birth of Reed, Matthew",
"gid": "E0935",
"media": [],
"part_family": [],
"part_person": [
1453
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1927-10-21",
"date_sdn": 2425175,
"descr": "Death of Reed, Matthew",
"gid": "E0936",
"media": [],
"part_family": [],
"part_person": [
1453
],
"place": 1272,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Michael",
"gid": "E1005",
"media": [],
"part_family": [],
"part_person": [
1455
],
"place": 345,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Michael",
"gid": "E0999",
"media": [],
"part_family": [],
"part_person": [
1456
],
"place": 591,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reed, Michael",
"gid": "E1000",
"media": [],
"part_family": [],
"part_person": [
1456
],
"place": 993,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1925-03-19",
"date_sdn": 2424229,
"descr": "Death of Reed, Michael",
"gid": "E0938",
"media": [],
"part_family": [],
"part_person": [
1457
],
"place": 1272,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Michael",
"gid": "E0993",
"media": [],
"part_family": [],
"part_person": [
1458
],
"place": 643,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Minnie",
"gid": "E0997",
"media": [],
"part_family": [],
"part_person": [
1459
],
"place": 591,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1928-07-00",
"date_sdn": 2425429,
"descr": "Birth of Reed, Norah",
"gid": "E0983",
"media": [],
"part_family": [],
"part_person": [
1460
],
"place": 296,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0984",
"media": [],
"part_family": [],
"part_person": [
1460
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1934-07-00",
"date_sdn": 2427620,
"descr": "Birth of Reed, Noreen",
"gid": "E0952",
"media": [],
"part_family": [],
"part_person": [
1461
],
"place": 852,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0953",
"media": [],
"part_family": [],
"part_person": [
1461
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Owen",
"gid": "E0980",
"media": [],
"part_family": [],
"part_person": [
1462
],
"place": 578,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1836-02-22",
"date_sdn": 2391697,
"descr": "Birth of Reed, Patrick",
"gid": "E0232",
"media": [],
"part_family": [],
"part_person": [
1463
],
"place": 812,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reed, Patrick",
"gid": "E0233",
"media": [],
"part_family": [],
"part_person": [
1463
],
"place": 296,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1967-07-07",
"date_sdn": 2439679,
"descr": "Death of Reed, Patrick",
"gid": "E0963",
"media": [],
"part_family": [],
"part_person": [
1464
],
"place": 1092,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1967-07-09",
"date_sdn": 2439681,
"descr": "Burial of Reed, Patrick",
"gid": "E0964",
"media": [],
"part_family": [],
"part_person": [
1464
],
"place": 660,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1936-07-00",
"date_sdn": 2428351,
"descr": "Birth of Reed, Peggy",
"gid": "E0948",
"media": [],
"part_family": [],
"part_person": [
1465
],
"place": 852,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0949",
"media": [],
"part_family": [],
"part_person": [
1465
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Peter",
"gid": "E0988",
"media": [],
"part_family": [],
"part_person": [
1466
],
"place": 245,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1904",
"date_sdn": 2416481,
"descr": "Birth of Reed, Peter",
"gid": "E0939",
"media": [],
"part_family": [],
"part_person": [
1467
],
"place": 1272,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1981-04-12",
"date_sdn": 2444707,
"descr": "Death of Reed, Peter",
"gid": "E0940",
"media": [],
"part_family": [],
"part_person": [
1467
],
"place": 374,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Peter James?",
"gid": "E0979",
"media": [],
"part_family": [],
"part_person": [
1468
],
"place": 491,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1906-04-00",
"date_sdn": 2417302,
"descr": "Birth of Reed, Sarah",
"gid": "E0933",
"media": [],
"part_family": [],
"part_person": [
1470
],
"place": 1272,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1984-05-12",
"date_sdn": 2445833,
"descr": "Death of Reed, Sarah",
"gid": "E0934",
"media": [],
"part_family": [],
"part_person": [
1470
],
"place": 1272,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Sarah",
"gid": "E0229",
"media": [],
"part_family": [],
"part_person": [
1471
],
"place": 420,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1876-11-25",
"date_sdn": 2406584,
"descr": "Birth of Reed, Terence",
"gid": "E0985",
"media": [],
"part_family": [],
"part_person": [
1472
],
"place": 610,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1948-05-07",
"date_sdn": 2432679,
"descr": "Birth of Reed, Terrence",
"gid": "E0942",
"media": [],
"part_family": [],
"part_person": [
1473
],
"place": 852,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0943",
"media": [],
"part_family": [],
"part_person": [
1473
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reed, Terrence (TyNed)",
"gid": "E0991",
"media": [],
"part_family": [],
"part_person": [
1474
],
"place": 452,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1940",
"date_sdn": 2429630,
"descr": "Death of Reed, Terrence (TyNed)",
"gid": "E0992",
"media": [],
"part_family": [],
"part_person": [
1474
],
"place": 185,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "before 1750",
"date_sdn": 2360235,
"descr": "Death of Reese",
"gid": "E1698",
"media": [],
"part_family": [],
"part_person": [
1477
],
"place": 800,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reese",
"gid": "E1699",
"media": [],
"part_family": [],
"part_person": [
1477
],
"place": 800,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "after 1901",
"date_sdn": 2415386,
"descr": "Death of Reeves, Ann",
"gid": "E1052",
"media": [],
"part_family": [],
"part_person": [
1478
],
"place": 814,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "before 1901",
"date_sdn": 2415386,
"descr": "Death of Reeves, Catherine",
"gid": "E1054",
"media": [],
"part_family": [],
"part_person": [
1480
],
"place": 814,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1883-03-21",
"date_sdn": 2408891,
"descr": "Birth of Reeves, Honora",
"gid": "E1580",
"media": [],
"part_family": [],
"part_person": [
1483
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1908-11-08",
"date_sdn": 2418254,
"descr": "Death of Reeves, Honora",
"gid": "E1581",
"media": [],
"part_family": [],
"part_person": [
1483
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1819-03-24",
"date_sdn": 2385518,
"descr": "Birth of Reeves, James",
"gid": "E0019",
"media": [],
"part_family": [],
"part_person": [
1485
],
"place": 497,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1897-07-11",
"date_sdn": 2414117,
"descr": "Death of Reeves, James",
"gid": "E0020",
"media": [],
"part_family": [],
"part_person": [
1485
],
"place": 158,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1897-07-13",
"date_sdn": 2414119,
"descr": "Burial of Reeves, James",
"gid": "E0021",
"media": [],
"part_family": [],
"part_person": [
1485
],
"place": 395,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reeves, John",
"gid": "E1988",
"media": [],
"part_family": [],
"part_person": [
1488
],
"place": 1153,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reeves, John",
"gid": "E1989",
"media": [],
"part_family": [],
"part_person": [
1488
],
"place": 651,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reeves, John",
"gid": "E1990",
"media": [],
"part_family": [],
"part_person": [
1488
],
"place": 1117,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1892-05-25",
"date_sdn": 2412244,
"descr": "Birth of Reeves, Margaret",
"gid": "E1578",
"media": [],
"part_family": [],
"part_person": [
1490
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-03-30",
"date_sdn": 2428988,
"descr": "Death of Reeves, Margaret",
"gid": "E1579",
"media": [],
"part_family": [],
"part_person": [
1490
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1856-11-26",
"date_sdn": 2399280,
"descr": "Birth of Reeves, Maria",
"gid": "E1832",
"media": [],
"part_family": [],
"part_person": [
1491
],
"place": 103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1929-01-29",
"date_sdn": 2425641,
"descr": "Death of Reeves, Maria",
"gid": "E1833",
"media": [],
"part_family": [],
"part_person": [
1491
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1929-01-31",
"date_sdn": 2425643,
"descr": "Burial of Reeves, Maria",
"gid": "E1834",
"media": [],
"part_family": [],
"part_person": [
1491
],
"place": 1273,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1880-11-28",
"date_sdn": 2408048,
"descr": "Birth of Reeves, Mary",
"gid": "E1571",
"media": [],
"part_family": [],
"part_person": [
1492
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-03-12",
"date_sdn": 2433353,
"descr": "Death of Reeves, Mary",
"gid": "E1572",
"media": [],
"part_family": [],
"part_person": [
1492
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1051",
"media": [],
"part_family": [],
"part_person": [
1496
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1694-02-04",
"date_sdn": 2339816,
"descr": "Birth of Reid, Anna Catherina",
"gid": "E2611",
"media": [],
"part_family": [],
"part_person": [
1497
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1740-11-20",
"date_sdn": 2356906,
"descr": "Death of Reid, Anna Catherina",
"gid": "E2612",
"media": [],
"part_family": [],
"part_person": [
1497
],
"place": 575,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reid, Anna Catherina",
"gid": "E2613",
"media": [],
"part_family": [],
"part_person": [
1497
],
"place": 658,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1644",
"date_sdn": 2321519,
"descr": "Birth of Reid, Hans",
"gid": "E2595",
"media": [],
"part_family": [],
"part_person": [
1498
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1707-12-06",
"date_sdn": 2344868,
"descr": "Death of Reid, Hans",
"gid": "E2596",
"media": [],
"part_family": [],
"part_person": [
1498
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1622",
"date_sdn": 2313484,
"descr": "Birth of Reynolds, Col. John",
"gid": "E2655",
"media": [],
"part_family": [],
"part_person": [
1500
],
"place": 631,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1670",
"date_sdn": 2331016,
"descr": "Death of Reynolds, Col. John",
"gid": "E2656",
"media": [],
"part_family": [],
"part_person": [
1500
],
"place": 628,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, Col. John",
"gid": "E2657",
"media": [],
"part_family": [],
"part_person": [
1500
],
"place": 628,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1669",
"date_sdn": 2330651,
"descr": "Birth of Reynolds, David",
"gid": "E2652",
"media": [],
"part_family": [],
"part_person": [
1501
],
"place": 1085,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1695",
"date_sdn": 2340147,
"descr": "Death of Reynolds, David",
"gid": "E2653",
"media": [],
"part_family": [],
"part_person": [
1501
],
"place": 1068,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, David",
"gid": "E2654",
"media": [],
"part_family": [],
"part_person": [
1501
],
"place": 928,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Death of Reynolds, John",
"gid": "E2664",
"media": [],
"part_family": [],
"part_person": [
1502
],
"place": 337,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, John",
"gid": "E2665",
"media": [],
"part_family": [],
"part_person": [
1502
],
"place": 628,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1599",
"date_sdn": 2305083,
"descr": "Birth of Reynolds, John",
"gid": "E0268",
"media": [],
"part_family": [],
"part_person": [
1503
],
"place": 631,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reynolds, John",
"gid": "E0269",
"media": [],
"part_family": [],
"part_person": [
1503
],
"place": 256,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1566",
"date_sdn": 2293030,
"descr": "Birth of Reynolds, John",
"gid": "E0278",
"media": [],
"part_family": [],
"part_person": [
1504
],
"place": 631,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Reynolds, Mary Jane",
"gid": "E2666",
"media": [],
"part_family": [],
"part_person": [
1505
],
"place": 176,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Reynolds, Mary Jane",
"gid": "E2667",
"media": [],
"part_family": [],
"part_person": [
1505
],
"place": 1261,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1643",
"date_sdn": 2321154,
"descr": "Birth of Reynolds, Nicholas",
"gid": "E2658",
"media": [],
"part_family": [],
"part_person": [
1506
],
"place": 199,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1695",
"date_sdn": 2340147,
"descr": "Death of Reynolds, Nicholas",
"gid": "E2659",
"media": [],
"part_family": [],
"part_person": [
1506
],
"place": 1068,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, Nicholas",
"gid": "E2660",
"media": [],
"part_family": [],
"part_person": [
1506
],
"place": 1124,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1695",
"date_sdn": 2340147,
"descr": "Birth of Reynolds, William",
"gid": "E2661",
"media": [],
"part_family": [],
"part_person": [
1508
],
"place": 808,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1788",
"date_sdn": 2374114,
"descr": "Death of Reynolds, William",
"gid": "E2662",
"media": [],
"part_family": [],
"part_person": [
1508
],
"place": 706,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Reynolds, William",
"gid": "E2663",
"media": [],
"part_family": [],
"part_person": [
1508
],
"place": 706,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rhodes, Catherine",
"gid": "E0222",
"media": [],
"part_family": [],
"part_person": [
1509
],
"place": 270,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Rhodes, Catherine",
"gid": "E0223",
"media": [],
"part_family": [],
"part_person": [
1509
],
"place": 270,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1928",
"date_sdn": 2425247,
"descr": "Birth of Rhodes, Donald E.",
"gid": "E2179",
"media": [],
"part_family": [],
"part_person": [
1510
],
"place": 1088,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1988",
"date_sdn": 2447162,
"descr": "Death of Rhodes, Donald E.",
"gid": "E2180",
"media": [],
"part_family": [],
"part_person": [
1510
],
"place": 213,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "about 1988",
"date_sdn": 2447162,
"descr": "Burial of Rhodes, Donald E.",
"gid": "E2181",
"media": [],
"part_family": [],
"part_person": [
1510
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1922-05-16",
"date_sdn": 2423191,
"descr": "Birth of Rhodes, Mary Jane",
"gid": "E2182",
"media": [],
"part_family": [],
"part_person": [
1511
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2183",
"media": [],
"part_family": [],
"part_person": [
1511
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rhodes, William Jr.",
"gid": "E2178",
"media": [],
"part_family": [],
"part_person": [
1512
],
"place": 1088,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Rhodes, William Sr.",
"gid": "E1963",
"media": [],
"part_family": [],
"part_person": [
1513
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1723",
"date_sdn": 2350373,
"descr": "Birth of Rice, Virginia Margaret",
"gid": "E1901",
"media": [],
"part_family": [],
"part_person": [
1514
],
"place": 50,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Death of Rice, Virginia Margaret",
"gid": "E1902",
"media": [],
"part_family": [],
"part_person": [
1514
],
"place": 612,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Rice, Virginia Margaret",
"gid": "E1903",
"media": [],
"part_family": [],
"part_person": [
1514
],
"place": 612,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1703",
"date_sdn": 2343068,
"descr": "Birth of Richard, Jeanne",
"gid": "E2207",
"media": [],
"part_family": [],
"part_person": [
1515
],
"place": 77,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1792",
"date_sdn": 2375575,
"descr": "Death of Richard, Jeanne",
"gid": "E2208",
"media": [],
"part_family": [],
"part_person": [
1515
],
"place": 639,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Richard, Jeanne",
"gid": "E2209",
"media": [],
"part_family": [],
"part_person": [
1515
],
"place": 20,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Riley, Thomas",
"gid": "E2683",
"media": [],
"part_family": [],
"part_person": [
1517
],
"place": 1005,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Riley, Thomas",
"gid": "E2684",
"media": [],
"part_family": [],
"part_person": [
1517
],
"place": 490,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1018",
"date_sdn": 2092877,
"descr": "Birth of Rios, Agnes",
"gid": "E0018",
"media": [],
"part_family": [],
"part_person": [
1518
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1924-03-07",
"date_sdn": 2423852,
"descr": "Birth of Robbins, Merida Lorene",
"gid": "E0607",
"media": [],
"part_family": [],
"part_person": [
1519
],
"place": 320,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0608",
"media": [],
"part_family": [],
"part_person": [
1519
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1922-01-15",
"date_sdn": 2423070,
"descr": "Birth of Robbins, Myrabel",
"gid": "E1229",
"media": [],
"part_family": [],
"part_person": [
1520
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1230",
"media": [],
"part_family": [],
"part_person": [
1520
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1703-10-24",
"date_sdn": 2343364,
"descr": "Death of Robertson, Elizabeth",
"gid": "E2424",
"media": [],
"part_family": [],
"part_person": [
1521
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Robinson, Clarence",
"gid": "E2092",
"media": [],
"part_family": [],
"part_person": [
1523
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1975-12-12",
"date_sdn": 2442759,
"descr": "Birth of Rodgers, Crystal Mae",
"gid": "E2299",
"media": [],
"part_family": [],
"part_person": [
1527
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2300",
"media": [],
"part_family": [],
"part_person": [
1527
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1979-08-05",
"date_sdn": 2444091,
"descr": "Birth of Rodgers, Shawna Marie",
"gid": "E2295",
"media": [],
"part_family": [],
"part_person": [
1529
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2296",
"media": [],
"part_family": [],
"part_person": [
1529
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1080",
"date_sdn": 2115522,
"descr": "Birth of Rodr\u00edguez, Agatha",
"gid": "E0026",
"media": [],
"part_family": [],
"part_person": [
1530
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1142",
"date_sdn": 2138167,
"descr": "Death of Rodr\u00edguez, Agatha",
"gid": "E0027",
"media": [],
"part_family": [],
"part_person": [
1530
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Alvin",
"gid": "E0831",
"media": [],
"part_family": [],
"part_person": [
1533
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1820-02-28",
"date_sdn": 2385859,
"descr": "Birth of Rodriquez, Barbara Ann",
"gid": "E0834",
"media": [],
"part_family": [],
"part_person": [
1534
],
"place": 733,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-07-20",
"date_sdn": 2415951,
"descr": "Death of Rodriquez, Barbara Ann",
"gid": "E0835",
"media": [],
"part_family": [],
"part_person": [
1534
],
"place": 573,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Charles",
"gid": "E0849",
"media": [],
"part_family": [],
"part_person": [
1535
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Elizabeth",
"gid": "E0856",
"media": [],
"part_family": [],
"part_person": [
1536
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1816-04-01",
"date_sdn": 2384431,
"descr": "Birth of Rodriquez, Elizabeth Jane",
"gid": "E0832",
"media": [],
"part_family": [],
"part_person": [
1537
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1776-07-22",
"date_sdn": 2369934,
"descr": "Birth of Rodriquez, James",
"gid": "E0850",
"media": [],
"part_family": [],
"part_person": [
1538
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1807-01-22",
"date_sdn": 2381074,
"descr": "Birth of Rodriquez, John",
"gid": "E0830",
"media": [],
"part_family": [],
"part_person": [
1539
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1849-12-25",
"date_sdn": 2396752,
"descr": "Death of Rodriquez, John",
"gid": "E0826",
"media": [],
"part_family": [],
"part_person": [
1540
],
"place": 525,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1781-03-05",
"date_sdn": 2371621,
"descr": "Birth of Rodriquez, Margaret",
"gid": "E0854",
"media": [],
"part_family": [],
"part_person": [
1541
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1825-09-24",
"date_sdn": 2387894,
"descr": "Birth of Rodriquez, Maria Louisa",
"gid": "E0840",
"media": [],
"part_family": [],
"part_person": [
1542
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1814-05-14",
"date_sdn": 2383743,
"descr": "Birth of Rodriquez, Mariam",
"gid": "E1975",
"media": [],
"part_family": [],
"part_person": [
1543
],
"place": 1035,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1900-08-31",
"date_sdn": 2415263,
"descr": "Death of Rodriquez, Mariam",
"gid": "E1976",
"media": [],
"part_family": [],
"part_person": [
1543
],
"place": 104,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1900-09-02",
"date_sdn": 2415265,
"descr": "Burial of Rodriquez, Mariam",
"gid": "E1977",
"media": [],
"part_family": [],
"part_person": [
1543
],
"place": 447,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1770-03-03",
"date_sdn": 2367601,
"descr": "Birth of Rodriquez, Mary",
"gid": "E0843",
"media": [],
"part_family": [],
"part_person": [
1544
],
"place": 652,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1823-06-17",
"date_sdn": 2387064,
"descr": "Birth of Rodriquez, Mary Ann",
"gid": "E0837",
"media": [],
"part_family": [],
"part_person": [
1545
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1828-08-27",
"date_sdn": 2388962,
"descr": "Birth of Rodriquez, Michael Mordica",
"gid": "E0841",
"media": [],
"part_family": [],
"part_person": [
1546
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1772-01-06",
"date_sdn": 2368275,
"descr": "Birth of Rodriquez, Mordica",
"gid": "E0844",
"media": [],
"part_family": [],
"part_person": [
1547
],
"place": 605,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853-07-00",
"date_sdn": 2398036,
"descr": "Death of Rodriquez, Mordica",
"gid": "E0845",
"media": [],
"part_family": [],
"part_person": [
1547
],
"place": 64,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1821-11-28",
"date_sdn": 2386498,
"descr": "Birth of Rodriquez, Oma",
"gid": "E0836",
"media": [],
"part_family": [],
"part_person": [
1548
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Peter",
"gid": "E0842",
"media": [],
"part_family": [],
"part_person": [
1549
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1778-07-31",
"date_sdn": 2370673,
"descr": "Birth of Rodriquez, Richard",
"gid": "E0853",
"media": [],
"part_family": [],
"part_person": [
1550
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Rodriquez, Thomas",
"gid": "E0855",
"media": [],
"part_family": [],
"part_person": [
1551
],
"place": 605,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1806-12-17",
"date_sdn": 2381038,
"descr": "Birth of Rodriquez, William Frederick",
"gid": "E0829",
"media": [],
"part_family": [],
"part_person": [
1552
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1818-05-07",
"date_sdn": 2385197,
"descr": "Birth of Rodriquez, William M.",
"gid": "E0833",
"media": [],
"part_family": [],
"part_person": [
1553
],
"place": 733,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1785-08-08",
"date_sdn": 2373238,
"descr": "Birth of Rodriquez, William M.",
"gid": "E1972",
"media": [],
"part_family": [],
"part_person": [
1554
],
"place": 706,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Rodriquez, William M.",
"gid": "E1973",
"media": [],
"part_family": [],
"part_person": [
1554
],
"place": 573,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Rodriquez, William M.",
"gid": "E1974",
"media": [],
"part_family": [],
"part_person": [
1554
],
"place": 1020,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1759-02-17",
"date_sdn": 2363569,
"descr": "Birth of Rogers, Barbara",
"gid": "E0665",
"media": [],
"part_family": [],
"part_person": [
1555
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1785",
"date_sdn": 2373019,
"descr": "Death of Rogers, Barbara",
"gid": "E0666",
"media": [],
"part_family": [],
"part_person": [
1555
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1607",
"date_sdn": 2308005,
"descr": "Birth of Rose, Ann",
"gid": "E2737",
"media": [],
"part_family": [],
"part_person": [
1557
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1955-04-23",
"date_sdn": 2435221,
"descr": "Birth of Ross, Evelyn Almazon",
"gid": "E1602",
"media": [],
"part_family": [],
"part_person": [
1558
],
"place": 1162,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1603",
"media": [],
"part_family": [],
"part_person": [
1558
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Rubio, Dorcas",
"gid": "E1892",
"media": [],
"part_family": [],
"part_person": [
1560
],
"place": 524,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1709",
"date_sdn": 2345260,
"descr": "Birth of Rubio, Winifred",
"gid": "E2635",
"media": [],
"part_family": [],
"part_person": [
1562
],
"place": 933,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1751-10-06",
"date_sdn": 2360878,
"descr": "Death of Rubio, Winifred",
"gid": "E2636",
"media": [],
"part_family": [],
"part_person": [
1562
],
"place": 628,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1751",
"date_sdn": 2360600,
"descr": "Burial of Rubio, Winifred",
"gid": "E2637",
"media": [],
"part_family": [],
"part_person": [
1562
],
"place": 725,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1786-04-20",
"date_sdn": 2373493,
"descr": "Birth of Ruiz, Catherine",
"gid": "E1719",
"media": [],
"part_family": [],
"part_person": [
1563
],
"place": 628,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-09-25",
"date_sdn": 2406888,
"descr": "Death of Ruiz, Catherine",
"gid": "E1720",
"media": [],
"part_family": [],
"part_person": [
1563
],
"place": 275,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Ruiz, Catherine",
"gid": "E1721",
"media": [],
"part_family": [],
"part_person": [
1563
],
"place": 636,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1968-02-15",
"date_sdn": 2439902,
"descr": "Birth of Russell, Beth Ann",
"gid": "E1964",
"media": [],
"part_family": [],
"part_person": [
1564
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1965",
"media": [],
"part_family": [],
"part_person": [
1564
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1964-12-28",
"date_sdn": 2438758,
"descr": "Birth of Russell, Bruce Lynn",
"gid": "E1970",
"media": [],
"part_family": [],
"part_person": [
1565
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1971",
"media": [],
"part_family": [],
"part_person": [
1565
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990-03-16",
"date_sdn": 2447967,
"descr": "Birth of Russell, Casey John",
"gid": "E2028",
"media": [],
"part_family": [],
"part_person": [
1566
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2029",
"media": [],
"part_family": [],
"part_person": [
1566
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1942-07-23",
"date_sdn": 2430564,
"descr": "Birth of Russell, Janet Gail",
"gid": "E1282",
"media": [],
"part_family": [],
"part_person": [
1567
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1283",
"media": [],
"part_family": [],
"part_person": [
1567
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1936-09-23",
"date_sdn": 2428435,
"descr": "Birth of Russell, Melvin Glen",
"gid": "E1280",
"media": [],
"part_family": [],
"part_person": [
1568
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1281",
"media": [],
"part_family": [],
"part_person": [
1568
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1987-04-03",
"date_sdn": 2446889,
"descr": "Birth of Russell, Nicholas Glen",
"gid": "E2026",
"media": [],
"part_family": [],
"part_person": [
1569
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2027",
"media": [],
"part_family": [],
"part_person": [
1569
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1908-04-27",
"date_sdn": 2418059,
"descr": "Birth of Russell, Norman",
"gid": "E1275",
"media": [],
"part_family": [],
"part_person": [
1570
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Russell, Norman",
"gid": "E1276",
"media": [],
"part_family": [],
"part_person": [
1570
],
"place": 24,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1992",
"date_sdn": 2448623,
"descr": "Burial of Russell, Norman",
"gid": "E1277",
"media": [],
"part_family": [],
"part_person": [
1570
],
"place": 1140,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "about 1556",
"date_sdn": 2289377,
"descr": "Birth of Ryan, Elizabeth",
"gid": "E1058",
"media": [],
"part_family": [],
"part_person": [
1571
],
"place": 1260,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1628",
"date_sdn": 2315675,
"descr": "Death of Ryan, Elizabeth",
"gid": "E1059",
"media": [],
"part_family": [],
"part_person": [
1571
],
"place": 1260,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1508",
"date_sdn": 2271845,
"descr": "Birth of Ryan, Elizabeth",
"gid": "E0067",
"media": [],
"part_family": [],
"part_person": [
1572
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1951-03-02",
"date_sdn": 2433708,
"descr": "Birth of S\u00e1nchez, David Andrew",
"gid": "E2449",
"media": [],
"part_family": [],
"part_person": [
1574
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2450",
"media": [],
"part_family": [],
"part_person": [
1574
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1480",
"date_sdn": 2261619,
"descr": "Birth of Sanchez, John",
"gid": "E2139",
"media": [],
"part_family": [],
"part_person": [
1575
],
"place": 926,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1545",
"date_sdn": 2285360,
"descr": "Death of Sanchez, John",
"gid": "E2140",
"media": [],
"part_family": [],
"part_person": [
1575
],
"place": 926,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1991-05-06",
"date_sdn": 2448383,
"descr": "Birth of S\u00e1nchez, Jonathan Andrew",
"gid": "E2457",
"media": [],
"part_family": [],
"part_person": [
1576
],
"place": 1103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2458",
"media": [],
"part_family": [],
"part_person": [
1576
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1988-09-12",
"date_sdn": 2447417,
"descr": "Birth of S\u00e1nchez, Roxanne Marie",
"gid": "E2455",
"media": [],
"part_family": [],
"part_person": [
1577
],
"place": 1103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2456",
"media": [],
"part_family": [],
"part_person": [
1577
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Sanders, Henry",
"gid": "E0006",
"media": [],
"part_family": [],
"part_person": [
1578
],
"place": 977,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1658-06-17",
"date_sdn": 2326800,
"descr": "Death of Sanders, Henry",
"gid": "E0007",
"media": [],
"part_family": [],
"part_person": [
1578
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1629",
"date_sdn": 2316041,
"descr": "Birth of Sanders, Mary",
"gid": "E2121",
"media": [],
"part_family": [],
"part_person": [
1579
],
"place": 165,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1003",
"media": [],
"part_family": [],
"part_person": [
1584
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Santos, Alice",
"gid": "E0247",
"media": [],
"part_family": [],
"part_person": [
1587
],
"place": 296,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1869-12-25",
"date_sdn": 2404057,
"descr": "Birth of Sanz, John",
"gid": "E0524",
"media": [],
"part_family": [],
"part_person": [
1588
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Sanz, John",
"gid": "E0525",
"media": [],
"part_family": [],
"part_person": [
1588
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1680",
"date_sdn": 2334668,
"descr": "Birth of Saunders, Ursula",
"gid": "E2258",
"media": [],
"part_family": [],
"part_person": [
1589
],
"place": 458,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1740",
"date_sdn": 2356582,
"descr": "Death of Saunders, Ursula",
"gid": "E2259",
"media": [],
"part_family": [],
"part_person": [
1589
],
"place": 145,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Birth of Savard, Honora",
"gid": "E2404",
"media": [],
"part_family": [],
"part_person": [
1590
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-04-01",
"date_sdn": 2415841,
"descr": "Death of Savard, Honora",
"gid": "E2405",
"media": [],
"part_family": [],
"part_person": [
1590
],
"place": 1120,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Savard, Honora",
"gid": "E2406",
"media": [],
"part_family": [],
"part_person": [
1590
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "about 1655",
"date_sdn": 2325537,
"descr": "Birth of Schmidt, Barbli",
"gid": "E2581",
"media": [],
"part_family": [],
"part_person": [
1592
],
"place": 200,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1885-02-14",
"date_sdn": 2409587,
"descr": "Birth of Schneider, Belle Irene",
"gid": "E0609",
"media": [],
"part_family": [],
"part_person": [
1594
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1960-10-11",
"date_sdn": 2437219,
"descr": "Death of Schneider, Belle Irene",
"gid": "E0610",
"media": [],
"part_family": [],
"part_person": [
1594
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Schultz, John",
"gid": "E0003",
"media": [],
"part_family": [],
"part_person": [
1595
],
"place": 669,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1860",
"date_sdn": 2400411,
"descr": "Death of Schultz, John",
"gid": "E0004",
"media": [],
"part_family": [],
"part_person": [
1595
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Schultz, John",
"gid": "E0005",
"media": [],
"part_family": [],
"part_person": [
1595
],
"place": -1,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Schultz, Rev.Isaac",
"gid": "E2616",
"media": [],
"part_family": [],
"part_person": [
1596
],
"place": 921,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Death of Schultz, Rev.Isaac",
"gid": "E2617",
"media": [],
"part_family": [],
"part_person": [
1596
],
"place": 1052,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Burial of Schultz, Rev.Isaac",
"gid": "E2618",
"media": [],
"part_family": [],
"part_person": [
1596
],
"place": 963,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1110",
"date_sdn": 2126479,
"descr": "Birth of Schwartz, Helewisa",
"gid": "E0032",
"media": [],
"part_family": [],
"part_person": [
1597
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1195",
"date_sdn": 2157525,
"descr": "Death of Schwartz, Helewisa",
"gid": "E0033",
"media": [],
"part_family": [],
"part_person": [
1597
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Serrano, Abraham",
"gid": "E0787",
"media": [],
"part_family": [],
"part_person": [
1599
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1804-12-15",
"date_sdn": 2380306,
"descr": "Birth of Serrano, Archibald",
"gid": "E0774",
"media": [],
"part_family": [],
"part_person": [
1600
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1842-11-17",
"date_sdn": 2394157,
"descr": "Death of Serrano, Archibald",
"gid": "E0775",
"media": [],
"part_family": [],
"part_person": [
1600
],
"place": 979,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1842-11-19",
"date_sdn": 2394159,
"descr": "Burial of Serrano, Archibald",
"gid": "E0776",
"media": [],
"part_family": [],
"part_person": [
1600
],
"place": 440,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1711",
"date_sdn": 2345990,
"descr": "Birth of Serrano, Caroline",
"gid": "E1757",
"media": [],
"part_family": [],
"part_person": [
1601
],
"place": 1226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Serrano, Caroline",
"gid": "E1758",
"media": [],
"part_family": [],
"part_person": [
1601
],
"place": 62,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Serrano, Carrie",
"gid": "E0797",
"media": [],
"part_family": [],
"part_person": [
1602
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0857",
"media": [],
"part_family": [],
"part_person": [
1603
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Serrano, Dot",
"gid": "E0798",
"media": [],
"part_family": [],
"part_person": [
1604
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1834-04-03",
"date_sdn": 2391007,
"descr": "Birth of Serrano, Joseph",
"gid": "E0777",
"media": [],
"part_family": [],
"part_person": [
1605
],
"place": 124,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1899-11-02",
"date_sdn": 2414961,
"descr": "Death of Serrano, Joseph",
"gid": "E0778",
"media": [],
"part_family": [],
"part_person": [
1605
],
"place": 979,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1899-11-04",
"date_sdn": 2414963,
"descr": "Burial of Serrano, Joseph",
"gid": "E0779",
"media": [],
"part_family": [],
"part_person": [
1605
],
"place": 837,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Serrano, Joseph",
"gid": "E0780",
"media": [],
"part_family": [],
"part_person": [
1606
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Sharp, ???",
"gid": "E2219",
"media": [],
"part_family": [],
"part_person": [
1608
],
"place": 1227,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "9",
"date_sdn": 1724348,
"descr": "Death of Sharp, ???",
"gid": "E2220",
"media": [],
"part_family": [],
"part_person": [
1608
],
"place": 574,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Sharp, ???",
"gid": "E2221",
"media": [],
"part_family": [],
"part_person": [
1608
],
"place": 1251,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1805-10-06",
"date_sdn": 2380601,
"descr": "Birth of Silva, Mildred",
"gid": "E2088",
"media": [],
"part_family": [],
"part_person": [
1610
],
"place": 282,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-05-10",
"date_sdn": 2403828,
"descr": "Death of Silva, Mildred",
"gid": "E2089",
"media": [],
"part_family": [],
"part_person": [
1610
],
"place": 467,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1869-05-12",
"date_sdn": 2403830,
"descr": "Burial of Silva, Mildred",
"gid": "E2090",
"media": [],
"part_family": [],
"part_person": [
1610
],
"place": 467,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Simard, Sarah",
"gid": "E2269",
"media": [],
"part_family": [],
"part_person": [
1611
],
"place": 542,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Simard, Thomas",
"gid": "E2270",
"media": [],
"part_family": [],
"part_person": [
1612
],
"place": 1127,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1626",
"date_sdn": 2314945,
"descr": "Birth of Simmons, Maria",
"gid": "E0297",
"media": [],
"part_family": [],
"part_person": [
1613
],
"place": 10,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1945-12-17",
"date_sdn": 2431807,
"descr": "Birth of Simpson, Geraldine Ann",
"gid": "E1357",
"media": [],
"part_family": [],
"part_person": [
1614
],
"place": 903,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1358",
"media": [],
"part_family": [],
"part_person": [
1614
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Smith, Anastasia?",
"gid": "E2217",
"media": [],
"part_family": [],
"part_person": [
1615
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Smith, Anastasia?",
"gid": "E2218",
"media": [],
"part_family": [],
"part_person": [
1615
],
"place": 298,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1840-02-20",
"date_sdn": 2393156,
"descr": "Death of Snyder, Ann Louisa",
"gid": "E1092",
"media": [],
"part_family": [],
"part_person": [
1616
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1585",
"date_sdn": 2299970,
"descr": "Birth of Spencer, Ann",
"gid": "E0008",
"media": [],
"part_family": [],
"part_person": [
1619
],
"place": 1188,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1662-12-20",
"date_sdn": 2328447,
"descr": "Death of Spencer, Ann",
"gid": "E0009",
"media": [],
"part_family": [],
"part_person": [
1619
],
"place": 950,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0872",
"media": [],
"part_family": [],
"part_person": [
1620
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Stanley, Barbara",
"gid": "E2735",
"media": [],
"part_family": [],
"part_person": [
1621
],
"place": 316,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Stevens, Elizabeth",
"gid": "E0279",
"media": [],
"part_family": [],
"part_person": [
1624
],
"place": 1267,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1966-11-27",
"date_sdn": 2439457,
"descr": "Birth of Stokes, Gabriel",
"gid": "E0915",
"media": [],
"part_family": [],
"part_person": [
1627
],
"place": 777,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0916",
"media": [],
"part_family": [],
"part_person": [
1627
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1997-03-27",
"date_sdn": 2450535,
"descr": "Birth of Stokes, Liam Michael",
"gid": "E0917",
"media": [],
"part_family": [],
"part_person": [
1628
],
"place": 549,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0918",
"media": [],
"part_family": [],
"part_person": [
1628
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1656-05-21",
"date_sdn": 2326043,
"descr": "Birth of Su\u00e1rez, Marie",
"gid": "E2602",
"media": [],
"part_family": [],
"part_person": [
1631
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1731-01-05",
"date_sdn": 2353299,
"descr": "Death of Su\u00e1rez, Marie",
"gid": "E2603",
"media": [],
"part_family": [],
"part_person": [
1631
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1691",
"date_sdn": 2338686,
"descr": "Birth of Sullivan, Anna",
"gid": "E2584",
"media": [],
"part_family": [],
"part_person": [
1632
],
"place": 969,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1718",
"date_sdn": 2348547,
"descr": "Birth of Sutton, Anna Maria",
"gid": "E0420",
"media": [],
"part_family": [],
"part_person": [
1633
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Swanson, Richard",
"gid": "E0302",
"media": [],
"part_family": [],
"part_person": [
1640
],
"place": 386,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Swanson, Richard",
"gid": "E0303",
"media": [],
"part_family": [],
"part_person": [
1640
],
"place": 1093,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1620",
"date_sdn": 2312753,
"descr": "Birth of Swanson, William",
"gid": "E0300",
"media": [],
"part_family": [],
"part_person": [
1642
],
"place": 476,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1684-10-15",
"date_sdn": 2336417,
"descr": "Death of Swanson, William",
"gid": "E0301",
"media": [],
"part_family": [],
"part_person": [
1642
],
"place": 783,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1780",
"date_sdn": 2371192,
"descr": "Birth of Taylor, Jacob",
"gid": "E0374",
"media": [],
"part_family": [],
"part_person": [
1644
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "about 1580",
"date_sdn": 2298143,
"descr": "Birth of Thomas, Elder Thomas",
"gid": "E1840",
"media": [],
"part_family": [],
"part_person": [
1648
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1632",
"date_sdn": 2317136,
"descr": "Death of Thomas, Elder Thomas",
"gid": "E1841",
"media": [],
"part_family": [],
"part_person": [
1648
],
"place": 522,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1620",
"date_sdn": 2312753,
"descr": "Birth of Thomas, Elizabeth",
"gid": "E1847",
"media": [],
"part_family": [],
"part_person": [
1649
],
"place": 53,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1713",
"date_sdn": 2346721,
"descr": "Death of Thomas, Elizabeth",
"gid": "E1848",
"media": [],
"part_family": [],
"part_person": [
1649
],
"place": 1259,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Thompson, Bridget",
"gid": "E2395",
"media": [],
"part_family": [],
"part_person": [
1650
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Thompson, Bridget",
"gid": "E2396",
"media": [],
"part_family": [],
"part_person": [
1650
],
"place": 684,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Thompson, Bridget",
"gid": "E2397",
"media": [],
"part_family": [],
"part_person": [
1650
],
"place": 1077,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Thornton, Arthur Otto",
"gid": "E1170",
"media": [],
"part_family": [],
"part_person": [
1654
],
"place": 387,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1913-02-20",
"date_sdn": 2419819,
"descr": "Birth of Thornton, Dorothy Eleanor",
"gid": "E1190",
"media": [],
"part_family": [],
"part_person": [
1655
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1191",
"media": [],
"part_family": [],
"part_person": [
1655
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1911-07-12",
"date_sdn": 2419230,
"descr": "Birth of Thornton, James Arthur",
"gid": "E1179",
"media": [],
"part_family": [],
"part_person": [
1656
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-12-02",
"date_sdn": 2445671,
"descr": "Death of Thornton, James Arthur",
"gid": "E1180",
"media": [],
"part_family": [],
"part_person": [
1656
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Thornton, James Arthur",
"gid": "E1181",
"media": [],
"part_family": [],
"part_person": [
1656
],
"place": 1091,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1949-06-17",
"date_sdn": 2433085,
"descr": "Birth of Thornton, Phillip James",
"gid": "E1783",
"media": [],
"part_family": [],
"part_person": [
1658
],
"place": 766,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1784",
"media": [],
"part_family": [],
"part_person": [
1658
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1891-09-22",
"date_sdn": 2411998,
"descr": "Birth of Todd, Benjamin Harrison",
"gid": "E1511",
"media": [],
"part_family": [],
"part_person": [
1660
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1968-02-13",
"date_sdn": 2439900,
"descr": "Death of Todd, Benjamin Harrison",
"gid": "E1512",
"media": [],
"part_family": [],
"part_person": [
1660
],
"place": 830,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Benjamin Harrison",
"gid": "E1513",
"media": [],
"part_family": [],
"part_person": [
1660
],
"place": 1067,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1727-08-15",
"date_sdn": 2352060,
"descr": "Birth of Todd, Charles",
"gid": "E2271",
"media": [],
"part_family": [],
"part_person": [
1661
],
"place": 831,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1805-07-06",
"date_sdn": 2380509,
"descr": "Death of Todd, Charles",
"gid": "E2272",
"media": [],
"part_family": [],
"part_person": [
1661
],
"place": 1241,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1889-06-18",
"date_sdn": 2411172,
"descr": "Birth of Todd, Cora Olive",
"gid": "E1508",
"media": [],
"part_family": [],
"part_person": [
1662
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Todd, Cora Olive",
"gid": "E1509",
"media": [],
"part_family": [],
"part_person": [
1662
],
"place": 830,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Cora Olive",
"gid": "E1510",
"media": [],
"part_family": [],
"part_person": [
1662
],
"place": 1067,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1873-07-13",
"date_sdn": 2405353,
"descr": "Birth of Todd, Flora Belle",
"gid": "E1493",
"media": [],
"part_family": [],
"part_person": [
1663
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-02-18",
"date_sdn": 2433331,
"descr": "Death of Todd, Flora Belle",
"gid": "E1494",
"media": [],
"part_family": [],
"part_person": [
1663
],
"place": 411,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Flora Belle",
"gid": "E1495",
"media": [],
"part_family": [],
"part_person": [
1663
],
"place": 195,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1820-01-02",
"date_sdn": 2385802,
"descr": "Birth of Todd, George W.",
"gid": "E2381",
"media": [],
"part_family": [],
"part_person": [
1664
],
"place": 1206,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1895-02-16",
"date_sdn": 2413241,
"descr": "Death of Todd, George W.",
"gid": "E2382",
"media": [],
"part_family": [],
"part_person": [
1664
],
"place": 379,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, George W.",
"gid": "E2383",
"media": [],
"part_family": [],
"part_person": [
1664
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1879-03-03",
"date_sdn": 2407412,
"descr": "Birth of Todd, George Walter",
"gid": "E1498",
"media": [],
"part_family": [],
"part_person": [
1665
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-06-28",
"date_sdn": 2422138,
"descr": "Death of Todd, George Walter",
"gid": "E1499",
"media": [],
"part_family": [],
"part_person": [
1665
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1678",
"date_sdn": 2333938,
"descr": "Birth of Todd, Hardy",
"gid": "E2233",
"media": [],
"part_family": [],
"part_person": [
1666
],
"place": 54,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750",
"date_sdn": 2360235,
"descr": "Death of Todd, Hardy",
"gid": "E2234",
"media": [],
"part_family": [],
"part_person": [
1666
],
"place": 54,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1699",
"date_sdn": 2341608,
"descr": "Death of Todd, Hodges",
"gid": "E2203",
"media": [],
"part_family": [],
"part_person": [
1667
],
"place": 54,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1886-09-14",
"date_sdn": 2410164,
"descr": "Birth of Todd, Irene Frances",
"gid": "E1505",
"media": [],
"part_family": [],
"part_person": [
1668
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Todd, Irene Frances",
"gid": "E1506",
"media": [],
"part_family": [],
"part_person": [
1668
],
"place": 830,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Irene Frances",
"gid": "E1507",
"media": [],
"part_family": [],
"part_person": [
1668
],
"place": 1067,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1881-09-10",
"date_sdn": 2408334,
"descr": "Birth of Todd, Jesse Elmer",
"gid": "E1500",
"media": [],
"part_family": [],
"part_person": [
1669
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-12-12",
"date_sdn": 2436185,
"descr": "Death of Todd, Jesse Elmer",
"gid": "E1501",
"media": [],
"part_family": [],
"part_person": [
1669
],
"place": 1067,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1765-11-26",
"date_sdn": 2366043,
"descr": "Birth of Todd, John",
"gid": "E2297",
"media": [],
"part_family": [],
"part_person": [
1671
],
"place": 1064,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Todd, John",
"gid": "E2298",
"media": [],
"part_family": [],
"part_person": [
1671
],
"place": 213,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1851-06-07",
"date_sdn": 2397281,
"descr": "Birth of Todd, John M.",
"gid": "E2425",
"media": [],
"part_family": [],
"part_person": [
1672
],
"place": 379,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1921-02-23",
"date_sdn": 2422744,
"descr": "Death of Todd, John M.",
"gid": "E2426",
"media": [],
"part_family": [],
"part_person": [
1672
],
"place": 769,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1921-02-25",
"date_sdn": 2422746,
"descr": "Burial of Todd, John M.",
"gid": "E2427",
"media": [],
"part_family": [],
"part_person": [
1672
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1884-06-26",
"date_sdn": 2409354,
"descr": "Birth of Todd, Lena Viola",
"gid": "E1502",
"media": [],
"part_family": [],
"part_person": [
1673
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Todd, Lena Viola",
"gid": "E1503",
"media": [],
"part_family": [],
"part_person": [
1673
],
"place": 830,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Lena Viola",
"gid": "E1504",
"media": [],
"part_family": [],
"part_person": [
1673
],
"place": 1067,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1877-03-26",
"date_sdn": 2406705,
"descr": "Birth of Todd, Louella Jane",
"gid": "E1633",
"media": [],
"part_family": [],
"part_person": [
1674
],
"place": 428,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1965-01-26",
"date_sdn": 2438787,
"descr": "Death of Todd, Louella Jane",
"gid": "E1634",
"media": [],
"part_family": [],
"part_person": [
1674
],
"place": 1007,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1965-01-00",
"date_sdn": 2438762,
"descr": "Burial of Todd, Louella Jane",
"gid": "E1635",
"media": [],
"part_family": [],
"part_person": [
1674
],
"place": 120,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1905-09-05",
"date_sdn": 2417094,
"descr": "Birth of Todd, Lucille",
"gid": "E2152",
"media": [],
"part_family": [],
"part_person": [
1675
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1995-11-29",
"date_sdn": 2450051,
"descr": "Death of Todd, Lucille",
"gid": "E2153",
"media": [],
"part_family": [],
"part_person": [
1675
],
"place": 259,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1995-12-04",
"date_sdn": 2450056,
"descr": "Burial of Todd, Lucille",
"gid": "E2154",
"media": [],
"part_family": [],
"part_person": [
1675
],
"place": 214,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1894-09-09",
"date_sdn": 2413081,
"descr": "Birth of Todd, Percy Haye",
"gid": "E1514",
"media": [],
"part_family": [],
"part_person": [
1677
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-05-29",
"date_sdn": 2433431,
"descr": "Death of Todd, Percy Haye",
"gid": "E1515",
"media": [],
"part_family": [],
"part_person": [
1677
],
"place": 1067,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Percy Haye",
"gid": "E1516",
"media": [],
"part_family": [],
"part_person": [
1677
],
"place": 1067,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1874-11-19",
"date_sdn": 2405847,
"descr": "Birth of Todd, Robert Arthur",
"gid": "E1496",
"media": [],
"part_family": [],
"part_person": [
1678
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1940-12-20",
"date_sdn": 2429984,
"descr": "Death of Todd, Robert Arthur",
"gid": "E1497",
"media": [],
"part_family": [],
"part_person": [
1678
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Todd, Wayne",
"gid": "E2150",
"media": [],
"part_family": [],
"part_person": [
1679
],
"place": 570,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, Wayne",
"gid": "E2151",
"media": [],
"part_family": [],
"part_person": [
1679
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1790-10-01",
"date_sdn": 2375118,
"descr": "Birth of Todd, William",
"gid": "E2343",
"media": [],
"part_family": [],
"part_person": [
1680
],
"place": 550,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1846-07-08",
"date_sdn": 2395486,
"descr": "Death of Todd, William",
"gid": "E2344",
"media": [],
"part_family": [],
"part_person": [
1680
],
"place": 130,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Todd, William",
"gid": "E2345",
"media": [],
"part_family": [],
"part_person": [
1680
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1785",
"date_sdn": 2373019,
"descr": "Birth of Tyler, Mary A.",
"gid": "E2726",
"media": [],
"part_family": [],
"part_person": [
1684
],
"place": 753,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Tyler, Mary A.",
"gid": "E2727",
"media": [],
"part_family": [],
"part_person": [
1684
],
"place": 999,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Tyler, Mary A.",
"gid": "E2728",
"media": [],
"part_family": [],
"part_person": [
1684
],
"place": 999,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "about 1669",
"date_sdn": 2330651,
"descr": "Birth of Vaughn, Mary Meriwether",
"gid": "E0260",
"media": [],
"part_family": [],
"part_person": [
1687
],
"place": 1226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Vaughn, Mary Meriwether",
"gid": "E0261",
"media": [],
"part_family": [],
"part_person": [
1687
],
"place": 1226,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1963-09-17",
"date_sdn": 2438290,
"descr": "Birth of V\u00e1zquez, April Lynn",
"gid": "E2469",
"media": [],
"part_family": [],
"part_person": [
1688
],
"place": 0,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2470",
"media": [],
"part_family": [],
"part_person": [
1688
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1928-01-12",
"date_sdn": 2425258,
"descr": "Birth of Walker, Andrew Vincent",
"gid": "E0393",
"media": [],
"part_family": [],
"part_person": [
1691
],
"place": 952,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0394",
"media": [],
"part_family": [],
"part_person": [
1691
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1951-11-24",
"date_sdn": 2433975,
"descr": "Birth of Walker, Sharon Lynette",
"gid": "E0744",
"media": [],
"part_family": [],
"part_person": [
1693
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0745",
"media": [],
"part_family": [],
"part_person": [
1693
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Wallace, Abraham",
"gid": "E2149",
"media": [],
"part_family": [],
"part_person": [
1694
],
"place": 203,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1955-01-06",
"date_sdn": 2435114,
"descr": "Birth of Walsh, Penelope",
"gid": "E2438",
"media": [],
"part_family": [],
"part_person": [
1695
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2439",
"media": [],
"part_family": [],
"part_person": [
1695
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1864",
"date_sdn": 2401872,
"descr": "Birth of Walters, Mary",
"gid": "E2473",
"media": [],
"part_family": [],
"part_person": [
1697
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1937-04-06",
"date_sdn": 2428630,
"descr": "Death of Walters, Mary",
"gid": "E2474",
"media": [],
"part_family": [],
"part_person": [
1697
],
"place": 44,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1937-04-08",
"date_sdn": 2428632,
"descr": "Burial of Walters, Mary",
"gid": "E2475",
"media": [],
"part_family": [],
"part_person": [
1697
],
"place": 728,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1250",
"date_sdn": 2177614,
"descr": "Birth of Walton, Theophania(Tiffany)",
"gid": "E0045",
"media": [],
"part_family": [],
"part_person": [
1698
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1980-09-28",
"date_sdn": 2444511,
"descr": "Birth of Ward, Catherine Marie",
"gid": "E1397",
"media": [],
"part_family": [],
"part_person": [
1699
],
"place": 28,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1398",
"media": [],
"part_family": [],
"part_person": [
1699
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1944-12-31",
"date_sdn": 2431456,
"descr": "Birth of Ward, David J.",
"gid": "E1393",
"media": [],
"part_family": [],
"part_person": [
1700
],
"place": 407,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1394",
"media": [],
"part_family": [],
"part_person": [
1700
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1978-08-24",
"date_sdn": 2443745,
"descr": "Birth of Ward, Michael David",
"gid": "E1395",
"media": [],
"part_family": [],
"part_person": [
1701
],
"place": 28,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1396",
"media": [],
"part_family": [],
"part_person": [
1701
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1952-02-01",
"date_sdn": 2434044,
"descr": "Birth of Warner, Allen Carl",
"gid": "E1795",
"media": [],
"part_family": [],
"part_person": [
1703
],
"place": 1273,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1796",
"media": [],
"part_family": [],
"part_person": [
1703
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1985-05-27",
"date_sdn": 2446213,
"descr": "Birth of Warner, Amber Lynne",
"gid": "E1457",
"media": [],
"part_family": [],
"part_person": [
1705
],
"place": 114,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1458",
"media": [],
"part_family": [],
"part_person": [
1705
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1969-04-21",
"date_sdn": 2440333,
"descr": "Birth of Warner, Andrea Susan",
"gid": "E1346",
"media": [],
"part_family": [],
"part_person": [
1706
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1347",
"media": [],
"part_family": [],
"part_person": [
1706
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1740-08-15",
"date_sdn": 2356809,
"descr": "Birth of Warner, Andrew",
"gid": "E1819",
"media": [],
"part_family": [],
"part_person": [
1707
],
"place": 802,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1827-10-14",
"date_sdn": 2388644,
"descr": "Death of Warner, Andrew",
"gid": "E1820",
"media": [],
"part_family": [],
"part_person": [
1707
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1954-01-24",
"date_sdn": 2434767,
"descr": "Birth of Warner, Arthur Maurice",
"gid": "E0304",
"media": [],
"part_family": [],
"part_person": [
1708
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0305",
"media": [],
"part_family": [],
"part_person": [
1708
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1974-07-14",
"date_sdn": 2442243,
"descr": "Birth of Warner, Belle Marie",
"gid": "E1365",
"media": [],
"part_family": [],
"part_person": [
1709
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1366",
"media": [],
"part_family": [],
"part_person": [
1709
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1940-01-16",
"date_sdn": 2429645,
"descr": "Birth of Warner, Betty Louise",
"gid": "E0644",
"media": [],
"part_family": [],
"part_person": [
1710
],
"place": 102,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0645",
"media": [],
"part_family": [],
"part_person": [
1710
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1947-08-19",
"date_sdn": 2432417,
"descr": "Birth of Warner, Beverly Ann",
"gid": "E0663",
"media": [],
"part_family": [],
"part_person": [
1711
],
"place": 102,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0664",
"media": [],
"part_family": [],
"part_person": [
1711
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1684-01-20",
"date_sdn": 2336148,
"descr": "Birth of Warner, Capt. Andrew",
"gid": "E1808",
"media": [],
"part_family": [],
"part_person": [
1712
],
"place": 408,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-01-11",
"date_sdn": 2361706,
"descr": "Death of Warner, Capt. Andrew",
"gid": "E1809",
"media": [],
"part_family": [],
"part_person": [
1712
],
"place": 617,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Capt. Andrew",
"gid": "E1810",
"media": [],
"part_family": [],
"part_person": [
1712
],
"place": 1231,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1618",
"date_sdn": 2312023,
"descr": "Birth of Warner, Capt. Francis",
"gid": "E2211",
"media": [],
"part_family": [],
"part_person": [
1713
],
"place": 1130,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1687-09-24",
"date_sdn": 2337491,
"descr": "Death of Warner, Capt. Francis",
"gid": "E2212",
"media": [],
"part_family": [],
"part_person": [
1713
],
"place": 1197,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1650",
"date_sdn": 2323711,
"descr": "Birth of Warner, Capt. George",
"gid": "E1803",
"media": [],
"part_family": [],
"part_person": [
1714
],
"place": 201,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1710-11-08",
"date_sdn": 2345936,
"descr": "Death of Warner, Capt. George",
"gid": "E1804",
"media": [],
"part_family": [],
"part_person": [
1714
],
"place": 1102,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Capt. George",
"gid": "E1805",
"media": [],
"part_family": [],
"part_person": [
1714
],
"place": 173,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1981-05-11",
"date_sdn": 2444736,
"descr": "Birth of Warner, Carl Thomas",
"gid": "E1378",
"media": [],
"part_family": [],
"part_person": [
1715
],
"place": 424,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1379",
"media": [],
"part_family": [],
"part_person": [
1715
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1982-10-04",
"date_sdn": 2445247,
"descr": "Birth of Warner, Christopher Arthur",
"gid": "E0170",
"media": [],
"part_family": [],
"part_person": [
1717
],
"place": 393,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0171",
"media": [],
"part_family": [],
"part_person": [
1717
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-04-12",
"date_sdn": 2444707,
"descr": "Birth of Warner, Cindy Lynn",
"gid": "E1438",
"media": [],
"part_family": [],
"part_person": [
1718
],
"place": 31,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1439",
"media": [],
"part_family": [],
"part_person": [
1718
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1422",
"media": [],
"part_family": [],
"part_person": [
1719
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1976-08-26",
"date_sdn": 2443017,
"descr": "Birth of Warner, Curtis Andrew",
"gid": "E1367",
"media": [],
"part_family": [],
"part_person": [
1720
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1994-12-18",
"date_sdn": 2449705,
"descr": "Death of Warner, Curtis Andrew",
"gid": "E1368",
"media": [],
"part_family": [],
"part_person": [
1720
],
"place": 997,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1994-12-22",
"date_sdn": 2449709,
"descr": "Burial of Warner, Curtis Andrew",
"gid": "E1369",
"media": [],
"part_family": [],
"part_person": [
1720
],
"place": 810,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1682-12-05",
"date_sdn": 2335737,
"descr": "Birth of Warner, Daniel",
"gid": "E1066",
"media": [],
"part_family": [],
"part_person": [
1721
],
"place": 1256,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1992-12-29",
"date_sdn": 2448986,
"descr": "Birth of Warner, Daniel Arthur",
"gid": "E2551",
"media": [],
"part_family": [],
"part_person": [
1722
],
"place": 393,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2552",
"media": [],
"part_family": [],
"part_person": [
1722
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1960-05-01",
"date_sdn": 2437056,
"descr": "Birth of Warner, Darin Kane",
"gid": "E1340",
"media": [],
"part_family": [],
"part_person": [
1723
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1341",
"media": [],
"part_family": [],
"part_person": [
1723
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1921-05-19",
"date_sdn": 2422829,
"descr": "Birth of Warner, David Luther",
"gid": "E0351",
"media": [],
"part_family": [],
"part_person": [
1725
],
"place": 952,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0352",
"media": [],
"part_family": [],
"part_person": [
1725
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1945-02-13",
"date_sdn": 2431500,
"descr": "Birth of Warner, David Warren",
"gid": "E0671",
"media": [],
"part_family": [],
"part_person": [
1726
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0672",
"media": [],
"part_family": [],
"part_person": [
1726
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-03-20",
"date_sdn": 2441762,
"descr": "Birth of Warner, Deirdra Denise",
"gid": "E1348",
"media": [],
"part_family": [],
"part_person": [
1727
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1349",
"media": [],
"part_family": [],
"part_person": [
1727
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1922-08-22",
"date_sdn": 2423289,
"descr": "Birth of Warner, Donald Louis",
"gid": "E0360",
"media": [],
"part_family": [],
"part_person": [
1728
],
"place": 952,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-08-09",
"date_sdn": 2444095,
"descr": "Death of Warner, Donald Louis",
"gid": "E0361",
"media": [],
"part_family": [],
"part_person": [
1728
],
"place": 904,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1978-12-11",
"date_sdn": 2443854,
"descr": "Birth of Warner, Douglas Lowell",
"gid": "E1370",
"media": [],
"part_family": [],
"part_person": [
1730
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1371",
"media": [],
"part_family": [],
"part_person": [
1730
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1713-01-06",
"date_sdn": 2346726,
"descr": "Birth of Warner, Edward",
"gid": "E1814",
"media": [],
"part_family": [],
"part_person": [
1732
],
"place": 37,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1776-09-27",
"date_sdn": 2370001,
"descr": "Death of Warner, Edward",
"gid": "E1815",
"media": [],
"part_family": [],
"part_person": [
1732
],
"place": 1196,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Edward",
"gid": "E1816",
"media": [],
"part_family": [],
"part_person": [
1732
],
"place": 445,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Warner, Elizabeth",
"gid": "E2175",
"media": [],
"part_family": [],
"part_person": [
1736
],
"place": 589,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1683-03-28",
"date_sdn": 2335850,
"descr": "Birth of Warner, Elizabeth",
"gid": "E1071",
"media": [],
"part_family": [],
"part_person": [
1737
],
"place": 427,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1956-11-27",
"date_sdn": 2435805,
"descr": "Birth of Warner, Fred Loren",
"gid": "E0379",
"media": [],
"part_family": [],
"part_person": [
1740
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0380",
"media": [],
"part_family": [],
"part_person": [
1740
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1678-08-04",
"date_sdn": 2334153,
"descr": "Birth of Warner, George",
"gid": "E1061",
"media": [],
"part_family": [],
"part_person": [
1741
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1679",
"date_sdn": 2334303,
"descr": "Death of Warner, George",
"gid": "E1062",
"media": [],
"part_family": [],
"part_person": [
1741
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1709-07-21",
"date_sdn": 2345461,
"descr": "Birth of Warner, George",
"gid": "E1073",
"media": [],
"part_family": [],
"part_person": [
1742
],
"place": 427,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1926-11-01",
"date_sdn": 2424821,
"descr": "Birth of Warner, George Edward",
"gid": "E2155",
"media": [],
"part_family": [],
"part_person": [
1744
],
"place": 254,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2156",
"media": [],
"part_family": [],
"part_person": [
1744
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1681-09-03",
"date_sdn": 2335279,
"descr": "Birth of Warner, Hannah",
"gid": "E1065",
"media": [],
"part_family": [],
"part_person": [
1746
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1946-12-21",
"date_sdn": 2432176,
"descr": "Birth of Warner, Harold Lowell",
"gid": "E0673",
"media": [],
"part_family": [],
"part_person": [
1747
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0674",
"media": [],
"part_family": [],
"part_person": [
1747
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1979-05-17",
"date_sdn": 2444011,
"descr": "Birth of Warner, James Andrew",
"gid": "E1436",
"media": [],
"part_family": [],
"part_person": [
1749
],
"place": 31,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1437",
"media": [],
"part_family": [],
"part_person": [
1749
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1984-05-03",
"date_sdn": 2445824,
"descr": "Birth of Warner, James Jeffrey",
"gid": "E1125",
"media": [],
"part_family": [],
"part_person": [
1750
],
"place": 424,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1126",
"media": [],
"part_family": [],
"part_person": [
1750
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1992-10-30",
"date_sdn": 2448926,
"descr": "Birth of Warner, Jeffrey George",
"gid": "E2464",
"media": [],
"part_family": [],
"part_person": [
1751
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2465",
"media": [],
"part_family": [],
"part_person": [
1751
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-02-06",
"date_sdn": 2441720,
"descr": "Birth of Warner, JenniferMae(Ganoe)",
"gid": "E0142",
"media": [],
"part_family": [],
"part_person": [
1752
],
"place": 222,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0143",
"media": [],
"part_family": [],
"part_person": [
1752
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1979-05-04",
"date_sdn": 2443998,
"descr": "Birth of Warner, John Allen",
"gid": "E1573",
"media": [],
"part_family": [],
"part_person": [
1757
],
"place": 842,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1574",
"media": [],
"part_family": [],
"part_person": [
1757
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1944-08-11",
"date_sdn": 2431314,
"descr": "Birth of Warner, John William",
"gid": "E0661",
"media": [],
"part_family": [],
"part_person": [
1759
],
"place": 102,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0662",
"media": [],
"part_family": [],
"part_person": [
1759
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "about 1689",
"date_sdn": 2337956,
"descr": "Birth of Warner, Johnathon",
"gid": "E1076",
"media": [],
"part_family": [],
"part_person": [
1761
],
"place": 427,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1754-07-00",
"date_sdn": 2361877,
"descr": "Death of Warner, Johnathon",
"gid": "E1077",
"media": [],
"part_family": [],
"part_person": [
1761
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1892-09-25",
"date_sdn": 2412367,
"descr": "Birth of Warner, Julia Angeline",
"gid": "E0480",
"media": [],
"part_family": [],
"part_person": [
1762
],
"place": 839,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1970-12-17",
"date_sdn": 2440938,
"descr": "Death of Warner, Julia Angeline",
"gid": "E0481",
"media": [],
"part_family": [],
"part_person": [
1762
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Julia Angeline",
"gid": "E0482",
"media": [],
"part_family": [],
"part_person": [
1762
],
"place": 787,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1952-09-27",
"date_sdn": 2434283,
"descr": "Birth of Warner, Laura Gail",
"gid": "E1383",
"media": [],
"part_family": [],
"part_person": [
1763
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1384",
"media": [],
"part_family": [],
"part_person": [
1763
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1958-09-20",
"date_sdn": 2436467,
"descr": "Birth of Warner, Marcia Jane",
"gid": "E0538",
"media": [],
"part_family": [],
"part_person": [
1766
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0539",
"media": [],
"part_family": [],
"part_person": [
1766
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1949-07-13",
"date_sdn": 2433111,
"descr": "Birth of Warner, Margaret Ruth",
"gid": "E0692",
"media": [],
"part_family": [],
"part_person": [
1767
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0693",
"media": [],
"part_family": [],
"part_person": [
1767
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-02-07",
"date_sdn": 2433320,
"descr": "Birth of Warner, Martha Ellen",
"gid": "E0681",
"media": [],
"part_family": [],
"part_person": [
1768
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0682",
"media": [],
"part_family": [],
"part_person": [
1768
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1985-07-22",
"date_sdn": 2446269,
"descr": "Birth of Warner, Martin B.",
"gid": "E1420",
"media": [],
"part_family": [],
"part_person": [
1769
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1421",
"media": [],
"part_family": [],
"part_person": [
1769
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1889-08-11",
"date_sdn": 2411226,
"descr": "Birth of Warner, Martin Bogarte",
"gid": "E1127",
"media": [],
"part_family": [],
"part_person": [
1770
],
"place": 911,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1961-08-12",
"date_sdn": 2437524,
"descr": "Death of Warner, Martin Bogarte",
"gid": "E1128",
"media": [],
"part_family": [],
"part_person": [
1770
],
"place": 154,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1961-08-14",
"date_sdn": 2437526,
"descr": "Burial of Warner, Martin Bogarte",
"gid": "E1129",
"media": [],
"part_family": [],
"part_person": [
1770
],
"place": 494,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1679-01-02",
"date_sdn": 2334304,
"descr": "Birth of Warner, Mary",
"gid": "E1063",
"media": [],
"part_family": [],
"part_person": [
1771
],
"place": 143,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1954-11-10",
"date_sdn": 2435057,
"descr": "Birth of Warner, Mary Christine",
"gid": "E0698",
"media": [],
"part_family": [],
"part_person": [
1773
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0699",
"media": [],
"part_family": [],
"part_person": [
1773
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1906-09-05",
"date_sdn": 2417459,
"descr": "Birth of Warner, Mary Grace Elizabeth",
"gid": "E0495",
"media": [],
"part_family": [],
"part_person": [
1774
],
"place": 184,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1993-06-06",
"date_sdn": 2449145,
"descr": "Death of Warner, Mary Grace Elizabeth",
"gid": "E0496",
"media": [],
"part_family": [],
"part_person": [
1774
],
"place": 1055,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1993-06-08",
"date_sdn": 2449147,
"descr": "Burial of Warner, Mary Grace Elizabeth",
"gid": "E0497",
"media": [],
"part_family": [],
"part_person": [
1774
],
"place": 1239,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1977-06-23",
"date_sdn": 2443318,
"descr": "Birth of Warner, Matthew Steven",
"gid": "E2529",
"media": [],
"part_family": [],
"part_person": [
1775
],
"place": 842,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2530",
"media": [],
"part_family": [],
"part_person": [
1775
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1987-06-13",
"date_sdn": 2446960,
"descr": "Birth of Warner, Melissa Lee",
"gid": "E0224",
"media": [],
"part_family": [],
"part_person": [
1776
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0225",
"media": [],
"part_family": [],
"part_person": [
1776
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1958-06-10",
"date_sdn": 2436365,
"descr": "Birth of Warner, Michael Douglas",
"gid": "E1333",
"media": [],
"part_family": [],
"part_person": [
1777
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1334",
"media": [],
"part_family": [],
"part_person": [
1777
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1985-02-26",
"date_sdn": 2446123,
"descr": "Birth of Warner, Michael Edward",
"gid": "E0187",
"media": [],
"part_family": [],
"part_person": [
1778
],
"place": 393,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0188",
"media": [],
"part_family": [],
"part_person": [
1778
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1936-12-22",
"date_sdn": 2428525,
"descr": "Birth of Warner, Michael Louis",
"gid": "E0636",
"media": [],
"part_family": [],
"part_person": [
1779
],
"place": 102,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0637",
"media": [],
"part_family": [],
"part_person": [
1779
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1913-10-29",
"date_sdn": 2420070,
"descr": "Birth of Warner, Michael Warren",
"gid": "E0349",
"media": [],
"part_family": [],
"part_person": [
1780
],
"place": 623,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1983-01-18",
"date_sdn": 2445353,
"descr": "Death of Warner, Michael Warren",
"gid": "E0350",
"media": [],
"part_family": [],
"part_person": [
1780
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1962-11-19",
"date_sdn": 2437988,
"descr": "Birth of Warner, Michelle Lorraine",
"gid": "E1338",
"media": [],
"part_family": [],
"part_person": [
1781
],
"place": 544,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1339",
"media": [],
"part_family": [],
"part_person": [
1781
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1990-10-20",
"date_sdn": 2448185,
"descr": "Birth of Warner, Monica Jane",
"gid": "E1759",
"media": [],
"part_family": [],
"part_person": [
1782
],
"place": 906,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1760",
"media": [],
"part_family": [],
"part_person": [
1782
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1951-10-20",
"date_sdn": 2433940,
"descr": "Birth of Warner, Nancy Elizabeth",
"gid": "E0694",
"media": [],
"part_family": [],
"part_person": [
1783
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0695",
"media": [],
"part_family": [],
"part_person": [
1783
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1996-09-19",
"date_sdn": 2450346,
"descr": "Birth of Warner, Nicole Lynn",
"gid": "E0156",
"media": [],
"part_family": [],
"part_person": [
1785
],
"place": 1237,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0157",
"media": [],
"part_family": [],
"part_person": [
1785
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1779-09-24",
"date_sdn": 2371093,
"descr": "Birth of Warner, Noah",
"gid": "E1255",
"media": [],
"part_family": [],
"part_person": [
1786
],
"place": 802,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1844-06-14",
"date_sdn": 2394732,
"descr": "Death of Warner, Noah",
"gid": "E1256",
"media": [],
"part_family": [],
"part_person": [
1786
],
"place": 616,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1844",
"date_sdn": 2394567,
"descr": "Burial of Warner, Noah",
"gid": "E1257",
"media": [],
"part_family": [],
"part_person": [
1786
],
"place": 592,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1998-06-30",
"date_sdn": 2450995,
"descr": "Birth of Warner, Noah Stuart",
"gid": "E0904",
"media": [],
"part_family": [],
"part_person": [
1787
],
"place": 107,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0905",
"media": [],
"part_family": [],
"part_person": [
1787
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1821-04-09",
"date_sdn": 2386265,
"descr": "Birth of Warner, Piatt D.",
"gid": "E1403",
"media": [],
"part_family": [],
"part_person": [
1788
],
"place": 811,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1889-10-11",
"date_sdn": 2411287,
"descr": "Death of Warner, Piatt D.",
"gid": "E1404",
"media": [],
"part_family": [],
"part_person": [
1788
],
"place": 51,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1889",
"date_sdn": 2411004,
"descr": "Burial of Warner, Piatt D.",
"gid": "E1405",
"media": [],
"part_family": [],
"part_person": [
1788
],
"place": 398,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Warner, Rev. Edmund",
"gid": "E2418",
"media": [],
"part_family": [],
"part_person": [
1790
],
"place": 327,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Warner, Rev. Edmund",
"gid": "E2419",
"media": [],
"part_family": [],
"part_person": [
1790
],
"place": 829,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1925-01-17",
"date_sdn": 2424168,
"descr": "Birth of Warner, Richard Kenneth",
"gid": "E0381",
"media": [],
"part_family": [],
"part_person": [
1791
],
"place": 952,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0382",
"media": [],
"part_family": [],
"part_person": [
1791
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1962-09-07",
"date_sdn": 2437915,
"descr": "Birth of Warner, Robert Douglas",
"gid": "E0765",
"media": [],
"part_family": [],
"part_person": [
1793
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0766",
"media": [],
"part_family": [],
"part_person": [
1793
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1923-10-08",
"date_sdn": 2423701,
"descr": "Birth of Warner, Robert Eugene",
"gid": "E0370",
"media": [],
"part_family": [],
"part_person": [
1794
],
"place": 952,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0371",
"media": [],
"part_family": [],
"part_person": [
1794
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1977-04-16",
"date_sdn": 2443250,
"descr": "Birth of Warner, Robert Warren",
"gid": "E1361",
"media": [],
"part_family": [],
"part_person": [
1795
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1362",
"media": [],
"part_family": [],
"part_person": [
1795
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1953-09-23",
"date_sdn": 2434644,
"descr": "Birth of Warner, Sarah Jane",
"gid": "E0696",
"media": [],
"part_family": [],
"part_person": [
1797
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0697",
"media": [],
"part_family": [],
"part_person": [
1797
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1987-08-29",
"date_sdn": 2447037,
"descr": "Birth of Warner, Sarah Suzanne",
"gid": "E0000",
"media": [],
"part_family": [],
"part_person": [
1799
],
"place": 424,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0001",
"media": [],
"part_family": [],
"part_person": [
1799
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1972-10-10",
"date_sdn": 2441601,
"descr": "Birth of Warner, Sheryl Ann",
"gid": "E1359",
"media": [],
"part_family": [],
"part_person": [
1800
],
"place": 1008,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1360",
"media": [],
"part_family": [],
"part_person": [
1800
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1957-10-14",
"date_sdn": 2436126,
"descr": "Birth of Warner, Shirley Kay",
"gid": "E0758",
"media": [],
"part_family": [],
"part_person": [
1801
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0759",
"media": [],
"part_family": [],
"part_person": [
1801
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1543",
"date_sdn": 2284629,
"descr": "Birth of Warner, Sir Francis",
"gid": "E2420",
"media": [],
"part_family": [],
"part_person": [
1802
],
"place": 1160,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1596-01-28",
"date_sdn": 2304014,
"descr": "Death of Warner, Sir Francis",
"gid": "E2421",
"media": [],
"part_family": [],
"part_person": [
1802
],
"place": 654,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1596-01-28",
"date_sdn": 2304014,
"descr": "Burial of Warner, Sir Francis",
"gid": "E2422",
"media": [],
"part_family": [],
"part_person": [
1802
],
"place": 654,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1963-06-17",
"date_sdn": 2438198,
"descr": "Birth of Warner, Stanley Louis",
"gid": "E0730",
"media": [],
"part_family": [],
"part_person": [
1803
],
"place": 1103,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0731",
"media": [],
"part_family": [],
"part_person": [
1803
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-06-23",
"date_sdn": 2433456,
"descr": "Birth of Warner, Stephanie Sue",
"gid": "E0708",
"media": [],
"part_family": [],
"part_person": [
1804
],
"place": 571,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0709",
"media": [],
"part_family": [],
"part_person": [
1804
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1951-11-04",
"date_sdn": 2433955,
"descr": "Birth of Warner, Stephen Paul",
"gid": "E0718",
"media": [],
"part_family": [],
"part_person": [
1805
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0719",
"media": [],
"part_family": [],
"part_person": [
1805
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1955-12-09",
"date_sdn": 2435451,
"descr": "Birth of Warner, Stuart Bogarte",
"gid": "E0723",
"media": [],
"part_family": [],
"part_person": [
1806
],
"place": 132,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0724",
"media": [],
"part_family": [],
"part_person": [
1806
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1556",
"date_sdn": 2289377,
"descr": "Birth of Warner, Thomas",
"gid": "E2417",
"media": [],
"part_family": [],
"part_person": [
1808
],
"place": 856,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1954-11-25",
"date_sdn": 2435072,
"descr": "Birth of Warner, Thomas Frederick",
"gid": "E0752",
"media": [],
"part_family": [],
"part_person": [
1809
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0753",
"media": [],
"part_family": [],
"part_person": [
1809
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1865",
"date_sdn": 2402238,
"descr": "Birth of Warner, unnamed girl",
"gid": "E0347",
"media": [],
"part_family": [],
"part_person": [
1810
],
"place": 904,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Warner, unnamed girl",
"gid": "E0348",
"media": [],
"part_family": [],
"part_person": [
1810
],
"place": 904,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1867-01-23",
"date_sdn": 2402990,
"descr": "Birth of Warner, Warren W.",
"gid": "E1210",
"media": [],
"part_family": [],
"part_person": [
1811
],
"place": 326,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1919-03-10",
"date_sdn": 2422028,
"descr": "Death of Warner, Warren W.",
"gid": "E1211",
"media": [],
"part_family": [],
"part_person": [
1811
],
"place": 598,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Warner, Warren W.",
"gid": "E1212",
"media": [],
"part_family": [],
"part_person": [
1811
],
"place": 494,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1986-08-26",
"date_sdn": 2446669,
"descr": "Birth of Warner, Whitney Lianne",
"gid": "E2699",
"media": [],
"part_family": [],
"part_person": [
1812
],
"place": 114,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2700",
"media": [],
"part_family": [],
"part_person": [
1812
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, Cecil",
"gid": "E0600",
"media": [],
"part_family": [],
"part_person": [
1817
],
"place": 481,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Waters, Cecil",
"gid": "E0601",
"media": [],
"part_family": [],
"part_person": [
1817
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1940",
"date_sdn": 2429630,
"descr": "Birth of Waters, Cecil Glenn",
"gid": "E0602",
"media": [],
"part_family": [],
"part_person": [
1818
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0603",
"media": [],
"part_family": [],
"part_person": [
1818
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0606",
"media": [],
"part_family": [],
"part_person": [
1819
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, Edith",
"gid": "E0760",
"media": [],
"part_family": [],
"part_person": [
1820
],
"place": 748,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, Everett",
"gid": "E0764",
"media": [],
"part_family": [],
"part_person": [
1821
],
"place": 748,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, Lola",
"gid": "E0762",
"media": [],
"part_family": [],
"part_person": [
1823
],
"place": 748,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, Nellie",
"gid": "E0761",
"media": [],
"part_family": [],
"part_person": [
1824
],
"place": 748,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0605",
"media": [],
"part_family": [],
"part_person": [
1825
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Waters, William",
"gid": "E0763",
"media": [],
"part_family": [],
"part_person": [
1826
],
"place": 748,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1871-08-24",
"date_sdn": 2404664,
"descr": "Birth of Waters, William",
"gid": "E0504",
"media": [],
"part_family": [],
"part_person": [
1827
],
"place": 1228,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-07-12",
"date_sdn": 2429092,
"descr": "Death of Waters, William",
"gid": "E0505",
"media": [],
"part_family": [],
"part_person": [
1827
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1938-07-14",
"date_sdn": 2429094,
"descr": "Burial of Waters, William",
"gid": "E0506",
"media": [],
"part_family": [],
"part_person": [
1827
],
"place": 939,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1950-12-12",
"date_sdn": 2433628,
"descr": "Birth of Watkins, Bruce Edward",
"gid": "E1414",
"media": [],
"part_family": [],
"part_person": [
1828
],
"place": 86,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1415",
"media": [],
"part_family": [],
"part_person": [
1828
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1980-09-26",
"date_sdn": 2444509,
"descr": "Birth of Watkins, Laura Kathryn",
"gid": "E1416",
"media": [],
"part_family": [],
"part_person": [
1829
],
"place": 613,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1417",
"media": [],
"part_family": [],
"part_person": [
1829
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-05-09",
"date_sdn": 2432681,
"descr": "Birth of Watson, Alvin E.",
"gid": "E1350",
"media": [],
"part_family": [],
"part_person": [
1830
],
"place": 975,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1351",
"media": [],
"part_family": [],
"part_person": [
1830
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1983-06-16",
"date_sdn": 2445502,
"descr": "Birth of Watson, Mary Grace",
"gid": "E1352",
"media": [],
"part_family": [],
"part_person": [
1831
],
"place": 1036,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1353",
"media": [],
"part_family": [],
"part_person": [
1831
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1995-06-07",
"date_sdn": 2449876,
"descr": "Birth of Weaver, Justin Matthew",
"gid": "E0138",
"media": [],
"part_family": [],
"part_person": [
1833
],
"place": 422,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0139",
"media": [],
"part_family": [],
"part_person": [
1833
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Weaver, Steven Matthew",
"gid": "E0137",
"media": [],
"part_family": [],
"part_person": [
1834
],
"place": 556,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1821",
"date_sdn": 2386167,
"descr": "Birth of Webb, Alexander",
"gid": "E2729",
"media": [],
"part_family": [],
"part_person": [
1836
],
"place": 882,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1854-02-02",
"date_sdn": 2398252,
"descr": "Death of Webb, Alexander",
"gid": "E2730",
"media": [],
"part_family": [],
"part_person": [
1836
],
"place": 555,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1854-02-00",
"date_sdn": 2398251,
"descr": "Burial of Webb, Alexander",
"gid": "E2731",
"media": [],
"part_family": [],
"part_person": [
1836
],
"place": 405,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Birth of Webb, Andrew",
"gid": "E2718",
"media": [],
"part_family": [],
"part_person": [
1837
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1850",
"date_sdn": 2396759,
"descr": "Death of Webb, Andrew",
"gid": "E2719",
"media": [],
"part_family": [],
"part_person": [
1837
],
"place": 999,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Webb, Andrew",
"gid": "E2720",
"media": [],
"part_family": [],
"part_person": [
1837
],
"place": 355,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1890-10-02",
"date_sdn": 2411643,
"descr": "Birth of Webb, Anna Mabel",
"gid": "E0814",
"media": [],
"part_family": [],
"part_person": [
1838
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1967-07-12",
"date_sdn": 2439684,
"descr": "Death of Webb, Anna Mabel",
"gid": "E0815",
"media": [],
"part_family": [],
"part_person": [
1838
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1901-09-23",
"date_sdn": 2415651,
"descr": "Birth of Webb, Charles Edward",
"gid": "E0338",
"media": [],
"part_family": [],
"part_person": [
1839
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1834",
"date_sdn": 2390915,
"descr": "Birth of Webb, Charles Leroy Boyd",
"gid": "E0326",
"media": [],
"part_family": [],
"part_person": [
1840
],
"place": 996,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1878-04-15",
"date_sdn": 2407090,
"descr": "Birth of Webb, Clarence",
"gid": "E2309",
"media": [],
"part_family": [],
"part_person": [
1841
],
"place": 152,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1953-12-24",
"date_sdn": 2434736,
"descr": "Death of Webb, Clarence",
"gid": "E2310",
"media": [],
"part_family": [],
"part_person": [
1841
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1953-12-26",
"date_sdn": 2434738,
"descr": "Burial of Webb, Clarence",
"gid": "E2311",
"media": [],
"part_family": [],
"part_person": [
1841
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1883-02-22",
"date_sdn": 2408864,
"descr": "Birth of Webb, David Festus",
"gid": "E0804",
"media": [],
"part_family": [],
"part_person": [
1842
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1950-08-23",
"date_sdn": 2433517,
"descr": "Death of Webb, David Festus",
"gid": "E0805",
"media": [],
"part_family": [],
"part_person": [
1842
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1884-11-17",
"date_sdn": 2409498,
"descr": "Birth of Webb, Ernest Arlington",
"gid": "E0801",
"media": [],
"part_family": [],
"part_person": [
1844
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-10-07",
"date_sdn": 2436119,
"descr": "Death of Webb, Ernest Arlington",
"gid": "E0802",
"media": [],
"part_family": [],
"part_person": [
1844
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1899-02-04",
"date_sdn": 2414690,
"descr": "Birth of Webb, Frances Mae",
"gid": "E0820",
"media": [],
"part_family": [],
"part_person": [
1845
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1989-05-05",
"date_sdn": 2447652,
"descr": "Death of Webb, Frances Mae",
"gid": "E0821",
"media": [],
"part_family": [],
"part_person": [
1845
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1869-04-28",
"date_sdn": 2403816,
"descr": "Birth of Webb, Francis Irvin",
"gid": "E1610",
"media": [],
"part_family": [],
"part_person": [
1846
],
"place": 985,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1957-02-07",
"date_sdn": 2435877,
"descr": "Death of Webb, Francis Irvin",
"gid": "E1611",
"media": [],
"part_family": [],
"part_person": [
1846
],
"place": 442,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1957-02-00",
"date_sdn": 2435871,
"descr": "Burial of Webb, Francis Irvin",
"gid": "E1612",
"media": [],
"part_family": [],
"part_person": [
1846
],
"place": 120,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1895-11-10",
"date_sdn": 2413508,
"descr": "Birth of Webb, Harry Noble",
"gid": "E0818",
"media": [],
"part_family": [],
"part_person": [
1847
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1925-12-07",
"date_sdn": 2424492,
"descr": "Death of Webb, Harry Noble",
"gid": "E0819",
"media": [],
"part_family": [],
"part_person": [
1847
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, James",
"gid": "E0803",
"media": [],
"part_family": [],
"part_person": [
1849
],
"place": 979,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1939-04-23",
"date_sdn": 2429377,
"descr": "Birth of Webb, James Lee",
"gid": "E1539",
"media": [],
"part_family": [],
"part_person": [
1850
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1994-09-23",
"date_sdn": 2449619,
"descr": "Death of Webb, James Lee",
"gid": "E1540",
"media": [],
"part_family": [],
"part_person": [
1850
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1994-09-27",
"date_sdn": 2449623,
"descr": "Burial of Webb, James Lee",
"gid": "E1541",
"media": [],
"part_family": [],
"part_person": [
1850
],
"place": 893,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1886-11-09",
"date_sdn": 2410220,
"descr": "Birth of Webb, James Leslie",
"gid": "E0806",
"media": [],
"part_family": [],
"part_person": [
1851
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1963-01-25",
"date_sdn": 2438055,
"descr": "Death of Webb, James Leslie",
"gid": "E0807",
"media": [],
"part_family": [],
"part_person": [
1851
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1856-12-04",
"date_sdn": 2399288,
"descr": "Birth of Webb, James Marshall",
"gid": "E0333",
"media": [],
"part_family": [],
"part_person": [
1852
],
"place": 338,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1938-08-04",
"date_sdn": 2429115,
"descr": "Death of Webb, James Marshall",
"gid": "E0334",
"media": [],
"part_family": [],
"part_person": [
1852
],
"place": 966,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1938-08-06",
"date_sdn": 2429117,
"descr": "Burial of Webb, James Marshall",
"gid": "E0335",
"media": [],
"part_family": [],
"part_person": [
1852
],
"place": 1046,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, James McPheeters",
"gid": "E0328",
"media": [],
"part_family": [],
"part_person": [
1853
],
"place": 1037,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1946-10-29",
"date_sdn": 2432123,
"descr": "Birth of Webb, Joan Lorinda",
"gid": "E1530",
"media": [],
"part_family": [],
"part_person": [
1854
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1531",
"media": [],
"part_family": [],
"part_person": [
1854
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1837",
"date_sdn": 2392011,
"descr": "Birth of Webb, John McCrea",
"gid": "E0327",
"media": [],
"part_family": [],
"part_person": [
1856
],
"place": 292,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1908-12-15",
"date_sdn": 2418291,
"descr": "Birth of Webb, John Raymond",
"gid": "E1043",
"media": [],
"part_family": [],
"part_person": [
1857
],
"place": 136,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1996-02-07",
"date_sdn": 2450121,
"descr": "Death of Webb, John Raymond",
"gid": "E1044",
"media": [],
"part_family": [],
"part_person": [
1857
],
"place": 674,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1996-02-10",
"date_sdn": 2450124,
"descr": "Burial of Webb, John Raymond",
"gid": "E1045",
"media": [],
"part_family": [],
"part_person": [
1857
],
"place": 1217,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1847-10-00",
"date_sdn": 2395936,
"descr": "Birth of Webb, Joseph LeRoy",
"gid": "E0771",
"media": [],
"part_family": [],
"part_person": [
1858
],
"place": 247,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1878-04-15",
"date_sdn": 2407090,
"descr": "Birth of Webb, Lawrence",
"gid": "E2312",
"media": [],
"part_family": [],
"part_person": [
1859
],
"place": 152,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1948-08-29",
"date_sdn": 2432793,
"descr": "Death of Webb, Lawrence",
"gid": "E2313",
"media": [],
"part_family": [],
"part_person": [
1859
],
"place": 1159,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1948-08-31",
"date_sdn": 2432795,
"descr": "Burial of Webb, Lawrence",
"gid": "E2314",
"media": [],
"part_family": [],
"part_person": [
1859
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1903-03-31",
"date_sdn": 2416205,
"descr": "Birth of Webb, Lewis I.",
"gid": "E1048",
"media": [],
"part_family": [],
"part_person": [
1860
],
"place": 104,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1942-12-25",
"date_sdn": 2430719,
"descr": "Death of Webb, Lewis I.",
"gid": "E1049",
"media": [],
"part_family": [],
"part_person": [
1860
],
"place": 580,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Webb, Lewis I.",
"gid": "E1050",
"media": [],
"part_family": [],
"part_person": [
1860
],
"place": 1015,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1846-02-11",
"date_sdn": 2395339,
"descr": "Birth of Webb, Livingstone Martin",
"gid": "E2129",
"media": [],
"part_family": [],
"part_person": [
1861
],
"place": 247,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1902-04-10",
"date_sdn": 2415850,
"descr": "Death of Webb, Livingstone Martin",
"gid": "E2130",
"media": [],
"part_family": [],
"part_person": [
1861
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1902-04-13",
"date_sdn": 2415853,
"descr": "Burial of Webb, Livingstone Martin",
"gid": "E2131",
"media": [],
"part_family": [],
"part_person": [
1861
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, Lucinda E.",
"gid": "E0772",
"media": [],
"part_family": [],
"part_person": [
1862
],
"place": 175,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1899-01-20",
"date_sdn": 2414675,
"descr": "Birth of Webb, Lucy Mabel",
"gid": "E1031",
"media": [],
"part_family": [],
"part_person": [
1863
],
"place": 604,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1971-05-10",
"date_sdn": 2441082,
"descr": "Death of Webb, Lucy Mabel",
"gid": "E1032",
"media": [],
"part_family": [],
"part_person": [
1863
],
"place": 3,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1971-05-13",
"date_sdn": 2441085,
"descr": "Burial of Webb, Lucy Mabel",
"gid": "E1033",
"media": [],
"part_family": [],
"part_person": [
1863
],
"place": 266,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1906-11-07",
"date_sdn": 2417522,
"descr": "Birth of Webb, Luella Florence",
"gid": "E1518",
"media": [],
"part_family": [],
"part_person": [
1864
],
"place": 1166,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1986-10-08",
"date_sdn": 2446712,
"descr": "Death of Webb, Luella Florence",
"gid": "E1519",
"media": [],
"part_family": [],
"part_person": [
1864
],
"place": 1273,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1986-10-11",
"date_sdn": 2446715,
"descr": "Burial of Webb, Luella Florence",
"gid": "E1520",
"media": [],
"part_family": [],
"part_person": [
1864
],
"place": 120,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1800",
"date_sdn": 2378497,
"descr": "Birth of Webb, Margaret Margarite?",
"gid": "E2721",
"media": [],
"part_family": [],
"part_person": [
1865
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1860",
"date_sdn": 2400411,
"descr": "Death of Webb, Margaret Margarite?",
"gid": "E2722",
"media": [],
"part_family": [],
"part_person": [
1865
],
"place": 999,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "after 1860",
"date_sdn": 2400411,
"descr": "Burial of Webb, Margaret Margarite?",
"gid": "E2723",
"media": [],
"part_family": [],
"part_person": [
1865
],
"place": 355,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1950-03-18",
"date_sdn": 2433359,
"descr": "Birth of Webb, Marilyn Jean",
"gid": "E1532",
"media": [],
"part_family": [],
"part_person": [
1866
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1533",
"media": [],
"part_family": [],
"part_person": [
1866
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1803",
"date_sdn": 2379592,
"descr": "Birth of Webb, Mary",
"gid": "E0319",
"media": [],
"part_family": [],
"part_person": [
1867
],
"place": 852,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1827-01-31",
"date_sdn": 2388388,
"descr": "Birth of Webb, Mary",
"gid": "E0320",
"media": [],
"part_family": [],
"part_person": [
1868
],
"place": 463,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1892-12-15",
"date_sdn": 2412448,
"descr": "Birth of Webb, Mary Ruth",
"gid": "E0816",
"media": [],
"part_family": [],
"part_person": [
1869
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1956-11-29",
"date_sdn": 2435807,
"descr": "Death of Webb, Mary Ruth",
"gid": "E0817",
"media": [],
"part_family": [],
"part_person": [
1869
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1888-11-19",
"date_sdn": 2410961,
"descr": "Birth of Webb, Michael Christie",
"gid": "E0812",
"media": [],
"part_family": [],
"part_person": [
1870
],
"place": 979,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1970-07-23",
"date_sdn": 2440791,
"descr": "Death of Webb, Michael Christie",
"gid": "E0813",
"media": [],
"part_family": [],
"part_person": [
1870
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, Nancy Lou",
"gid": "E1537",
"media": [],
"part_family": [],
"part_person": [
1872
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Webb, Nancy Lou",
"gid": "E1538",
"media": [],
"part_family": [],
"part_person": [
1872
],
"place": 893,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1842-10-13",
"date_sdn": 2394122,
"descr": "Birth of Webb, Newton Kitridge",
"gid": "E0329",
"media": [],
"part_family": [],
"part_person": [
1873
],
"place": 888,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1912-07-28",
"date_sdn": 2419612,
"descr": "Death of Webb, Newton Kitridge",
"gid": "E0330",
"media": [],
"part_family": [],
"part_person": [
1873
],
"place": 613,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1912-07-30",
"date_sdn": 2419614,
"descr": "Burial of Webb, Newton Kitridge",
"gid": "E0331",
"media": [],
"part_family": [],
"part_person": [
1873
],
"place": 1046,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1925",
"date_sdn": 2424152,
"descr": "Birth of Webb, Noble A.",
"gid": "E0343",
"media": [],
"part_family": [],
"part_person": [
1874
],
"place": 338,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Webb, Noble A.",
"gid": "E0344",
"media": [],
"part_family": [],
"part_person": [
1874
],
"place": 979,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1928-03-14",
"date_sdn": 2425320,
"descr": "Birth of Webb, Richard L.",
"gid": "E1542",
"media": [],
"part_family": [],
"part_person": [
1876
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1994-03-05",
"date_sdn": 2449417,
"descr": "Death of Webb, Richard L.",
"gid": "E1543",
"media": [],
"part_family": [],
"part_person": [
1876
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1994-03-08",
"date_sdn": 2449420,
"descr": "Burial of Webb, Richard L.",
"gid": "E1544",
"media": [],
"part_family": [],
"part_person": [
1876
],
"place": 707,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Webb, Sallie",
"gid": "E0318",
"media": [],
"part_family": [],
"part_person": [
1878
],
"place": 852,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1832",
"date_sdn": 2390184,
"descr": "Birth of Webb, Sarah Margarite",
"gid": "E0325",
"media": [],
"part_family": [],
"part_person": [
1879
],
"place": 996,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1881-10-27",
"date_sdn": 2408381,
"descr": "Birth of Webb, William Herman",
"gid": "E0341",
"media": [],
"part_family": [],
"part_person": [
1880
],
"place": 966,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1952-08-23",
"date_sdn": 2434248,
"descr": "Death of Webb, William Herman",
"gid": "E0342",
"media": [],
"part_family": [],
"part_person": [
1880
],
"place": 979,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1829-07-14",
"date_sdn": 2389283,
"descr": "Birth of Webb, William John",
"gid": "E0321",
"media": [],
"part_family": [],
"part_person": [
1881
],
"place": 996,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1888-04-17",
"date_sdn": 2410745,
"descr": "Death of Webb, William John",
"gid": "E0322",
"media": [],
"part_family": [],
"part_person": [
1881
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1679-05-01",
"date_sdn": 2334423,
"descr": "Birth of Webster, Johanne(John)",
"gid": "E2255",
"media": [],
"part_family": [],
"part_person": [
1883
],
"place": 567,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Webster, Johanne(John)",
"gid": "E2256",
"media": [],
"part_family": [],
"part_person": [
1883
],
"place": 1038,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1951-03-30",
"date_sdn": 2433736,
"descr": "Birth of Welch, Annabelle Elaine",
"gid": "E2440",
"media": [],
"part_family": [],
"part_person": [
1884
],
"place": 766,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2441",
"media": [],
"part_family": [],
"part_person": [
1884
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1966-09-04",
"date_sdn": 2439373,
"descr": "Birth of Welch, Christopher Paul",
"gid": "E1667",
"media": [],
"part_family": [],
"part_person": [
1885
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1668",
"media": [],
"part_family": [],
"part_person": [
1885
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1920-10-28",
"date_sdn": 2422626,
"descr": "Birth of Welch, Irwin Arthur",
"gid": "E2431",
"media": [],
"part_family": [],
"part_person": [
1886
],
"place": 1157,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1979-06-25",
"date_sdn": 2444050,
"descr": "Death of Welch, Irwin Arthur",
"gid": "E2432",
"media": [],
"part_family": [],
"part_person": [
1886
],
"place": 747,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1979-06-27",
"date_sdn": 2444052,
"descr": "Burial of Welch, Irwin Arthur",
"gid": "E2433",
"media": [],
"part_family": [],
"part_person": [
1886
],
"place": 1242,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1982-08-09",
"date_sdn": 2445191,
"descr": "Birth of Welch, Jeremy Quentin",
"gid": "E1488",
"media": [],
"part_family": [],
"part_person": [
1887
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1489",
"media": [],
"part_family": [],
"part_person": [
1887
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1962-12-21",
"date_sdn": 2438020,
"descr": "Birth of Welch, Lisa Dawn",
"gid": "E1663",
"media": [],
"part_family": [],
"part_person": [
1888
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1664",
"media": [],
"part_family": [],
"part_person": [
1888
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1995-11-01",
"date_sdn": 2450023,
"descr": "Birth of Welch, Madeleine Christine",
"gid": "E0150",
"media": [],
"part_family": [],
"part_person": [
1889
],
"place": 1187,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0151",
"media": [],
"part_family": [],
"part_person": [
1889
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1959-03-04",
"date_sdn": 2436632,
"descr": "Birth of Welch, Michael",
"gid": "E1486",
"media": [],
"part_family": [],
"part_person": [
1890
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1487",
"media": [],
"part_family": [],
"part_person": [
1890
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1940-09-30",
"date_sdn": 2429903,
"descr": "Birth of Welch, Paul Allen",
"gid": "E1640",
"media": [],
"part_family": [],
"part_person": [
1891
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1641",
"media": [],
"part_family": [],
"part_person": [
1891
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1956-08-03",
"date_sdn": 2435689,
"descr": "Birth of Welch, Rosalie Jane",
"gid": "E2447",
"media": [],
"part_family": [],
"part_person": [
1892
],
"place": 747,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2448",
"media": [],
"part_family": [],
"part_person": [
1892
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1949-04-08",
"date_sdn": 2433015,
"descr": "Birth of Welch, Russell Eugene",
"gid": "E2434",
"media": [],
"part_family": [],
"part_person": [
1893
],
"place": 766,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2435",
"media": [],
"part_family": [],
"part_person": [
1893
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Wells, Alice",
"gid": "E0244",
"media": [],
"part_family": [],
"part_person": [
1895
],
"place": 150,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1653-11-08",
"date_sdn": 2325118,
"descr": "Death of Wells, Alice",
"gid": "E0245",
"media": [],
"part_family": [],
"part_person": [
1895
],
"place": 736,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1985-11-06",
"date_sdn": 2446376,
"descr": "Birth of West, Erin Kathleen",
"gid": "E1682",
"media": [],
"part_family": [],
"part_person": [
1896
],
"place": 251,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1683",
"media": [],
"part_family": [],
"part_person": [
1896
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1989-05-05",
"date_sdn": 2447652,
"descr": "Birth of West, Kevin Wayne",
"gid": "E0152",
"media": [],
"part_family": [],
"part_person": [
1897
],
"place": 997,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0153",
"media": [],
"part_family": [],
"part_person": [
1897
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1953-07-13",
"date_sdn": 2434572,
"descr": "Birth of West, Ronald David",
"gid": "E1646",
"media": [],
"part_family": [],
"part_person": [
1898
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1647",
"media": [],
"part_family": [],
"part_person": [
1898
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[
{
"cita": [],
"date": "1977-01-04",
"date_sdn": 2443148,
"descr": "Birth of Wheeler, Jason Earl",
"gid": "E2285",
"media": [],
"part_family": [],
"part_person": [
1901
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2286",
"media": [],
"part_family": [],
"part_person": [
1901
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1970-10-05",
"date_sdn": 2440865,
"descr": "Birth of Wheeler, Lynnett Diane",
"gid": "E2283",
"media": [],
"part_family": [],
"part_person": [
1902
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2284",
"media": [],
"part_family": [],
"part_person": [
1902
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1967-10-02",
"date_sdn": 2439766,
"descr": "Birth of Wheeler, Richard Max",
"gid": "E2280",
"media": [],
"part_family": [],
"part_person": [
1903
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2281",
"media": [],
"part_family": [],
"part_person": [
1903
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1993-10-27",
"date_sdn": 2449288,
"descr": "Birth of Willis, Carissa Nicole",
"gid": "E2695",
"media": [],
"part_family": [],
"part_person": [
1907
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2696",
"media": [],
"part_family": [],
"part_person": [
1907
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1996-08-09",
"date_sdn": 2450305,
"descr": "Birth of Willis, Matea Elizabeth",
"gid": "E0144",
"media": [],
"part_family": [],
"part_person": [
1909
],
"place": 1004,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0145",
"media": [],
"part_family": [],
"part_person": [
1909
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1996-08-19",
"date_sdn": 2450315,
"descr": "Birth of Willis, Mattea Elizabeth",
"gid": "E0160",
"media": [],
"part_family": [],
"part_person": [
1910
],
"place": 486,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0161",
"media": [],
"part_family": [],
"part_person": [
1910
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1536-06-19",
"date_sdn": 2282242,
"descr": "Birth of Wise, Thomas",
"gid": "E2143",
"media": [],
"part_family": [],
"part_person": [
1912
],
"place": 475,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1606-10-09",
"date_sdn": 2307921,
"descr": "Death of Wise, Thomas",
"gid": "E2144",
"media": [],
"part_family": [],
"part_person": [
1912
],
"place": 336,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1967-06-25",
"date_sdn": 2439667,
"descr": "Death of W\u00f3jcik, Arnold",
"gid": "E2079",
"media": [],
"part_family": [],
"part_person": [
1914
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of W\u00f3jcik, Arnold",
"gid": "E2080",
"media": [],
"part_family": [],
"part_person": [
1914
],
"place": 1183,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1944-09-04",
"date_sdn": 2431338,
"descr": "Birth of W\u00f3jcik, Arnold Clark",
"gid": "E2105",
"media": [],
"part_family": [],
"part_person": [
1915
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2106",
"media": [],
"part_family": [],
"part_person": [
1915
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1949-08-25",
"date_sdn": 2433154,
"descr": "Birth of W\u00f3jcik, Daniel Burton",
"gid": "E2107",
"media": [],
"part_family": [],
"part_person": [
1916
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2108",
"media": [],
"part_family": [],
"part_person": [
1916
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1932-03-24",
"date_sdn": 2426791,
"descr": "Birth of W\u00f3jcik, James",
"gid": "E2103",
"media": [],
"part_family": [],
"part_person": [
1917
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2104",
"media": [],
"part_family": [],
"part_person": [
1917
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1930-10-25",
"date_sdn": 2426275,
"descr": "Birth of W\u00f3jcik, Patricia",
"gid": "E2101",
"media": [],
"part_family": [],
"part_person": [
1918
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2102",
"media": [],
"part_family": [],
"part_person": [
1918
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1929-08-14",
"date_sdn": 2425838,
"descr": "Birth of W\u00f3jcik, Richard",
"gid": "E2099",
"media": [],
"part_family": [],
"part_person": [
1919
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2100",
"media": [],
"part_family": [],
"part_person": [
1919
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1928-06-25",
"date_sdn": 2425423,
"descr": "Birth of W\u00f3jcik, Suzanne",
"gid": "E2097",
"media": [],
"part_family": [],
"part_person": [
1920
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2098",
"media": [],
"part_family": [],
"part_person": [
1920
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1771-01-29",
"date_sdn": 2367933,
"descr": "Birth of Wood, Polly",
"gid": "E1029",
"media": [],
"part_family": [],
"part_person": [
1924
],
"place": 182,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "before 1850",
"date_sdn": 2396759,
"descr": "Death of Wood, Polly",
"gid": "E1030",
"media": [],
"part_family": [],
"part_person": [
1924
],
"place": 149,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1777-11-29",
"date_sdn": 2370429,
"descr": "Birth of Woods, Mary Polly",
"gid": "E1038",
"media": [],
"part_family": [],
"part_person": [
1926
],
"place": 1226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1854-11-15",
"date_sdn": 2398538,
"descr": "Death of Woods, Mary Polly",
"gid": "E1039",
"media": [],
"part_family": [],
"part_person": [
1926
],
"place": 539,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Wright, Dr. Charles J.",
"gid": "E1707",
"media": [],
"part_family": [],
"part_person": [
1929
],
"place": 23,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of Yates, Sarah",
"gid": "E2713",
"media": [],
"part_family": [],
"part_person": [
1930
],
"place": 680,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of Yates, Sarah",
"gid": "E2714",
"media": [],
"part_family": [],
"part_person": [
1930
],
"place": 298,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of Yates, Sarah",
"gid": "E2715",
"media": [],
"part_family": [],
"part_person": [
1930
],
"place": 298,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1827-04-12",
"date_sdn": 2388459,
"descr": "Birth of Zieli\u0144ski, Phoebe Emily",
"gid": "E0124",
"media": [],
"part_family": [],
"part_person": [
1932
],
"place": 116,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1882-03-07",
"date_sdn": 2408512,
"descr": "Death of Zieli\u0144ski, Phoebe Emily",
"gid": "E0125",
"media": [],
"part_family": [],
"part_person": [
1932
],
"place": 21,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1882-03-09",
"date_sdn": 2408514,
"descr": "Burial of Zieli\u0144ski, Phoebe Emily",
"gid": "E0126",
"media": [],
"part_family": [],
"part_person": [
1932
],
"place": 763,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1887-05-20",
"date_sdn": 2410412,
"descr": "Birth of Zimmerman, Edith Irene",
"gid": "E2516",
"media": [],
"part_family": [],
"part_person": [
1933
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1890-05-20",
"date_sdn": 2411508,
"descr": "Birth of Zimmerman, Edith Irene",
"gid": "E2461",
"media": [],
"part_family": [],
"part_person": [
1934
],
"place": 61,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1962-12-21",
"date_sdn": 2438020,
"descr": "Death of Zimmerman, Edith Irene",
"gid": "E2462",
"media": [],
"part_family": [],
"part_person": [
1934
],
"place": 598,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1962-12-23",
"date_sdn": 2438022,
"descr": "Burial of Zimmerman, Edith Irene",
"gid": "E2463",
"media": [],
"part_family": [],
"part_person": [
1934
],
"place": 891,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1920-04-07",
"date_sdn": 2422422,
"descr": "",
"gid": "E3424",
"media": [],
"part_family": [],
"part_person": [
1935
],
"place": 1293,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1995-03-02",
"date_sdn": 2449779,
"descr": "",
"gid": "E3429",
"media": [],
"part_family": [],
"part_person": [
1935
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1940-03-01",
"date_sdn": 2429690,
"descr": "",
"gid": "E3416",
"media": [],
"part_family": [],
"part_person": [
1936
],
"place": 1289,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1970-09-09",
"date_sdn": 2440839,
"descr": "",
"gid": "E3418",
"media": [],
"part_family": [],
"part_person": [
1936
],
"place": -1,
"text": "",
"type": "Marriage"
}
],
[
{
"cita": [],
"date": "1978-11-30",
"date_sdn": 2443843,
"descr": "",
"gid": "E3427",
"media": [],
"part_family": [],
"part_person": [
1937
],
"place": 1289,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1910-06-29",
"date_sdn": 2418852,
"descr": "",
"gid": "E3423",
"media": [],
"part_family": [],
"part_person": [
1938
],
"place": 1291,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1990-02-02",
"date_sdn": 2447925,
"descr": "",
"gid": "E3428",
"media": [],
"part_family": [],
"part_person": [
1938
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1973-04-11",
"date_sdn": 2441784,
"descr": "",
"gid": "E3420",
"media": [],
"part_family": [],
"part_person": [
1939
],
"place": 1289,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1976-09-29",
"date_sdn": 2443051,
"descr": "",
"gid": "E3422",
"media": [],
"part_family": [],
"part_person": [
1940
],
"place": 1289,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1974-12-03",
"date_sdn": 2442385,
"descr": "",
"gid": "E3421",
"media": [],
"part_family": [],
"part_person": [
1941
],
"place": 1289,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1971-11-05",
"date_sdn": 2441261,
"descr": "",
"gid": "E3419",
"media": [],
"part_family": [],
"part_person": [
1942
],
"place": 1289,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1915-03-10",
"date_sdn": 2420567,
"descr": "",
"gid": "E3425",
"media": [],
"part_family": [],
"part_person": [
1943
],
"place": 1288,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "2005-06-28",
"date_sdn": 2453550,
"descr": "",
"gid": "E3430",
"media": [],
"part_family": [],
"part_person": [
1943
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1950-06-18",
"date_sdn": 2433451,
"descr": "",
"gid": "E3417",
"media": [],
"part_family": [],
"part_person": [
1944
],
"place": 1290,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1925-07-15",
"date_sdn": 2424347,
"descr": "",
"gid": "E3426",
"media": [],
"part_family": [],
"part_person": [
1945
],
"place": 1292,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "2006-01-11",
"date_sdn": 2453747,
"descr": "",
"gid": "E3431",
"media": [],
"part_family": [],
"part_person": [
1945
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1730",
"date_sdn": 2352930,
"descr": "Birth of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"gid": "E0432",
"media": [],
"part_family": [],
"part_person": [
1946
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1817",
"date_sdn": 2384706,
"descr": "Death of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"gid": "E0433",
"media": [],
"part_family": [],
"part_person": [
1946
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1721",
"date_sdn": 2349643,
"descr": "Birth of \u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Johann Adam",
"gid": "E0429",
"media": [],
"part_family": [],
"part_person": [
1947
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1815",
"date_sdn": 2383975,
"descr": "Birth of \u0411\u0430\u0440\u0430\u043d\u043e\u0432, Susan",
"gid": "E0365",
"media": [],
"part_family": [],
"part_person": [
1951
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1717-01-26",
"date_sdn": 2348207,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2555",
"media": [],
"part_family": [],
"part_person": [
1953
],
"place": 356,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1788-04-20",
"date_sdn": 2374224,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2556",
"media": [],
"part_family": [],
"part_person": [
1953
],
"place": 448,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1788-04-22",
"date_sdn": 2374226,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"gid": "E2557",
"media": [],
"part_family": [],
"part_person": [
1953
],
"place": 548,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1658",
"date_sdn": 2326633,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2599",
"media": [],
"part_family": [],
"part_person": [
1954
],
"place": 575,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1718-08-16",
"date_sdn": 2348774,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2600",
"media": [],
"part_family": [],
"part_person": [
1954
],
"place": 575,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"gid": "E2601",
"media": [],
"part_family": [],
"part_person": [
1954
],
"place": 658,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1690-02-23",
"date_sdn": 2338374,
"descr": "Birth of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2608",
"media": [],
"part_family": [],
"part_person": [
1955
],
"place": 575,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750-12-25",
"date_sdn": 2360593,
"descr": "Death of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2609",
"media": [],
"part_family": [],
"part_person": [
1955
],
"place": 575,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"gid": "E2610",
"media": [],
"part_family": [],
"part_person": [
1955
],
"place": 658,
"text": "",
"type": "Burial"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1915-09-28",
"date_sdn": 2420769,
"descr": "Birth of \u0411\u0440\u044e\u0445\u0430\u043d\u043e\u0432, Violet Louise",
"gid": "E2122",
"media": [],
"part_family": [],
"part_person": [
1959
],
"place": 324,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2123",
"media": [],
"part_family": [],
"part_person": [
1959
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[],
[],
[],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1732-01-17",
"date_sdn": 2353676,
"descr": "Birth of \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"gid": "E0164",
"media": [],
"part_family": [],
"part_person": [
1968
],
"place": 176,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1789-05-29",
"date_sdn": 2374628,
"descr": "Death of \u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"gid": "E0165",
"media": [],
"part_family": [],
"part_person": [
1968
],
"place": 322,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1818",
"date_sdn": 2385071,
"descr": "Birth of \u0412\u043e\u0440\u043e\u043d\u043e\u0432, Katherine",
"gid": "E0848",
"media": [],
"part_family": [],
"part_person": [
1972
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1956-01-14",
"date_sdn": 2435487,
"descr": "Birth of \u0413\u0435\u0440\u0430\u0441\u0438\u043c\u043e\u0432, John",
"gid": "E2301",
"media": [],
"part_family": [],
"part_person": [
1973
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2302",
"media": [],
"part_family": [],
"part_person": [
1973
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1515",
"date_sdn": 2274402,
"descr": "Birth of \u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"gid": "E2247",
"media": [],
"part_family": [],
"part_person": [
1974
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1572",
"date_sdn": 2295221,
"descr": "Death of \u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"gid": "E2248",
"media": [],
"part_family": [],
"part_person": [
1974
],
"place": 926,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1754",
"date_sdn": 2361696,
"descr": "Birth of \u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432, Anna Maria",
"gid": "E0356",
"media": [],
"part_family": [],
"part_person": [
1977
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1955-04-30",
"date_sdn": 2435228,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Barbara Joanne",
"gid": "E0810",
"media": [],
"part_family": [],
"part_person": [
1979
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0811",
"media": [],
"part_family": [],
"part_person": [
1979
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1984-10-26",
"date_sdn": 2446000,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Daniel James Ramos",
"gid": "E1600",
"media": [],
"part_family": [],
"part_person": [
1980
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1601",
"media": [],
"part_family": [],
"part_person": [
1980
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1953-09-11",
"date_sdn": 2434632,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Darrell Edwin",
"gid": "E0799",
"media": [],
"part_family": [],
"part_person": [
1981
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0800",
"media": [],
"part_family": [],
"part_person": [
1981
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1951-10-23",
"date_sdn": 2433943,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Elaine Suzanne",
"gid": "E0789",
"media": [],
"part_family": [],
"part_person": [
1983
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0790",
"media": [],
"part_family": [],
"part_person": [
1983
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1948-12-23",
"date_sdn": 2432909,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Kathryn Louise",
"gid": "E0781",
"media": [],
"part_family": [],
"part_person": [
1984
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0782",
"media": [],
"part_family": [],
"part_person": [
1984
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1958-04-12",
"date_sdn": 2436306,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Lucinda Elinor",
"gid": "E0824",
"media": [],
"part_family": [],
"part_person": [
1985
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0825",
"media": [],
"part_family": [],
"part_person": [
1985
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1982-12-31",
"date_sdn": 2445335,
"descr": "Birth of \u0414\u0430\u043d\u0438\u043b\u043e\u0432, Rebecca Kristine Ramos",
"gid": "E1478",
"media": [],
"part_family": [],
"part_person": [
1986
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1479",
"media": [],
"part_family": [],
"part_person": [
1986
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1771-04-20",
"date_sdn": 2368014,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"gid": "E1036",
"media": [],
"part_family": [],
"part_person": [
1987
],
"place": 462,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1838-01-18",
"date_sdn": 2392393,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"gid": "E1037",
"media": [],
"part_family": [],
"part_person": [
1987
],
"place": 539,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1729",
"date_sdn": 2352565,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"gid": "E0283",
"media": [],
"part_family": [],
"part_person": [
1988
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1786",
"date_sdn": 2373384,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"gid": "E0284",
"media": [],
"part_family": [],
"part_person": [
1988
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1687",
"date_sdn": 2337225,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"gid": "E2706",
"media": [],
"part_family": [],
"part_person": [
1989
],
"place": 584,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1750-05-13",
"date_sdn": 2360367,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"gid": "E2707",
"media": [],
"part_family": [],
"part_person": [
1989
],
"place": 1054,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, George",
"gid": "E1014",
"media": [],
"part_family": [],
"part_person": [
1990
],
"place": 156,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, George",
"gid": "E1015",
"media": [],
"part_family": [],
"part_person": [
1990
],
"place": 1174,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1737",
"date_sdn": 2355487,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"gid": "E0289",
"media": [],
"part_family": [],
"part_person": [
1991
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1807",
"date_sdn": 2381053,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"gid": "E0290",
"media": [],
"part_family": [],
"part_person": [
1991
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1741",
"date_sdn": 2356948,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"gid": "E0293",
"media": [],
"part_family": [],
"part_person": [
1992
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "about 1778",
"date_sdn": 2370462,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"gid": "E0294",
"media": [],
"part_family": [],
"part_person": [
1992
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1739",
"date_sdn": 2356217,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"gid": "E0291",
"media": [],
"part_family": [],
"part_person": [
1993
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1762",
"date_sdn": 2364618,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"gid": "E0292",
"media": [],
"part_family": [],
"part_person": [
1993
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1733",
"date_sdn": 2354026,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lucy",
"gid": "E0288",
"media": [],
"part_family": [],
"part_person": [
1994
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Margaret Jane",
"gid": "E1034",
"media": [],
"part_family": [],
"part_person": [
1995
],
"place": 1226,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Margaret Jane",
"gid": "E1035",
"media": [],
"part_family": [],
"part_person": [
1995
],
"place": 1111,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "about 1731",
"date_sdn": 2353295,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Mary",
"gid": "E0285",
"media": [],
"part_family": [],
"part_person": [
1996
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1735-11-09",
"date_sdn": 2355068,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Moses Aaron",
"gid": "E2668",
"media": [],
"part_family": [],
"part_person": [
1997
],
"place": 1257,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Moses Aaron",
"gid": "E2669",
"media": [],
"part_family": [],
"part_person": [
1997
],
"place": 984,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Moses Aaron",
"gid": "E2670",
"media": [],
"part_family": [],
"part_person": [
1997
],
"place": 280,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1767-09-12",
"date_sdn": 2366698,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Travis",
"gid": "E1023",
"media": [],
"part_family": [],
"part_person": [
1999
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Travis",
"gid": "E1024",
"media": [],
"part_family": [],
"part_person": [
1999
],
"place": 1261,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1768-04-01",
"date_sdn": 2366900,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E1027",
"media": [],
"part_family": [],
"part_person": [
2000
],
"place": 1282,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1853",
"date_sdn": 2397855,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E1028",
"media": [],
"part_family": [],
"part_person": [
2000
],
"place": 844,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1727",
"date_sdn": 2351834,
"descr": "Birth of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E0281",
"media": [],
"part_family": [],
"part_person": [
2001
],
"place": 962,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1766-05-12",
"date_sdn": 2366210,
"descr": "Death of \u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"gid": "E0282",
"media": [],
"part_family": [],
"part_person": [
2001
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0415\u0433\u043e\u0440\u043e\u0432, Dr. Charles J.",
"gid": "E0749",
"media": [],
"part_family": [],
"part_person": [
2002
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0416\u0443\u043a\u043e\u0432, Curtis Dale",
"gid": "E2034",
"media": [],
"part_family": [],
"part_person": [
2004
],
"place": 1072,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0416\u0443\u043a\u043e\u0432, Scott",
"gid": "E2033",
"media": [],
"part_family": [],
"part_person": [
2007
],
"place": 1072,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1898",
"media": [],
"part_family": [],
"part_person": [
2010
],
"place": 332,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1771",
"date_sdn": 2367905,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1899",
"media": [],
"part_family": [],
"part_person": [
2010
],
"place": 1090,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"gid": "E1900",
"media": [],
"part_family": [],
"part_person": [
2010
],
"place": 944,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1695",
"date_sdn": 2340147,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, John",
"gid": "E2252",
"media": [],
"part_family": [],
"part_person": [
2011
],
"place": 587,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, John",
"gid": "E2253",
"media": [],
"part_family": [],
"part_person": [
2011
],
"place": 332,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1756-02-15",
"date_sdn": 2362471,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"gid": "E1910",
"media": [],
"part_family": [],
"part_person": [
2012
],
"place": 809,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1801-08-11",
"date_sdn": 2379084,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"gid": "E1911",
"media": [],
"part_family": [],
"part_person": [
2012
],
"place": 32,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1790-01-29",
"date_sdn": 2374873,
"descr": "Birth of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1916",
"media": [],
"part_family": [],
"part_person": [
2013
],
"place": 1047,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-06-27",
"date_sdn": 2396571,
"descr": "Death of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1917",
"media": [],
"part_family": [],
"part_person": [
2013
],
"place": -1,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1849-06-29",
"date_sdn": 2396573,
"descr": "Burial of \u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"gid": "E1918",
"media": [],
"part_family": [],
"part_person": [
2013
],
"place": 914,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0417\u044b\u043a\u043e\u0432, ???????",
"gid": "E2148",
"media": [],
"part_family": [],
"part_person": [
2014
],
"place": 1061,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1846-08-17",
"date_sdn": 2395526,
"descr": "Birth of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1467",
"media": [],
"part_family": [],
"part_person": [
2015
],
"place": 370,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1891-10-31",
"date_sdn": 2412037,
"descr": "Death of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1468",
"media": [],
"part_family": [],
"part_person": [
2015
],
"place": 900,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1891-11-01",
"date_sdn": 2412038,
"descr": "Burial of \u0417\u044b\u043a\u043e\u0432, Angeline",
"gid": "E1469",
"media": [],
"part_family": [],
"part_person": [
2015
],
"place": 900,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1795-11-06",
"date_sdn": 2376980,
"descr": "Birth of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1354",
"media": [],
"part_family": [],
"part_person": [
2016
],
"place": 49,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1875-12-12",
"date_sdn": 2406235,
"descr": "Death of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1355",
"media": [],
"part_family": [],
"part_person": [
2016
],
"place": 1200,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0417\u044b\u043a\u043e\u0432, John",
"gid": "E1356",
"media": [],
"part_family": [],
"part_person": [
2016
],
"place": 126,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "1977-05-00",
"date_sdn": 2443265,
"descr": "Birth of \u0418\u043b\u044c\u0438\u043d, Eric Scott",
"gid": "E1589",
"media": [],
"part_family": [],
"part_person": [
2018
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1590",
"media": [],
"part_family": [],
"part_person": [
2018
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1950-05-12",
"date_sdn": 2433414,
"descr": "Birth of \u0418\u043b\u044c\u0438\u043d, Gary",
"gid": "E1587",
"media": [],
"part_family": [],
"part_person": [
2019
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1588",
"media": [],
"part_family": [],
"part_person": [
2019
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1981-03-00",
"date_sdn": 2444665,
"descr": "Birth of \u0418\u043b\u044c\u0438\u043d, Timothy Ryan",
"gid": "E1594",
"media": [],
"part_family": [],
"part_person": [
2020
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1595",
"media": [],
"part_family": [],
"part_person": [
2020
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1768-01-04",
"date_sdn": 2366812,
"descr": "Birth of \u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"gid": "E0846",
"media": [],
"part_family": [],
"part_person": [
2021
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1828-12-21",
"date_sdn": 2389078,
"descr": "Death of \u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"gid": "E0847",
"media": [],
"part_family": [],
"part_person": [
2021
],
"place": 426,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1858",
"date_sdn": 2399681,
"descr": "Birth of \u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"gid": "E0235",
"media": [],
"part_family": [],
"part_person": [
2022
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1913-09-02",
"date_sdn": 2420013,
"descr": "Death of \u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"gid": "E0236",
"media": [],
"part_family": [],
"part_person": [
2022
],
"place": 528,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041a\u0430\u0440\u043f\u043e\u0432, Damian",
"gid": "E2368",
"media": [],
"part_family": [],
"part_person": [
2023
],
"place": 540,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1987",
"date_sdn": 2446797,
"descr": "Birth of \u041a\u0430\u0440\u043f\u043e\u0432, Sarah",
"gid": "E2369",
"media": [],
"part_family": [],
"part_person": [
2024
],
"place": 1240,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E2370",
"media": [],
"part_family": [],
"part_person": [
2024
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1520",
"date_sdn": 2276228,
"descr": "Birth of \u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432, ??",
"gid": "E0014",
"media": [],
"part_family": [],
"part_person": [
2025
],
"place": 1006,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1985-08-08",
"date_sdn": 2446286,
"descr": "Birth of \u041a\u0438\u0441\u0435\u043b\u0435\u0432, Aaron D.",
"gid": "E1406",
"media": [],
"part_family": [],
"part_person": [
2026
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1407",
"media": [],
"part_family": [],
"part_person": [
2026
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1952-07-16",
"date_sdn": 2434210,
"descr": "Birth of \u041a\u0438\u0441\u0435\u043b\u0435\u0432, Dennis John",
"gid": "E1399",
"media": [],
"part_family": [],
"part_person": [
2027
],
"place": 391,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1400",
"media": [],
"part_family": [],
"part_person": [
2027
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1983-07-07",
"date_sdn": 2445523,
"descr": "Birth of \u041a\u0438\u0441\u0435\u043b\u0435\u0432, Timothy Andrew",
"gid": "E1401",
"media": [],
"part_family": [],
"part_person": [
2028
],
"place": 1244,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1402",
"media": [],
"part_family": [],
"part_person": [
2028
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "about 1604",
"date_sdn": 2306909,
"descr": "Birth of \u041a\u043e\u0432\u0430\u043b\u0435\u0432, Sarah",
"gid": "E0270",
"media": [],
"part_family": [],
"part_person": [
2029
],
"place": 736,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u041a\u043e\u0432\u0430\u043b\u0435\u0432, Sarah",
"gid": "E0271",
"media": [],
"part_family": [],
"part_person": [
2029
],
"place": 631,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "1972-08-08",
"date_sdn": 2441538,
"descr": "Death of \u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432, Hanora",
"gid": "E0941",
"media": [],
"part_family": [],
"part_person": [
2034
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041b\u0435\u0431\u0435\u0434\u0435\u0432, Trustum",
"gid": "E1072",
"media": [],
"part_family": [],
"part_person": [
2037
],
"place": 595,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1947-01-22",
"date_sdn": 2432208,
"descr": "Birth of \u041b\u043e\u043f\u0430\u0442\u0438\u043d, Carmen Diana",
"gid": "E1262",
"media": [],
"part_family": [],
"part_person": [
2039
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1263",
"media": [],
"part_family": [],
"part_person": [
2039
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1949-05-18",
"date_sdn": 2433055,
"descr": "Birth of \u041b\u043e\u043f\u0430\u0442\u0438\u043d, Donna Elaine",
"gid": "E1264",
"media": [],
"part_family": [],
"part_person": [
2040
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1265",
"media": [],
"part_family": [],
"part_person": [
2040
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1922-04-14",
"date_sdn": 2423159,
"descr": "Birth of \u041b\u043e\u043f\u0430\u0442\u0438\u043d, Raymond A.",
"gid": "E1260",
"media": [],
"part_family": [],
"part_person": [
2041
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1261",
"media": [],
"part_family": [],
"part_person": [
2041
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u043a\u0430\u0440\u043e\u0432, Joseph",
"gid": "E0332",
"media": [],
"part_family": [],
"part_person": [
2042
],
"place": 170,
"text": "",
"type": "Birth"
}
],
[],
[],
[
{
"cita": [],
"date": "1749-10-25",
"date_sdn": 2360167,
"descr": "Death of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Christina",
"gid": "E1872",
"media": [],
"part_family": [],
"part_person": [
2045
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1970-05-15",
"date_sdn": 2440722,
"descr": "Birth of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Heather Michelle",
"gid": "E1629",
"media": [],
"part_family": [],
"part_person": [
2047
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1630",
"media": [],
"part_family": [],
"part_person": [
2047
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1973-08-25",
"date_sdn": 2441920,
"descr": "Birth of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Hyla Rae",
"gid": "E1631",
"media": [],
"part_family": [],
"part_person": [
2048
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1632",
"media": [],
"part_family": [],
"part_person": [
2048
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2513",
"media": [],
"part_family": [],
"part_person": [
2049
],
"place": 815,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1849-05-08",
"date_sdn": 2396521,
"descr": "Death of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2514",
"media": [],
"part_family": [],
"part_person": [
2049
],
"place": 945,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1849-05-09",
"date_sdn": 2396522,
"descr": "Burial of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"gid": "E2515",
"media": [],
"part_family": [],
"part_person": [
2049
],
"place": 438,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1945-10-22",
"date_sdn": 2431751,
"descr": "Birth of \u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Rodney Herman",
"gid": "E1627",
"media": [],
"part_family": [],
"part_person": [
2050
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E1628",
"media": [],
"part_family": [],
"part_person": [
2050
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1420",
"date_sdn": 2239704,
"descr": "Birth of \u041c\u0430\u043b\u044c\u0446\u0435\u0432, Joan",
"gid": "E0055",
"media": [],
"part_family": [],
"part_person": [
2051
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"gid": "E2164",
"media": [],
"part_family": [],
"part_person": [
2053
],
"place": 16,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1829-07-19",
"date_sdn": 2389288,
"descr": "Death of \u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"gid": "E2165",
"media": [],
"part_family": [],
"part_person": [
2053
],
"place": 750,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1930-05-20",
"date_sdn": 2426117,
"descr": "Birth of \u041c\u0435\u043b\u044c\u043d\u0438\u043a\u043e\u0432, Marylou",
"gid": "E0579",
"media": [],
"part_family": [],
"part_person": [
2055
],
"place": 78,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0580",
"media": [],
"part_family": [],
"part_person": [
2055
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1788",
"date_sdn": 2374114,
"descr": "Birth of \u041c\u043e\u0440\u043e\u0437\u043e\u0432, Mary Elizabeth",
"gid": "E0354",
"media": [],
"part_family": [],
"part_person": [
2056
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041d\u0438\u043a\u0438\u0442\u0438\u043d, Monica",
"gid": "E2337",
"media": [],
"part_family": [],
"part_person": [
2057
],
"place": 655,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u041d\u0438\u043a\u0438\u0442\u0438\u043d, Monica",
"gid": "E2338",
"media": [],
"part_family": [],
"part_person": [
2057
],
"place": 816,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1704-01-26",
"date_sdn": 2343458,
"descr": "Birth of \u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Maria Catharina",
"gid": "E2266",
"media": [],
"part_family": [],
"part_person": [
2059
],
"place": 278,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "1660",
"date_sdn": 2327363,
"descr": "Birth of \u041d\u043e\u0432\u0438\u043a\u043e\u0432, Sarah",
"gid": "E1133",
"media": [],
"part_family": [],
"part_person": [
2061
],
"place": 90,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041e\u0440\u043b\u043e\u0432, Margaret(?)",
"gid": "E0133",
"media": [],
"part_family": [],
"part_person": [
2063
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u041e\u0440\u043b\u043e\u0432, Margaret(?)",
"gid": "E0134",
"media": [],
"part_family": [],
"part_person": [
2063
],
"place": 298,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041f\u0430\u0432\u043b\u043e\u0432, Calvin",
"gid": "E0668",
"media": [],
"part_family": [],
"part_person": [
2064
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u041f\u0430\u0432\u043b\u043e\u0432, Thomas",
"gid": "E0667",
"media": [],
"part_family": [],
"part_person": [
2066
],
"place": 250,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1771",
"date_sdn": 2367905,
"descr": "Birth of \u041f\u043e\u043b\u044f\u043a\u043e\u0432, Eve",
"gid": "E0827",
"media": [],
"part_family": [],
"part_person": [
2067
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u041f\u043e\u043b\u044f\u043a\u043e\u0432, Eve",
"gid": "E0828",
"media": [],
"part_family": [],
"part_person": [
2067
],
"place": 525,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1080",
"date_sdn": 2115522,
"descr": "Birth of \u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"gid": "E0028",
"media": [],
"part_family": [],
"part_person": [
2068
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1168",
"date_sdn": 2147663,
"descr": "Death of \u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"gid": "E0029",
"media": [],
"part_family": [],
"part_person": [
2068
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[],
[],
[
{
"cita": [],
"date": "1645",
"date_sdn": 2321885,
"descr": "Birth of \u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"gid": "E2597",
"media": [],
"part_family": [],
"part_person": [
2072
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1699-03-02",
"date_sdn": 2341668,
"descr": "Death of \u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"gid": "E2598",
"media": [],
"part_family": [],
"part_person": [
2072
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1971-06-01",
"date_sdn": 2441104,
"descr": "Birth of \u0421\u0435\u0440\u0433\u0435\u0435\u0432, Adria Maria",
"gid": "E0108",
"media": [],
"part_family": [],
"part_person": [
2073
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0109",
"media": [],
"part_family": [],
"part_person": [
2073
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "1981-01-18",
"date_sdn": 2444623,
"descr": "Birth of \u0421\u0435\u0440\u0433\u0435\u0435\u0432, Jacqueline Denise",
"gid": "E0110",
"media": [],
"part_family": [],
"part_person": [
2075
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0111",
"media": [],
"part_family": [],
"part_person": [
2075
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1978-02-10",
"date_sdn": 2443550,
"descr": "Birth of \u0421\u0435\u0440\u0433\u0435\u0435\u0432, Jon Dennis",
"gid": "E0101",
"media": [],
"part_family": [],
"part_person": [
2076
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0102",
"media": [],
"part_family": [],
"part_person": [
2076
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1984-04-07",
"date_sdn": 2445798,
"descr": "Birth of \u0421\u0435\u0440\u0433\u0435\u0435\u0432, Joshua David",
"gid": "E0112",
"media": [],
"part_family": [],
"part_person": [
2077
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0113",
"media": [],
"part_family": [],
"part_person": [
2077
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1014",
"date_sdn": 2091416,
"descr": "Birth of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Eudo",
"gid": "E0017",
"media": [],
"part_family": [],
"part_person": [
2078
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1050",
"date_sdn": 2104565,
"descr": "Birth of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"gid": "E0022",
"media": [],
"part_family": [],
"part_person": [
2079
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1121",
"date_sdn": 2130497,
"descr": "Death of \u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"gid": "E0023",
"media": [],
"part_family": [],
"part_person": [
2079
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0315",
"media": [],
"part_family": [],
"part_person": [
2081
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0313",
"media": [],
"part_family": [],
"part_person": [
2082
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0314",
"media": [],
"part_family": [],
"part_person": [
2083
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[],
[
{
"cita": [],
"date": "after 1824",
"date_sdn": 2387262,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432",
"gid": "E0191",
"media": [],
"part_family": [],
"part_person": [
2085
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1818",
"date_sdn": 2385071,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, John P.",
"gid": "E0189",
"media": [],
"part_family": [],
"part_person": [
2086
],
"place": 1226,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1812-03-07",
"date_sdn": 2382945,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0184",
"media": [],
"part_family": [],
"part_person": [
2087
],
"place": 322,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1880-11-27",
"date_sdn": 2408047,
"descr": "Death of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0185",
"media": [],
"part_family": [],
"part_person": [
2087
],
"place": 1100,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1880-11-29",
"date_sdn": 2408049,
"descr": "Burial of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"gid": "E0186",
"media": [],
"part_family": [],
"part_person": [
2087
],
"place": 8,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1825-07-29",
"date_sdn": 2387837,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Sarah Jane",
"gid": "E0190",
"media": [],
"part_family": [],
"part_person": [
2088
],
"place": 1111,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1813-02-04",
"date_sdn": 2383279,
"descr": "Birth of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0181",
"media": [],
"part_family": [],
"part_person": [
2089
],
"place": 758,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1877-01-16",
"date_sdn": 2406636,
"descr": "Death of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0182",
"media": [],
"part_family": [],
"part_person": [
2089
],
"place": 553,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "about 1877-01-18",
"date_sdn": 2406638,
"descr": "Burial of \u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"gid": "E0183",
"media": [],
"part_family": [],
"part_person": [
2089
],
"place": 553,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "1864-01-27",
"date_sdn": 2401898,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1754",
"media": [],
"part_family": [],
"part_person": [
2090
],
"place": 893,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1903-11-27",
"date_sdn": 2416446,
"descr": "Death of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1755",
"media": [],
"part_family": [],
"part_person": [
2090
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1903-11-29",
"date_sdn": 2416448,
"descr": "Burial of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"gid": "E1756",
"media": [],
"part_family": [],
"part_person": [
2090
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, John",
"gid": "E2176",
"media": [],
"part_family": [],
"part_person": [
2091
],
"place": 528,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Mary Ellen",
"gid": "E2177",
"media": [],
"part_family": [],
"part_person": [
2092
],
"place": 528,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Miles?",
"gid": "E2215",
"media": [],
"part_family": [],
"part_person": [
2093
],
"place": 298,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Death of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Miles?",
"gid": "E2216",
"media": [],
"part_family": [],
"part_person": [
2093
],
"place": 298,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1827",
"date_sdn": 2388358,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2548",
"media": [],
"part_family": [],
"part_person": [
2094
],
"place": 363,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1872",
"date_sdn": 2404794,
"descr": "Death of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2549",
"media": [],
"part_family": [],
"part_person": [
2094
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"gid": "E2550",
"media": [],
"part_family": [],
"part_person": [
2094
],
"place": 656,
"text": "",
"type": "Burial"
}
],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Birth of \u0422\u0438\u0445\u043e\u043d\u043e\u0432, Myles",
"gid": "E2174",
"media": [],
"part_family": [],
"part_person": [
2095
],
"place": 528,
"text": "",
"type": "Birth"
}
],
[],
[],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0972",
"media": [],
"part_family": [],
"part_person": [
2100
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1657-02-00",
"date_sdn": 2326299,
"descr": "Birth of \u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"gid": "E2228",
"media": [],
"part_family": [],
"part_person": [
2101
],
"place": 135,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1747-09-03",
"date_sdn": 2359384,
"descr": "Death of \u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"gid": "E2229",
"media": [],
"part_family": [],
"part_person": [
2101
],
"place": 37,
"text": "",
"type": "Death"
}
],
[],
[],
[
{
"cita": [],
"date": "1928",
"date_sdn": 2425247,
"descr": "Death of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Louis",
"gid": "E0754",
"media": [],
"part_family": [],
"part_person": [
2104
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1883-08-09",
"date_sdn": 2409032,
"descr": "Birth of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"gid": "E0547",
"media": [],
"part_family": [],
"part_person": [
2106
],
"place": -1,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1973-12-08",
"date_sdn": 2442025,
"descr": "Death of \u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"gid": "E0548",
"media": [],
"part_family": [],
"part_person": [
2106
],
"place": 1159,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1325",
"date_sdn": 2205007,
"descr": "Birth of \u0427\u0435\u0440\u043d\u043e\u0432, Maud",
"gid": "E0051",
"media": [],
"part_family": [],
"part_person": [
2107
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1916-05-08",
"date_sdn": 2420992,
"descr": "Birth of \u0427\u0435\u0440\u043d\u044b\u0445, Mary Helen",
"gid": "E0623",
"media": [],
"part_family": [],
"part_person": [
2108
],
"place": 217,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Custom FTW5 tag to specify LIVING not specified in GEDCOM 5.5",
"gid": "E0624",
"media": [],
"part_family": [],
"part_person": [
2108
],
"place": -1,
"text": "",
"type": "LVG"
}
],
[
{
"cita": [],
"date": "1734-09-04",
"date_sdn": 2354637,
"descr": "Birth of \u0428\u0430\u0434\u0440\u0438\u043d, Mary",
"gid": "E1914",
"media": [],
"part_family": [],
"part_person": [
2109
],
"place": -1,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "about 1784-09-00",
"date_sdn": 2372897,
"descr": "Birth of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2679",
"media": [],
"part_family": [],
"part_person": [
2110
],
"place": 116,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1864-03-09",
"date_sdn": 2401940,
"descr": "Death of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2680",
"media": [],
"part_family": [],
"part_person": [
2110
],
"place": 888,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "1864-03-00",
"date_sdn": 2401932,
"descr": "Burial of \u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"gid": "E2681",
"media": [],
"part_family": [],
"part_person": [
2110
],
"place": 763,
"text": "",
"type": "Burial"
}
],
[],
[],
[
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u042f\u043a\u043e\u0432\u043b\u0435\u0432, George",
"gid": "E2087",
"media": [],
"part_family": [],
"part_person": [
2113
],
"place": 1108,
"text": "",
"type": "Burial"
}
],
[],
[
{
"cita": [],
"date": "204 (Islamic)",
"date_sdn": 2020376,
"descr": "",
"gid": "E3408",
"media": [],
"part_family": [],
"part_person": [
0,
2115
],
"place": -1,
"text": "",
"type": "Marriage"
},
{
"cita": [],
"date": "234 (Islamic)",
"date_sdn": 2031007,
"descr": "",
"gid": "E3410",
"media": [],
"part_family": [],
"part_person": [
2115
],
"place": -1,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "estimated about 1850",
"date_sdn": 2396759,
"descr": "",
"gid": "E3414",
"media": [],
"part_family": [],
"part_person": [
2116
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1941-02-16",
"date_sdn": 2430042,
"descr": "Death of \u4f0a\u85e4, Mary",
"gid": "E0234",
"media": [],
"part_family": [],
"part_person": [
2118
],
"place": -1,
"text": "",
"type": "Death"
}
],
[],
[
{
"cita": [],
"date": "1643-07-10",
"date_sdn": 2321344,
"descr": "Birth of \u5c71\u672c, Antoine Desaure Perronett",
"gid": "E2267",
"media": [],
"part_family": [],
"part_person": [
2120
],
"place": 1024,
"text": "",
"type": "Birth"
}
],
[
{
"cita": [],
"date": "1672-10-12",
"date_sdn": 2332031,
"descr": "Birth of \u5c71\u672c, Gabriel Gustav",
"gid": "E0713",
"media": [],
"part_family": [],
"part_person": [
2121
],
"place": 1132,
"text": "",
"type": "Birth"
}
],
[],
[
{
"cita": [],
"date": "about 1675",
"date_sdn": 2332842,
"descr": "Birth of \u658e\u85e4, Zariakius Cyriacus",
"gid": "E2260",
"media": [],
"part_family": [],
"part_person": [
2123
],
"place": 171,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "after 1748-07-01",
"date_sdn": 2359686,
"descr": "Death of \u658e\u85e4, Zariakius Cyriacus",
"gid": "E2261",
"media": [],
"part_family": [],
"part_person": [
2123
],
"place": 63,
"text": "",
"type": "Death"
}
],
[
{
"cita": [],
"date": "1802-06-15",
"date_sdn": 2379392,
"descr": "Birth of \u6e21\u8fba, Mary (Polly)",
"gid": "E2365",
"media": [],
"part_family": [],
"part_person": [
2124
],
"place": 558,
"text": "",
"type": "Birth"
},
{
"cita": [],
"date": "1869-01-25",
"date_sdn": 2403723,
"descr": "Death of \u6e21\u8fba, Mary (Polly)",
"gid": "E2366",
"media": [],
"part_family": [],
"part_person": [
2124
],
"place": 893,
"text": "",
"type": "Death"
},
{
"cita": [],
"date": "",
"date_sdn": 0,
"descr": "Burial of \u6e21\u8fba, Mary (Polly)",
"gid": "E2367",
"media": [],
"part_family": [],
"part_person": [
2124
],
"place": 379,
"text": "",
"type": "Burial"
}
],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_I_events_0.js');
