// This file is generated

I_names_0 = [
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0623\u062d\u0645\u062f",
"given": "\u0623\u062d\u0645\u062f",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0623\u0645 \u0643\u0644\u062b\u0648\u0645",
"given": "\u0623\u0645\u00a0\u0643\u0644\u062b\u0648\u0645",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0627\u0644\u0642\u0627\u0633\u0645",
"given": "\u0627\u0644\u0642\u0627\u0633\u0645",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u062e\u062f\u064a\u062c\u0629",
"given": "\u062e\u062f\u064a\u062c\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0631\u064a\u062d\u0627\u0646\u0629",
"given": "\u0631\u064a\u062d\u0627\u0646\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0635\u0627\u0644\u062d",
"given": "\u0635\u0627\u0644\u062d",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0639\u0627\u0626\u0634\u0629",
"given": "\u0639\u0627\u0626\u0634\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0639\u0628\u062f \u0627\u0644\u0644\u0647",
"given": "\u0639\u0628\u062f\u00a0\u0627\u0644\u0644\u0647",
"nick": "\u0627\u0644\u0637\u064a\u0628",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0639\u0628\u062f \u0627\u0644\u0644\u0647",
"given": "\u0639\u0628\u062f\u00a0\u0627\u0644\u0644\u0647",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": ", \u0645\u062d\u0645\u062f",
"given": "\u0645\u062d\u0645\u062f",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
""
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Abbott, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Abbott"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adams, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adams, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Minnie",
"given": "Minnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Adkins, Robert Sr.",
"given": "Robert Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Adkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Aguilar, Eleanor",
"given": "Eleanor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Aguilar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Aguilar, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Aguilar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alexander, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alexander"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Abigail",
"given": "Abigail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Enos",
"given": "Enos",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Gershom",
"given": "Gershom",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Joanna",
"given": "Joanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Job",
"given": "Job",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Jonathan",
"given": "Jonathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Lediah",
"given": "Lediah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Lydia",
"given": "Lydia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Rachel",
"given": "Rachel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Allen, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Allen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alonso, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alonso"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alonso, Laura",
"given": "Laura",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alonso"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alonso, Roisine",
"given": "Roisine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alonso"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Andrew David",
"given": "Andrew David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Cadwallader",
"given": "Cadwallader",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Col. Charles",
"given": "Col. Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Cynthia Diane",
"given": "Cynthia Diane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Douglas David",
"given": "Douglas David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Eliza",
"given": "Eliza",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Franklin",
"given": "Franklin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jack D.",
"given": "Jack D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jacob W.",
"given": "Jacob W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jacqueline",
"given": "Jacqueline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jeffery",
"given": "Jeffery",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Jeffrey",
"given": "Jeffrey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Marsha",
"given": "Marsha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Marshall",
"given": "Marshall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Matthew Vincent",
"given": "Matthew Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Michelle Lynn",
"given": "Michelle Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Richard",
"given": "Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Thomas C.",
"given": "Thomas C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, Wayne",
"given": "Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarado, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u00c1lvarez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u00c1lvarez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Alvarez, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Alvarez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Aaron B.",
"given": "Aaron B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Marion",
"given": "Marion",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, Samuel A.",
"given": "Samuel A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andersen, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Mary Molly",
"given": "Mary Molly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Rev. John",
"given": "Rev. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Anderson, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Anderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andrews, Harold",
"given": "Harold",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andrews"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Andrews, William Arthur",
"given": "William Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Andrews"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Armstrong, Linda",
"given": "Linda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Armstrong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Armstrong, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Armstrong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Armstrong, Teddy C.",
"given": "Teddy C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Armstrong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Arnold, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Arnold"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Austin, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Austin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Austin, Johannas",
"given": "Johannas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Austin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Baker, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Baker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Baldwin, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Baldwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Baldwin, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Baldwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Abigail",
"given": "Abigail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Ezekiel",
"given": "Ezekiel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Ida B.",
"given": "Ida B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Ida E.",
"given": "Ida E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Jasper",
"given": "Jasper",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, John DeKalb",
"given": "John DeKalb",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Katie E.",
"given": "Katie E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Lucy A.",
"given": "Lucy A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias",
"given": "Matthias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias Sr.",
"given": "Matthias Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Matthias, Jr.",
"given": "Matthias, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Maude Waldon",
"given": "Maude Waldon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Nathanial Green",
"given": "Nathanial Green",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Robert Lee",
"given": "Robert Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ball, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ball"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ballard, Judith Ellen",
"given": "Judith Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ballard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barber, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barber"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barker, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barnes, Ernestina",
"given": "Ernestina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barnes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barnett, Anna Gertrude",
"given": "Anna Gertrude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barnett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Barrett, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Barrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bass, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bass"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bates, John Allen",
"given": "John Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bates"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bates, Stephen Michael",
"given": "Stephen Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bates"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bates, Timothy Christian",
"given": "Timothy Christian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bates"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bates, William Robert",
"given": "William Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bates"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Catharina",
"given": "Anna Catharina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Elisabeth",
"given": "Anna Elisabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Anna Ottilia",
"given": "Anna Ottilia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Franciskus",
"given": "Johann Franciskus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Michael",
"given": "Johann Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Simon",
"given": "Johann Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Theobald",
"given": "Johann Theobald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Valentin",
"given": "Johann Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beaulieu, Johann Valentin",
"given": "Johann Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beaulieu"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Beck, Jack",
"given": "Jack",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Beck"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Becker",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Becker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9dard, Swanson",
"given": "Swanson",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9dard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, Adrian",
"given": "Adrian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, Amy Jo",
"given": "Amy Jo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, Donald",
"given": "Donald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, Linda Ellen",
"given": "Linda Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "B\u00e9langer, Pamela Ann",
"given": "Pamela Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"B\u00e9langer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bell, Brandy Nichole",
"given": "Brandy Nichole",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bell, Gary Richard",
"given": "Gary Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bell, William Austin",
"given": "William Austin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Col. David",
"given": "Col. David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Col. Joseph",
"given": "Col. Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, James Edwin",
"given": "James Edwin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Jason Spotswood",
"given": "Jason Spotswood",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Joseph Louis(Jr.)",
"given": "Joseph Louis(Jr.)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Joseph Louis(Sr.)",
"given": "Joseph Louis(Sr.)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Louise DeSoix",
"given": "Louise DeSoix",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Martha Ellen",
"given": "Martha Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Martha Ellen M.",
"given": "Martha Ellen M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Mary Frances",
"given": "Mary Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Robert Watkins",
"given": "Robert Watkins",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Samuel Sr.",
"given": "Samuel Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Thomas Stewart",
"given": "Thomas Stewart",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Benson, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Benson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bergeron, John Henry",
"given": "John Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bergeron"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bergeron, John W.",
"given": "John W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bergeron"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bernier, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bernier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Berry",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Berry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Berry, Honorah",
"given": "Honorah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Berry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bishop, Anna Barbara",
"given": "Anna Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bishop"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bishop, Quirinus",
"given": "Quirinus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bishop"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Black, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Black"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blair, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blair"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blais, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blais"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blake, Conrad",
"given": "Conrad",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blake"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blake, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blake"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blake, M. Susannah",
"given": "M. Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blake"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Bendicht",
"given": "Bendicht",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Catarina",
"given": "Catarina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Gerhard",
"given": "Gerhard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Hans(Johannes)",
"given": "Hans(Johannes)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Heinrich",
"given": "Heinrich",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, John Sr.",
"given": "John Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, John W.",
"given": "John W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, L. J.",
"given": "L. J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Lucinda Catherine",
"given": "Lucinda Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Malvina",
"given": "Malvina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Margareta",
"given": "Margareta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mary F.",
"given": "Mary F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Milton",
"given": "Milton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Paris",
"given": "Paris",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Rufus",
"given": "Rufus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Blanco, Stephen",
"given": "Stephen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Blanco"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bouchard, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bouchard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Agnes",
"given": "Agnes",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bishop Patrick",
"given": "Bishop Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Cynthia Louise",
"given": "Cynthia Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Ella",
"given": "Ella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Flannan",
"given": "Flannan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Fr. Daniel Gabriel",
"given": "Fr. Daniel Gabriel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Fr. Patrick",
"given": "Fr. Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Fr.Lawrence M.",
"given": "Fr.Lawrence M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Francis",
"given": "Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Garrett",
"given": "Garrett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Kyle Joseph",
"given": "Kyle Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Martin",
"given": "Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Martin",
"given": "Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Mary Cecilia",
"given": "Mary Cecilia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Mary Josephine",
"given": "Mary Josephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael J.",
"given": "Michael J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michael Shannon",
"given": "Michael Shannon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Michelle",
"given": "Michelle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Miread",
"given": "Miread",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Nancy A.",
"given": "Nancy A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Nora A.",
"given": "Nora A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Norene",
"given": "Norene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Prof. William Joseph",
"given": "Prof. William Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Roger Joseph",
"given": "Roger Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Rose Mary",
"given": "Rose Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Sean",
"given": "Sean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Sharon",
"given": "Sharon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Stephen Francis",
"given": "Stephen Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Steven Joseph",
"given": "Steven Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Sylvia B.",
"given": "Sylvia B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Thomas W.",
"given": "Thomas W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Tony",
"given": "Tony",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, Tracy",
"given": "Tracy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William Bernard",
"given": "William Bernard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William C.",
"given": "William C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William Donel",
"given": "William Donel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William J.",
"given": "William J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William J.",
"given": "William J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, William J.",
"given": "William J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boucher, woman",
"given": "woman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boucher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bowen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bowen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Capt.",
"given": "Capt.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Carmen Alberta",
"given": "Carmen Alberta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Charles Newton",
"given": "Charles Newton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Boyd, Lauretta Esther",
"given": "Lauretta Esther",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Boyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bradley, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bradley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Aidinn",
"given": "Aidinn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, CatherineJosephine",
"given": "CatherineJosephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Clara",
"given": "Clara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Enda",
"given": "Enda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Roisin",
"given": "Roisin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Shane",
"given": "Shane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brady, Tony",
"given": "Tony",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brady"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Briggs, Joyce Inez",
"given": "Joyce Inez",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Briggs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brock, Celeste Ellen",
"given": "Celeste Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brock"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brock, Lance Edward",
"given": "Lance Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brock"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brock, Stephen",
"given": "Stephen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brock"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Elizabeth\"Betty\"",
"given": "Elizabeth\"Betty\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Fielding",
"given": "Fielding",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Guillaume de",
"given": "Guillaume de",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Major Marquis II",
"given": "Major Marquis II",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Marquis I",
"given": "Marquis I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Marquis IV",
"given": "Marquis IV",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Miriam",
"given": "Miriam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, Spencer",
"given": "Spencer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brooks, William Waller",
"given": "William Waller",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brooks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Brown, ?????",
"given": "?????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Brown"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bryant, Kathryn Ladon",
"given": "Kathryn Ladon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bryant"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Buchanan, Elsbeth",
"given": "Elsbeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Buchanan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burgess, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burgess"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burke, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burke"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burns, Jonathan",
"given": "Jonathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burns"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Burns, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Burns"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, John Joseph",
"given": "John Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Martin",
"given": "Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Bush, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Bush"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Butler, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Butler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caldwell, Colm",
"given": "Colm",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caldwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caldwell, Fergl",
"given": "Fergl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caldwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caldwell, Niall",
"given": "Niall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caldwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caldwell, Paul",
"given": "Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caldwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cannon, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cannon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Caron, Mary E.",
"given": "Mary E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Caron"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carpenter, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carpenter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carr, Zelpha Josephine",
"given": "Zelpha Josephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carr"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Grace",
"given": "Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Jacob A.",
"given": "Jacob A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carroll, Matthias Sr.",
"given": "Matthias Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carroll"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Carter, Debra J.",
"given": "Debra J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Carter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Castillo, Margaretha",
"given": "Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Castillo"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Castro, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Castro"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Chambers, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Chambers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christensen, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Nathaniel",
"given": "Nathaniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Christiansen, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Christiansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Clark, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Clark"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cobb, Merrick",
"given": "Merrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cobb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cole, Eurydice",
"given": "Eurydice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cole, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Coleman",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Coleman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Coleman, Marilyn",
"given": "Marilyn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Coleman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Coleman, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Coleman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Collins, Loren",
"given": "Loren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Collins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Colon, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Colon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cook, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cook"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cooper, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cooper"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Copeland, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Copeland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "C\u00f4t\u00e9, Raymond Patrick",
"given": "Raymond Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"C\u00f4t\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Couture, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Couture"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cox, Robert C.",
"given": "Robert C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Craig, Mary J.",
"given": "Mary J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Craig"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Crawford, Lori",
"given": "Lori",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Crawford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Crawford, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Crawford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Alta M.",
"given": "Alta M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Evelyn",
"given": "Evelyn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Gertrude",
"given": "Gertrude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Loraine (Fanny)",
"given": "Loraine (Fanny)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Louise",
"given": "Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Ralph (Scotty)",
"given": "Ralph (Scotty)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cross, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Ann Lynn",
"given": "Ann Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Arthur Ray",
"given": "Arthur Ray",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Dale Eugene",
"given": "Dale Eugene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, David Wayne",
"given": "David Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Everett",
"given": "Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Gayle Joan",
"given": "Gayle Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Gerald Ray",
"given": "Gerald Ray",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Ivan Wayne",
"given": "Ivan Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, James Richard",
"given": "James Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Jane Elizabeth",
"given": "Jane Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Janis Marlene",
"given": "Janis Marlene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Jesse Christopher",
"given": "Jesse Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Jill Suzanne",
"given": "Jill Suzanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Joella Lynn",
"given": "Joella Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Joy Leanne",
"given": "Joy Leanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Joyce Marie",
"given": "Joyce Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Judy Denise",
"given": "Judy Denise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Karen Kay",
"given": "Karen Kay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Karla Sue",
"given": "Karla Sue",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Laura Joy",
"given": "Laura Joy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Linda Helen",
"given": "Linda Helen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Marsha Ann",
"given": "Marsha Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Melinda Lou",
"given": "Melinda Lou",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Patti Jo",
"given": "Patti Jo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Paul Eugene",
"given": "Paul Eugene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Susan Marguerite",
"given": "Susan Marguerite",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, Thomas Everett",
"given": "Thomas Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cruz, William Everett",
"given": "William Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cruz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cummings, Leonnah",
"given": "Leonnah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cummings"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, Peter Sr.",
"given": "Peter Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, Sally Sarah",
"given": "Sally Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Cunningham, William Philip",
"given": "William Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Cunningham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curry, Kenner S.",
"given": "Kenner S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curtis, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curtis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Curtis, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Curtis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "D\u0105browski, Letitia C.",
"given": "Letitia C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"D\u0105browski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Daniels",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Daniels"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Daniels, Phoebe",
"given": "Phoebe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Daniels"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davidson, Bernice",
"given": "Bernice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davidson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Jonathan",
"given": "Jonathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Davis, Sabra",
"given": "Sabra",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Davis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dawson",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dawson, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Day, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Day"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dean, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dean"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Delgado",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Delgado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Delgado, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Delgado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Delgado, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Delgado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Demers, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Demers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Demers, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Demers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dennis, Mary (Hannah?)",
"given": "Mary (Hannah?)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dennis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dennis, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dennis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Desjardins, J.",
"given": "J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Desjardins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Anne",
"given": "Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Clemence",
"given": "Clemence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Cuthbert",
"given": "Cuthbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Mary Polly",
"given": "Mary Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, Urselie",
"given": "Urselie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Diaz, William (Rev.)",
"given": "William (Rev.)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Diaz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "D\u00edez, William George",
"given": "William George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"D\u00edez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "D\u00edez, William George Jr.",
"given": "William George Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"D\u00edez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dixon, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dixon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Mahala",
"given": "Mahala",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Mary E.",
"given": "Mary E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dom\u00ednguez, Zorada",
"given": "Zorada",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dom\u00ednguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Alfred",
"given": "Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Arthur",
"given": "Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Edgar",
"given": "Edgar",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Eliza Jane",
"given": "Eliza Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frank",
"given": "Frank",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frederick",
"given": "Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frederick",
"given": "Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Frederick",
"given": "Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Hans Peter",
"given": "Hans Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John Jr.",
"given": "John Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, John Sr.",
"given": "John Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Johnathon",
"given": "Johnathon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Lucinda J.",
"given": "Lucinda J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Mary\"Polly\"",
"given": "Mary\"Polly\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Douglas, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Douglas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Doyle, Robert Gove",
"given": "Robert Gove",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Doyle"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dub\u00e9, Rose",
"given": "Rose",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dub\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Duncan",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Duncan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Duncan, Clare",
"given": "Clare",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Duncan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Duncan, Colin",
"given": "Colin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Duncan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Duncan, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Duncan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Duncan, Noella",
"given": "Noella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Duncan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Dunn, Margaret Mary?",
"given": "Margaret Mary?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Dunn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Edwards, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Edwards"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Elliott, Lodowick",
"given": "Lodowick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Elliott"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ellis, Margaret Steel",
"given": "Margaret Steel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ellis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Erickson, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Erickson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Estrada, Mary Claire",
"given": "Mary Claire",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Estrada"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, ?m.MaryJane",
"given": "?m.MaryJane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, Christian Anne",
"given": "Christian Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, Heather Lee",
"given": "Heather Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, James Patrick",
"given": "James Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, Michael Patrick",
"given": "Michael Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Evans, Patricia Kay",
"given": "Patricia Kay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Evans"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Anna Marie",
"given": "Anna Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Benjamin H.",
"given": "Benjamin H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Caroline",
"given": "Caroline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Catharine",
"given": "Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Cyrus Melville",
"given": "Cyrus Melville",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Elizabeth Ellen",
"given": "Elizabeth Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Eva",
"given": "Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Flora Alice",
"given": "Flora Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, George William",
"given": "George William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Magdalena",
"given": "Magdalena",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Miranda Keziah",
"given": "Miranda Keziah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Peter Simon",
"given": "Peter Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Simon",
"given": "Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Susanna",
"given": "Susanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Susanne Delilah",
"given": "Susanne Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Valentine",
"given": "Valentine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Farmer, Winfield Scott",
"given": "Winfield Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Farmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ferguson, Lord Samuel",
"given": "Lord Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ferguson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez El Fern\u00e1ndez, Avis III",
"given": "Avis",
"nick": "Av",
"note": "",
"suffix": "III",
"surnames": [
"Fernandez",
"Fern\u00e1ndez"
],
"title": "Dr.",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fernandez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fields, Bridget M.",
"given": "Bridget M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fields"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, B",
"given": "B",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, C",
"given": "C",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, D",
"given": "D",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, E",
"given": "E",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, F",
"given": "F",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, G",
"given": "G",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, H",
"given": "H",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, I",
"given": "I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, J",
"given": "J",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, K",
"given": "K",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, L",
"given": "L",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, M",
"given": "M",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, N",
"given": "N",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fillin, O",
"given": "O",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fillin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fisher, Bendichtli",
"given": "Bendichtli",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fisher"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fitzgerald, David Lee",
"given": "David Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fitzgerald"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Flores, Jamie Lee",
"given": "Jamie Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Flores"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Flowers, Mary A.",
"given": "Mary A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Flowers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Christopher Randall",
"given": "Christopher Randall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Gregory Scott",
"given": "Gregory Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Joan Louise",
"given": "Joan Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, John Morgan",
"given": "John Morgan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, John S.",
"given": "John S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Martha Frances \"Fannie\"",
"given": "Martha Frances \"Fannie\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Robert William",
"given": "Robert William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Floyd, Sarah (Sally)",
"given": "Sarah (Sally)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Floyd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Carl",
"given": "Carl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Lorinda Catherine",
"given": "Lorinda Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Phillip D.",
"given": "Phillip D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, Stephen Jacob",
"given": "Stephen Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ford, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ford"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fortin, Mathas",
"given": "Mathas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fortin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fortin, Matthias",
"given": "Matthias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fortin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Foster, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Foster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fournier, Peggy",
"given": "Peggy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fournier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Jacob, Sr.",
"given": "Jacob, Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Julia Colville",
"given": "Julia Colville",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Fox, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Fox"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Francis, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Francis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frank, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frank"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Johann Walter",
"given": "Johann Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Frazier, Maria Margaretha",
"given": "Maria Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Frazier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "French, Erin Jenny",
"given": "Erin Jenny",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"French"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "French, Jimmy Michael",
"given": "Jimmy Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"French"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "French, Kevin Wayne",
"given": "Kevin Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"French"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gagn\u00e9, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gagn\u00e9"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gagnon, Bettie Lou",
"given": "Bettie Lou",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gagnon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garc\u00eda, Maude",
"given": "Maude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garc\u00eda"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gardner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gardner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gardner, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gardner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gardner, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gardner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gardner, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gardner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Alecia \"Allie\" Clare",
"given": "Alecia \"Allie\" Clare",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Allison Renee",
"given": "Allison Renee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Amy Elizabeth",
"given": "Amy Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Anderson",
"given": "Anderson",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Andrew Joseph",
"given": "Andrew Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Anetta",
"given": "Anetta",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Anne Therese",
"given": "Anne Therese",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Antoinette",
"given": "Antoinette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Barbara Jo",
"given": "Barbara Jo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Barry Joseph",
"given": "Barry Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Bernadette",
"given": "Bernadette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Bernetha Ellen",
"given": "Bernetha Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Bertha P.",
"given": "Bertha P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Betty Jane",
"given": "Betty Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Cecile Elizabeth",
"given": "Cecile Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Cecilia",
"given": "Cecilia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Daniel Burton",
"given": "Daniel Burton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Daniel Patrick",
"given": "Daniel Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Daniel Webster",
"given": "Daniel Webster",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, David Walter",
"given": "David Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Emma A.",
"given": "Emma A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Eugene Stanley",
"given": "Eugene Stanley",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Eugene Stanley, Jr.",
"given": "Eugene Stanley, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Francis William",
"given": "Francis William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Gerard Stephen",
"given": "Gerard Stephen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Heather Jo",
"given": "Heather Jo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Helen Bernice",
"given": "Helen Bernice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Howard Lane",
"given": "Howard Lane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Iola Elizabeth Betty",
"given": "Iola Elizabeth Betty",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jane McClellan",
"given": "Jane McClellan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jason Richard",
"given": "Jason Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jennie S.",
"given": "Jennie S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Jesse V.",
"given": "Jesse V.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, John Joseph",
"given": "John Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, John Roger",
"given": "John Roger",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Kathryn Mary",
"given": "Kathryn Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Lewis",
"given": "Lewis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "Anderson",
"cita": [
2827
],
"date": "1875-04-01",
"fam_nick": "Beauregard",
"full": "Garner von Zieli\u0144ski, Lewis Anderson Sr",
"given": "Lewis Anderson",
"nick": "Big Louie",
"note": "",
"suffix": "Sr",
"surnames": [
"Garner",
"Zieli\u0144ski"
],
"title": "Dr.",
"type": "Birth Name"
},
{
"call": "",
"cita": [
2836
],
"date": "",
"fam_nick": "",
"full": "Garner, Louis",
"given": "Louis",
"nick": "",
"note": "<div>\n<i class=\"NoteType\">\nName Note\n</i>\n<div class=\"grampsstylednote\">\n<p>\nNames can notes, too. This is a note for the alternate name of Louse Garner for <a href=\"person.html?idx=671\">Lewis Anderson Garner</a>.\n</p>\n</div>\n</div>",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Also Known As"
},
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Louie",
"given": "Louie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Other Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Louella Marie",
"given": "Louella Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Margaret Ann",
"given": "Margaret Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Marguarite",
"given": "Marguarite",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Marie",
"given": "Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Mark Gerard",
"given": "Mark Gerard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Mary J.",
"given": "Mary J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Mary M.",
"given": "Mary M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Maude",
"given": "Maude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Megan Ann",
"given": "Megan Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Melissa Sue",
"given": "Melissa Sue",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Michael Christopher",
"given": "Michael Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Michael Stanley",
"given": "Michael Stanley",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Peter George",
"given": "Peter George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Phebe",
"given": "Phebe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Raymond E.",
"given": "Raymond E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Raymond Scott",
"given": "Raymond Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Raymond Webster",
"given": "Raymond Webster",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Rebecca Catharine",
"given": "Rebecca Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Regina Lynne",
"given": "Regina Lynne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Richard Eugene",
"given": "Richard Eugene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Rita Marie",
"given": "Rita Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Robert F.",
"given": "Robert F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Robert W.",
"given": "Robert W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Stephen Gerard",
"given": "Stephen Gerard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Thomas James",
"given": "Thomas James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Vanichia Elaine",
"given": "Vanichia Elaine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Victor",
"given": "Victor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Victoria Laine",
"given": "Victoria Laine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Walter E.",
"given": "Walter E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Carmen Eloise",
"given": "Carmen Eloise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Doris Mae",
"given": "Doris Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Keith William",
"given": "Keith William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Lloyd Willis",
"given": "Lloyd Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Terry Lee",
"given": "Terry Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, Wayne Allen",
"given": "Wayne Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, William Forest",
"given": "William Forest",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garrett, William Walker",
"given": "William Walker",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garrett"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garza, Jeffrey Adam Ramos",
"given": "Jeffrey Adam Ramos",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garza"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gauthier, Julius",
"given": "Julius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gauthier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "George, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"George"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Connie",
"given": "Connie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Elaine",
"given": "Elaine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Jennie",
"given": "Jennie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Joy",
"given": "Joy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Lori",
"given": "Lori",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Rosina M.",
"given": "Rosina M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Ruth",
"given": "Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibbs, Sharon",
"given": "Sharon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibbs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gibson, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gibson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gil, Nora",
"given": "Nora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gil"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gilbert, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gilbert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gill, Avery",
"given": "Avery",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gill, Lawrence",
"given": "Lawrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gill, Lawrence",
"given": "Lawrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gill, Linda",
"given": "Linda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gill, Lorie Ann",
"given": "Lorie Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Girard, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Girard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Glover, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Glover"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gomez, Culthbert",
"given": "Culthbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gomez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gomez, Jane Joane",
"given": "Jane Joane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gomez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonzales, Linda S.",
"given": "Linda S.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonzales"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonzales, Mark R.",
"given": "Mark R.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonzales"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonz\u00e1lez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonz\u00e1lez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonzalez, Eliza Jane",
"given": "Eliza Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonzalez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonz\u00e1lez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonz\u00e1lez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gonz\u00e1lez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gonz\u00e1lez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodman, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodwin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodwin, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Goodwin, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Goodwin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gordon, Heather Kathleen",
"given": "Heather Kathleen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gordon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gosselin, Andrea Lynn",
"given": "Andrea Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gosselin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gosselin, Craig Richard",
"given": "Craig Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gosselin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gosselin, David Martin",
"given": "David Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gosselin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gosselin, Joel Thomas",
"given": "Joel Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gosselin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gosselin, Martin Kelly",
"given": "Martin Kelly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gosselin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grabowski, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grabowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Graham, Steve",
"given": "Steve",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Graham"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grant, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grant"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Graves, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Graves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gray, Beatrix",
"given": "Beatrix",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Frances",
"given": "Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Randolph",
"given": "Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Green, Yelverton",
"given": "Yelverton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Green"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Greene, Marcy",
"given": "Marcy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Greene"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Greer, Mary Wein",
"given": "Mary Wein",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Greer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gregory, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gregory"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grenier, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grenier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Grenier, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Grenier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Griffith, Experience",
"given": "Experience",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Griffith"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gross",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guerrero, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guerrero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gutierrez, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gutierrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guti\u00e9rrez, Dorothy Jean",
"given": "Dorothy Jean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guti\u00e9rrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guti\u00e9rrez, Joan Arlene",
"given": "Joan Arlene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guti\u00e9rrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Gutierrez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Gutierrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guti\u00e9rrez, Virginia Elizabeth",
"given": "Virginia Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guti\u00e9rrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guti\u00e9rrez, Walter Harmon",
"given": "Walter Harmon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guti\u00e9rrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Guzman, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Guzman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hale, Gina Marie",
"given": "Gina Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hale"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hale, Jeffrey Brian",
"given": "Jeffrey Brian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hale"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hale, Joseph Brendan",
"given": "Joseph Brendan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hale"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hale, Lawrence Paul",
"given": "Lawrence Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hale"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hale, Michael Patrick",
"given": "Michael Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hale"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hall, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hall"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hamilton, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hamilton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hammond, Roy",
"given": "Roy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hammond"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Barry",
"given": "Barry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Irene",
"given": "Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Kevin",
"given": "Kevin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Monica",
"given": "Monica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Noel",
"given": "Noel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Nula",
"given": "Nula",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hansen, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hanson, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hardy, Jakob",
"given": "Jakob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hardy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harmon, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harmon"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harper, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harper"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Ella Mae",
"given": "Ella Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Lawrence",
"given": "Lawrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Mary Alice",
"given": "Mary Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Patricia Anne",
"given": "Patricia Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harris, Theresa Frances",
"given": "Theresa Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harrison, Benjamin Allen",
"given": "Benjamin Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harrison, Douglas Glenn",
"given": "Douglas Glenn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harrison, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harrison, Paul Allen",
"given": "Paul Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hart, Gerry",
"given": "Gerry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hart, Laura",
"given": "Laura",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hart, Lisa",
"given": "Lisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hart, Paul",
"given": "Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hart, Raymond",
"given": "Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harvey, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harvey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Harvey, Lydia",
"given": "Lydia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Harvey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Beckham",
"given": "Beckham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Ellen Marie",
"given": "Ellen Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Gail",
"given": "Gail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Gerald L.",
"given": "Gerald L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, James R.",
"given": "James R.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Janelle",
"given": "Janelle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Jean",
"given": "Jean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Jennifer Leigh",
"given": "Jennifer Leigh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, Richard W.",
"given": "Richard W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hawkins, William Melvin",
"given": "William Melvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hawkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hayes, LeAnn",
"given": "LeAnn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hayes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Haynes, David William Sigfred",
"given": "David William Sigfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Haynes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Haynes, Elizabeth Ellen",
"given": "Elizabeth Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Haynes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Haynes, Marc W.",
"given": "Marc W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Haynes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Haynes, Melany",
"given": "Melany",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Haynes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Haynes, Michael Walter",
"given": "Michael Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Haynes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "H\u00e9bert, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"H\u00e9bert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "H\u00e9bert, Ruth Ann",
"given": "Ruth Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"H\u00e9bert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Henderson, Cathy Sue",
"given": "Cathy Sue",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Henderson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Henry, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Henry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Henry, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Henry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hernandez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hernandez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hern\u00e1ndez, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hern\u00e1ndez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hern\u00e1ndez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hern\u00e1ndez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hicks, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hicks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Higgins, Charity",
"given": "Charity",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Higgins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hill",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hill, Jo Lynn",
"given": "Jo Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hill, Leigh Ann",
"given": "Leigh Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hill, Sean Michael",
"given": "Sean Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hill"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hines",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hines"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hodges, Comfort",
"given": "Comfort",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hodges"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hoffman, Fay",
"given": "Fay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hoffman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holland, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holloway, Gail",
"given": "Gail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holloway"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holloway, John(?)",
"given": "John(?)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holloway"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holloway, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holloway"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Holt, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Holt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hopkins, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hopkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hopkins, Mary Eve",
"given": "Mary Eve",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hopkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Houston, Ellender",
"given": "Ellender",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Houston"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howard, Juliana",
"given": "Juliana",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howard, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, JOHN",
"given": "JOHN",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, Marie",
"given": "Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Howell, Mary (Sarah)",
"given": "Mary (Sarah)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Howell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hubbard, Donna",
"given": "Donna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hubbard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hudson, Eugene Stanley",
"given": "Eugene Stanley",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hudson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hudson, Howard Lane",
"given": "Howard Lane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hudson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hudson, Howard Lane",
"given": "Howard Lane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hudson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Huff, Bertrama",
"given": "Bertrama",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Huff"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Huff, Isabel",
"given": "Isabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Huff"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Hunt, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Hunt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Iglesias, Kate",
"given": "Kate",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Iglesias"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ingram, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ingram"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jackson, Cora Ellen",
"given": "Cora Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jackson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jackson, Cora Ellen",
"given": "Cora Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jackson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jacobs, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jacobs"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh Jr.",
"given": "Hugh Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Hugh Sr.",
"given": "Hugh Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Molly",
"given": "Molly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Pamela",
"given": "Pamela",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Thomas Sr.",
"given": "Thomas Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, Walter Crockett",
"given": "Walter Crockett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "James, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"James"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, George Jr.",
"given": "George Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Isabella Belle",
"given": "Isabella Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Margaret Jane \"Maggie\"",
"given": "Margaret Jane \"Maggie\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Minnie",
"given": "Minnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jankowski, Willie",
"given": "Willie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jankowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jenkins, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jenkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jenkins, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jenkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jensen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jimenez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jimenez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Amanda E.",
"given": "Amanda E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Armand E.",
"given": "Armand E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Cornelius",
"given": "Cornelius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George H.",
"given": "George H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George Henry, III",
"given": "George Henry, III",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George Henry, Jr.",
"given": "George Henry, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, George, Sr.",
"given": "George, Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, James T.",
"given": "James T.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, John T. L.",
"given": "John T. L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lincoln F.",
"given": "Lincoln F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lucinda",
"given": "Lucinda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Lucinda Ellen",
"given": "Lucinda Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Mary C.",
"given": "Mary C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Mary C.",
"given": "Mary C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Nancy E.",
"given": "Nancy E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Nathan M.",
"given": "Nathan M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Philip",
"given": "Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Polly Mary",
"given": "Polly Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Richard? Cornelius",
"given": "Richard? Cornelius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Sarah M.",
"given": "Sarah M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jim\u00e9nez, Tolbert A.",
"given": "Tolbert A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jim\u00e9nez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johansen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johansen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnson, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnson, Richard F.",
"given": "Richard F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Johnston",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Johnston"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jones, Martha Elizabeth",
"given": "Martha Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jones"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Jordan, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Jordan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "J\u00f8rgensen, Jeffrey",
"given": "Jeffrey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"J\u00f8rgensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "J\u00f8rgensen, Maggie Leigh",
"given": "Maggie Leigh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"J\u00f8rgensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "J\u00f8rgensen, Molly Marie",
"given": "Molly Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"J\u00f8rgensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Joseph, Alfred",
"given": "Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Joseph"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kaczmarek, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kaczmarek"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kami\u0144ski",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kami\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kami\u0144ski, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kami\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Keller, ?????",
"given": "?????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Keller"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Keller, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Keller"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kelley, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kelley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kelly, Ashley Diane",
"given": "Ashley Diane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kelly"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kelly, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kelly"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kennedy, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kennedy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kim, Frank",
"given": "Frank",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kim"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "King, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"King"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Klein, Alma Katherine",
"given": "Alma Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Klein"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knight, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knight"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Ranulf",
"given": "Ranulf",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Knudsen, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Knudsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kowalski, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kowalski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kowalski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kowalski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kowalski, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kowalski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Koz\u0142owski, Margret",
"given": "Margret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Koz\u0142owski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Krawczyk, Douglas",
"given": "Douglas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Krawczyk"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Anna June",
"given": "Anna June",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Catherine Virginia",
"given": "Catherine Virginia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, John Francis\"Chick\"",
"given": "John Francis\"Chick\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Margaret Agnes\"Maudy\"",
"given": "Margaret Agnes\"Maudy\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Miles Joseph\"Dutch\"",
"given": "Miles Joseph\"Dutch\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Kristensen, Sarah \"Sr. Sabina\"",
"given": "Sarah \"Sr. Sabina\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Kristensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lachance, Helen",
"given": "Helen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lachance"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lachance, Helen",
"given": "Helen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lachance"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lambert, Marguerite",
"given": "Marguerite",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lambert"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Catherine M.",
"given": "Catherine M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Charles Doyle",
"given": "Charles Doyle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Charles M.",
"given": "Charles M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Eleanor (Nellie) Therese",
"given": "Eleanor (Nellie) Therese",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Eleanor Jean",
"given": "Eleanor Jean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Helen Margaret",
"given": "Helen Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, John Anthony",
"given": "John Anthony",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, John Chandler",
"given": "John Chandler",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Josephine Grace",
"given": "Josephine Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Kitty",
"given": "Kitty",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Mary A.",
"given": "Mary A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Maurice T.",
"given": "Maurice T.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Maurice, Jr.",
"given": "Maurice, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Michael Edward",
"given": "Michael Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Mollie",
"given": "Mollie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Rose Marie",
"given": "Rose Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Landry, Theresa A.",
"given": "Theresa A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Landry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Anthony David",
"given": "Anthony David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Donna Elizabeth",
"given": "Donna Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Joseph Edward",
"given": "Joseph Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Joseph Robert",
"given": "Joseph Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lane, Remo",
"given": "Remo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lane"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, Lucy aka Sarah",
"given": "Lucy aka Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, Sir Thomas",
"given": "Sir Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lapointe, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lapointe"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Larsen, Nelly",
"given": "Nelly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Larsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Larson, Christena Wiseman",
"given": "Christena Wiseman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Larson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lavoie, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lavoie"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawrence, Dorcas C.",
"given": "Dorcas C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawrence"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, Permelia",
"given": "Permelia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, Phoebe",
"given": "Phoebe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lawson, Willard",
"given": "Willard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lawson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Leclerc, Sesaria",
"given": "Sesaria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Leclerc"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Rev. John L.",
"given": "Rev. John L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lefebvre, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lefebvre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Leonard, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Leonard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Carl Tolbert",
"given": "Carl Tolbert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Dorothy Louise",
"given": "Dorothy Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Elinor Jane",
"given": "Elinor Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Emma Jane",
"given": "Emma Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Helen Belle",
"given": "Helen Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Ira Willis",
"given": "Ira Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Izora",
"given": "Izora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Laura Eloise",
"given": "Laura Eloise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Mary Alice",
"given": "Mary Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Ralph Raymond",
"given": "Ralph Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lessard, Susanna Marie",
"given": "Susanna Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lessard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Clarence",
"given": "Clarence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Elsie",
"given": "Elsie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Howard",
"given": "Howard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, James W.",
"given": "James W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Jennie",
"given": "Jennie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, John C.",
"given": "John C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Olive",
"given": "Olive",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00e9vesque, Wilma",
"given": "Wilma",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00e9vesque"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Carroll",
"given": "Carroll",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Everett",
"given": "Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Marvin",
"given": "Marvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Paul",
"given": "Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lewandowski, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lewandowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lindsey, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lindsey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Little, O. D.",
"given": "O. D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Little"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Logan, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Logan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Long, Elisa Ann",
"given": "Elisa Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Long"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00f3pez, Anna Elisabeth",
"given": "Anna Elisabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00f3pez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "L\u00f3pez, Hans Valentin",
"given": "Hans Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"L\u00f3pez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lopez, John Warren",
"given": "John Warren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lopez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lopez, Lee William",
"given": "Lee William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lopez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Love",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Love"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lucas, Christina",
"given": "Christina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lucas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lynch, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lynch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Lynch, Rhonda",
"given": "Rhonda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Lynch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mack, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mack"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Madsen, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Madsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maldonado, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maldonado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maldonado, Eunice",
"given": "Eunice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maldonado"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Malone, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Malone"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mann, Agnes",
"given": "Agnes",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mann"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Manning, Judith Ann",
"given": "Judith Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Manning"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Albert",
"given": "Albert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Alfred Franklin(Frank)",
"given": "Alfred Franklin(Frank)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Elizabeth Therese",
"given": "Elizabeth Therese",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Frances Coppage",
"given": "Frances Coppage",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Frank",
"given": "Frank",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Joseph William",
"given": "Joseph William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Lilla Estella",
"given": "Lilla Estella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Mary Anne",
"given": "Mary Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Moses Wallace",
"given": "Moses Wallace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Nancy H.",
"given": "Nancy H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Nellie",
"given": "Nellie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Noah, Jr.",
"given": "Noah, Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Thomas Willis",
"given": "Thomas Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Walter Matthew",
"given": "Walter Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Wilbur",
"given": "Wilbur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Willis",
"given": "Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mar\u00edn, Willis H.",
"given": "Willis H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mar\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Marsh, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Marsh"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Marshall, Kate Teel",
"given": "Kate Teel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Marshall"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martel, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martel, Luella Jacques",
"given": "Luella Jacques",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mart\u00edn",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mart\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mart\u00edn, Tyler William",
"given": "Tyler William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mart\u00edn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Martinez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Martinez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mart\u00ednez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mart\u00ednez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mason, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mason"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mason, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mason"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Massey, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Massey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Matthews, Mark John",
"given": "Mark John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Matthews"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Matthews, Nicholas Ian",
"given": "Nicholas Ian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Matthews"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maxwell, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maxwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Maxwell, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Maxwell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mazur, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mazur"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mazur, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mazur"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mcbride, Paul",
"given": "Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mcbride"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCarthy, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCarthy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCarthy, Valentine Thomas",
"given": "Valentine Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCarthy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCormick, Dean",
"given": "Dean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCormick"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Canice Oliver",
"given": "Canice Oliver",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Celine Bridget",
"given": "Celine Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Francis",
"given": "Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Francis",
"given": "Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Orla Sarah",
"given": "Orla Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Paula",
"given": "Paula",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "McCoy, Thomas Michael",
"given": "Thomas Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"McCoy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mcdaniel, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mcdaniel"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Medina, Wesley G.",
"given": "Wesley G.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Medina"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mendez, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mendez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mendoza, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mendoza"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Meyer, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Meyer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Meyer, P.D.",
"given": "P.D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Meyer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Michaud, Anna Eva",
"given": "Anna Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Michaud"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Michaud, Valentin",
"given": "Valentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Michaud"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Miles, Rebecca J.",
"given": "Rebecca J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Miles"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Miller, Anna Catherine",
"given": "Anna Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Miller"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mills, Isabella",
"given": "Isabella",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mills"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mitchell, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mitchell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Molina, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Molina"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Montgomery, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Montgomery"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moody, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moody"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moore, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moore"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morales, Penelope Margot",
"given": "Penelope Margot",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morales"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moran, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moran"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moran, Ann Delilah \"Tilley\"",
"given": "Ann Delilah \"Tilley\"",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moran"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Aaron",
"given": "Aaron",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Abigail Chapman",
"given": "Abigail Chapman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Absalom",
"given": "Absalom",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Christian",
"given": "Christian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Christian, I",
"given": "Christian, I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Cyrus W.",
"given": "Cyrus W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Darius",
"given": "Darius",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Delilah",
"given": "Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Delilah",
"given": "Delilah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Enoch",
"given": "Enoch",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Enoch T.",
"given": "Enoch T.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Esau",
"given": "Esau",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Flora E.",
"given": "Flora E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Green P.",
"given": "Green P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Herman",
"given": "Herman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Johann Christian II",
"given": "Johann Christian II",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Johann Henrich",
"given": "Johann Henrich",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Joseph McDowell",
"given": "Joseph McDowell",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Leah",
"given": "Leah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Lelia L.",
"given": "Lelia L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Lydia M.",
"given": "Lydia M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Maj. Christopher",
"given": "Maj. Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Martha A.",
"given": "Martha A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Mary H.",
"given": "Mary H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Minerva",
"given": "Minerva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Noah",
"given": "Noah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Phebe J.",
"given": "Phebe J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Rosan",
"given": "Rosan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Solon",
"given": "Solon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moreno, Thomas H.",
"given": "Thomas H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moreno"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morgan, Elisabeth Margaretha",
"given": "Elisabeth Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morgan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Adam",
"given": "Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Carlisle",
"given": "Carlisle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Cyrus",
"given": "Cyrus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Cyrus",
"given": "Cyrus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morris, Roland",
"given": "Roland",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morrison, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morrison"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mortensen, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mortensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mortensen, Maria Christine",
"given": "Maria Christine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mortensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mortensen, Robert Alan",
"given": "Robert Alan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mortensen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Morton, Gail Darlene",
"given": "Gail Darlene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Morton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Christy",
"given": "Christy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Florence",
"given": "Florence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Fred",
"given": "Fred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Mattie",
"given": "Mattie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Moss, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Moss"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mullins, Robert?",
"given": "Robert?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mullins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Alvah F.",
"given": "Alvah F.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Mu\u00f1oz, Don",
"given": "Don",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Mu\u00f1oz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Lulu",
"given": "Lulu",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Moses Romulus?",
"given": "Moses Romulus?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Shadrach M.",
"given": "Shadrach M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Munoz, Willis E.",
"given": "Willis E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Munoz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Murray, Nicholas",
"given": "Nicholas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Murray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Murray, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Murray"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Myers, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Myers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Myers, James Joseph Jr.",
"given": "James Joseph Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Myers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Myers, Nina Mae",
"given": "Nina Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Myers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nadeau, John Franklin",
"given": "John Franklin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nadeau"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Navarro, Grace",
"given": "Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Navarro"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Belle",
"given": "Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Helen M.",
"given": "Helen M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Neal, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Neal"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nelson, Arlene",
"given": "Arlene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nelson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Newman, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Newman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nguyen, Elizabeth Diane",
"given": "Elizabeth Diane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nguyen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nguyen, John Harry",
"given": "John Harry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nguyen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nguyen, Laurie Ann",
"given": "Laurie Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nguyen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nichols, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nichols"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Louise",
"given": "Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Margaret A.",
"given": "Margaret A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nielsen, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nielsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norman, Dorothy Louise",
"given": "Dorothy Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norris, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norris"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norton, Christina",
"given": "Christina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Norton, Dorothy",
"given": "Dorothy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Norton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nowak, John H.",
"given": "John H.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nowak"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Nunez, Barbara Ann",
"given": "Barbara Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Nunez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Obrien, Kieran Thomas",
"given": "Kieran Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Obrien"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Oliver, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Oliver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Oliver, Hans Michael",
"given": "Hans Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Oliver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Oliver, Harmonas I",
"given": "Harmonas I",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Oliver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Oliver, Harmonas II",
"given": "Harmonas II",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Oliver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Olson, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Olson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortega, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortega"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortiz, Don",
"given": "Don",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortiz, Raymond",
"given": "Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ortiz, Ted",
"given": "Ted",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ortiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Aaron Patrick",
"given": "Aaron Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Andrew Cole",
"given": "Andrew Cole",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Anita June",
"given": "Anita June",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Dwight Billington",
"given": "Dwight Billington",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Julia Marie",
"given": "Julia Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Madeline Kathleen",
"given": "Madeline Kathleen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Osborne, Paul Daniel",
"given": "Paul Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Osborne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ouellet, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ouellet"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Owens, Wilford",
"given": "Wilford",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Owens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Padilla, Otis Earl",
"given": "Otis Earl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Padilla"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Andrew Vincent",
"given": "Andrew Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Anna",
"given": "Anna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Belle",
"given": "Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Brandon Kelly",
"given": "Brandon Kelly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Clara Belle",
"given": "Clara Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Darvin Ray",
"given": "Darvin Ray",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, David Alan",
"given": "David Alan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Debra Dale",
"given": "Debra Dale",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Dwayne Alan",
"given": "Dwayne Alan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Edith (Dolly)",
"given": "Edith (Dolly)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Edith Mae",
"given": "Edith Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Eleanor Irene",
"given": "Eleanor Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Eleanor Maude",
"given": "Eleanor Maude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Elmer",
"given": "Elmer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Everett Glenn (Ezra)",
"given": "Everett Glenn (Ezra)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Ferne",
"given": "Ferne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Florence",
"given": "Florence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, George Kenneth (Red)",
"given": "George Kenneth (Red)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, John James",
"given": "John James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Kenneth Fritz",
"given": "Kenneth Fritz",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Marvin Ray",
"given": "Marvin Ray",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Matilda",
"given": "Matilda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Maude",
"given": "Maude",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mildred",
"given": "Mildred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mitchell Lee",
"given": "Mitchell Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Rebecca",
"given": "Rebecca",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Richard C.",
"given": "Richard C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Robert Francis",
"given": "Robert Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Ruth Ellen",
"given": "Ruth Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Sylvia Louise",
"given": "Sylvia Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Todd Christopher",
"given": "Todd Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Page, Vernett Gail",
"given": "Vernett Gail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Page"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Palmer, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Palmer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Betsy",
"given": "Betsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Capt.Jacob C.",
"given": "Capt.Jacob C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Eleanor",
"given": "Eleanor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Harry",
"given": "Harry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Henry Clay",
"given": "Henry Clay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Jacob G.",
"given": "Jacob G.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, John Sr.",
"given": "John Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Montgomery",
"given": "Montgomery",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Patsy",
"given": "Patsy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parent, Polly",
"given": "Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parent"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Park, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Park"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Park, Susannah",
"given": "Susannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Park"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parker, Frank R.",
"given": "Frank R.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parks, Cliff",
"given": "Cliff",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Parsons, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Parsons"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patrick, Melvin",
"given": "Melvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patrick"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patrick, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patrick"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patterson, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patterson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Patton, Adolph",
"given": "Adolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Patton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Alexander",
"given": "Alexander",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Fielding",
"given": "Fielding",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Jane Coppage",
"given": "Jane Coppage",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Leonard",
"given": "Leonard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Leonard?",
"given": "Leonard?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Lucretia",
"given": "Lucretia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Moses",
"given": "Moses",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Willis",
"given": "Willis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Payne, Winifred",
"given": "Winifred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Payne"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pearson, Eileen Ruth",
"given": "Eileen Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pearson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pedersen, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pedersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pelletier, Esiquio",
"given": "Esiquio",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pelletier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pelletier, Josephine",
"given": "Josephine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pelletier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pena, Julia",
"given": "Julia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pena"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "P\u00e9rez, Angela Gay",
"given": "Angela Gay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"P\u00e9rez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Perkins, Lydia",
"given": "Lydia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Perkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Perkins, Wilma Mae",
"given": "Wilma Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Perkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Perry, M.",
"given": "M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Perry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Person, The First",
"given": "The First",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Person"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Dorothy",
"given": "Dorothy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Eleanor",
"given": "Eleanor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Elissa Marie",
"given": "Elissa Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Frank O.",
"given": "Frank O.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, George Sr.",
"given": "George Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, John C.",
"given": "John C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Peters, Rose",
"given": "Rose",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Peters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Petersen, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Petersen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Phillips, Anita Irene",
"given": "Anita Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Phillips"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pierce, Joanne",
"given": "Joanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pierce"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, John Jr.",
"given": "John Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, Sir John",
"given": "Sir John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Piotrowski, Sir Michael",
"given": "Sir Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Piotrowski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pittman, June Christine",
"given": "June Christine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pittman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poirier, James A.",
"given": "James A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poirier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poirier, Janelle Marie",
"given": "Janelle Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poirier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poirier, Jeffrey Alan",
"given": "Jeffrey Alan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poirier"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poole, Dr. John",
"given": "Dr. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poole, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poole, Polly",
"given": "Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poole, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poole"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pope, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pope"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter, Mahala J.",
"given": "Mahala J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Porter, Rachel D.",
"given": "Rachel D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Porter"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulin",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulin"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulsen, Chelsea Dawn",
"given": "Chelsea Dawn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulsen, Cole Randall",
"given": "Cole Randall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulsen, Curtis Theobald",
"given": "Curtis Theobald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Poulsen, Randall Lee",
"given": "Randall Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Poulsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Powell, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Powell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Powers, Nancy Lou",
"given": "Nancy Lou",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Powers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Pratt, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Pratt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Price, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Price"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Quinn, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Quinn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Quinn, Abram",
"given": "Abram",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Quinn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Quinn, Elizabeth Marium",
"given": "Elizabeth Marium",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Quinn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramirez, Helen",
"given": "Helen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramirez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ram\u00edrez, John B.",
"given": "John B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ram\u00edrez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramos, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramos, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ramsey, Joan",
"given": "Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ramsey"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rasmussen, Marilyn Joan",
"given": "Marilyn Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rasmussen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Anastasia",
"given": "Anastasia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Brendan",
"given": "Brendan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Bridget Ann",
"given": "Bridget Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Bridgette",
"given": "Bridgette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Carmel",
"given": "Carmel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Carmel",
"given": "Carmel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Frances Lucille (Babe)",
"given": "Frances Lucille (Babe)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Francis Vincent",
"given": "Francis Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Hugh",
"given": "Hugh",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jamesy",
"given": "Jamesy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Jenny",
"given": "Jenny",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Joan",
"given": "Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, John Noel",
"given": "John Noel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Kate",
"given": "Kate",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Matthew",
"given": "Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Maureen",
"given": "Maureen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Minnie",
"given": "Minnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Norah",
"given": "Norah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Noreen",
"given": "Noreen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Owen",
"given": "Owen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peggy",
"given": "Peggy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Peter James?",
"given": "Peter James?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Rose",
"given": "Rose",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Terence",
"given": "Terence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Terrence",
"given": "Terrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Terrence (TyNed)",
"given": "Terrence (TyNed)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reed, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reed"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reese",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reese"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Jesse",
"given": "Jesse",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, Mathew",
"given": "Mathew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reeves, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reeves"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reid, Anna Catherina",
"given": "Anna Catherina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reid"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reid, Hans",
"given": "Hans",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reid"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reyes",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reyes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Col. John",
"given": "Col. John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Nicholas",
"given": "Nicholas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Reynolds, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Reynolds"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rhodes, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rhodes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rhodes, Donald E.",
"given": "Donald E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rhodes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rhodes, Mary Jane",
"given": "Mary Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rhodes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rhodes, William Jr.",
"given": "William Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rhodes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rhodes, William Sr.",
"given": "William Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rhodes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rice, Virginia Margaret",
"given": "Virginia Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rice"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Richard, Jeanne",
"given": "Jeanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Richard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Richards, Diana",
"given": "Diana",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Richards"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Riley, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Riley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rios, Agnes",
"given": "Agnes",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rios"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robbins, Merida Lorene",
"given": "Merida Lorene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robbins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robbins, Myrabel",
"given": "Myrabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robbins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robertson, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robertson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robinson, Albert Raymond",
"given": "Albert Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robinson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robinson, Clarence",
"given": "Clarence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robinson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robinson, Hugh Martin",
"given": "Hugh Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robinson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robinson, Luther",
"given": "Luther",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robinson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Robinson, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Robinson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodgers, Crystal Mae",
"given": "Crystal Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodgers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodgers, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodgers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodgers, Shawna Marie",
"given": "Shawna Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodgers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodr\u00edguez, Agatha",
"given": "Agatha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodr\u00edguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriguez, Helen M.",
"given": "Helen M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriguez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Alvin",
"given": "Alvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Barbara Ann",
"given": "Barbara Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Elizabeth Jane",
"given": "Elizabeth Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Maria Louisa",
"given": "Maria Louisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mariam",
"given": "Mariam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Michael Mordica",
"given": "Michael Mordica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Mordica",
"given": "Mordica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Oma",
"given": "Oma",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Richard",
"given": "Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, William Frederick",
"given": "William Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rodriquez, William M.",
"given": "William M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rodriquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rogers, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rogers"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Romero, Ernest",
"given": "Ernest",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Romero"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rose, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rose"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ross, Evelyn Almazon",
"given": "Evelyn Almazon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ross"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Roy, Prince Alfred",
"given": "Prince Alfred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Roy"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rubio, Dorcas",
"given": "Dorcas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rubio"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rubio, John III",
"given": "John III",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rubio"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Rubio, Winifred",
"given": "Winifred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Rubio"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ruiz, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ruiz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Beth Ann",
"given": "Beth Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Bruce Lynn",
"given": "Bruce Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Casey John",
"given": "Casey John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Janet Gail",
"given": "Janet Gail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Melvin Glen",
"given": "Melvin Glen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Nicholas Glen",
"given": "Nicholas Glen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Russell, Norman",
"given": "Norman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Russell"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ryan, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ryan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ryan, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ryan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Salazar, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Salazar"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "S\u00e1nchez, David Andrew",
"given": "David Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"S\u00e1nchez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanchez, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanchez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "S\u00e1nchez, Jonathan Andrew",
"given": "Jonathan Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"S\u00e1nchez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "S\u00e1nchez, Roxanne Marie",
"given": "Roxanne Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"S\u00e1nchez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanders, Henry",
"given": "Henry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanders, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, Jean",
"given": "Jean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, John Joe",
"given": "John Joe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, Johnnie",
"given": "Johnnie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, Liz",
"given": "Liz",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, Sean",
"given": "Sean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sandoval, Terry",
"given": "Terry",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sandoval"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Santiago, Mathias",
"given": "Mathias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Santiago"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Santos, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Santos"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sanz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sanz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Saunders, Ursula",
"given": "Ursula",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Saunders"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Savard, Honora",
"given": "Honora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Savard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Savard, Walter",
"given": "Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Savard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schmidt, Barbli",
"given": "Barbli",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schmidt"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schneider",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schneider"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schneider, Belle Irene",
"given": "Belle Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schneider"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schultz, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schultz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schultz, Rev.Isaac",
"given": "Rev.Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schultz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Schwartz, Helewisa",
"given": "Helewisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Schwartz"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Scott, Cheryl Lee",
"given": "Cheryl Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Scott"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Archibald",
"given": "Archibald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Caroline",
"given": "Caroline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Carrie",
"given": "Carrie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Dean",
"given": "Dean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Dot",
"given": "Dot",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Serrano, Reh Dawn",
"given": "Reh Dawn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Serrano"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sharp, ???",
"given": "???",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sharp"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Shelton, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Shelton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Silva, Mildred",
"given": "Mildred",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Silva"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simard, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simard, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simard"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simmons, Maria",
"given": "Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simmons"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Simpson, Geraldine Ann",
"given": "Geraldine Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Simpson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Smith, Anastasia?",
"given": "Anastasia?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Smith"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Snyder, Ann Louisa",
"given": "Ann Louisa",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Snyder"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Soto, Harriet",
"given": "Harriet",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Soto"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sparks, Catherine",
"given": "Catherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sparks"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Spencer, Ann",
"given": "Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Spencer"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "St-Pierre, Joe",
"given": "Joe",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"St-Pierre"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stanley, Barbara",
"given": "Barbara",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stanley"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Steele, Valentine",
"given": "Valentine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Steele"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stephens, Adam",
"given": "Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stephens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stevens, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stevens"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stevenson, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stevenson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stewart",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stewart"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stokes, Gabriel",
"given": "Gabriel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stokes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stokes, Liam Michael",
"given": "Liam Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stokes"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Stone, Alfred Wayne",
"given": "Alfred Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Stone"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Strickland, Col. Robert",
"given": "Col. Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Strickland"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Su\u00e1rez, Marie",
"given": "Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Su\u00e1rez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sullivan, Anna",
"given": "Anna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sullivan"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Sutton, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Sutton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Benjamin",
"given": "Benjamin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Joane",
"given": "Joane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Judith",
"given": "Judith",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Richard",
"given": "Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Swanson, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Swanson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Szyma\u0144ski, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Szyma\u0144ski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Taylor, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Taylor"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Taylor, Philip",
"given": "Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Taylor"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Taylor, Viola",
"given": "Viola",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Taylor"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Terry, J.",
"given": "J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Terry"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomas, Elder Thomas",
"given": "Elder Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomas, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thompson, Bridget",
"given": "Bridget",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thompson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomsen, new",
"given": "new",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomsen, new",
"given": "new",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thomsen, new",
"given": "new",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thomsen"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Arthur Otto",
"given": "Arthur Otto",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Dorothy Eleanor",
"given": "Dorothy Eleanor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, James Arthur",
"given": "James Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Philip",
"given": "Philip",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Phillip James",
"given": "Phillip James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Thornton, Romaine",
"given": "Romaine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Thornton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Benjamin Harrison",
"given": "Benjamin Harrison",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Cora Olive",
"given": "Cora Olive",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Flora Belle",
"given": "Flora Belle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, George W.",
"given": "George W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, George Walter",
"given": "George Walter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Hardy",
"given": "Hardy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Hodges",
"given": "Hodges",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Irene Frances",
"given": "Irene Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Jesse Elmer",
"given": "Jesse Elmer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, John M.",
"given": "John M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Lena Viola",
"given": "Lena Viola",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Louella Jane",
"given": "Louella Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Lucille",
"given": "Lucille",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Olive",
"given": "Olive",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Percy Haye",
"given": "Percy Haye",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Robert Arthur",
"given": "Robert Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, Wayne",
"given": "Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Todd, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Todd"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Torres",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Torres"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Townsend, Mark",
"given": "Mark",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Townsend"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Turner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Turner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Tyler, Mary A.",
"given": "Mary A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Tyler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Valdez",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Valdez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Vargas, Caroline Metzger",
"given": "Caroline Metzger",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Vargas"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Vaughn, Mary Meriwether",
"given": "Mary Meriwether",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Vaughn"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "V\u00e1zquez, April Lynn",
"given": "April Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"V\u00e1zquez"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wade, Joy A.",
"given": "Joy A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wade"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wagner, Martha Ann",
"given": "Martha Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wagner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walker, Andrew Vincent",
"given": "Andrew Vincent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walker, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walker, Sharon Lynette",
"given": "Sharon Lynette",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walker"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wallace, Abraham",
"given": "Abraham",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wallace"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walsh, Penelope",
"given": "Penelope",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walsh"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walters, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walters, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Walton, Theophania(Tiffany)",
"given": "Theophania(Tiffany)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Walton"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ward, Catherine Marie",
"given": "Catherine Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ward"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ward, David J.",
"given": "David J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ward"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Ward, Michael David",
"given": "Michael David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Ward"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Allen Carl",
"given": "Allen Carl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Amanda",
"given": "Amanda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Amber Lynne",
"given": "Amber Lynne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Andrea Susan",
"given": "Andrea Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Arthur Maurice",
"given": "Arthur Maurice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Belle Marie",
"given": "Belle Marie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Betty Louise",
"given": "Betty Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Beverly Ann",
"given": "Beverly Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. Andrew",
"given": "Capt. Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. Francis",
"given": "Capt. Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Capt. George",
"given": "Capt. George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Carl Thomas",
"given": "Carl Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Christopher",
"given": "Christopher",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Christopher Arthur",
"given": "Christopher Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Cindy Lynn",
"given": "Cindy Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Clayton James",
"given": "Clayton James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Curtis Andrew",
"given": "Curtis Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Daniel",
"given": "Daniel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Daniel Arthur",
"given": "Daniel Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Darin Kane",
"given": "Darin Kane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, David Brant",
"given": "David Brant",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, David Luther",
"given": "David Luther",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, David Warren",
"given": "David Warren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Deirdra Denise",
"given": "Deirdra Denise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Donald Louis",
"given": "Donald Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Dorcas",
"given": "Dorcas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Douglas Lowell",
"given": "Douglas Lowell",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eden",
"given": "Eden",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Edward Randolph",
"given": "Edward Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eliza Frances",
"given": "Eliza Frances",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Eunice",
"given": "Eunice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Ezra",
"given": "Ezra",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Fred Loren",
"given": "Fred Loren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, George Edward",
"given": "George Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Greenleaf",
"given": "Greenleaf",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Harold Lowell",
"given": "Harold Lowell",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Humphrey Martin",
"given": "Humphrey Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, James Andrew",
"given": "James Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, James Jeffrey",
"given": "James Jeffrey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Jeffrey George",
"given": "Jeffrey George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, JenniferMae(Ganoe)",
"given": "JenniferMae(Ganoe)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johanna",
"given": "Johanna",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John Allen",
"given": "John Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John Quincy Adams",
"given": "John Quincy Adams",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, John William",
"given": "John William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johnathan",
"given": "Johnathan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Johnathon",
"given": "Johnathon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Julia Angeline",
"given": "Julia Angeline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Laura Gail",
"given": "Laura Gail",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Lewis",
"given": "Lewis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Marcia Jane",
"given": "Marcia Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Margaret Ruth",
"given": "Margaret Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Martha Ellen",
"given": "Martha Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Martin B.",
"given": "Martin B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Martin Bogarte",
"given": "Martin Bogarte",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary Christine",
"given": "Mary Christine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Mary Grace Elizabeth",
"given": "Mary Grace Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Matthew Steven",
"given": "Matthew Steven",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Melissa Lee",
"given": "Melissa Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michael Douglas",
"given": "Michael Douglas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michael Edward",
"given": "Michael Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michael Louis",
"given": "Michael Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michael Warren",
"given": "Michael Warren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Michelle Lorraine",
"given": "Michelle Lorraine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Monica Jane",
"given": "Monica Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Nancy Elizabeth",
"given": "Nancy Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Nathaniel M.",
"given": "Nathaniel M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Nicole Lynn",
"given": "Nicole Lynn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Noah",
"given": "Noah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Noah Stuart",
"given": "Noah Stuart",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Piatt D.",
"given": "Piatt D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Randolph",
"given": "Randolph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Rev. Edmund",
"given": "Rev. Edmund",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Richard Kenneth",
"given": "Richard Kenneth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Robert Douglas",
"given": "Robert Douglas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Robert Eugene",
"given": "Robert Eugene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Robert Warren",
"given": "Robert Warren",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Samuel Harvey",
"given": "Samuel Harvey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sarah Maria",
"given": "Sarah Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sarah Suzanne",
"given": "Sarah Suzanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sheryl Ann",
"given": "Sheryl Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Shirley Kay",
"given": "Shirley Kay",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sir Francis",
"given": "Sir Francis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Stanley Louis",
"given": "Stanley Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Stephanie Sue",
"given": "Stephanie Sue",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Stephen Paul",
"given": "Stephen Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Stuart Bogarte",
"given": "Stuart Bogarte",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Sylvester",
"given": "Sylvester",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Thomas Frederick",
"given": "Thomas Frederick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, unnamed girl",
"given": "unnamed girl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Warren W.",
"given": "Warren W.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, Whitney Lianne",
"given": "Whitney Lianne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warner, William Waller",
"given": "William Waller",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warner"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Warren, Pansy L.",
"given": "Pansy L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Warren"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Washington, Pearline",
"given": "Pearline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Washington"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Cecil",
"given": "Cecil",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Cecil Glenn",
"given": "Cecil Glenn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Debby",
"given": "Debby",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Edith",
"given": "Edith",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Everett",
"given": "Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Lola",
"given": "Lola",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Nellie",
"given": "Nellie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, Randy",
"given": "Randy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Waters, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Waters"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Watkins, Bruce Edward",
"given": "Bruce Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Watkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Watkins, Laura Kathryn",
"given": "Laura Kathryn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Watkins"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Watson, Alvin E.",
"given": "Alvin E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Watson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Watson, Mary Grace",
"given": "Mary Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Watson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Watts, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Watts"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Weaver, Justin Matthew",
"given": "Justin Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Weaver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Weaver, Steven Matthew",
"given": "Steven Matthew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Weaver"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Alex",
"given": "Alex",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Alexander",
"given": "Alexander",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Andrew",
"given": "Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Anna Mabel",
"given": "Anna Mabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Charles Edward",
"given": "Charles Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Charles Leroy Boyd",
"given": "Charles Leroy Boyd",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Clarence",
"given": "Clarence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, David Festus",
"given": "David Festus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Elias",
"given": "Elias",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Ernest Arlington",
"given": "Ernest Arlington",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Frances Mae",
"given": "Frances Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Francis Irvin",
"given": "Francis Irvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Harry Noble",
"given": "Harry Noble",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Homer",
"given": "Homer",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James Lee",
"given": "James Lee",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James Leslie",
"given": "James Leslie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James Marshall",
"given": "James Marshall",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, James McPheeters",
"given": "James McPheeters",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Joan Lorinda",
"given": "Joan Lorinda",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, John David",
"given": "John David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, John McCrea",
"given": "John McCrea",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, John Raymond",
"given": "John Raymond",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Joseph LeRoy",
"given": "Joseph LeRoy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lawrence",
"given": "Lawrence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lewis I.",
"given": "Lewis I.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Livingstone Martin",
"given": "Livingstone Martin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lucinda E.",
"given": "Lucinda E.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Lucy Mabel",
"given": "Lucy Mabel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Luella Florence",
"given": "Luella Florence",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Margaret Margarite?",
"given": "Margaret Margarite?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Marilyn Jean",
"given": "Marilyn Jean",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Mary Ruth",
"given": "Mary Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Michael Christie",
"given": "Michael Christie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Nancy Lou",
"given": "Nancy Lou",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Newton Kitridge",
"given": "Newton Kitridge",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Noble A.",
"given": "Noble A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, R. Eaken",
"given": "R. Eaken",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Richard L.",
"given": "Richard L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Sallie",
"given": "Sallie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, Sarah Margarite",
"given": "Sarah Margarite",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, William Herman",
"given": "William Herman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webb, William John",
"given": "William John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webb"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webster, Conrad",
"given": "Conrad",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Webster, Johanne(John)",
"given": "Johanne(John)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Webster"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Annabelle Elaine",
"given": "Annabelle Elaine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Christopher Paul",
"given": "Christopher Paul",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Irwin Arthur",
"given": "Irwin Arthur",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Jeremy Quentin",
"given": "Jeremy Quentin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Lisa Dawn",
"given": "Lisa Dawn",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Madeleine Christine",
"given": "Madeleine Christine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Michael",
"given": "Michael",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Paul Allen",
"given": "Paul Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Rosalie Jane",
"given": "Rosalie Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Russell Eugene",
"given": "Russell Eugene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Welch, Shirley",
"given": "Shirley",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Welch"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wells, Alice",
"given": "Alice",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wells"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "West, Erin Kathleen",
"given": "Erin Kathleen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"West"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "West, Kevin Wayne",
"given": "Kevin Wayne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"West"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "West, Ronald David",
"given": "Ronald David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"West"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wheeler, Don",
"given": "Don",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wheeler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wheeler, Jacob Earl",
"given": "Jacob Earl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wheeler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wheeler, Jason Earl",
"given": "Jason Earl",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wheeler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wheeler, Lynnett Diane",
"given": "Lynnett Diane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wheeler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wheeler, Richard Max",
"given": "Richard Max",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wheeler"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "White",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"White"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Williams, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Williams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Williams, Thomas Jr.",
"given": "Thomas Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Williams"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Willis, Carissa Nicole",
"given": "Carissa Nicole",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Willis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Willis, Corey",
"given": "Corey",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Willis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Willis, Matea Elizabeth",
"given": "Matea Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Willis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Willis, Mattea Elizabeth",
"given": "Mattea Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Willis"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wilson, Douglas",
"given": "Douglas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wilson"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wise, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wise"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wi\u015bniewski, D.",
"given": "D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wi\u015bniewski"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Arnold",
"given": "Arnold",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Arnold Clark",
"given": "Arnold Clark",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Daniel Burton",
"given": "Daniel Burton",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Patricia",
"given": "Patricia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Richard",
"given": "Richard",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "W\u00f3jcik, Suzanne",
"given": "Suzanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"W\u00f3jcik"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wong",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wong, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wong"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wood, Peter",
"given": "Peter",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wood"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wood, Polly",
"given": "Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wood"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, Mary Polly",
"given": "Mary Polly",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Woods, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Woods"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wo\u017aniak, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wo\u017aniak"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Wright, Dr. Charles J.",
"given": "Dr. Charles J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Wright"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Yates, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Yates"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Young, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Young"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Zieli\u0144ski, Phoebe Emily",
"given": "Phoebe Emily",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Zieli\u0144ski"
],
"title": "",
"type": "Birth Name"
},
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Garner, Phoebe Emily",
"given": "Phoebe Emily",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Garner"
],
"title": "",
"type": "Married Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Zimmerman, Edith Irene",
"given": "Edith Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Zimmerman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "Zimmerman, Edith Irene",
"given": "Edith Irene",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"Zimmerman"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0391\u03bd\u03b1\u03b3\u03bd\u03c9\u03c3\u03c4\u03bf\u03c0\u03bf\u03cd\u03bb\u03bf\u03c5, \u0392\u03b5\u03bd\u03b5\u03c4\u03af\u03b1",
"given": "\u0392\u03b5\u03bd\u03b5\u03c4\u03af\u03b1",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0391\u03bd\u03b1\u03b3\u03bd\u03c9\u03c3\u03c4\u03bf\u03c0\u03bf\u03cd\u03bb\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u0391\u03b3\u03b1\u03bc\u03ad\u03bc\u03bd\u03c9\u03bd",
"given": "\u0391\u03b3\u03b1\u03bc\u03ad\u03bc\u03bd\u03c9\u03bd",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u0386\u03b3\u03b7\u03c2",
"given": "\u0386\u03b3\u03b7\u03c2",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u0399\u03ac\u03c3\u03c9\u03bd",
"given": "\u0399\u03ac\u03c3\u03c9\u03bd",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u039c\u03c5\u03c1\u03c3\u03af\u03bd\u03b7",
"given": "\u039c\u03c5\u03c1\u03c3\u03af\u03bd\u03b7",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u039d\u03ad\u03c3\u03c4\u03bf\u03c1\u03b1\u03c2",
"given": "\u039d\u03ad\u03c3\u03c4\u03bf\u03c1\u03b1\u03c2",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u039d\u03b5\u03c6\u03ad\u03bb\u03b7",
"given": "\u039d\u03b5\u03c6\u03ad\u03bb\u03b7",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5, \u038c\u03bc\u03b7\u03c1\u03bf\u03c2",
"given": "\u038c\u03bc\u03b7\u03c1\u03bf\u03c2",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0394\u03b5\u03bb\u03b7\u03c0\u03ad\u03c4\u03c1\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0399\u03c9\u03ac\u03bd\u03bd\u03bf\u03c5, \u0395\u03c0\u03b1\u03bc\u03b5\u03b9\u03bd\u03ce\u03bd\u03b4\u03b1\u03c2",
"given": "\u0395\u03c0\u03b1\u03bc\u03b5\u03b9\u03bd\u03ce\u03bd\u03b4\u03b1\u03c2",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0399\u03c9\u03ac\u03bd\u03bd\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0399\u03c9\u03ac\u03bd\u03bd\u03bf\u03c5, \u0395\u03c5\u03c4\u03ad\u03c1\u03c0\u03b7",
"given": "\u0395\u03c5\u03c4\u03ad\u03c1\u03c0\u03b7",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0399\u03c9\u03ac\u03bd\u03bd\u03bf\u03c5"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u039a\u03b1\u03bb\u03ad\u03c1\u03b3\u03b7, \u0399\u03bf\u03c5\u03bb\u03af\u03b1",
"given": "\u0399\u03bf\u03c5\u03bb\u03af\u03b1",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u039a\u03b1\u03bb\u03ad\u03c1\u03b3\u03b7"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Anna Margaretha",
"given": "Anna Margaretha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432, Johann Adam",
"given": "Johann Adam",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0430\u043d\u0434\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043b\u0435\u043a\u0441\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u043d\u0434\u0440\u0435\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u043d\u0434\u0440\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0410\u0444\u0430\u043d\u0430\u0441\u044c\u0435\u0432, Angie",
"given": "Angie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0410\u0444\u0430\u043d\u0430\u0441\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0430\u0440\u0430\u043d\u043e\u0432, Susan",
"given": "Susan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0430\u0440\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0432, Katherine",
"given": "Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Catharine",
"given": "Catharine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Jacob",
"given": "Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432, Johannas Jacob",
"given": "Johannas Jacob",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u043e\u0443\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0435\u043b\u044f\u0435\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0435\u043b\u044f\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u043e\u0433\u0434\u0430\u043d\u043e\u0432, Dr. Brent",
"given": "Dr. Brent",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u043e\u0433\u0434\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u043e\u0440\u0438\u0441\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u043e\u0440\u0438\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u0440\u044e\u0445\u0430\u043d\u043e\u0432, Violet Louise",
"given": "Violet Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u0440\u044e\u0445\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Annie",
"given": "Annie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Bettie",
"given": "Bettie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Harriet",
"given": "Harriet",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Herod",
"given": "Herod",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Janie",
"given": "Janie",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0411\u044b\u043a\u043e\u0432, Samuel",
"given": "Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0411\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u0430\u0441\u0438\u043b\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043b\u0430\u0441\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043b\u0430\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432, Eva",
"given": "Eva",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432, Rev. Samuel",
"given": "Rev. Samuel",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u0431\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0412\u043e\u0440\u043e\u043d\u043e\u0432, Katherine",
"given": "Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0412\u043e\u0440\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u0435\u0440\u0430\u0441\u0438\u043c\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u0435\u0440\u0430\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Ellen",
"given": "Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u043e\u043d\u0447\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u043e\u0440\u0431\u0443\u043d\u043e\u0432, Matt",
"given": "Matt",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u043e\u0440\u0431\u0443\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432, Anna Maria",
"given": "Anna Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0413\u0440\u0438\u0433\u043e\u0440\u044c\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u0432\u044b\u0434\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u0432\u044b\u0434\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Barbara Joanne",
"given": "Barbara Joanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Daniel James Ramos",
"given": "Daniel James Ramos",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Darrell Edwin",
"given": "Darrell Edwin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Earl William",
"given": "Earl William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Elaine Suzanne",
"given": "Elaine Suzanne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Kathryn Louise",
"given": "Kathryn Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Lucinda Elinor",
"given": "Lucinda Elinor",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u0430\u043d\u0438\u043b\u043e\u0432, Rebecca Kristine Ramos",
"given": "Rebecca Kristine Ramos",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u0430\u043d\u0438\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Alexander Carroll Sr.",
"given": "Alexander Carroll Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles",
"given": "Charles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Charles Sr.",
"given": "Charles Sr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Isaac",
"given": "Isaac",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, James",
"given": "James",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lazarus",
"given": "Lazarus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Lucy",
"given": "Lucy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Margaret Jane",
"given": "Margaret Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Moses Aaron",
"given": "Moses Aaron",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Nancy Ann",
"given": "Nancy Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, Travis",
"given": "Travis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432, William",
"given": "William",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0414\u043c\u0438\u0442\u0440\u0438\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0415\u0433\u043e\u0440\u043e\u0432, Dr. Charles J.",
"given": "Dr.  Charles J.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0415\u0433\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Annabell Gordon",
"given": "Annabell Gordon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Curtis Dale",
"given": "Curtis Dale",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, David",
"given": "David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Hannah",
"given": "Hannah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0416\u0443\u043a\u043e\u0432, Scott",
"given": "Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0416\u0443\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u0430\u0439\u0446\u0435\u0432, Ruth L.",
"given": "Ruth L.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u0430\u0439\u0446\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u0430\u0445\u0430\u0440\u043e\u0432, Margaret",
"given": "Margaret",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u0430\u0445\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Col. Joseph",
"given": "Col. Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Joseph Jr.",
"given": "Joseph Jr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u043b\u043e\u0431\u0438\u043d, Martha",
"given": "Martha",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u043b\u043e\u0431\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u043a\u043e\u0432, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u043a\u043e\u0432, Angeline",
"given": "Angeline",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u043a\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0417\u044b\u0440\u044f\u043d\u043e\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0417\u044b\u0440\u044f\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0418\u043b\u044c\u0438\u043d, Eric Scott",
"given": "Eric Scott",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0418\u043b\u044c\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0418\u043b\u044c\u0438\u043d, Gary",
"given": "Gary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0418\u043b\u044c\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0418\u043b\u044c\u0438\u043d, Timothy Ryan",
"given": "Timothy Ryan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0418\u043b\u044c\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0437\u0430\u043a\u043e\u0432, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0437\u0430\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432, Katherine",
"given": "Katherine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0437\u0430\u043d\u0446\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0440\u043f\u043e\u0432, Damian",
"given": "Damian",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0440\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0430\u0440\u043f\u043e\u0432, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0430\u0440\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432, ??",
"given": "??",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0438\u0440\u0438\u043b\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0438\u0441\u0435\u043b\u0435\u0432, Aaron D.",
"given": "Aaron D.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0438\u0441\u0435\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0438\u0441\u0435\u043b\u0435\u0432, Dennis John",
"given": "Dennis John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0438\u0441\u0435\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0438\u0441\u0435\u043b\u0435\u0432, Timothy Andrew",
"given": "Timothy Andrew",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0438\u0441\u0435\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u0432\u0430\u043b\u0435\u0432, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u0432\u0430\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u0437\u043b\u043e\u0432, Linda Mae",
"given": "Linda Mae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u0437\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u0437\u043b\u043e\u0432, Samuel C.",
"given": "Samuel C.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u0437\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u043b\u0435\u0441\u043d\u0438\u043a\u043e\u0432, Conrad",
"given": "Conrad",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u043b\u0435\u0441\u043d\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u043e\u043c\u0430\u0440\u043e\u0432, Jane",
"given": "Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u043e\u043c\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432, Hanora",
"given": "Hanora",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0443\u0437\u043d\u0435\u0446\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041a\u0443\u0437\u044c\u043c\u0438\u043d, Mary Anne",
"given": "Mary Anne",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041a\u0443\u0437\u044c\u043c\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u0430\u043b\u0435\u0442\u0438\u043d, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u0430\u043b\u0435\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u0435\u0431\u0435\u0434\u0435\u0432, Trustum",
"given": "Trustum",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u0435\u0431\u0435\u0434\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u043e\u0433\u0438\u043d\u043e\u0432, Guy",
"given": "Guy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u043e\u0433\u0438\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u043e\u043f\u0430\u0442\u0438\u043d, Carmen Diana",
"given": "Carmen Diana",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u043e\u043f\u0430\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u043e\u043f\u0430\u0442\u0438\u043d, Donna Elaine",
"given": "Donna Elaine",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u043e\u043f\u0430\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041b\u043e\u043f\u0430\u0442\u0438\u043d, Raymond A.",
"given": "Raymond A.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041b\u043e\u043f\u0430\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0430\u0440\u043e\u0432, Joseph",
"given": "Joseph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0430\u0440\u043e\u0432, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0430\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Christina",
"given": "Christina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Heather Michelle",
"given": "Heather Michelle",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Hyla Rae",
"given": "Hyla Rae",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Nancy",
"given": "Nancy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432, Rodney Herman",
"given": "Rodney Herman",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043a\u0441\u0438\u043c\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u043b\u044c\u0446\u0435\u0432, Joan",
"given": "Joan",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u043b\u044c\u0446\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u0440\u0442\u044b\u043d\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u0440\u0442\u044b\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0430\u0442\u0432\u0435\u0435\u0432, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0430\u0442\u0432\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0435\u0434\u0432\u0435\u0434\u0435\u0432, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0435\u0434\u0432\u0435\u0434\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u0435\u043b\u044c\u043d\u0438\u043a\u043e\u0432, Marylou",
"given": "Marylou",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u0435\u043b\u044c\u043d\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041c\u043e\u0440\u043e\u0437\u043e\u0432, Mary Elizabeth",
"given": "Mary Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041c\u043e\u0440\u043e\u0437\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u0438\u0442\u0438\u043d, Monica",
"given": "Monica",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u0438\u0442\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u0438\u0444\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u0438\u0444\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Maria Catharina",
"given": "Maria Catharina",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432, Veltin",
"given": "Veltin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u0438\u043a\u043e\u043b\u0430\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u043e\u0432\u0438\u043a\u043e\u0432, Sarah",
"given": "Sarah",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u043e\u0432\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041d\u043e\u0432\u0438\u043a\u043e\u0432, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041d\u043e\u0432\u0438\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041e\u0440\u043b\u043e\u0432, Margaret(?)",
"given": "Margaret(?)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041e\u0440\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u0430\u0432\u043b\u043e\u0432, Calvin",
"given": "Calvin",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u0430\u0432\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u0430\u0432\u043b\u043e\u0432, Reuben",
"given": "Reuben",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u0430\u0432\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u0430\u0432\u043b\u043e\u0432, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u0430\u0432\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u043b\u044f\u043a\u043e\u0432, Eve",
"given": "Eve",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u043b\u044f\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432, Ralph",
"given": "Ralph",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u043d\u043e\u043c\u0430\u0440\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u043f\u043e\u0432, ???????",
"given": "???????",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u041f\u043e\u0442\u044b\u043b\u0438\u0446\u0438\u043d, Edward",
"given": "Edward",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u041f\u043e\u0442\u044b\u043b\u0438\u0446\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0420\u043e\u043c\u0430\u043d\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0420\u043e\u043c\u0430\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u043c\u0435\u043d\u043e\u0432, Cathern",
"given": "Cathern",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u043c\u0435\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u0440\u0433\u0435\u0435\u0432, Adria Maria",
"given": "Adria Maria",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u0440\u0433\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u0440\u0433\u0435\u0435\u0432, Dennis",
"given": "Dennis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u0440\u0433\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u0440\u0433\u0435\u0435\u0432, Jacqueline Denise",
"given": "Jacqueline Denise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u0440\u0433\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u0440\u0433\u0435\u0435\u0432, Jon Dennis",
"given": "Jon Dennis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u0440\u0433\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u0435\u0440\u0433\u0435\u0435\u0432, Joshua David",
"given": "Joshua David",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u0435\u0440\u0433\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043c\u0438\u0440\u043d\u043e\u0432, Eudo",
"given": "Eudo",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043c\u0438\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043c\u0438\u0440\u043d\u043e\u0432, Ribald",
"given": "Ribald",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043c\u0438\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043e\u043a\u043e\u043b\u043e\u0432, Louise",
"given": "Louise",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043e\u043a\u043e\u043b\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043e\u0440\u043e\u043a\u0438\u043d, Candy",
"given": "Candy",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043e\u0440\u043e\u043a\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043e\u0440\u043e\u043a\u0438\u043d, Holly Ruth",
"given": "Holly Ruth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043e\u0440\u043e\u043a\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0421\u043e\u0440\u043e\u043a\u0438\u043d, Robert",
"given": "Robert",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0421\u043e\u0440\u043e\u043a\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0430\u0440\u0430\u0441\u043e\u0432, Simon",
"given": "Simon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0430\u0440\u0430\u0441\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, John P.",
"given": "John P.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Mary Ann",
"given": "Mary Ann",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Sarah Jane",
"given": "Sarah Jane",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432, Willoughby M.",
"given": "Willoughby M.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u043c\u043e\u0444\u0435\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Catherine Virginia",
"given": "Catherine Virginia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, John",
"given": "John",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Mary Ellen",
"given": "Mary Ellen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Miles?",
"given": "Miles?",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Moses",
"given": "Moses",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0422\u0438\u0445\u043e\u043d\u043e\u0432, Myles",
"given": "Myles",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0422\u0438\u0445\u043e\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432",
"given": "",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0435\u0434\u043e\u0440\u043e\u0432, Patrick",
"given": "Patrick",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0435\u0434\u043e\u0440\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432, Elizabeth",
"given": "Elizabeth",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u0438\u043b\u0438\u043f\u043f\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0424\u043e\u043c\u0438\u043d, Grace",
"given": "Grace",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0424\u043e\u043c\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0425\u0443\u0434\u043e\u043d\u043e\u0433\u043e\u0432, Patricia",
"given": "Patricia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0425\u0443\u0434\u043e\u043d\u043e\u0433\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Louis",
"given": "Louis",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Merritt",
"given": "Merritt",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043a\u0430\u0448\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043d\u043e\u0432, Maud",
"given": "Maud",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043d\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0427\u0435\u0440\u043d\u044b\u0445, Mary Helen",
"given": "Mary Helen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0427\u0435\u0440\u043d\u044b\u0445"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0428\u0430\u0434\u0440\u0438\u043d, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0428\u0430\u0434\u0440\u0438\u043d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0428\u0435\u0441\u0442\u0430\u043a\u043e\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u042f\u043a\u043e\u0432\u043b\u0435\u0432, Esther Faye",
"given": "Esther Faye",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u042f\u043a\u043e\u0432\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u042f\u043a\u043e\u0432\u043b\u0435\u0432, Everett",
"given": "Everett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u042f\u043a\u043e\u0432\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u042f\u043a\u043e\u0432\u043b\u0435\u0432, George",
"given": "George",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u042f\u043a\u043e\u0432\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u042f\u043a\u043e\u0432\u043b\u0435\u0432, Georgia",
"given": "Georgia",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u042f\u043a\u043e\u0432\u043b\u0435\u0432"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0627\u0644\u0641\u0636\u0644, \u0627\u0644\u0639\u0628\u0627\u0633\u0629",
"given": "\u0627\u0644\u0639\u0628\u0627\u0633\u0629",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0627\u0644\u0641\u0636\u0644"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u0e1a\u0e38\u0e0d, Foon",
"given": "Foon",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u0e1a\u0e38\u0e0d"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u4e2d\u6751, Thomas",
"given": "Thomas",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u4e2d\u6751"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u4f0a\u85e4, Mary",
"given": "Mary",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u4f0a\u85e4"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c0f\u6797, Mr.",
"given": "Mr.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c0f\u6797"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Antoine Desaure Perronett",
"given": "Antoine Desaure Perronett",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Gabriel Gustav",
"given": "Gabriel Gustav",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u5c71\u672c, Gabriel Gustave",
"given": "Gabriel Gustave",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u5c71\u672c"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u658e\u85e4, Zariakius Cyriacus",
"given": "Zariakius Cyriacus",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u658e\u85e4"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u6e21\u8fba, Mary (Polly)",
"given": "Mary (Polly)",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u6e21\u8fba"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u9234\u6728, Allen",
"given": "Allen",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u9234\u6728"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u9234\u6728, Earl Kieble",
"given": "Earl Kieble",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u9234\u6728"
],
"title": "",
"type": "Birth Name"
}
],
[
{
"call": "",
"cita": [],
"date": "",
"fam_nick": "",
"full": "\u9234\u6728, Robert B.",
"given": "Robert B.",
"nick": "",
"note": "",
"suffix": "",
"surnames": [
"\u9234\u6728"
],
"title": "",
"type": "Birth Name"
}
]
]
Dwr.ScriptLoaded('dwr_db_I_names_0.js');
