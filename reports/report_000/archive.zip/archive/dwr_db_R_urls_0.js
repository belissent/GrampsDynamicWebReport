// This file is generated

R_urls_0 = [
[
{
"descr": "",
"type": "Web Home",
"uri": "http://library.gramps-project.org"
}
],
[],
[
{
"descr": "",
"type": "Web Home",
"uri": "http://great-falls.org"
}
]
]
Dwr.ScriptLoaded('dwr_db_R_urls_0.js');
