// This file is generated

P_enclosed_by_0 = [
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 533
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 17
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 313
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 718
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 972
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 568
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 955
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1123
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1116
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 796
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 9
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 697
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 41
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1109
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 161
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 305
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 208
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 57
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 209
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 495
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 415
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 645
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 746
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 293
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 746
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 431
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 537
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 334
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 731
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 564
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 640
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 89
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1202
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 521
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 140
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 560
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 541
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 105
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 786
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1275
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 776
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1222
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 121
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1118
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 125
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1214
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1225
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 368
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 853
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 167
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 480
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 358
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 303
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1202
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 765
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 853
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 895
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1138
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 416
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 545
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 941
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 820
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 715
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 189
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1151
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 249
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 153
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 619
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 931
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 219
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 599
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 793
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 131
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 346
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 76
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 561
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 377
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1248
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 268
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 470
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1110
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 863
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 833
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 260
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 792
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 2
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 272
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 695
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 127
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1192
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 68
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1040
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 5
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 691
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 803
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1185
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1201
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 942
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 287
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 647
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 392
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 516
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 229
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 583
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 637
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 321
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 799
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 607
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 732
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 853
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 333
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 343
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1243
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 535
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 349
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 197
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 686
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 228
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 523
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1190
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 9
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1219
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 94
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 226
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 634
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1095
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 629
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1235
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 141
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 804
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1049
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 915
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 875
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 27
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1137
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 220
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 409
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 413
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 362
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 12
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 472
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 668
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 382
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 620
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 75
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1215
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 417
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 511
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 755
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1238
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 294
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1135
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 119
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 485
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 351
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 13
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 291
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 498
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 659
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 206
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 498
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 493
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 429
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1143
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 480
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 239
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 694
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1208
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 980
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 118
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 569
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 198
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 330
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 318
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 418
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 559
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1232
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 264
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 9
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 498
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 498
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 855
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 290
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 646
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 585
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 9
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 91
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1173
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 596
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 520
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 611
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1150
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 160
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 237
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 785
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 940
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 285
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1234
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 315
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 506
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 746
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 850
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 378
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1056
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 671
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 964
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1179
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 635
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 464
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 676
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 563
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 629
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 42
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 740
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 101
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 692
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 562
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 236
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 410
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 986
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1249
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 341
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 446
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 483
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 720
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1285
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 449
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 730
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 500
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 602
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 743
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 751
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 759
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 759
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 626
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 768
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 69
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1236
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 909
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 819
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 782
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1099
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 896
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 791
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 797
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1098
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 633
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 235
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1139
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 794
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 353
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1245
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 299
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 822
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 827
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 233
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 832
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 817
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 289
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 496
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 841
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 889
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 557
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1031
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 565
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 843
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 13
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 713
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 853
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 745
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1097
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 179
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 892
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 883
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 886
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 703
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 608
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1210
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 284
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1191
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 739
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 968
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 513
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 134
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 385
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 450
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 84
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 454
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 435
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 978
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 360
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 919
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 760
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1163
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 709
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 265
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 97
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 519
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 221
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 721
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 72
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1094
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 682
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1161
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 746
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 329
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 982
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 961
}
],
[],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 192
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 4
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1141
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1058
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1025
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 864
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 696
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 699
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1233
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1101
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1264
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 851
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 746
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 390
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 946
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 662
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 441
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 884
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1011
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 790
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 100
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1016
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1018
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1023
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 885
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1032
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 194
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 836
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1041
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1125
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1245
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 46
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 274
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1053
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 546
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 601
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1277
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 157
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 225
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1121
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1268
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 965
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1096
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 212
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 307
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 474
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1029
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 432
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 678
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 727
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 148
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 357
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 670
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1246
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1021
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 146
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1003
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 196
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 290
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 857
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1131
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 881
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 648
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 700
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 501
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 854
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 204
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1198
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 770
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1122
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1176
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 415
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1148
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1105
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1059
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 665
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 929
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 930
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 11
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1165
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 689
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 531
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1168
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1075
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 749
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1152
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1182
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 681
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1076
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 187
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1180
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1253
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 538
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 661
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1161
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 384
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1204
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 741
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1039
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 517
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 757
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 600
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 283
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 309
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 865
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 478
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1211
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 419
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 536
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 530
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 609
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1276
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 223
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 924
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 907
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 780
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1274
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 47
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 603
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1252
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1170
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1262
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 835
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 838
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1184
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 263
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 534
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 834
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1250
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 529
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 874
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 687
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1271
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 779
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1178
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1203
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1045
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 958
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 818
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 901
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 872
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1126
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 155
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 66
}
],
[
{
"date": "",
"date_sdn": 0,
"pdx": 1286
}
],
[],
[],
[],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_P_enclosed_by_0.js');
