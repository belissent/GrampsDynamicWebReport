// This file is generated

S_xgid = {
"S0000": 3,
"S0001": 0,
"S0002": 2,
"S0003": 1
}