// This file is generated

M_bks_0 = [
[
{
"bk_idx": 3,
"cita": [],
"note": "",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/1/2/b39fe1cfc1305ac4a21.png"
}
],
[],
[],
[],
[],
[],
[]
]
Dwr.ScriptLoaded('dwr_db_M_bks_0.js');
