// This file is generated

S_abbrev_0 = [
"",
"",
"WOTW",
"BR-GFC 1850"
]
Dwr.ScriptLoaded('dwr_db_S_abbrev_0.js');
