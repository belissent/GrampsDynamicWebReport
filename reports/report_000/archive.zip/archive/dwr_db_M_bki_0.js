// This file is generated

M_bki_0 = [
[
{
"bk_idx": 671,
"cita": [
2845,
2846,
2846
],
"note": "<div>\n<p>\n<b>Father's Age</b>: 25\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/1/2/b39fe1cfc1305ac4a21.png"
}
],
[
{
"bk_idx": 671,
"cita": [],
"note": "",
"rect": [
51,
19,
59,
33
],
"thumb": "thumb/g/m/238cgq939hg18ss5mg-51,19-59,33.png"
},
{
"bk_idx": 693,
"cita": [],
"note": "",
"rect": [
15,
27,
25,
43
],
"thumb": "thumb/g/m/238cgq939hg18ss5mg-15,27-25,43.png"
}
],
[
{
"bk_idx": 671,
"cita": [
2831,
2832,
2832
],
"note": "<div>\n<p>\n<b>Age</b>: 50\n</p>\n</div>",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/m/z/b1aufqv7h8r9nr4szm.png"
}
],
[],
[
{
"bk_idx": 1112,
"cita": [],
"note": "",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/h/d/y3argqwe088eqrttdh.png"
}
],
[
{
"bk_idx": 665,
"cita": [],
"note": "",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/x/9/f8jygqfl2pklsyh79x.png"
}
],
[
{
"bk_idx": 654,
"cita": [],
"note": "",
"rect": [
0,
0,
100,
100
],
"thumb": "thumb/e/h/78v2gqx2fknsyq3ohe.png"
}
]
]
Dwr.ScriptLoaded('dwr_db_M_bki_0.js');
