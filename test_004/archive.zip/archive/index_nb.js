// This file is generated

NBI=2090;
NBF=734;
NBS=0;
NBC=0;
NBM=0;
